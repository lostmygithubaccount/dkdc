# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""The Reinforcement Learning Base Estimator class."""

import os

from abc import ABC
from azureml.contrib.train.rl._rl_runconfig import ReinforcementLearningConfiguration, \
    HeadConfiguration, WorkerConfiguration
from azureml.train._estimator_helper import _get_arguments
from azureml.train._telemetry_logger import _TelemetryLogger as TelemetryLogger
from azureml._restclient.snapshots_client import SnapshotsClient
from azureml.core.experiment import Experiment
from azureml.exceptions import AzureMLException
from multiprocessing.dummy import Pool
import uuid
from azureml._base_sdk_common import _ClientSessionId
from azureml.core.conda_dependencies import CondaDependencies

from azureml.contrib.train.rl._rl_environment_helper import _setup_environment

from azureml.core._experiment_method import experiment_method


def _rl_estimator_submit_method(estimator, workspace, experiment_name, **kwargs):
    # TODO check if override params is something we want to support

    rl_run = estimator._submit(workspace, experiment_name)

    return rl_run


class _RLBaseEstimator(ABC):
    """Abstract base class for Reinforcement Learning estimators"""

    _worker_configuration = None
    _simulator_configuration = None
    _head_configuration = None
    _source_directory = None
    _estimator_config = None
    _rl_framework = None

    @experiment_method(submit_function=_rl_estimator_submit_method)
    def __init__(self,
                 source_directory,
                 *,
                 environment=None,
                 entry_script=None,
                 script_params=None,
                 compute_target=None,
                 use_gpu=False,
                 pip_packages=None,
                 conda_packages=None,
                 rl_framework=None,
                 worker_configuration=None,
                 simulator_configuration=None,
                 max_run_duration_seconds=None,
                 job_queue_timeout=None,
                 cluster_coordination_timeout_seconds=None):
        """Initialize properties common to all RL estimators.

        :param source_directory: The directory containing code or configuration for the estimator.
        :type source_directory: str
        TODO add documentation for all the parameters.
        """
        self._source_directory = source_directory if source_directory else "."
        self._compute_target = compute_target
        self._rl_framework = rl_framework

        if environment:
            self._environment = _setup_environment(base_env=environment, framework=self.framework,
                                                   use_gpu=use_gpu,
                                                   user_pip_packages=pip_packages,
                                                   user_conda_packages=conda_packages)
            self._user_provided_environment = True
            self._original_user_env = environment
        else:
            self._environment = _setup_environment(framework=self.framework, use_gpu=use_gpu,
                                                   user_conda_packages=conda_packages,
                                                   user_pip_packages=pip_packages)
            self._user_provided_environment = False

        self._entry_script = entry_script
        self._script_params = script_params

        self._job_queue_timeout_seconds = job_queue_timeout
        self._coordination_timeout = cluster_coordination_timeout_seconds
        self._max_run_duration_seconds = max_run_duration_seconds

        self._estimator_config = self._init_rl_config()

        self.head_configuration = self._get_head_configuration()

        self.worker_configuration = worker_configuration

        self._simulator_configuration = simulator_configuration

        self._logger = TelemetryLogger.get_telemetry_logger(__name__)

    @property
    def source_directory(self):
        """Return the path to the source directory.

        :return: The source directory path.
        :rtype: str
        """
        return self._source_directory

    @property
    def rl_config(self):
        """Return `ReinforcementLearningConfiguration` object for this estimator.

        :return: The run configuration.
        :rtype: azureml.contrib.train.rl.ReinforcementLearningConfiguration
        """
        return self._estimator_config

    @property
    def framework(self):
        return self._rl_framework

    @property
    def head_configuration(self):
        return self._head_configuration

    @head_configuration.setter
    def head_configuration(self, head_configuration):
        if isinstance(head_configuration, HeadConfiguration):
            self._head_configuration = head_configuration
            self.rl_config.head = self._head_configuration

    @property
    def worker_configuration(self):
        return self._worker_configuration

    @worker_configuration.setter
    def worker_configuration(self, worker_configuration):
        if isinstance(worker_configuration, WorkerConfiguration):
            self._worker_configuration = worker_configuration
            if not self._worker_configuration._is_environment_intialized():
                if self._user_provided_environment:
                    self._worker_configuration._initialize_custom_env(self._original_user_env)
                else:
                    self._worker_configuration._initialize_env_for_framework(self.framework)
            self.rl_config.workers = self._worker_configuration

    def _get_head_configuration(self):
        return HeadConfiguration(script=self._entry_script,
                                 arguments=_get_arguments(self._script_params),
                                 compute_target=self._compute_target,
                                 environment=self._environment)

    def _init_rl_config(self):

        # TODO initialize data references (data store)

        # TODO add list of supported framework versions and validate accordinginly

        return ReinforcementLearningConfiguration(framework=self.framework,
                                                  head_configuration=self.head_configuration,
                                                  worker_configuration=self.worker_configuration,
                                                  simulator_configuration=self._simulator_configuration,
                                                  max_run_duration_seconds=self._max_run_duration_seconds,
                                                  cluster_coordination_timeout_seconds=self._coordination_timeout,
                                                  queue_timeout_seconds=self._job_queue_timeout_seconds,
                                                  source_directory=self.source_directory)

    def _submit(self, workspace, experiment_name):

        telemetry_values = self._get_telemetry_values(self._submit)
        with TelemetryLogger.log_activity(self._logger,
                                          "train.rl.estimator.submit",
                                          custom_dimensions=telemetry_values) as activity_logger:
            try:
                self._init_head_snapshot(workspace, experiment_name)
                activity_logger.info("Submitting RL experiment through estimator...")
                experiment = Experiment(workspace, experiment_name)
                # TODO check if it's notebook and modify the runconfig appropriately
                self.rl_config._telemetry_values = telemetry_values
                experiment_run = experiment.submit(self.rl_config)
                activity_logger.info("Experiment was submitted. RunId=%s", experiment_run.id)
                return experiment_run
            except AzureMLException as e:
                raise e from None

    def _init_head_snapshot(self, workspace, experiment_name):
        snapshots_client = SnapshotsClient(workspace.service_context)
        thread_pool = Pool(1)
        snapshot_async = thread_pool.apply_async(
            snapshots_client.create_snapshot,
            (os.path.abspath(self._source_directory),))
        snapshot_id = snapshot_async.get()

        self.rl_config.head._snapshot_id = snapshot_id

    def _get_telemetry_values(self, func):
        try:
            telemetry_values = {}
            _azureml_supported_framework_packages = ("tensorflow", "ray")
            # client common...
            telemetry_values['amlClientType'] = 'azureml-sdk-train-rl'
            telemetry_values['amlClientFunction'] = func.__name__
            telemetry_values['amlClientModule'] = self.__class__.__module__
            telemetry_values['amlClientClass'] = self.__class__.__name__
            telemetry_values['amlClientRequestId'] = str(uuid.uuid4())
            telemetry_values['amlClientSessionId'] = _ClientSessionId
            telemetry_values['frameworkName'] = self.framework.name
            telemetry_values['frameworkVersion'] = self.framework.version

            # estimator related...
            telemetry_values['head-scriptName'] = self.head_configuration.script
            telemetry_values['head-useDocker'] = self.head_configuration.environment.docker.enabled
            telemetry_values['head-useCustomDockerImage'] = not (
                self.head_configuration.environment.docker.base_image.lower()
                .startswith('mcr.microsoft.com/azureml/base') or (
                    self.head_configuration.environment.docker.base_image_registry.address is not None and
                    self.head_configuration.environment.docker.base_image_registry.address
                    .startswith('viennaprivate.azurecr.io')))
            telemetry_values['head-addCondaOrPipPackage'] = \
                self.head_configuration.environment.python.conda_dependencies.serialize_to_string() != \
                CondaDependencies().serialize_to_string()
            telemetry_values['head-IsFrameworkPipPackageAdded'] = True \
                if len([p for p in self.head_configuration.environment.python.conda_dependencies.pip_packages if
                        p.lower().startswith(_azureml_supported_framework_packages)]) else False
            telemetry_values['head-IsFrameworkCondaPackageAdded'] = True \
                if len([p for p in self.head_configuration.environment.python.conda_dependencies.conda_packages if
                        p.lower().startswith(_azureml_supported_framework_packages)]) else False
            telemetry_values['head-incrementalBuild'] = self.head_configuration.environment.python. \
                _base_conda_environment is not None
            # TODO how to get whether customer dependencies were added from the new Environment object

            # TODO add data reference telemetry

            # TODO add workers telemetry

            # TODO add simulators telemetry
        except Exception:
            pass

        return telemetry_values
