# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

""" Reinforcement Learing framework base, and supported framework's classes"""

from abc import ABC, abstractmethod


class RLFramework(ABC):
    _version = None
    _name = None

    def __init__(self, version=None, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @property
    def version(self):
        return self._version

    @property
    def name(self):
        return self._name

    def __repr__(self):
        return '{}-{}'.format(self._name, self._version).lower()

    @abstractmethod
    def get_default_version(self):
        pass


class Ray(RLFramework):

    _DEFAULT_RAY_VERSION = "0.7.2"

    def __init__(self, version=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._version = version if version else self._DEFAULT_RAY_VERSION
        self._name = "Ray"

    def get_default_version(self):
        return self._DEFAULT_RAY_VERSION
