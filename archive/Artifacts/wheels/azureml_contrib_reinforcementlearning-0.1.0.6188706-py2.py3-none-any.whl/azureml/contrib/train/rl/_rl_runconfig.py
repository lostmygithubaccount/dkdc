# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import collections
import json

from azureml._base_sdk_common.abstract_run_config_element import _AbstractRunConfigElement
from azureml._base_sdk_common.field_info import _FieldInfo
from azureml.core._serialization_utils import _serialize_to_dict
from azureml.core.compute_target import AbstractComputeTarget
from azureml.core.compute import ComputeTarget

from azureml.exceptions import UserErrorException
from azureml.core.runconfig import EnvironmentDefinition, HistoryConfiguration
from azureml.core._experiment_method import experiment_method

from azureml.contrib.train.rl._rl_environment_helper import _setup_environment


def submit(rl_run_config, workspace, experiment_name, run_id=None):
    from azureml.core import Experiment
    from azureml._project.project import Project
    from azureml.contrib._rlservice import _commands
    from azureml._base_sdk_common.tracking import global_tracking_info_registry

    experiment = Experiment(workspace, experiment_name)
    project = Project(directory=rl_run_config._source_directory, experiment=experiment)

    run_config_copy = ReinforcementLearningConfiguration._get_run_config_object(rl_run_config._source_directory,
                                                                                rl_run_config)

    run = _commands.start_run(project, run_config_copy,
                              telemetry_values=rl_run_config._telemetry_values,
                              run_id=run_id)

    run.add_properties(global_tracking_info_registry.gather_all(rl_run_config._source_directory))

    return run


class _SimulatorConfiguration(_AbstractRunConfigElement):
    # TODO add definition
    def __init__(self):
        super(_SimulatorConfiguration, self).__init__()
        self._initialized = True


class WorkerConfiguration(_AbstractRunConfigElement):

    """ WorkerConfiguration is the class that holds all the necessary information for the workers to run"""

    _field_to_info_dict = collections.OrderedDict([
        ("_target", _FieldInfo(str, "The name of the compute target to use.", serialized_name="target")),
        ("node_count", _FieldInfo(int, "Number of compute nodes to run the job on.", serialized_name="nodecount")),
        ("environment", _FieldInfo(EnvironmentDefinition, "The environment definition.")),
        ("history", _FieldInfo(HistoryConfiguration, "History details."))
    ])

    def __init__(self, node_count, compute_target=None, environment=None, history=None, use_gpu=False,
                 pip_packages=None, conda_packages=None):

        """Initialize the WorkerConfiguration

        :param node_count: Number of worker nodes to be initialized, one worker will run per machine in the
            compute target.
        :type node_count: int
        :param compute_target: The compute target where the workers will run. This can either be an object or the
            the compute target's name.
        :type compute_target: azureml.core.compute_target.ComputeTarget or str
        :param environment: The environment definition for the workers. It includes
            PythonSection, DockerSection, and environment variables. Any environment option not directly
            exposed through other parameters to the WorkerConfiguration construction can be set using this
            parameter. If this parameter is specified, it will be used as a base upon which packages specified in
            ``pip_packages`` and ``conda_packages`` will be added.
        :type environment: azureml.core.Environment
        :param history: History configuration for the worker's run, this controls which logs folders will be monitored
        :type azureml.core.runconfig.HistoryConfiguration
        :param use_gpu: Prameter used to signal whether the default base image should have the packages for
            gpu added. This parameter is ignored if ``enviroment`` is set.
        :type is_gpu_enable: bool
        :param conda_packages: A list of strings representing conda packages to be added to the Python environment
            for the workers.
        :type conda_packages: list
        :param pip_packages: A list of strings representing pip packages to be added to the Python environment
            for the workers
        :type pip_packages: list
        """
        super(WorkerConfiguration, self).__init__()
        self.target = compute_target
        self.environment = environment
        self.history = history if history else HistoryConfiguration()
        # TODO add validators
        self.node_count = node_count
        self._use_gpu = use_gpu
        self._pip_packages = pip_packages
        self._conda_packages = conda_packages
        self._initialized = True

    @property
    def target(self):
        """Get target.

        Target refers to compute where the job is scheduled for execution.
        Available cloud compute targets can be found using the function
        :attr:`azureml.core.Workspace.compute_targets`

        :return: The target name
        :rtype: str
        """
        return self._target

    @target.setter
    def target(self, target):
        """Set target.

        :param target:
        :type target: str
        """
        if isinstance(target, (AbstractComputeTarget, ComputeTarget)):
            self._target = target.name
        elif isinstance(target, str):
            self._target = target

    def _is_environment_intialized(self):
        if self.environment:
            return True
        return False

    def _initialize_env_for_framework(self, framework):
        self.environment = _setup_environment(framework=framework, use_gpu=self._use_gpu,
                                              user_conda_packages=self._conda_packages,
                                              user_pip_packages=self._pip_packages)

    def _initialize_custom_env(self, head_environment):
        self.environment = _setup_environment(base_env=head_environment, framework=None,
                                              use_gpu=self._use_gpu,
                                              user_conda_packages=self._conda_packages,
                                              user_pip_packages=self._pip_packages)


class HeadConfiguration(_AbstractRunConfigElement):

    """ HeadConfiguration is the class that holds all the necessary information for the head to run"""

    _field_to_info_dict = collections.OrderedDict([
        ("script", _FieldInfo(str, "The relative path to the python script file. \
            The file path is relative to the source_directory.")),
        ("arguments", _FieldInfo(list, "The arguments to the script file.", list_element_type=str)),
        ("_target", _FieldInfo(str, "The name of the compute target to use.", serialized_name="target")),
        ("_snapshot_id", _FieldInfo(str, "The snapshot that contains the code that will be used for simulators run",
                                    serialized_name="snapshotid")),
        ("data_references", _FieldInfo(str, "All the data sources are made available to the run during execution \
            based on each configuration.")),
        ("environment", _FieldInfo(EnvironmentDefinition, "The environment definition.")),
        ("history", _FieldInfo(HistoryConfiguration, "History details."))
    ])

    def __init__(self, script=None, arguments=None, compute_target=None,
                 environment=None, history=None):
        super(HeadConfiguration, self).__init__()
        # TODO do we want to keep this default.
        self.script = script if script else "train.py"
        self.arguments = arguments if arguments else []
        self.target = compute_target
        self._snapshot_id = ""
        self.environment = environment if environment else EnvironmentDefinition()
        self.history = history if history else HistoryConfiguration()
        self._initialized = True

    @property
    def target(self):
        """Get target.

        Target refers to compute where the job is scheduled for execution.
        Available cloud compute targets can be found using the function
        :attr:`azureml.core.Workspace.compute_targets`

        :return: The target name
        :rtype: str
        """
        return self._target

    @target.setter
    def target(self, target):
        """Set target.

        :param target:
        :type target: str
        """
        if isinstance(target, (AbstractComputeTarget, ComputeTarget)):
            self._target = target.name
        elif isinstance(target, str):
            self._target = target

    @property
    def snapshot_id(self):
        return self._snapshot_id

    @snapshot_id.setter
    def snapshot_id(self, snapshot_id):
        self._snapshot_id = snapshot_id


class ReinforcementLearningConfiguration(_AbstractRunConfigElement):

    # TODO uncomment workers and simulators
    _field_to_info_dict = collections.OrderedDict([
        ("framework", _FieldInfo(str, "RL framework to use")),
        ("head", _FieldInfo(HeadConfiguration, "Configuration for the head's run")),
        ("workers", _FieldInfo(WorkerConfiguration, "Configuration for the workers' run")),
        # ("simulators", _FieldInfo(SimulatorConfiguration, "Configuration for the simulators' run")),
        ("max_run_duration_seconds", _FieldInfo(int, "Maximum allowed duration for the run",
                                                serialized_name="maxRunDurationSeconds")),
        ("queue_timeout_seconds", _FieldInfo(int,
                                             ('The maximum allowed time for the run to be queued'
                                              'before it\'s cancelled'),
                                             serialized_name="queueTimeoutSeconds")),
        ("cluster_coordination_timeout_seconds", _FieldInfo(int,
                                                            ('The maximum allowed time for nodes in a cluster'
                                                             'to be in running state before all clusters are'
                                                             'in running state.'),
                                                            serialized_name="clusterCoordinationTimeoutSeconds"))
    ])

    @experiment_method(submit_function=submit)
    def __init__(self, framework, head_configuration, worker_configuration, simulator_configuration,
                 max_run_duration_seconds, cluster_coordination_timeout_seconds, queue_timeout_seconds,
                 source_directory=None):
        super(ReinforcementLearningConfiguration, self).__init__()

        DEFAULT_RUN_DURATION = None   # TODO define defaults
        DEFAULT_COORDINATION_PERIOD = None
        DEFAULT_QUEUE_TIMEOUT = None

        self.framework = framework.name
        self._name = None
        self._path = None
        self._source_directory = source_directory
        self._telemetry_values = None
        self.head = head_configuration if head_configuration else HeadConfiguration()
        self.workers = worker_configuration
        self.simulators = simulator_configuration

        self.max_run_duration_seconds = max_run_duration_seconds if max_run_duration_seconds else DEFAULT_RUN_DURATION
        self.cluster_coordination_timeout_seconds = cluster_coordination_timeout_seconds \
            if cluster_coordination_timeout_seconds else DEFAULT_COORDINATION_PERIOD
        self.queue_timeout_seconds = queue_timeout_seconds if queue_timeout_seconds else DEFAULT_QUEUE_TIMEOUT
        self._iterable = None
        self._initialized = True

    def __repr__(self):
        """Return the string representation of the RunConfiguration object.

        :return: String representation of the RunConfiguration object
        :rtype: str
        """
        run_config_dict = _serialize_to_dict(self)
        return json.dumps(run_config_dict, indent=4)

    @staticmethod
    def _get_run_config_object(path, run_config):
        """Return run config object.

        :param path:
        :type path: str
        :param run_config:
        :type run_config: RunConfiguration
        :return: Returns the run configuration object
        :rtype: azureml.core.runconfig.RunConfiguration
        """
        if isinstance(run_config, str):
            # TODO: load ReinforcementLearingConfig from file
            pass
        elif isinstance(run_config, ReinforcementLearningConfiguration):
            # TODO: Deep copy of project and auth object too.
            import copy
            return copy.deepcopy(run_config)
        else:
            raise UserErrorException("Unsupported runconfig type {}."
                                     "run_config can be of str or "
                                     "azureml.contrib.train.rl.ReinforcementLearningConfiguration"
                                     "type.".format(type(run_config)))

    # TODO implement helper methods to load/save ReinforcementLearningConfigs from files.
