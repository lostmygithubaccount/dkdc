# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from os import path
from azureml.exceptions import TrainingException
import ruamel.yaml
import copy
from azureml.core.runconfig import EnvironmentDefinition
from azureml._base_sdk_common.utils import merge_list


def _add_packages_to_env(env, pip_packages, conda_packages):
    # TODO either add logic to check for conflicts here, or add it in the add methods in CondaDependencies
    if pip_packages:
        for pip_package in pip_packages:
            env.python.conda_dependencies.add_pip_package(pip_package)
    if conda_packages:
        for conda_package in conda_packages:
            env.python.conda_dependencies.add_conda_package(conda_package)
    env.python.user_managed_dependencies = False


def _setup_environment(framework, use_gpu, user_pip_packages, user_conda_packages, base_env=None):
    if not base_env:
        env = EnvironmentDefinition()
        is_custom_env = False
    else:
        env = copy.deepcopy(base_env)
        is_custom_env = True

    if is_custom_env:
        if user_pip_packages or user_conda_packages:
            _add_packages_to_env(env, user_pip_packages, user_conda_packages)
        else:
            env.python.user_managed_dependencies = True
    elif user_pip_packages or user_conda_packages:
        _load_env_defaults(env, use_gpu, framework)
        _add_packages_to_env(env, user_pip_packages, user_conda_packages)
    else:
        _load_framework_image(env, use_gpu, framework)
    return env


def _load_packages_from_file(source_directory, pip_requirements_file, base_requirements_list=None):

    from azureml.exceptions import UserErrorException
    if not base_requirements_list:
        base_requirements_list = {}
    full_packages_path = path.normpath(
        path.join(source_directory, pip_requirements_file))

    if not path.isfile(full_packages_path):
        raise UserErrorException("{} path doesn't exist. "
                                 "The packages file should be inside the project "
                                 "folder".format(full_packages_path))

    with open(full_packages_path) as in_file:
        requirements = in_file.read().splitlines()
        return merge_list(requirements, base_requirements_list)


def _load_conda_dependencies(source_directory=None, conda_dependencies_file=None, conda_dependencies_yaml=None,
                             base_package_list=None, base_conda_dependencies_list=None):

    """Helper method to load conda_dependencies into pip_packages and conda_packages list,
    can't handle conda_dependencies_file and _yaml at the same time. _file would take precendece.
    One of conda_depencencies_file or conda_dependencies_yaml must be set.
    :return: The pip_package list and the conda_package_list.
    :rtype: list, list"""
    from azureml.exceptions import UserErrorException
    from azureml.core.conda_dependencies import CondaDependencies

    if not base_package_list:
        base_package_list = {}

    if not base_conda_dependencies_list:
        base_conda_dependencies_list = {}

    if conda_dependencies_file:
        full_dependencies_path = path.normpath(
            path.join(source_directory, conda_dependencies_file))

        if not path.isfile(full_dependencies_path):
            raise UserErrorException("{} path doesn't exist. "
                                     "The dependencies file should be inside the project "
                                     "folder".format(full_dependencies_path))

        conda_dependencies = CondaDependencies(full_dependencies_path)
    elif conda_dependencies_yaml:
        conda_dependencies = CondaDependencies(_underlying_structure=conda_dependencies_yaml)

    if conda_dependencies.conda_packages:
        final_conda_dependencies = merge_list(conda_dependencies.conda_packages, base_conda_dependencies_list)
    else:
        final_conda_dependencies = base_conda_dependencies_list

    if conda_dependencies.pip_packages:
        final_pip_packages = merge_list(conda_dependencies.pip_packages, base_package_list)
    else:
        final_pip_packages = base_package_list

    return final_conda_dependencies, final_pip_packages


def _load_env_defaults(target_env, use_gpu, framework):

    _SCENARIO_FILE_NOT_FOUND_ERROR = 'Scenario file for {name}:{version} not found.'

    if use_gpu:
        image_type = "gpu"
    else:
        image_type = "cpu"
    scenario_filename = '{}-{}.yml'.format(repr(framework),
                                           image_type)
    scenario_path = path.join(path.dirname(__file__), "scenarios", scenario_filename)

    if not path.isfile(scenario_path):
        raise TrainingException((_SCENARIO_FILE_NOT_FOUND_ERROR).
                                format(name=framework._name, version=framework._version))

    with open(scenario_path, "r") as input:
        scenario = ruamel.yaml.round_trip_load(input)
        base_image = scenario.get('baseImage', None)
        dependencies = scenario.get('inlineCondaDependencies', None)

        framework_conda_packages, framework_pip_packages = \
            _load_conda_dependencies(conda_dependencies_yaml=dependencies)

        _add_packages_to_env(target_env, framework_pip_packages, framework_conda_packages)

        target_env.docker.base_image = base_image
        target_env.docker.enabled = True


def _load_framework_image(target_env, use_gpu, framework):

    if use_gpu:
        image_type = "gpu"
    else:
        image_type = "cpu"
    base_image = "viennaprivate.azurecr.io/{0}:{1}-{2}".format(framework.name.lower(),
                                                               framework.version, image_type)
    target_env.docker.base_image = base_image
    target_env.docker.enabled = True
    target_env.python.user_managed_dependencies = True
