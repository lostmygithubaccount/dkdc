# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
""" Make REST calls to the Report service. """
from azureml._restclient.experiment_client import ExperimentClient


class ReportClient(ExperimentClient):
    """
    Report APIs

    :param host: The base path for the server to call.
    :type host: str
    :param auth: Client authentication
    :type auth: azureml.core.authentication.AbstractAuthentication
    :param subscription_id:
    :type subscription_id: str
    :param resource_group_name:
    :type resource_group_name: str
    :param workspace_name:
    :type workspace_name: str
    :param experiment_name:
    :type experiment_name: str
    """

    def get_relevant_runs(self, report_id):
        """ Apply filters from a report to runs. """
        return self._execute_with_experiment_arguments(
            self._client.reports.get_relevant_runs_by_id, report_id=report_id)
