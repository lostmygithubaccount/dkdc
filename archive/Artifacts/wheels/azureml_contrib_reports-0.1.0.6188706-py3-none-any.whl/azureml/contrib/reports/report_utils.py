# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

""" Helpers for Reports """
from azureml.contrib.reports import constants
import logging
module_logger = logging.getLogger(__name__)


def clean_dict(to_clean):
    """ Mutates by removing unneeded fields from a combined dictionary. """
    to_remove = constants.FIELDS_TO_REMOVE
    cleaned = {k: v for k, v in to_clean.items() if k not in to_remove}
    removed = to_clean.keys() - cleaned.keys()
    if len(removed) > 0:
        module_logger.debug("Removed {removed} from {to_clean}.".format(
            removed=removed, to_clean=to_clean))
    return cleaned


def rename_keys(list_of_dicts, old_key, new_key):
    """ Mutates each dict to rename key with the given prefix. """
    for to_rename in list_of_dicts:
        if to_rename.get(old_key, None) is not None:
            to_rename[new_key] = to_rename.pop(old_key)
            module_logger.debug("Renamed key from {old_key} to {new_key} in {to_rename}.".format(
                old_key=old_key, new_key=new_key, to_rename=to_rename))


def rename_keys_with_prefix(list_of_dicts, prefix):
    """ Mutates each dict to rename key with the given prefix. """
    for to_prefix in list_of_dicts:
        for k in list(to_prefix):  # prevents mutating while iterating
            to_prefix[prefix + k] = to_prefix.pop(k)
            module_logger.debug("Added the prefix {prefix} to {old_key} in {to_rename}.".format(
                prefix=prefix, old_key=k, to_rename=to_prefix))


def inner_join(run_dict, list_of_dicts, key1, key2):
    """ Join the two lists of dicts on the given keys. """
    for d2 in list_of_dicts:
        if key1 in run_dict and key2 in d2 and run_dict[key1] == d2[key2]:
            run_dict.update(d2)
            module_logger.debug("Joined {d1} and {d2} by shared key {key1} and {key2} respectively.".format(
                d1=run_dict, d2=d2, key1=key1, key2=key2))
