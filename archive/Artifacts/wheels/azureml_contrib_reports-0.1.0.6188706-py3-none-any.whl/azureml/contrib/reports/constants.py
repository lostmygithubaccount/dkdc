# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

""" Constants for Reports """
METRICS_PREFIX = "Metrics."
ARTIFACT_PREFIX = "Artifact."
RUN_PREFIX = "Run."
METRICS_RUN_ID = "{}run_id".format(METRICS_PREFIX)
ARTIFACT_RUN_ID = "{}container".format(ARTIFACT_PREFIX)
RUN_RUN_ID = "{}run_id".format(RUN_PREFIX)

ARTIFACT_ID = "{}artifact_id".format(ARTIFACT_PREFIX)
ARTIFACT_ETAG = "{}etag".format(ARTIFACT_PREFIX)
METRIC_ID = "{}metric_id".format(METRICS_PREFIX)
METRIC_DESCRIPTION = "{}description".format(METRICS_PREFIX)
METRIC_LABEL = "{}label".format(METRICS_PREFIX)
METRIC_TYPE = "{}metric_type".format(METRICS_PREFIX)
METRIC_NUM_CELLS = "{}num_cells".format(METRICS_PREFIX)
METRIC_SCHEMA = "{}schema".format(METRICS_PREFIX)
RUN_NAME = "{}Name".format(RUN_PREFIX)
RUN_PROPERTIES = "{}properties".format(RUN_PREFIX)
RUN_TAGS = "{}tags".format(RUN_PREFIX)
RUN_HIDDEN = "{}hidden".format(RUN_PREFIX)
RUN_TOKEN = "{}token".format(RUN_PREFIX)
RUN_DESCRIPTION = "{}description".format(RUN_PREFIX)
RUN_ROOT_RUN_ID = "{}root_run_id".format(RUN_PREFIX)
RUN_TOKEN_EXPIRY_TIME = "{}token_expiry_time_utc".format(RUN_PREFIX)
RUN_PARENT_RUN_ID = "{}parent_run_id".format(RUN_PREFIX)
RUN_HEARTBEAT_ENABLED = "{}heartbeat_enabled".format(RUN_PREFIX)

FIELDS_TO_REMOVE = [
    ARTIFACT_ID,
    ARTIFACT_RUN_ID,
    ARTIFACT_ETAG,
    METRIC_ID,
    METRIC_DESCRIPTION,
    METRIC_LABEL,
    METRIC_TYPE,
    METRIC_NUM_CELLS,
    METRIC_SCHEMA,
    RUN_NAME,
    RUN_PROPERTIES,
    RUN_TAGS,
    RUN_HIDDEN,
    RUN_TOKEN,
    RUN_DESCRIPTION,
    RUN_ROOT_RUN_ID,
    RUN_TOKEN_EXPIRY_TIME,
    RUN_PARENT_RUN_ID,
    RUN_HEARTBEAT_ENABLED
]
