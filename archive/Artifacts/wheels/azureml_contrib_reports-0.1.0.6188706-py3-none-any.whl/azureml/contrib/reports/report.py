# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

""" Access Reports """
from azureml.contrib.reports.report_utils import (clean_dict, rename_keys, rename_keys_with_prefix,
                                                  inner_join)
from azureml.contrib.reports import constants
from azureml._restclient.artifacts_client import ArtifactsClient
from azureml._restclient.experiment_client import ExperimentClient
from azureml._logging import ChainedIdentity
from azureml.contrib.reports.restclient.report_client import ReportClient


class Report(ChainedIdentity):
    """ Get relevant runs for reports with the option of schematized results. """

    def __init__(self,
                 experiment,
                 report_id,
                 **kwargs):
        """
        Makes a new report to expose the report schema.
        :param experiment:
        :type experiment: azureml.core.experiment.Experiment
        :param report_id:
        :type report_id: str
        """
        super(Report, self).__init__(**kwargs)
        self._report_id = report_id
        self._artifacts_client = ArtifactsClient(experiment.workspace.service_context,
                                                 _parent_logger=self._logger)
        self._report_client = ReportClient(experiment.workspace.service_context, experiment.name,
                                           _parent_logger=self._logger)

    @property
    def report_id(self):
        """ Get the report id. """
        return self._report_id

    def get_runs(self):
        """ Get all of the runs for this report. """
        return self._report_client.get_relevant_runs(report_id=self._report_id)

    def load_data(self):
        """ Get the report information.

        Artifacts, metrics, and run information are cleaned and packaged together.

        """
        run_ids = [run.run_id for run in self.get_runs().value]
        return Report._get_report_for_run_ids(self._report_client, self._artifacts_client, run_ids)

    @staticmethod
    def _schematize_run_data(run_dicts, metrics, artifacts):
        """ Bring together runs, metrics, and artifacts into a single schema. """
        # TODO: enforce schema consistency between power query M and python
        rename_keys_with_prefix(run_dicts, constants.RUN_PREFIX)
        rename_keys_with_prefix(metrics, constants.METRICS_PREFIX)
        rename_keys_with_prefix(artifacts, constants.ARTIFACT_PREFIX)

        output = []
        for run_dict in run_dicts:
            inner_join(run_dict,
                       artifacts,
                       constants.RUN_RUN_ID,
                       constants.ARTIFACT_RUN_ID)

            inner_join(run_dict,
                       metrics,
                       constants.RUN_RUN_ID,
                       constants.METRICS_RUN_ID)
            output.append(run_dict)

        rename_keys(output,
                    constants.ARTIFACT_RUN_ID,
                    constants.RUN_RUN_ID)

        rename_keys(output,
                    constants.METRICS_RUN_ID,
                    constants.RUN_RUN_ID)
        # make this a dictionary of lists?
        return [clean_dict(d) for d in output]

    @staticmethod
    def _get_report_for_run_ids(exprc, ac, run_ids):
        """ Builds a dictionary for the run, metrics, and artifacts,
        making as many batch calls as possible.
        :param exprc:
        :type exprc: azureml._restclient.experiment_client.ExperimentClient
        :param ac:
        :type ac: azureml._restclient.artifacts_client.ArtifactsClient
        :param run_id:
        :type run_id: str
        """
        run_dicts = [run.as_dict() for run in exprc.get_runs_by_run_ids(run_ids)]

        metrics = [metric.as_dict() for metric in exprc.get_metrics_by_run_ids(run_ids)]

        artifacts = [d.as_dict() for run in run_dicts
                     for d in ac.get_artifact_by_container(run["data_container_id"])]

        return Report._schematize_run_data(run_dicts, metrics, artifacts)

    # TODO: rename this and move to a schematized report results
    @staticmethod
    def get_report_for_run_ids(workspace, experiment_name, run_ids):
        """ Builds a dictionary for the run, metrics, and artifacts,
        making as many batch calls as possible.
        :param workspace: User's workspace
        :type workspace: azureml.core.workspace.Workspace
        :param experiment_name:
        :type experiment_name: str
        :param run_ids
        :type run_ids: list
        """
        exprc = ExperimentClient(workspace.service_context, experiment_name)
        ac = ArtifactsClient(workspace.service_context)
        return Report._get_report_for_run_ids(exprc, ac, experiment_name)
