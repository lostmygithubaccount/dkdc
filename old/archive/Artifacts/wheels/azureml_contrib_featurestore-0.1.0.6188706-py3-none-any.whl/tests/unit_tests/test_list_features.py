import unittest
from azureml.contrib.featurestore._featurestore import Featurestore


class TestListFeatures(unittest.TestCase):
    def test_list_features(self):
        print(Featurestore.get())


if __name__ == "__main__":
    unittest.main()
