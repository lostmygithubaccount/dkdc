# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""Package for feature store functionalities.

To help import, retrieve, join features with both offline (datastore) and
online (cosmosdb) options
"""

from ._featurestore import Featurestore

__all__ = ["Featurestore"]
