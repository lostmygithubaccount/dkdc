# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""Featurestore module manages the interactions with Azure Machine Learning Featurestore.

This module provides convenient methods for importing features and execute feature actions.
"""
from collections import OrderedDict


class Featurestore(object):
    """Featurestore class manages the interactions with Azure Machine Learning Featurestore.

    This class provides convenient methods for creating featurestores and execute featurestore actions.
    """

    def __init__(
            self, workspace=None, name=None,
            id=None, offlinestore=None, onlinestore=None):
        """Initialize the Featurestore object.

        :param workspace: The workspace in which Featurestore exists
        :type workspace: azureml.core.Workspace
        :param id: The id of the featuredataset.
        :type id: str
        :param offlinestore: offlinestore of the user.
        :type offlinestore: str
        :param onlinestore: onlinestore of the user.
        :type onlinestore: str
        :return: The corresponding Featurestore for the definition.
        :rtype: Featurestore
        """
        self._workspace = workspace
        self._name = name
        self._id = id
        if offlinestore:
            self.offline_store = offlinestore
        else:
            self.offline_store = workspace.get_default_datastore()

        if onlinestore:
            self.online_store = onlinestore
        self._state = None

    @property
    def name(self):
        """Return the Featurestore name.

        :return: Featurestore name.
        :rtype: str
        """
        return self._name

    @property
    def workspace(self):
        """Return the workspace.

        :return: The workspace.
        :rtype: azureml.core.Workspace
        """
        return self._workspace

    @property
    def state(self):
        """Return the state of the Featurestore.

        :return: Featurestore state.
        :rtype: str
        """
        return self._state

    @staticmethod
    def get(workspace=None, featurestore_name=None):
        """Get a Featurestore that already exists in the workspace by specifying either its name.

        .. remarks::
            You can provide featurestore_name.
            Will throw an exception if the Featurestore with the specified
            featurestore_name cannot be found in the
            workspace.

        :param workspace: The workspace in which Featurestore exists.
        :type workspace: azureml.core.Workspace
        :param featurestore_name: The name of the Featurestore to be retrieved.
        :type featurestore_name: str
        :return: Featurestore with the specified name.
        :rtype: Featurestore
        """
        return "Function not implemented"

    def __str__(self):
        """Format Featurestore data into a string.

        :return:
        :rtype: str
        """
        info = self._get_base_info_dict()
        formatted_info = ',\n'.join(["{}: {}".format(k, v) for k, v in info.items()])
        return "Featurestore({0})".format(formatted_info)

    def __repr__(self):
        """Representation of the object.

        :return: Return the string form of the Featurestore object
        :rtype: str
        """
        return self.__str__()

    def _get_base_info_dict(self):
        """Return base info dictionary.

        :return:
        :rtype: OrderedDict
        """
        return OrderedDict([
            ('Name', self.name),
            ('Workspace', self.workspace.name if self.workspace is not None else None)
        ])
