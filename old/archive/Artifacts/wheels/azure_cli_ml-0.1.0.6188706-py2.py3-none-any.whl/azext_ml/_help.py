# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps

# pylint: disable=line-too-long

helps['ml'] = """
            type: group
            short-summary: Access Machine Learning commands.
            """

helps["ml model"] = """
                  type: group
                  short-summary: Manage machine learning models."""

helps["ml model delete"] = """
                  type: command
                  short-summary: Delete a model from the workspace."""

helps["ml model deploy"] = """
                  type: command
                  short-summary: Deploy model(s) from the workspace."""

helps["ml model download"] = """
                  type: command
                  short-summary: Download a model from the workspace."""

helps["ml model list"] = """
                  type: command
                  short-summary: List models in the workspace."""

helps["ml model profile"] = """
                  type: command
                  short-summary: Profile model(s) in the workspace."""

helps["ml model register"] = """
                  type: command
                  short-summary: Register a model to the workspace."""

helps["ml model show"] = """
                  type: command
                  short-summary: Show a model in the workspace."""

helps["ml model update"] = """
                  type: command
                  short-summary: Update a model in the workspace."""

helps["ml service"] = """
                    type: group
                    short-summary: Manage operationalized services."""

helps["ml service delete"] = """
                  type: command
                  short-summary: Delete a service from the workspace."""

helps["ml service get-keys"] = """
                  type: command
                  short-summary: Get keys to issue requests against a service."""

helps["ml service get-logs"] = """
                  type: command
                  short-summary: Get logs for a service."""

helps["ml service list"] = """
                  type: command
                  short-summary: List services in the workspace."""

helps["ml service regen-key"] = """
                  type: command
                  short-summary: Regenerate keys for a service."""

helps["ml service get-access-token"] = """
                  type: command
                  short-summary: Get a token to issue requests a service."""

helps["ml service run"] = """
                  type: command
                  short-summary: Run a service in the workspace."""

helps["ml service show"] = """
                  type: command
                  short-summary: Show details for a service in the workspace."""

helps["ml service update"] = """
                  type: command
                  short-summary: Update a service in the workspace."""

helps["ml pipeline"] = """
                     type: group
                     short-summary: Access and manage machine learning pipelines"""
