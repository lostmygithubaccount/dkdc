# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import json
import os
from ._util import cli_context, collect_input_models, file_to_inference_config, file_stream_to_object, \
    parse_tags, parse_properties, try_get_local_service, create_inference_config, create_deploy_config, \
    str_to_bool
from azureml._cli_common.ml_cli_error import MlCliError
from azureml.core import Experiment, Run
from azureml.core.compute import ComputeTarget
from azureml.core.dataset import Dataset
from azureml.data import TabularDataset, FileDataset
from azureml.core.image import Image, ContainerImage
from azureml.core.model import Model
from azureml.core.model import InferenceConfig
from azureml.core.resource_configuration import ResourceConfiguration
from azureml.core.webservice import Webservice, AciWebservice, AksWebservice, LocalWebservice
from azureml.exceptions import ComputeTargetException, WebserviceException
from azureml._model_management._constants import MODEL_METADATA_FILE_ID_KEY, \
    CLI_METADATA_FILE_WORKSPACE_KEY, CLI_METADATA_FILE_RG_KEY, \
    RUN_METADATA_EXPERIMENT_NAME_KEY, RUN_METADATA_RUN_ID_KEY, \
    PROFILE_RECOMMENDED_CPU_KEY, PROFILE_RECOMMENDED_MEMORY_KEY, \
    LOCAL_WEBSERVICE_TYPE

module_logger = logging.getLogger(__name__)


def model_register(model_name, model_path, run_id, run_metadata_file, experiment_name, asset_path,
                   model_framework, model_framework_version, tags, properties, description,
                   output_metadata_file, path, cpu_cores, memory_gb, gpu_cores, sample_input_dataset_id,
                   sample_output_dataset_id, workspace_name, resource_group, verbose_local, context=cli_context):
    # Input validation before doing meaningful work. User needs to provide one of three ways:
    #   1. model_path: for the scenario of registering model from a file
    #   2. run_id + experiment_name + asset_path: for the scenario of registering from an exp run
    #   3. run_metadata_file + asset_path: for the scenario of registering from an exp run
    if (not model_path) and (not run_id or not asset_path or not experiment_name) \
            and (not run_metadata_file or not asset_path):
        raise MlCliError('Error, need to specify source of the model. You can use --model-path to register from '
                         'a file; or --run-id, --experiment-name and --asset-path to register from an experiment run; or '
                         '--run-metadata-file and --asset-path to register from an experiment run')

    workspace = context.get_workspace(workspace_name, resource_group, path)

    tags_dict = parse_tags(tags)
    properties_dict = parse_properties(properties)

    resource_configuration = None
    if cpu_cores or memory_gb or gpu_cores:
        resource_configuration = ResourceConfiguration(cpu=cpu_cores, memory_in_gb=memory_gb, gpu=gpu_cores)

    sample_input_dataset=None

    try:
        if sample_input_dataset_id:
            sample_input_dataset = Dataset.get_by_id(workspace, sample_input_dataset_id)
    except Exception as e:
        raise MlCliError('Error, dataset with id {}  in workspace {} in '
                         'resource group {} could not be retrieved with error: {}'.format(sample_input_dataset_id,
                                                                                          workspace_name,
                                                                                          resource_group, e))

    sample_output_dataset = None
    try:
        if sample_output_dataset_id:
            sample_output_dataset = Dataset.get_by_id(workspace, sample_output_dataset_id)
    except Exception as e:
        raise MlCliError('Error, dataset with id {}  in workspace {} in '
                         'resource group {} could not be retrieved with error: {}'.format(sample_output_dataset_id,
                                                                                          workspace_name,
                                                                                          resource_group, e))

    if model_path:
        # register model from a file path
        model = Model.register(
            workspace, model_path, model_name, tags_dict, properties_dict, description, None, model_framework,
            model_framework_version, None, sample_input_dataset, sample_output_dataset, resource_configuration)
    else:
        # register model from an experiment run
        run_object = None

        # prefer to use run_metadata_file if exists
        if run_metadata_file:
            with open(run_metadata_file, 'r') as infile:
                run_metadata = json.load(infile)
                experiment_name = run_metadata.get(
                    RUN_METADATA_EXPERIMENT_NAME_KEY)
                if not experiment_name:
                    raise MlCliError('Run metadata file \'{}\' does not contain experiement name, '
                                     'property \'{}\''.format(run_metadata_file, RUN_METADATA_EXPERIMENT_NAME_KEY))

                run_id = run_metadata.get(RUN_METADATA_RUN_ID_KEY)
                if not run_id:
                    raise MlCliError('Run metadata file \'{}\' does not contain experiement run ID, '
                                     'property \'{}\''.format(run_metadata_file, RUN_METADATA_RUN_ID_KEY))

                experiment = Experiment(workspace, experiment_name)
                run_object = Run(experiment, run_id)
        else:
            experiment = Experiment(workspace, experiment_name)
            run_object = Run(experiment, run_id)
        model = run_object.register_model(
            model_name, asset_path, tags_dict, properties_dict, None, None, None, None, sample_input_dataset,
            sample_output_dataset, resource_configuration)

    if output_metadata_file:
        model_metadata = {MODEL_METADATA_FILE_ID_KEY: model.id, CLI_METADATA_FILE_WORKSPACE_KEY: model.workspace.name,
                          CLI_METADATA_FILE_RG_KEY: model.workspace.resource_group}

        with open(output_metadata_file, 'w') as outfile:
            json.dump(model_metadata, outfile)

        module_logger.debug(
            "Wrote JSON metadata to {}".format(output_metadata_file))

    module_logger.debug('Id: {}'.format(model.id))
    module_logger.debug(
        'More information: \'az ml model show -i {}\''.format(model.id))

    return model.serialize(), verbose_local


def model_show(model_name, model_id, version, run_id, path, workspace_name, resource_group, verbose_local,
               context=cli_context):
    if not model_name and not model_id:
        raise MlCliError(
            'Error, one of model_id or model_name must be provided.')

    workspace = context.get_workspace(workspace_name, resource_group, path)
    try:
        model = Model(workspace, name=model_name, id=model_id, version=version, run_id=run_id)
    except WebserviceException as e:
        if 'ModelNotFound' in e.message:
            if model_name:
                raise MlCliError('Error, no model with name {} found in workspace {} in '
                                 'resource group {}.'.format(model_name, workspace.name, workspace.resource_group))
            else:
                raise MlCliError('Error, no model with id {} found in workspace {} in '
                                 'resource group {}.'.format(model_id, workspace.name, workspace.resource_group))
        else:
            raise e

    return model.serialize(), verbose_local


def model_list(model_name, tags, properties, run_id, path, workspace_name, resource_group, verbose_local,
               context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path)
    models = Model.list(workspace, name=model_name, tags=tags, properties=properties, run_id=run_id)
    models = [model.serialize() for model in models]

    return models, verbose_local


def model_update(model_id, add_tags, remove_tags, add_properties, description, path, workspace_name,
                 cpu_cores, memory_gb, gpu_cores, sample_input_dataset_id, sample_output_dataset_id,
                 resource_group, verbose_local, context=cli_context):
    # load the workspace object
    workspace = context.get_workspace(workspace_name, resource_group, path)
    try:
        model = Model(workspace, id=model_id)
    except WebserviceException as e:
        if 'ModelNotFound' in e.message:
            raise MlCliError('Error, no model with id {} found in workspace {} in '
                             'resource group {}.'.format(model_id, workspace.name, workspace.resource_group))
        else:
            raise e

    add_tags_dict = None
    if add_tags:
        add_tags_dict = dict()
        for tag in add_tags:
            if '=' not in tag:
                raise MlCliError(
                    'Error, --add-tag must be entered in the following format: key=value')
            key, value = tag.partition("=")[::2]
            add_tags_dict[key] = value

    add_properties_dict = None
    if add_properties:
        add_properties_dict = dict()
        for prop in add_properties:
            if '=' not in prop:
                raise MlCliError(
                    'Error, --add-property must be entered in the following format: key=value')
            key, value = prop.partition("=")[::2]
            add_properties_dict[key] = value

    model.update_tags_properties(add_tags=add_tags_dict, remove_tags=remove_tags,
                                 add_properties=add_properties_dict)

    resource_configuration = None
    if cpu_cores or memory_gb or gpu_cores:
        resource_configuration = model.resource_configuration if model.resource_configuration else ResourceConfiguration()
        if cpu_cores:
            resource_configuration.cpu = cpu_cores
        if memory_gb:
            resource_configuration.memory_in_gb = memory_gb
        if gpu_cores:
            resource_configuration.gpu = gpu_cores

    sample_input_dataset = None
    try:
        if sample_input_dataset_id:
            sample_input_dataset = Dataset.get_by_id(workspace, sample_input_dataset_id)
    except Exception as e:
        raise MlCliError('Error, dataset with id {}  in workspace {} in '
                         'resource group {} could not be retrieved with error: {}'.format(sample_input_dataset_id,
                                                                                          workspace_name,
                                                                                          resource_group, e))

    sample_output_dataset = None
    try:
        if sample_output_dataset_id:
            sample_output_dataset = Dataset.get_by_id(workspace, sample_output_dataset_id)
    except Exception as e:
        raise MlCliError('Error, dataset with id {}  in workspace {} in '
                         'resource group {} could not be retrieved with error: {}'.format(sample_output_dataset_id,
                                                                                          workspace_name,
                                                                                          resource_group, e))

    if description or sample_input_dataset or sample_output_dataset or resource_configuration:
        model.update(description=description, sample_input_dataset=sample_input_dataset,
                     sample_output_dataset=sample_output_dataset, resource_configuration=resource_configuration)

    return model.serialize(), verbose_local


def model_delete(model_id, path, workspace_name, resource_group, verbose_local, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path)
    try:
        model = Model(workspace, id=model_id)
    except WebserviceException as e:
        if 'ModelNotFound' in e.message:
            raise MlCliError('Error, no model with id {} found in workspace {} in '
                             'resource group {}.'.format(model_id, workspace.name, workspace.resource_group))
        else:
            raise e

    model.delete()

    module_logger.debug('Resource deletion successful.')
    return model.serialize(), verbose_local


def model_download(model_id, target_dir, overwrite, path, workspace_name, resource_group, verbose_local,
                   context=cli_context):
    # load the workspace object
    workspace = context.get_workspace(workspace_name, resource_group, path)
    try:
        model = Model(workspace, id=model_id)
    except WebserviceException as e:
        if 'ModelNotFound' in e.message:
            raise MlCliError('Error, no model with id {} found in workspace {} in '
                             'resource group {}.'.format(model_id, workspace.name, workspace.resource_group))
        else:
            raise e

    # download model file to target directory
    model.download(target_dir=target_dir, exist_ok=overwrite)

    module_logger.debug('Model download successful.')
    return model.serialize(), verbose_local


def model_deploy(name, overwrite, tags, properties, description, models, model_metadata_files, inference_config_file,
                 compute_target, deploy_config_file, profile_metadata_file, path, workspace_name,
                 resource_group, namespace, no_wait_flag, verbose_local, entry_script, runtime, conda_file,
                 extra_docker_file_steps, source_directory, enable_gpu, base_image, base_image_registry,
                 cuda_version, compute_type, cpu_cores, memory_gb, location, auth_enabled, token_auth_enabled,
                 ssl_enabled, enable_app_insights, ssl_cert_pem_file, ssl_key_pem_file, ssl_cname, dns_name_label,
                 autoscale_enabled, autoscale_min_replicas, autoscale_max_replicas, autoscale_refresh_seconds,
                 autoscale_target_utilization, collect_model_data, scoring_timeout_ms,
                 replica_max_concurrent_requests, max_request_wait_time, num_replicas, primary_key, secondary_key,
                 gpu_cores, period_seconds, initial_delay_seconds, timeout_seconds, success_threshold,
                 failure_threshold, port, environment_name, environment_version, environment_directory,
                 context=cli_context):
    # user needs to provide either models, or model_metadata_files
    if (not models) and (not model_metadata_files):
        raise MlCliError('Error, need to specify either --model or --model-metadata-file '
                         'for model(s) to be deployed.')

    workspace = context.get_workspace(workspace_name, resource_group, path)

    # Collect all of the input models. Models can be specified via --model, or --model-metadata-file parameters.
    # In either case, the models need to be registered to MMS first
    registered_models = collect_input_models(workspace, model_metadata_files, models)

    # check whether same service already exists.
    service = None
    try:
        service = Webservice(workspace, name)
    except WebserviceException as e:
        if 'WebserviceNotFound' not in e.message:
            # 'WebserviceNotFound' in error message is the case that same name service doesn't exist, which is fine
            raise e

    if service is None:
        # same name cloud service doens't exist, so we check whether same name local service exists.
        service = try_get_local_service(workspace, name)

    if (service and not overwrite):
        raise MlCliError('A service with name \'{}\' already exists. If you want to overwrite the existing service,' \
            ' please specify --overwrite option.'.format(name))

    tags_dict = parse_tags(tags)
    properties_dict = parse_properties(properties)

    # Create InferenceConfig object from input file and parameters
    # The parameter validations (e.g. entry_script is required, runtime cannot co-exist with environment etc.) are
    # delegated to SDK layer, InferenceConfig.validate_configuration
    inference_config = create_inference_config(workspace, inference_config_file, entry_script, environment_name, 
                                               environment_version, environment_directory, runtime, conda_file,
                                               extra_docker_file_steps, source_directory, str_to_bool(enable_gpu),
                                               description, base_image, base_image_registry, cuda_version)

    # Create deployment config object from input file and parameters
    if (not deploy_config_file) and (not compute_type):
        raise MlCliError('Error, need to specify either --deploy-config-file or --compute-type '
                         'parameter for model(s) to be deployed.')

    if compute_type:
        deploy_compute_type = compute_type.lower()
    else:
        try:
            with open(deploy_config_file, 'r') as deploy_file_stream:
                deploy_config_obj = file_stream_to_object(deploy_file_stream)
                compute_type_key = 'computeType'
                if not compute_type_key in deploy_config_obj:
                    raise MlCliError('need to specify {} in --deploy-config-file or with '
                                     '--compute-type parameter'.format(compute_type_key))

                deploy_compute_type = deploy_config_obj[compute_type_key].lower()
        except Exception as ex:
            raise MlCliError('Error getting deploy compute type from config file.', content=ex)

    deploy_config = create_deploy_config(deploy_config_file, deploy_compute_type, cpu_cores, memory_gb, tags_dict,
                                         properties_dict, description, location, str_to_bool(auth_enabled),
                                         str_to_bool(ssl_enabled), str_to_bool(enable_app_insights), ssl_cert_pem_file,
                                         ssl_key_pem_file, ssl_cname, dns_name_label, str_to_bool(autoscale_enabled),
                                         autoscale_min_replicas, autoscale_max_replicas, autoscale_refresh_seconds,
                                         autoscale_target_utilization, str_to_bool(collect_model_data),
                                         scoring_timeout_ms, replica_max_concurrent_requests, max_request_wait_time,
                                         num_replicas, primary_key, secondary_key, tags_dict, properties_dict,
                                         gpu_cores, period_seconds, initial_delay_seconds, timeout_seconds,
                                         success_threshold, failure_threshold, namespace, port,
                                         str_to_bool(token_auth_enabled))

    # Get profiling results from input file
    profile_results = None
    if profile_metadata_file:
        with open(profile_metadata_file, 'r') as infile:
            profile_metadata = json.load(infile)
            if profile_metadata.get(PROFILE_RECOMMENDED_CPU_KEY) is None  or \
                profile_metadata.get(PROFILE_RECOMMENDED_MEMORY_KEY) is None:
                raise MlCliError('Profile metadata file "{}" does not contain the parameters "{}" and "{}" '
                                 'which are needed to use the profile metadata file'.format(profile_metadata_file,
                                 PROFILE_RECOMMENDED_CPU_KEY, PROFILE_RECOMMENDED_MEMORY_KEY))
            profile_results = {PROFILE_RECOMMENDED_CPU_KEY: profile_metadata[PROFILE_RECOMMENDED_CPU_KEY],
                               PROFILE_RECOMMENDED_MEMORY_KEY: profile_metadata[PROFILE_RECOMMENDED_MEMORY_KEY]}
            module_logger.info("Using profiling results for deployment.")
            module_logger.info("CPU:{} MemoryInGB:{}".format(profile_results[PROFILE_RECOMMENDED_CPU_KEY],
                                                             profile_results[PROFILE_RECOMMENDED_MEMORY_KEY]))
            deploy_config.cpu_cores = profile_results[PROFILE_RECOMMENDED_CPU_KEY]
            deploy_config.memory_gb = profile_results[PROFILE_RECOMMENDED_MEMORY_KEY]

    if service:
        # The existing service should have same compute type as the one in deployment config
        if service.compute_type.lower() != deploy_compute_type:
            raise MlCliError('Invalid \'{}\' value \'{}\' in --deploy-config-file. The existing service ' \
                             'compute type is \'{}\'. Cannot overwrite the service to a different compute ' \
                             'type'.format(compute_type_key,
                                           deploy_compute_type,
                                           service.compute_type))       

    if deploy_compute_type == "aci":
            module_logger.debug('Create ACI service \'{}\'.'.format(name))
            service = Model.deploy(workspace, name, registered_models, inference_config, deploy_config,
                                   overwrite=overwrite)

    elif deploy_compute_type == "aks":
            if not compute_target:
                raise MlCliError('Error, need to specify --compute-target when creating an AKS service.')

            module_logger.debug('Create AKS service \'{}\'.'.format(name))
            try:
                target = ComputeTarget(workspace, compute_target)
            except ComputeTargetException as e:
                if 'ComputeTargetNotFound' in e.message:
                    raise MlCliError('Error, no compute target found with name {}'.format(compute_target))
                else:
                    raise e

            service = Model.deploy(workspace, name, registered_models, inference_config, deploy_config, target,
                                   overwrite=overwrite)

    elif deploy_compute_type == "local":
        # local deployment
        if service:
            module_logger.debug('Update Local service \'{}\'.'.format(name))
            service.update(models=registered_models,
                           deployment_config=deploy_config,
                           inference_config=inference_config)
        else:
            module_logger.debug('Create Local service \'{}\'.'.format(name))
            service = Model.deploy(workspace, name, registered_models, inference_config, deploy_config)
    else:
        raise MlCliError("unknown deployment type: {}".format(deploy_compute_type))

    if no_wait_flag:
        module_logger.debug('Service may take a few minutes to be created.')
        module_logger.debug('To see if your service is ready to use, run:')
        module_logger.debug('  az ml service show -n {}'.format(service.name))
    else:
        service.wait_for_deployment(verbose_local)
        if service.state == 'Healthy':
            module_logger.debug('Service Name: {}'.format(service.name))
            module_logger.debug(
                'Run your service using "az ml service run -n {} -d <input data>'.format(service.name))
        elif isinstance(service, LocalWebservice) and service.state == LocalWebservice.STATE_RUNNING.lower():
            module_logger.debug('Service Name: {}'.format(service.name))
            module_logger.debug(
                'Run your service using "az ml service run -n {} -d <input data>'.format(service.name))
        else:
            raise MlCliError('Polling for service creation ended with service in \'{}\' state and with error ' \
                             'field \'{}\'. \nMore information can be found using "az ml service get-logs -n {}"\n' \
                             'Service name: {}\n'
                             'Workspace name: {}\n'
                             'Resource group: {}'.format(service.state, service.error, service.name,
                                                         service.name, workspace.name, workspace.resource_group))

    return service.serialize(), verbose_local


def model_profile(name, description, models, model_metadata_files,
                  inference_config_file, input_data, output_metadata_file, workspace_name, resource_group,
                  verbose_local, context=cli_context):
    # user needs to provide either models, or model_metadata_files
    if (not models) and (not model_metadata_files):
        raise MlCliError('Error, need to specify either --model or --model-metadata-file '
                         'for model(s) to be profiled.')

    workspace = context.get_workspace(workspace_name, resource_group)

    # Collect all of the input models. Models can be specified via --model, or --model-metadata-file parameters.
    # In either case, the models need to be registered to MMS first
    registered_models = collect_input_models(workspace, model_metadata_files, models)

    # Parse --inference-config-file input
    inference_config = file_to_inference_config(workspace, inference_config_file, description)

    profile = Model.profile(workspace, name, registered_models, inference_config, input_data)

    profile.wait_for_profiling(True)
    if profile.state == 'Succeeded':
        module_logger.debug('Profile name {} has finished in {} state.'.format(profile.name, profile.state))
    else:
        raise MlCliError('Polling for model profiling ended with profile in "{}" state and with error field "{}".\n'
                         'Profile name: {}\n'
                         'Workspace name: {}\n'
                         'Resource group: {}'.format(profile.state, profile.error, profile.name,
                                                     workspace.name, workspace.resource_group))

    if output_metadata_file:
        profile_metadata = {PROFILE_RECOMMENDED_CPU_KEY: profile.recommended_cpu,
                            PROFILE_RECOMMENDED_MEMORY_KEY: profile.recommended_memory}

        with open(output_metadata_file, 'w') as outfile:
            json.dump(profile_metadata, outfile)

        module_logger.debug("Wrote JSON metadata to {}".format(output_metadata_file))

    return profile.serialize(), verbose_local
