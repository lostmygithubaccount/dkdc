# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from __future__ import print_function

import copy
import json
import logging
from .._ml_cli_error import MlCliError
from .._util import cli_context, collect_input_models, try_get_local_service, create_inference_config, \
    create_deploy_config, str_to_bool
from azureml.core.image import Image
from azureml.core.image import ContainerImage
from azureml.core.model import Model
from azureml.core.webservice import Webservice
from azureml.core.webservice import AciWebservice
from azureml.core.webservice import AksWebservice
from azureml.core.webservice import LocalWebservice
from azureml.exceptions import WebserviceException
from azureml._model_management._constants import IMAGE_METADATA_FILE_ID_KEY, \
    CLI_METADATA_FILE_WORKSPACE_KEY, CLI_METADATA_FILE_RG_KEY

module_logger = logging.getLogger(__name__)


def service_update(service_name, add_tags, remove_tags, add_properties, description, deploy_config_file,
                   path, models, model_metadata_files, inference_config_file, workspace_name, resource_group,
                   no_wait_flag, verbose_local, entry_script, runtime, conda_file, extra_docker_file_steps,
                   source_directory, enable_gpu, base_image, base_image_registry, cuda_version, cpu_cores, memory_gb,
                   location, auth_enabled, token_auth_enabled,
                   ssl_enabled, enable_app_insights, ssl_cert_pem_file, ssl_key_pem_file,
                   ssl_cname, dns_name_label, autoscale_enabled, autoscale_min_replicas, autoscale_max_replicas,
                   autoscale_refresh_seconds, autoscale_target_utilization, collect_model_data, scoring_timeout_ms,
                   replica_max_concurrent_requests, max_request_wait_time, num_replicas, primary_key, secondary_key,
                   gpu_cores, period_seconds, initial_delay_seconds, timeout_seconds, success_threshold,
                   failure_threshold, port, environment_name, environment_version, environment_directory,
                   context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path)
    service = None
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            pass
        else:
            raise e

    if service is None:
        # same name cloud service doesn't exist, check local service now
        service = try_get_local_service(workspace, service_name)

    if service is None:
        # no service exists with the input name, cloud or local. raise error
        raise MlCliError('Error, no service with name {} found in workspace {} in '
                         'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))

    # handle add_tags
    tags_dict = None
    if add_tags:
        tags_dict = dict()
        for tag in add_tags:
            if '=' not in tag:
                raise MlCliError('Error, tags must be entered in the following format: key=value')
            key, value = tag.partition("=")[::2]
            tags_dict[key] = value
        if service.tags is not None:
            for key in service.tags:
                if key not in tags_dict:
                    tags_dict[key] = service.tags[key]

    # handle remove_tags
    if remove_tags:
        if service.tags is None:
            module_logger.debug('Model has no tags to remove.')
        else:
            if not tags_dict:
                tags_dict = copy.deepcopy(service.tags)
            if type(remove_tags) is not list:
                remove_tags = [remove_tags]
            for key in remove_tags:
                if key in tags_dict:
                    del tags_dict[key]
                else:
                    module_logger.debug('Tag with key {} not found.'.format(key))

    # handle add_properties
    properties_dict = None
    if add_properties:
        properties_dict = dict()
        for prop in add_properties:
            if '=' not in prop:
                raise MlCliError('Error, properties must be entered in the following format: key=value')
            key, value = prop.partition("=")[::2]
            properties_dict[key] = value

    registered_models = collect_input_models(workspace, model_metadata_files, models)

    if len(registered_models) == 0:
        registered_models = None

    # Create InferenceConfig object from input file and parameters
    inference_config = create_inference_config(workspace, inference_config_file, entry_script, environment_name, 
                                               environment_version, environment_directory, runtime, conda_file,
                                               extra_docker_file_steps, source_directory, str_to_bool(enable_gpu),
                                               description, base_image, base_image_registry, cuda_version)

    # Create deployment config object from input file and parameters
    deploy_config = create_deploy_config(deploy_config_file, service._webservice_type.lower(), cpu_cores, memory_gb,
                                         tags_dict, properties_dict, description, location, str_to_bool(auth_enabled),
                                         str_to_bool(ssl_enabled), str_to_bool(enable_app_insights), ssl_cert_pem_file,
                                         ssl_key_pem_file, ssl_cname, dns_name_label, str_to_bool(autoscale_enabled),
                                         autoscale_min_replicas, autoscale_max_replicas, autoscale_refresh_seconds,
                                         autoscale_target_utilization, str_to_bool(collect_model_data),
                                         scoring_timeout_ms, replica_max_concurrent_requests, max_request_wait_time,
                                         num_replicas, primary_key, secondary_key, tags_dict, properties_dict,
                                         gpu_cores,
                                         period_seconds, initial_delay_seconds, timeout_seconds, success_threshold,
                                         failure_threshold, None, port, str_to_bool(token_auth_enabled))

    if service._webservice_type.lower() == 'aci':
        # aci update
        service.update(image=None, tags=tags_dict, properties=properties_dict, description=description,
                       auth_enabled=deploy_config.auth_enabled,
                       ssl_enabled=deploy_config.ssl_enabled,
                       ssl_cert_pem_file=deploy_config.ssl_cert_pem_file,
                       ssl_key_pem_file=deploy_config.ssl_key_pem_file,
                       ssl_cname=deploy_config.ssl_cname,
                       enable_app_insights=deploy_config.enable_app_insights,
                       models=registered_models,
                       inference_config=inference_config)

    elif service._webservice_type.lower() == 'aks':
        # aks update
        service.update(image=None, autoscale_enabled=deploy_config.autoscale_enabled,
                       autoscale_min_replicas=deploy_config.autoscale_min_replicas,
                       autoscale_max_replicas=deploy_config.autoscale_max_replicas,
                       autoscale_refresh_seconds=deploy_config.autoscale_refresh_seconds,
                       autoscale_target_utilization=deploy_config.autoscale_target_utilization,
                       collect_model_data=deploy_config.collect_model_data,
                       auth_enabled=deploy_config.auth_enabled,
                       cpu_cores=deploy_config.cpu_cores,
                       memory_gb=deploy_config.memory_gb,
                       enable_app_insights=deploy_config.enable_app_insights,
                       scoring_timeout_ms=deploy_config.scoring_timeout_ms,
                       replica_max_concurrent_requests=deploy_config.replica_max_concurrent_requests,
                       max_request_wait_time=deploy_config.max_request_wait_time,
                       num_replicas=deploy_config.num_replicas,
                       token_auth_enabled=deploy_config.token_auth_enabled,
                       tags=tags_dict, properties=properties_dict, description=description,
                       models=registered_models, inference_config=inference_config)

    elif service._webservice_type.lower() == 'local':
        # local update
        deployment_config = LocalWebservice.deploy_configuration(port=deploy_config.port if deploy_config else None)

        service.update(models=registered_models,
                       deployment_config=deployment_config,
                       inference_config=inference_config)
    else:
        raise MlCliError("unknown deployment type: {}".format(service._webservice_type))

    if no_wait_flag:
        module_logger.debug('Service Update submitted successfully.')
        module_logger.debug('To see if your service is ready to use, run:')
        module_logger.debug('  az ml service show -n {}'.format(service_name))
    else:
        service.wait_for_deployment(verbose_local)
        if service.state == 'Healthy':
            module_logger.debug('Service Name: {}'.format(service.name))
            module_logger.debug('Run your service using "az ml service run -n {} -d <input data>'.format(service.name))
        elif isinstance(service, LocalWebservice) and service.state == LocalWebservice.STATE_RUNNING.lower():
            module_logger.debug('Service Name: {}'.format(service.name))
            module_logger.debug('Run your service using "az ml service run -n {} -d <input data>'.format(service.name))
        else:
            raise MlCliError('Polling for service update ended with service in "{}" state and with error field "{}".\n'
                             'More information can be found using "az ml service get-logs -n {}"\n'
                             'Service name: {}\n'
                             'Workspace name: {}\n'
                             'Resource group: {}'.format(service.state, service.error, service.name, service.name,
                                                         workspace.name, workspace.resource_group))

    return service.serialize(), verbose_local


def service_run(service_name, input_data, path, workspace_name, resource_group, verbose_local, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path)
    service = None
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            pass
        else:
            raise e

    if service is None:
        # same name cloud service doesn't exist, check local service now
        service = try_get_local_service(workspace, service_name)

    if service is None:
        # no service exists with the input name, cloud or local. raise error
        raise MlCliError('Error, no service with name {} found in workspace {} in '
                         'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))

    result = service.run(input_data)
    return result, verbose_local


def service_delete(service_name, path, workspace_name, resource_group, verbose_local, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path)
    service = None
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            pass
        else:
            raise e

    if service is None:
        # same name cloud service doesn't exist, check local service now
        service = try_get_local_service(workspace, service_name)

    if service is None:
        # no service exists with the input name, cloud or local. raise error
        raise MlCliError('Error, no service with name {} found in workspace {} in '
                         'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))

    # get the image ID for this service
    image_id = service.image_id

    # local webservice has no underlying image
    is_local_webservice = isinstance(service, LocalWebservice)
    service.delete()

    # do not try to delete image for local webservice as there is no cloud Image for local
    if not is_local_webservice and image_id:
        image = Image(workspace, id=image_id)
        if not image or not image.id:
            raise MlCliError('Error, no model package with id {} found in workspace {} in '
                             'resource group {}.'.format(image_id, workspace.name, workspace.resource_group))
        image.delete()

    module_logger.debug('Resource deletion successfully submitted.')
    module_logger.debug('Resources may take a few minutes to be completely deprovisioned.')

    return service.serialize(), verbose_local


def service_list(workspace_name, compute_type, model_name, model_id, tags, properties,
                 image_digest, resource_group, path, verbose_local, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path)
    services = Webservice.list(workspace, compute_type=compute_type, model_name=model_name, model_id=model_id,
                               tags=tags, properties=properties, image_digest=image_digest)

    return [service.serialize() for service in services], verbose_local


def service_show(service_name, path, workspace_name, resource_group, verbose_local, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path)
    service = None
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            pass
        else:
            raise e

    if service is None:
        # same name cloud service doesn't exist, check local service now
        service = try_get_local_service(workspace, service_name)

    if service is None:
        # no service exists with the input name, cloud or local. raise error
        raise MlCliError('Error, no service with name {} found in workspace {} in '
                         'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))

    return service.serialize(), verbose_local


def service_regen_key(service_name, key, path, workspace_name, resource_group, verbose_local, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path)
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            raise MlCliError('Error, no service with name {} found in workspace {} in '
                             'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))
        else:
            raise e

    if service.auth_enabled is False:
        raise MlCliError('Error, key authentication is disabled for service {}'.format(service.name))

    service.regen_key(key)

    primary_key, secondary_key = service.get_keys()

    return {
               'primaryKey': primary_key,
               'secondaryKey': secondary_key
           }, verbose_local


def service_get_keys(service_name, path, workspace_name, resource_group, verbose_local, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path)
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            raise MlCliError('Error, no service with name {} found in workspace {} in '
                             'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))
        else:
            raise e

    if service.auth_enabled is False:
        raise MlCliError('Error, key authentication is disabled for service {}'.format(service.name))

    primary_key, secondary_key = service.get_keys()

    return {
               'primaryKey': primary_key,
               'secondaryKey': secondary_key
           }, verbose_local


def service_get_logs(service_name, num_lines, path, workspace_name, resource_group, verbose_local,
                     context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path)
    service = None
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            pass
        else:
            raise e

    if service is None:
        # same name cloud service doesn't exist, check local service now
        service = try_get_local_service(workspace, service_name)

    if service is None:
        # no service exists with the input name, cloud or local. raise error
        raise MlCliError('Error, no service with name {} found in workspace {} in '
                         'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))

    logs = service.get_logs(num_lines=num_lines)

    return logs, verbose_local


def service_get_access_token(service_name, path, workspace_name, resource_group, verbose_local, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path)
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            raise MlCliError('Error, no service with name {} found in workspace {} in '
                             'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))
        else:
            raise e

    if service.token_auth_enabled is False:
        raise MlCliError('Error, token authentication is disabled for service {}'.format(service.name))

    primary_key, refresh_by = service.get_token()

    return {
               'token': primary_key,
               'refreshBy': refresh_by
           }, verbose_local
