# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""Jupyter run module contains code to perform a jupyter run that opens a notebook connected to remote kernels."""
import random
import string
import os
import json
import sys
import re
import time
import webbrowser
from azure.mgmt.relay import RelayManagementClient
from azureml.core.script_run_config import ScriptRunConfig
from azureml.core.experiment import Experiment
from azureml.exceptions import ExperimentExecutionException, UserErrorException
from azureml.exceptions import ActivityFailedException
from azureml._restclient.utils import create_session_with_retry
from azureml._restclient.constants import RunStatus
from azureml.core.script_run import ScriptRun
from azureml.core.conda_dependencies import CondaDependencies

_RELAY_NAMESPACE_ROOT_KEY = "RootManageSharedAccessKey"


def get_or_create_relay_namespace(workspace_object, relay_namespace=None):
    """Get or create a service bus relay namespace.

    :param workspace_object:
    :type: azureml.core.workspace.Workspace
    :return: The relay namespace created.
    :rtype: str
    """
    workspace_auth = workspace_object._auth_object
    relay_client = workspace_auth._get_service_client(RelayManagementClient, workspace_object.subscription_id)
    if not relay_namespace:
        relay_namespace = 'relaynamespace' + ''.join(random.choice(string.digits) for _ in range(8))

    # Try get first, if it exists then just return that.
    try:
        relay_client.namespaces.get(workspace_object.resource_group, relay_namespace)
        return relay_namespace
    except Exception:
        # relay namespace not found, so we create it.
        pass

    result = relay_client.namespaces.check_name_availability_method(relay_namespace)
    if not result.name_available:
        raise UserErrorException("relay name = {} not available. message = {} reason = {}".format(
            relay_namespace, result.message, result.reason))
    else:
        from azure.mgmt.relay.models import RelayNamespace
        relay_location = workspace_object.location
        if "euap" in workspace_object.location.lower():
            relay_location = "eastus"

        params = RelayNamespace(relay_location)
        print("Creating a relaynamespace {}".format(relay_namespace))
        azure_poller = relay_client.namespaces.create_or_update(workspace_object.resource_group,
                                                                relay_namespace, params)
        # Blocking till the operation completes.
        result = azure_poller.result()
        print("Relaynamespace = {}".format(result.as_dict()))
        return relay_namespace


def start_jupyter_run(workspace_object, experiment_name, run_config, relay_namespace, run_time_in_mins=10,
                      use_jeg=False, byo_relay_subscription=None, byo_relay_resource_group=None,
                      byo_relay_name=None, use_jupyter_lab=False):
    """Start a jupyter run for PySpark framework on amlcompute cluster.

    :param workspace_object:
    :type workspace_object: azureml.core.workspace.Workspace
    :param experiment_name:
    :type experiment_name: str
    :param run_config:
    :type run_config: azureml.core.runconfig.RunConfiguration
    :param relay_namespace:
    :type relay_namespace: str
    :param run_time_in_mins: The run time in minutes. This is the time till which the spark standalone
    cluster remains active. After this, we tear down the spark standalone cluster and stop jupyter server.
    :type run_time_in_mins: int
    :param use_jeg: use_jeg=False starts jupyter notebook on the spark driver node. use_jeg=True starts
    jupyter enterprise gateway on the spark driver node. In use_jeg=True, a user has to start jupyter server
    somewhere else and connect to the jupyter enterprise gateway.
    :type use_jeg: bool
    :param byo_relay_subscription: The subscription id for the bring-your-own relay.
    :type byo_relay_subscription: str
    :param byo_relay_resource_group: The resource group for the bring-your-own relay.
    :type byo_relay_resource_group: str
    :param byo_relay_name: The relay name for the bring-your-own relay.
    :type byo_relay_name: str
    :param use_jupyter_lab: use_jupyter_lab=True indicates to use Jupyter Lab instead of Jupyter notebook.
    :type use_jupyter_lab: bool
    :return:
    """
    workspace_auth = workspace_object._auth_object

    if byo_relay_subscription and byo_relay_resource_group and byo_relay_name:
        relay_client = workspace_auth._get_service_client(RelayManagementClient, byo_relay_subscription)
        relay_name = byo_relay_name

        access_keys = relay_client.namespaces.list_keys(byo_relay_resource_group,
                                                        relay_namespace, _RELAY_NAMESPACE_ROOT_KEY)
    else:
        relay_client = workspace_auth._get_service_client(RelayManagementClient, workspace_object.subscription_id)
        relay_name = 'relay' + ''.join(random.choice(string.digits) for _ in range(6))

        relay_client.hybrid_connections.create_or_update(
            workspace_object.resource_group, relay_namespace, relay_name, requires_client_authorization=False)

        access_keys = relay_client.namespaces.list_keys(workspace_object.resource_group,
                                                        relay_namespace, _RELAY_NAMESPACE_ROOT_KEY)

    link_to_open = "https://{}.servicebus.windows.net/{}".format(relay_namespace, relay_name)

    run_config.framework = "PySparkInteractive"
    run_config.node_count = 2
    conda_dependencies = CondaDependencies()
    conda_dependencies.add_channel("conda-forge")
    if use_jeg:
        conda_dependencies.add_conda_package("jupyter_enterprise_gateway>=1.1.1")
        conda_dependencies.add_pip_package("jupyter_enterprise_gateway>=2.0.0b1")
    else:
        if use_jupyter_lab:
            conda_dependencies.add_conda_package("jupyterlab")
        else:
            conda_dependencies.add_conda_package("notebook")
        conda_dependencies.add_conda_package("tornado<6.0.0")

    conda_dependencies.add_conda_package("aiohttp")
    conda_dependencies.add_conda_package("websockets")

    run_config.environment.python.conda_dependencies = conda_dependencies
    run_config.environment.environment_variables = {
        # TODO: we can get service bus endpoint from the get namespace call.
        "AZUREML_RELAY_NAMESPACE": relay_namespace + ".servicebus.windows.net",
        "AZUREML_RELAY_NAME": relay_name,
        "AZUREML_RELAY_KEY": access_keys.primary_key,
        "AZUREML_INTERACTIVE_RUN_TIME_IN_MINS": run_time_in_mins,
        "AZUREML_RELAY_USE_JEG": str(use_jeg),
        "AZUREML_RELAY_USE_JLAB": str(use_jupyter_lab)
    }

    notebook_dir = os.path.join(os.path.expanduser("~"), "aml_jupyter_folder")
    os.makedirs(notebook_dir, exist_ok=True)
    # A dummy file.
    with open(os.path.join(notebook_dir, "train.py"), "w"):
        pass

    run_config.script = "train.py"

    script_run_config = ScriptRunConfig(notebook_dir, run_config=run_config)
    experiment = Experiment(workspace_object, experiment_name)
    start_time = time.time()
    run_object = experiment.submit(script_run_config)

    if not use_jeg:
        print("Setting up an interactive spark run. A jupyter notebook will open in "
              "browser on {} link after the setup finishes.".format(link_to_open))

    try:
        _stream_run_output(run_object, file_handle=sys.stdout,
                           wait_post_processing=True,
                           raise_on_error=True, link_to_open=link_to_open,
                           start_time=start_time)
        return run_object.get_details()
    except KeyboardInterrupt:
        error_message = "The output streaming for the run interrupted.\n" \
                        "But the run is still executing on the compute target. \n" \
                        "Details for canceling the run can be found here: " \
                        "https://aka.ms/aml-docs-cancel-run"
        raise ExperimentExecutionException(error_message)


def delete_all_relays_in_namespace(workspace_object, relay_namespace):
    """Delete all relays in the service bus relay namespace, the relay namespace itself is not deleted.

    :param workspace_object:
    :type workspace_object: azureml.core.workspace.Workspace
    :param relay_namespace:
    :type relay_namespace: str
    :return:
    """
    workspace_auth = workspace_object._auth_object
    relay_client = workspace_auth._get_service_client(RelayManagementClient, workspace_object.subscription_id)

    paged_list = relay_client.hybrid_connections.list_by_namespace(workspace_object.resource_group, relay_namespace)
    for hybrid_relay in paged_list:
        print("Deleting {} relay in {} namespace in {} resource group".format(hybrid_relay.name, relay_namespace,
                                                                              workspace_object.resource_group))
        relay_client.hybrid_connections.delete(workspace_object.resource_group,
                                               relay_namespace, hybrid_relay.name)


def _stream_run_output(run_object, file_handle=sys.stdout,
                       wait_post_processing=False, raise_on_error=True,
                       link_to_open=None, start_time=None):
    """Stream the experiment run output to the specified file handle.

    By default the the file handle points to stdout.

    :param file_handle: A file handle to stream the output to.
    :type file_handle: file
    :param wait_post_processing:
    :type wait_post_processing: bool
    :return:
    :rtype: :class:`list`
    """
    from azureml._execution import _commands

    def incremental_print(log, printed, fileout):
        """Incremental print.

        :param log:
        :type log: dict
        :param printed:
        :type printed: int
        :param fileout:
        :type fileout: TestIOWrapper
        :return:
        :rtype: int
        """
        count = 0
        for line in log.splitlines():
            if count >= printed:
                print(line, file=fileout)
                printed += 1
            count += 1

        return printed

    def get_logs(status):
        """Return logs.

        :param status:
        :type status: dict
        :return:
        :rtype: :class:`list`
        """
        logs = [x for x in status["logFiles"] if re.match("azureml-logs/[\d]{2}.+\.txt", x)]
        logs.sort()
        return logs

    file_handle.write("RunId: {}\n".format(run_object._run_id))

    printed = 0
    current_log = None
    running_states = [RunStatus.STARTING, RunStatus.PREPARING,
                      RunStatus.RUNNING, RunStatus.PROVISIONING, RunStatus.QUEUED]
    if wait_post_processing:
        running_states.append(RunStatus.FINALIZING)
        running_states.append(RunStatus.CANCEL_REQUESTED)

    current_details = run_object.get_details()
    session = create_session_with_retry()

    jupyter_proxy_found = False
    jupyter_notebook_found = False
    link_opened = False
    # TODO: Temporary solution to wait for all the logs to be printed in the finalizing state.
    while (current_details["status"] in running_states or
           current_details["status"] == RunStatus.FINALIZING):
        file_handle.flush()
        time.sleep(1)
        current_details = run_object.get_details()  # TODO use FileWatcher

        # Check whether there is a higher priority log than the one we are currently streaming (current_log)
        available_logs = get_logs(current_details)
        # next_log is the log we should be following now, based on the available logs we just got
        next_log = ScriptRun._get_last_log_primary_instance(available_logs) if available_logs else None
        # if next_log != current_log, we need to switch to streaming next_log
        if available_logs and current_log != next_log:
            printed = 0
            current_log = next_log
            file_handle.write("\n")
            file_handle.write("Streaming " + current_log + "\n")
            file_handle.write("=" * (len(current_log) + 10) + "\n")
            file_handle.write("\n")

        if current_log:
            content = _commands._get_content_from_uri(current_details["logFiles"][current_log], session)
            printed = incremental_print(content, printed, file_handle)
            if "Starting jupyter notebook" in content:
                jupyter_notebook_found = True

            if "Starting jupyter proxy" in content:
                jupyter_proxy_found = True

            if jupyter_notebook_found and jupyter_proxy_found and not link_opened:
                print("Time to launch kernel = {} s".format(time.time() - start_time))
                link_opened = True
                try:
                    webbrowser.open_new_tab(link_to_open)
                except Exception:
                    print("Unable to open browser. Please open {} link in the browser to connect to the "
                          "jupyter notebook with spark kernels.".format(link_to_open))

            # TODO: Temporary solution to wait for all the logs to be printed in the finalizing state.
            if (current_details["status"] not in running_states and
                current_details["status"] == RunStatus.FINALIZING and
                    "The activity completed successfully. Finalizing run..." in content):
                break

    file_handle.write("\n")
    file_handle.write("Execution Summary\n")
    file_handle.write("=================\n")
    file_handle.write("RunId: {}\n".format(run_object.id))

    warnings = current_details.get("warnings")
    if warnings:
        messages = [x.get("message") for x in warnings if x.get("message")]
        if len(messages) > 0:
            file_handle.write("\nWarnings:\n")
            for message in messages:
                file_handle.write(message + "\n")
            file_handle.write("\n")

    error = current_details.get("error")
    if error:
        file_handle.write("\nError:\n")
        file_handle.write(json.dumps(error, indent=4))
        file_handle.write("\n")
    if error and raise_on_error:
        raise ActivityFailedException(error_details=json.dumps(error, indent=4))

    file_handle.write("\n")
    file_handle.flush()
