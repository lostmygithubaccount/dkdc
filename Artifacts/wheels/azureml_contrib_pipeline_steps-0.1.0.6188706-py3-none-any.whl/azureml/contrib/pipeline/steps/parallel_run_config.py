# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""ParallelRunConfig for ParallelRunStep."""
import re
import logging

from azureml.core.compute import AmlCompute

module_logger = logging.getLogger(__name__)


class ParallelRunConfig(object):
    """
    Config for parallel run step.

    :param entry_script: User script which will be run in parallel on multiple nodes.  This is
                specified as local file path.  If source_directory is specified, then entry_script is
                a relative path inside. Otherwise, it can be any path accessible on machine.
    :type entry_script: str
    :param input_format: Deprecated.
    :type input_format: str
    :param error_threshold: The number of record failures for TabularDataset and file failures
        for FileDataset that should be ignored during processing.  If the error count goes
        above this value, then the job will be aborted.  Error threshold is for the entire
        input and not for individual mini-batches sent to run() method.
        The range is [-1, int.max]. -1 indicates ignore all failures during processing.
    :type error_threshold: int
    :param output_action: How the output to be organized.  Currently supported values
        are 'append_row' and 'summary_only'
        1. append_row – All values output by run() method invocations will be aggregated into
                one unique file named parallel_run_step.txt that is created in the output location.
        2. summary_only – User script is expected to store the output by itself.  An output row
                is still expected for each successful input item processed.  The system uses this output
                only for error threshold calculation (ignoring the actual value of the row).
    :type output_action: str
    :param compute_target: Compute target to use
    :type compute_target: azureml.core.compute.AmlCompute
    :param node_count: Number of nodes in the compute target used for running the ParallelRunStep.
    :type node_count: int
    :param process_count_per_node: Number of processes executed on each node.
    :type process_count_per_node: int
    :param mini_batch_size: For FileDataset input it is number of files user script can process
        in one run() call. For TabularDataset input it is approximate size of data user script
               can process in one run() call. E.g. 1024, 1024KB, 10MB, 1GB
        (optional, default value 10 files for FileDataset and 1MB for TabularDataset.)
    :type mini_batch_size: str
    :param source_directory: Paths to folders that contains the entry_script and supporting files used
        to execute on compute target
    :type source_directory: : str
    :param environment: The environment definition. This field configures the Python environment.
        It can be configured to use an existing Python environment or to set up a temp environment
               for the experiment.  The definition is also responsible for setting the required application
               dependencies.
    :type environment: azureml.core.Environment
    :param description: A description to give batch service used for display purposes.
    :type description: str
    :param logging_level: A string of the logging level name, which is defined in 'logging'.
        The default value is 'INFO'.
    :type logging_level: str
    :param run_invocation_timeout: Timeout in seconds to use for each invocation of the run() method.
    :type run_invocation_timeout: int
    """

    def __init__(self, entry_script, input_format, error_threshold, output_action, compute_target,
                 node_count, process_count_per_node=None, mini_batch_size=None,
                 source_directory=None, environment=None, description=None, logging_level='INFO',
                 run_invocation_timeout=30):
        """Initialize the config object.

        :param entry_script: User script which will be run in parallel on multiple nodes.  This is
                    specified as local file path.  If source_directory is specified, then entry_script is
                    a relative path inside. Otherwise, it can be any path accessible on machine.
        :type entry_script: str
        :param input_format: Deprecated.
        :type input_format: str
        :param error_threshold: The number of record failures for TabularDataset and file failures
            for FileDataset that should be ignored during processing.  If the error count goes
            above this value, then the job will be aborted.  Error threshold is for the entire
            input and not for individual mini-batches sent to run() method.
            The range is [-1, int.max]. -1 indicates ignore all failures during processing.
        :type error_threshold: int
        :param output_action: How the output to be organized.  Currently supported values
            are 'append_row' and 'summary_only'
            1. append_row – All values output by run() method invocations will be aggregated into
                    one unique file named parallel_run_step.txt that is created in the output location.
            2. summary_only – User script is expected to store the output by itself.  An output row
                    is still expected for each successful input item processed.  The system uses this output
                    only for error threshold calculation (ignoring the actual value of the row).
        :type output_action: str
        :param compute_target: Compute target to use
        :type compute_target: azureml.core.compute.AmlCompute
        :param node_count: Number of nodes in the compute target used for running the ParallelRunStep.
        :type node_count: int
        :param process_count_per_node: Number of processes executed on each node.
        :type process_count_per_node: int
        :param mini_batch_size: For FileDataset input it is number of files user script can process
            in one run() call. For TabularDataset input it is approximate size of data user script
                   can process in one run() call. E.g. 1024, 1024KB, 10MB, 1GB
            (optional, default value 10 files for FileDataset and 1MB for TabularDataset.)
        :type mini_batch_size: str
        :param source_directory: Paths to folders that contains the entry_script and supporting files used
            to execute on compute target
        :type source_directory: : str
        :param environment: The environment definition. This field configures the Python environment.
            It can be configured to use an existing Python environment or to set up a temp environment
                   for the experiment.  The definition is also responsible for setting the required application
                   dependencies.
        :type environment: azureml.core.Environment
        :param description: A description to give batch service used for display purposes.
        :type description: str
        :param logging_level: A string of the logging level name, which is defined in 'logging'.
            The default value is 'INFO'.
        :type logging_level: str
        :param run_invocation_timeout: Timeout in seconds to use for each invocation of the run() method.
        :type run_invocation_timeout: int
        """
        self.input_format = input_format
        self.mini_batch_size = mini_batch_size
        self.error_threshold = error_threshold
        self.output_action = output_action
        self.logging_level = logging_level
        self.compute_target = compute_target
        self.node_count = node_count
        self.process_count_per_node = process_count_per_node
        self.entry_script = entry_script
        self.source_directory = source_directory
        self.description = description
        self.environment = environment
        self.run_invocation_timeout = run_invocation_timeout

        if self.input_format.lower() != 'file' and self.input_format.lower() != 'line':
            raise Exception('Parameter input_format must be file or line')

        if self.output_action.lower() != 'summary_only' \
                and self.output_action.lower() != 'file' \
                and self.output_action.lower() != 'append_row':
            raise Exception('Parameter output_action must be summary_only, file or append_row')

        if not isinstance(self.error_threshold, int) or self.error_threshold < -1:
            raise Exception('Parameter error_threshold must be an int value greater than or equal to -1')

        if self.mini_batch_size is not None:
            self._mini_batch_size_to_int()

        if self.process_count_per_node is not None and self.process_count_per_node < 1:
            raise Exception("Param process_count_per_node must be greater or equal to 1",
                            logger=module_logger)

        if self.compute_target.type.lower() != AmlCompute._compute_type.lower():
            raise Exception("Compute compute_target {0} is not supported in ParallelRunStep. "
                            "AmlCompute is the only supported compute_target."
                            .format(self.compute_target), logger=module_logger)

        if (self.node_count > self.compute_target.scale_settings.maximum_node_count or self.node_count <= 0):
            raise Exception("Node count must larger than 0 and can not be larger than max_nodes {}"
                            .format(self.compute_target.scale_settings.maximum_node_count),
                            logger=module_logger)

        if self.run_invocation_timeout <= 0:
            raise Exception('Parameter run_invocation_timeout must be a greater than 0')

    def _mini_batch_size_to_int(self):
        pattern = re.compile(r"^\d+([kKmMgG][bB])*$")
        if not pattern.match(self.mini_batch_size):
            raise Exception('mini_batch_size must follow regex rule ^\d+([kKmMgG][bB])*$')

        try:
            self.mini_batch_size = int(self.mini_batch_size)
        except ValueError:
            unit = self.mini_batch_size[-2:].lower()
            if unit == 'kb':
                self.mini_batch_size = int(self.mini_batch_size[0:-2]) * 1024
            elif unit == 'mb':
                self.mini_batch_size = int(self.mini_batch_size[0:-2]) * 1024 * 1024
            elif unit == 'gb':
                self.mini_batch_size = int(self.mini_batch_size[0:-2]) * 1024 * 1024 * 1024
