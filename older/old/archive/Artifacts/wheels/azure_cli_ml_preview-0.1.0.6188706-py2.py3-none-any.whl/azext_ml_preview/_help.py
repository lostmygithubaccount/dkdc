# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps  # noqa: F401

# pylint: disable=line-too-long

# add help for intermediate nodes e.g.
# helps['ml'] = """
#             type: group
#             short-summary: Module to access Machine Learning commands
#             """
