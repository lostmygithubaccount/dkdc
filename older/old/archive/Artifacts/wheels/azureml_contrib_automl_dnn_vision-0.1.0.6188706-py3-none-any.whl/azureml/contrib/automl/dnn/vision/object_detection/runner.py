# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Entry script that is invoked by the driver script from automl.'''

import argparse
import json
import os
import torch

from .data import datasets, loaders
from .models import detection
from .trainer import optimize, lrschedule, criterion, train
from .eval import cocotools
from .writers import modelsaver
from .common.constants import ModelNames, TrainingParameters, LearningParameters, SchedulerParameters

try:
    from azureml.core.run import Run
    azureml_run = Run.get_context()
except ImportError:
    azureml_run = None

from .common.constants import ArtifactLiterals


def run(automl_settings):
    '''Invoke training by passing settings and write the resulting model.

    :param automl_settings: Dictionary with all training and model settings
    :type automl_settings: Dictionary
    '''

    parser = argparse.ArgumentParser(description="Object detection")

    # Model and Device Settings

    parser.add_argument("--model_name", type=str,
                        default=ModelNames.FASTER_RCNN_RESNET50_FPN, help="model_name")

    parser.add_argument("--device", type=str,
                        help="Device to train on (cpu/cuda:0/cuda:1,...)",
                        default="cuda:0")

    # Training Related Settings

    parser.add_argument("--number_of_epochs", type=int,
                        help="number of training epochs",
                        default=TrainingParameters.DEFAULT_NUMBER_EPOCHS)
    parser.add_argument("--max_patience_iterations", type=int,
                        help="max number of epochs with no validation improvment",
                        default=TrainingParameters.DEFAULT_PATIENCE_ITERATIONS)

    parser.add_argument("--learning_rate", type=float,
                        help="learning rate for optimizer",
                        default=LearningParameters.SGD_DEFAULT_LEARNING_RATE)
    parser.add_argument("--momentum", type=float,
                        help="momentum for optimizer",
                        default=LearningParameters.SGD_DEFAULT_MOMENTUM)
    parser.add_argument("--weight_decay", type=float,
                        help="optimizer weight decay",
                        default=LearningParameters.SGD_DEFAULT_WEIGHT_DECAY)

    parser.add_argument("--step_size", type=int,
                        help="step size for learning rate scheduler",
                        default=SchedulerParameters.DEFAULT_STEP_LR_STEP_SIZE)
    parser.add_argument("--gamma", type=float,
                        help="decay rate for learning rate scheduler",
                        default=SchedulerParameters.DEFAULT_STEP_LR_GAMMA)

    # Dataloader Settings

    parser.add_argument("--training_batch_size", type=int,
                        help="training batch size",
                        default=TrainingParameters.DEFAULT_TRAINING_BATCH_SIZE)

    parser.add_argument("--validation_batch_size", type=int,
                        help="validation batch size",
                        default=TrainingParameters.DEFAULT_VALIDATION_BATCH_SIZE)

    parser.add_argument('--data-folder', type=str,
                        help='root of the blob store',
                        default='')

    parser.add_argument('--labels-file-root', type=str,
                        help='root relative to which label file paths exist',
                        default='')

    # Extract Commandline Settings

    args = parser.parse_args()

    model_name = args.model_name
    device = args.device

    training_settings = {'number_of_epochs': args.number_of_epochs,
                         'lr': args.learning_rate,
                         'momentum': args.momentum,
                         'weight_decay': args.weight_decay,
                         'step_size': args.step_size,
                         'gamma': args.gamma,
                         'max_patience_iterations': args.max_patience_iterations}

    train_data_loader_settings = {'batch_size': args.training_batch_size}
    validation_data_loader_settings = {
        'batch_size': args.validation_batch_size}

    image_folder = os.path.join(
        args.data_folder, automl_settings["images_folder"])

    # Extract Automl Settings

    annotations_file = os.path.join(
        args.labels_file_root, automl_settings['labels_file'])
    output_directory = ArtifactLiterals.OUTPUT_DIR
    annotations_test_file = None
    resume_file = None

    if 'validation_labels_file' in automl_settings:
        annotations_test_file = os.path.join(args.labels_file_root, automl_settings['validation_labels_file'])
    if 'resume' in automl_settings:
        resume_file = automl_settings['resume']

    # Do validations of input arguments

    if image_folder is None:
        raise ValueError('Image folder path needs to be specified')

    # Setup Dataset

    annotations = []

    with open(annotations_file, "r") as json_file:
        for line in json_file:
            annotations.append(json.loads(line))

    if annotations_test_file:
        annotations_test = []
        with open(annotations_test_file, "r") as json_file:
            for line in json_file:
                annotations_test.append(json.loads(line))

    if annotations_test_file:
        training_dataset = datasets.CommonObjectDetectionDatasetWrapper(annotations, image_folder, is_train=True)
        validation_dataset = datasets.CommonObjectDetectionDatasetWrapper(annotations_test,
                                                                          image_folder, is_train=False)
    else:
        dataset = datasets.CommonObjectDetectionDatasetWrapper(annotations, image_folder, is_train=False)
        training_dataset, validation_dataset = dataset.train_val_split()

    # Setup Model

    num_classes = training_dataset.num_classes
    model = detection.setup_model(model_name=model_name,
                                  number_of_classes=num_classes)
    model.classes = training_dataset.classes

    # Resume

    if resume_file:
        checkpoint = torch.load(resume_file, map_location='cpu')
        model.model.load_state_dict(checkpoint)

    # Setup Optimizer

    optimizer = optimize.setup_optimizer(model, **training_settings)
    lr_scheduler = lrschedule.setup_lr_scheduler(
        optimizer, **training_settings)
    loss_function = criterion.setup_criterion("FASTER_RCNN")

    # Setup Dataloaders

    train_loader = loaders.setup_dataloader(
        training_dataset, **train_data_loader_settings)
    validation_loader = loaders.setup_dataloader(
        validation_dataset, **validation_data_loader_settings)

    # Setup Evaluation Tools

    coco_index = cocotools.create_coco_index(validation_dataset)

    # Train Model

    test_settings = train.train_settings(**training_settings)

    train.train(model=model,
                optimizer=optimizer,
                scheduler=lr_scheduler,
                train_data_loader=train_loader,
                device=device,
                criterion=loss_function,
                train_settings=test_settings,
                val_data_loader=validation_loader,
                val_coco_index=coco_index,
                val_index_map=model.classes,
                run=azureml_run)

    # Save Model

    modelsaver.write_model(model, training_dataset, None, output_directory)

    folder_name = os.path.basename(output_directory)
    if azureml_run is not None:
        azureml_run.upload_folder(name=folder_name, path=output_directory)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Object detection")
    parser.add_argument("--annotations_file", type=str,
                        help="Annotations file")
    parser.add_argument("--model_name", type=str,
                        default="fasterrcnn", help="model_name")
    parser.add_argument("--data_folder", type=str, help="root of blob store")
    parser.add_argument("--device", type=str,
                        help="Device to train on (cpu/cuda:0/cuda:1,...)")
    parser.add_argument("--training_settings", type=str,
                        help="Device to train on (cpu/cuda:0/cuda:1,...)")
    parser.add_argument("--output_directory", type=str,
                        help="Device to train on (cpu/cuda:0/cuda:1,...)")

    args = parser.parse_args()
