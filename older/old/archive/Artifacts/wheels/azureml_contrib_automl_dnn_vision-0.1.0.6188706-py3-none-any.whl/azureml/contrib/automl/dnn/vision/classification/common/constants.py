# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Defines literals and constants for the classification part of the package.'''


try:
    import torch
except ImportError:
    print('ImportError: torch not installed. If on windows, install torch, pretrainedmodels, torchvision and '
          'pytorch-ignite separately before running the package.')


class ArtifactsLiterals:
    '''Filenames for artifacts.'''
    MODEL_FILE_NAME = 'model.pth'
    MODEL_WRAPPER_PKL = 'model_wrapper.pkl'
    CONDA_YML = 'conda_dependencies.yml'
    SCORE_SCRIPT = 'score_script.py'
    FEATURIZE_SCRIPT = 'featurize_script.py'
    OUTPUT_DIRECTORY = 'train_artifacts'


class MetricsLiterals:
    '''String key names for metrics.'''
    ACCURACY = 'accuracy'
    PRECISION = 'precision'
    RECALL = 'recall'
    AVERAGE_PRECISION = 'average_precision'
    ACCURACY_TOP5 = 'accuracy_top5'


class PredictionLiterals:
    '''Strings that will be keys in the output json during prediction.'''
    FEATURE_VECTOR = 'feature_vector'
    FILENAME = 'filename'
    LABELS = 'labels'
    PROBS = 'probs'
    PREDICTION_FILE_NAME = 'predictions.txt'
    FEATURE_FILE_NAME = 'features.txt'


class TrainingLiterals:
    '''String keys for training parameters.'''
    IMAGE_FOLDER = 'images_folder'
    LABELS_FILE = 'labels_file'
    VALIDATION_LABELS_FILE = 'validation_labels_file'
    DIFF_LR = 'diff_lr'
    FIT_LAST = 'fit_last'
    PARAMS = 'params'
    LR = 'lr'
    MOMENTUM = 'momentum'
    PRIMARY_METRIC = 'primary_metric'
    OUTPUT_DIR = 'output_dir'
    EARLY_STOPPING_PATIENCE = 'early_stopping_patience'
    BATCH_SIZE = 'batch_size'
    NUM_EPOCHS = 'epochs'
    DEVICE = 'device'
    TEST_RATIO = 'test_ratio'
    MULTILABEL = 'multilabel'


class ModelNames:
    '''Currently supported model names.'''
    RESNET18 = 'resnet18'
    MOBILENETV2 = 'mobilenetv2'
    SERESNEXT = 'seresnext'


class PackageInfo:
    '''Contains package details'''
    PYTHON_VERSION = '3.6'
    CONDA_PACKAGE_NAMES = ['pip']
    PIP_PACKAGE_NAMES = ['azureml-contrib-automl-dnn-vision']
    EXTRA_INDEX_URL = 'https://azuremlsdktestpypi.azureedge.net/automl_dnn_vision/A24B94E4F810/'


training_settings_defaults = {
    TrainingLiterals.BATCH_SIZE: 80,
    TrainingLiterals.NUM_EPOCHS: 15,
    TrainingLiterals.PRIMARY_METRIC: MetricsLiterals.ACCURACY,
    TrainingLiterals.DEVICE: torch.device("cuda:0" if torch.cuda.is_available() else "cpu"),
    TrainingLiterals.TEST_RATIO: 0.2,
    TrainingLiterals.EARLY_STOPPING_PATIENCE: 2,
    TrainingLiterals.OUTPUT_DIR: ArtifactsLiterals.OUTPUT_DIRECTORY,
    TrainingLiterals.MULTILABEL: False,
}
