# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Contains dataloader functions for the package.'''

try:
    import torch
    import torch.utils.data as data
    from torch.utils.data.dataloader import default_collate
except ImportError:
    print('ImportError: torch not installed. If on windows, install torch, pretrainedmodels, torchvision and '
          'pytorch-ignite separately before running the package.')


def _one_hot_encode(label_list, num_classes=None):
    if num_classes is None:
        raise ValueError('num classes needs to be passed')
    one_hot_label = torch.zeros(num_classes)
    one_hot_label[label_list] = 1

    return one_hot_label


def _collate_fn(f, multilabel=False, num_classes=None):
    '''Return collate function for the dataloader that performs transformations on dataset input.

    :param f: function that takes in a pillow image and returns a torch Tensor.
    :type f: function
    :param multilabel: whether this is a multilabel dataset
    :type multilabel: bool
    :param num_classes: number of classes
    :type num_classes: int
    :return: function that can take a batch of tuples of pillow images and labels and returns tensors of transformed
    images and the label.
    :rtype: function
    '''
    if multilabel and num_classes is None:
        raise ValueError('num_classes needs to be set if multilabel is True')

    def transform(x):
        batch = []
        for im, label in x:
            if multilabel:
                label = _one_hot_encode(label, num_classes=num_classes)
            batch.append((f(im), label))

        return default_collate(batch)

    return transform


def _get_data_loader(dataset_wrapper, indices=None, transform_fn=None, batch_size=None, num_workers=None):
    '''Get data loader for the torch dataset only loading the selected indices and transforming the input images using
    transform_fn.

    :param dataset_wrapper: dataset wrapper
    :type dataset_wrapper: azureml.contrib.automl.dnn.vision.io.read.dataset_wrapper.BaseDatasetWrapper
    :param indices: numpy array of integer indices
    :type indices: numpy.array(int)
    :param transform_fn: function that takes a pillow image and returns a torch Tensor
    :type transform_fn: function
    :param batch_size: batch size for dataloader
    :type batch_size: int
    :param num_workers: number of workers for dataloader
    :type num_workers: int
    :return: dataloader
    :rtype: torch.utils.data.DataLoader
    '''
    if num_workers is None:
        import multiprocessing
        num_workers = multiprocessing.cpu_count()

    if indices is not None:
        sampler = data.SubsetRandomSampler(indices)
    else:
        sampler = data.RandomSampler(dataset_wrapper)

    if transform_fn is None:
        transform_fn = _identity

    collate_fn = _collate_fn(transform_fn, multilabel=dataset_wrapper.multilabel,
                             num_classes=dataset_wrapper.num_classes)
    return data.DataLoader(dataset_wrapper, batch_sampler=data.BatchSampler(
        sampler, batch_size=batch_size, drop_last=False), num_workers=num_workers, collate_fn=collate_fn)


def _identity(x):
    '''

    :param x: any input
    :type x: any type
    :return: return the input
    :rtype: any type
    '''
    return x
