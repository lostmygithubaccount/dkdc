# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Class for metrics logging '''


class AverageMeter(object):
    '''Computes and stores the average and current value'''

    def __init__(self):
        '''reset self params to zero'''
        self.val = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        '''Update total sum and count for the meter

        :param val: current value
        :type val: Float
        :param n: Count
        :type n: Int
        '''
        self.val = val
        self.sum += val * n
        self.count += n

    @property
    def avg(self):
        '''Get average values

        :return: Average Value
        :rtype: Float
        '''
        return self.sum / self.count

    @property
    def value(self):
        '''Get current values

        :return: Current Value
        :rtype: Float
        '''
        return self.val
