# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Entry script that is invoked by the driver script from automl.'''

import argparse
import copy
import os

from ..classification.common.constants import TrainingLiterals, training_settings_defaults
from ..classification.trainer.trainer import train_model
from ..classification.io.read.dataset_wrappers import ImageFolderLabelFileDatasetWrapper
from ..classification.io.write.write_model import _write_model


try:
    from azureml.core.run import Run
    azureml_run = Run.get_context()
except ImportError:
    azureml_run = None


def _fill_missing_settings_with_defaults(automl_settings):
    '''

    :param automl_settings: automl settings object to fill
    :type automl_settings: dict
    :return: automl settings dictionary with all settings filled in
    :rtype: dict
    '''
    settings = copy.deepcopy(automl_settings)
    for param_name, param_value in training_settings_defaults.items():
        if param_name not in settings:
            settings[param_name] = param_value
    return settings


def _get_train_valid_dataset_wrappers(root_dir, train_file=None, valid_file=None, multilabel=False):
    '''

    :param root_dir: root directory that will be used as prefix for paths in train_file and valid_file
    :type root_dir: str
    :param train_file: labels file for training with filenames and labels
    :type train_file: str
    :param valid_file: labels file for validation with filenames and labels
    :type valid_file: str
    :param multilabel: boolean flag for whether its multilabel or not
    :type multilabel: bool
    :return: tuple of train and validation dataset wrappers
    :rtype: tuple[BaseDatasetWrapper, BaseDatasetWrapper]
    '''
    train_dataset_wrapper = ImageFolderLabelFileDatasetWrapper(root_dir=root_dir, input_file=train_file,
                                                               multilabel=multilabel)

    if valid_file is None:
        valid_dataset_wrapper = None
    else:
        valid_dataset_wrapper = ImageFolderLabelFileDatasetWrapper(
            root_dir=root_dir, input_file=valid_file, multilabel=multilabel,
            all_labels=train_dataset_wrapper.labels)

        if valid_dataset_wrapper.labels != train_dataset_wrapper.labels:
            train_dataset_wrapper.reset_labels(valid_dataset_wrapper.labels)

    return train_dataset_wrapper, valid_dataset_wrapper


def run(automl_settings, multilabel=False):
    '''Invoke training by passing settings and write the output model.

    :param automl_settings: dictionary with automl settings
    :type automl_settings: dict
    :param multilabel: boolean flag for multilabel
    :type multilabel: bool
    '''
    parser = argparse.ArgumentParser(description='cluster images')
    parser.add_argument('--model_name', type=str, default='seresnext', help='model name.')
    parser.add_argument('--strategy', default='diff_lr')
    parser.add_argument('--data-folder', type=str, default='', help='root of the blob store')
    parser.add_argument('--labels-file-root', type=str, default='',
                        help='root relative to which label file paths exist')

    args = parser.parse_args()

    automl_settings = _fill_missing_settings_with_defaults(automl_settings)
    # set multilabel flag in settings
    automl_settings[TrainingLiterals.MULTILABEL] = multilabel

    labels_file = automl_settings[TrainingLiterals.LABELS_FILE]
    validation_labels_file = automl_settings.get(TrainingLiterals.VALIDATION_LABELS_FILE, None)
    image_folder = automl_settings.get(TrainingLiterals.IMAGE_FOLDER, None)
    output_dir = automl_settings[TrainingLiterals.OUTPUT_DIR]
    device = automl_settings[TrainingLiterals.DEVICE]

    if labels_file is None and image_folder is None:
        raise ValueError('Neither images_folder or labels_file found in automl settings')

    labels_path = None if labels_file is None else os.path.join(args.labels_file_root, labels_file)

    image_folder_path = os.path.join(args.data_folder, image_folder)

    if validation_labels_file is not None:
        validation_labels_path = os.path.join(args.labels_file_root, validation_labels_file)
    else:
        validation_labels_path = None

    train_dataset_wrapper, valid_dataset_wrapper = _get_train_valid_dataset_wrappers(
        root_dir=image_folder_path, train_file=labels_path, valid_file=validation_labels_path,
        multilabel=multilabel
    )

    best_model = train_model(args.model_name, strategy=args.strategy, dataset_wrapper=train_dataset_wrapper,
                             valid_dataset=valid_dataset_wrapper, device=device, azureml_run=azureml_run,
                             settings=automl_settings)

    _write_model(best_model, labels=train_dataset_wrapper.labels, output_dir=output_dir)

    folder_name = os.path.basename(output_dir)
    azureml_run.upload_folder(name=folder_name, path=output_dir)
