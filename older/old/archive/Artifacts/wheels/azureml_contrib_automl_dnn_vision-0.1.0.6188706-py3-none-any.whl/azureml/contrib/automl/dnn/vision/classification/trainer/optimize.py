# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Defines functions related to optimization.'''

try:
    from torch import nn
    import torch.optim as optim
except ImportError:
    print('ImportError: torch not installed. If on windows, install torch, pretrainedmodels, torchvision and '
          'pytorch-ignite separately before running the package.')
from ..common.constants import TrainingLiterals
from ..common.utils import _get_model_params


def _get_sgd_params(strategy, last_layer_params=None, other_layers_params=None):
    if strategy == TrainingLiterals.FIT_LAST:
        sgd_params = [
            {
                TrainingLiterals.PARAMS: last_layer_params,
                TrainingLiterals.LR: 0.001, TrainingLiterals.MOMENTUM: 0.9
            }
        ]
    elif strategy == TrainingLiterals.DIFF_LR:
        sgd_params = [
            {
                TrainingLiterals.PARAMS: last_layer_params,
                TrainingLiterals.LR: 0.01,
                TrainingLiterals.MOMENTUM: 0.9
            },
            {
                TrainingLiterals.PARAMS: other_layers_params,
                TrainingLiterals.LR: 1e-4,
                TrainingLiterals.MOMENTUM: 0.9
            }
        ]
    else:
        raise ValueError('invalid strategy passed')

    return sgd_params


def _get_optimizer(model_wrapper, strategy=TrainingLiterals.DIFF_LR):
    '''Get torch optimizer.

    :param model_wrapper: model wrapper object
    :type model_wrapper: azureml.contrib.automl.dnn.vision.base_model_wrapper.BaseModelWrapper
    :param strategy: training strategy
    :type strategy: str
    :return: get optimizer
    :rtype: torch.optim.Optimizer object
    '''
    last_layer, other_layers = _get_model_params(model_wrapper.model, model_wrapper.name)
    params = _get_sgd_params(strategy, last_layer_params=last_layer, other_layers_params=other_layers)
    return optim.SGD(params, lr=0.001, momentum=0.9)


def _get_criterion(multilabel=False):
    '''Get torch criterion.

    :param multilabel: flag indicating if it is a multilabel problem or not.
    :type multilabel: bool
    :return: torch criterion
    :rtype: object from one of torch.nn criterion classes
    '''
    if multilabel:
        criterion = nn.BCEWithLogitsLoss()
    else:
        criterion = nn.CrossEntropyLoss()

    return criterion
