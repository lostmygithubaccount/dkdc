# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Tools for using using pycocotools for evaluating model performance.'''

from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval


def prepare_dataset_for_coco(dataset):
    '''Convert a dataset object to a dictionary that
    can be consumed by cocotools during evaluation.

    :param dataset: Dataset with ground truth data used
    for evaluation
    :type dataset: CommonObjectDetectionDatasetWrapper object
    (see object_detection.data.datasets)
    :return: Dataset in format that can be converted into a cocotools
    index.
    :rtype: Dict of dicts
    '''
    images = []
    ann_id = 0
    annotations = []

    for _, box_info, image_info in dataset:

        image_id = image_info['filename']

        img_dict = {}

        img_dict['id'] = image_id
        img_dict['height'] = image_info['height']
        img_dict['width'] = image_info['width']

        images.append(img_dict)

        boxes = box_info['boxes']
        labels = box_info['labels']
        areas = image_info['areas']
        is_crowds = image_info['iscrowd']

        for box, label, area, is_crowd in zip(boxes, labels, areas, is_crowds):

            ann = {}

            box_width = box[2] - box[0]
            box_height = box[3] - box[1]

            ann['bbox'] = [box[0], box[1], box_width, box_height]
            classification = dataset.index_to_label(label)

            ann['category_id'] = classification
            ann['image_id'] = image_id
            ann['id'] = ann_id
            ann['area'] = area
            ann['iscrowd'] = is_crowd
            ann_id += 1

            annotations.append(ann)

        categories = [{'id': cat} for cat in dataset.classes]

    return {'images': images, 'annotations': annotations, 'categories': categories}


def prepare_bounding_boxes_for_coco(bounding_box_list):
    '''Converts a list of  bounding box records to a format
    that can be consumed by cocotools.

    :param bounding_box_list: Bounding box records for a set of
    images
    :type bounding_box_list: List of ImageBoxes (see
    object_detection.common.bounding_box)
    :return: Detections in format that can be consumed by cocotools
    :rtype: List of dicts
    '''
    detections = []

    for bounding_box_record in bounding_box_list:
        image_id = bounding_box_record.image_name

        for box_record in bounding_box_record._boxes:
            box = box_record.bounding_box
            category = box_record.label
            score = box_record.score

            record = {"image_id": image_id,
                      "bbox": box,
                      "category_id": category,
                      "score": score}

            detections.append(record)

    return detections


def create_coco_index(dataset):
    '''Creates a cocotools index from a dataset

    :param dataset: Dataset for evaluations
    :type dataset: CommonObjectDetectionDatasetWrapper object
    (see object_detection.data.datasets)
    :return: Index created from dataset
    :rtype: cocotools index object
    '''
    coco_dataset = COCO()
    coco_dataset.dataset = prepare_dataset_for_coco(dataset)
    coco_dataset.createIndex()

    return coco_dataset


def score_from_index(coco_index, boxes):
    '''Scores the a set of bounding box records from an index created
    from a set of ground truth bounding boxes.

    :param coco_index: Ground truth index
    :type coco_index: cocotools index object
    :param boxes: Detections for a set of images
    :type: List of ImageBoxes (see object_detection.common.boundingbox)
    :returns: List of scores - [CocoMAP (all sizes),
                                MAP@IoU0.5 (all sizes),
                                MAP@IoU0.75 (all sizes),
                                CocoMAP (small),
                                CocoMAP (medium),
                                CocoMAP (large),
                                CocoAR (all sizes, max detections 1),
                                CocoAR (all sizes, max detections 10),
                                CocoAR (all sizes, max detections 100),
                                CocoAR (small, max detections 100),
                                CocoAR (medium, max detections 100),
                                CocoAR (large, max detections 100)]
    plase refer to the coco challenge: cocodataset.org for detailed
    description of these metrics.
    :rtype: List of floats
    '''

    # No detections
    if len(boxes) == 0:
        return [0.] * 12

    coco_detections = coco_index.loadRes(boxes)
    cocoEval = COCOeval(coco_index, coco_detections, 'bbox')
    cocoEval.evaluate()
    cocoEval.accumulate()
    cocoEval.summarize()

    return cocoEval.stats


def score(dataset, boxes):
    '''Scores the a set of bounding box records from a set of
    ground truth bounding boxes.

    :param coco_index: Ground truth index
    :type coco_index: cocotools index object
    :param boxes: Detections for a set of images
    :type: List of ImageBoxes (see object_detection.common.boundingbox)
    :returns: List of scores - [CocoMAP (all sizes),
                                MAP@IoU0.5 (all sizes),
                                MAP@IoU0.75 (all sizes),
                                CocoMAP (small),
                                CocoMAP (medium),
                                CocoMAP (large),
                                CocoAR (all sizes, max detections 1),
                                CocoAR (all sizes, max detections 10),
                                CocoAR (all sizes, max detections 100),
                                CocoAR (small, max detections 100),
                                CocoAR (medium, max detections 100),
                                CocoAR (large, max detections 100)]
    plase refer to the coco challenge: cocodataset.org for detailed
    description of these metrics.
    :rtype: List of floats
    '''

    coco_dataset = COCO()
    coco_dataset.dataset = prepare_dataset_for_coco(dataset)
    coco_dataset.createIndex()
    coco_detections = coco_dataset.loadRes(boxes)
    cocoEval = COCOeval(coco_dataset, coco_detections, 'bbox')
    cocoEval.evaluate()
    cocoEval.accumulate()
    cocoEval.summarize()

    return cocoEval.stats
