# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Classification metrics for the package.'''

from itertools import chain

try:
    from ignite.metrics import Accuracy, Precision, Recall
    from ignite.contrib.metrics import AveragePrecision
    import torch
except ImportError:
    print('ImportError: torch not installed. If on windows, install torch, pretrainedmodels, torchvision and '
          'pytorch-ignite separately before running the package.')
from ..classification.common.constants import MetricsLiterals


class ClassificationMetrics:
    '''Class to calculate classification metrics.

    This class is modeled on the ignite Metrics class. Enabling us to compute metrics per batch,
    aggregate them and compute them only at the end. This is done without saving the full list of
    predictions.

    For multilabel, input predictions are supposed to be one hot encoded already. Since this is required for data
    loader to stack multiple tensors of labels anyways. For multiclass, prediction is a single column tensor of the
    predictions.
    '''
    def __init__(self, num_classes=2, multilabel=False):
        '''

        :param num_classes: number of classes
        :type num_classes: int
        :param multilabel: flag indicating whether this is multilabel problem
        :type multilabel: bool
        '''
        self._prob_metrics = {
            MetricsLiterals.AVERAGE_PRECISION: AveragePrecision(_get_single_column_label) if multilabel else
            AveragePrecision(),
        }

        self._pred_metrics = {
            MetricsLiterals.ACCURACY: Accuracy(),
            MetricsLiterals.PRECISION: Precision(is_multilabel=multilabel, average=True),
            MetricsLiterals.RECALL: Recall(is_multilabel=multilabel, average=True),
        }

        self._multilabel = multilabel
        self._num_classes = num_classes

    def _get_one_hot_labels(self, preds=None, num_classes=None):
        '''

        :param preds: predictions
        :type preds: torch.Tensor
        :param num_classes: number of classes
        :type num_classes: int
        :return: one hot encoded predictions
        :rtype: torch.Tensor
        '''
        y = torch.zeros(preds.shape[0], num_classes).to(preds.device)
        return y.scatter_(1, preds.reshape(-1, 1), 1)

    def reset(self):
        '''Resets batch metric.'''
        for _, metric in chain(self._pred_metrics.items(), self._prob_metrics.items()):
            metric.reset()

    def update(self, probs=None, preds=None, labels=None):
        '''Update the metrics.

        :param probs: probabilities
        :type probs: torch.Tensor
        :param preds: predictions
        :type preds: torch.Tensor
        :param labels: labels
        :type labels: torch.Tensor
        '''
        if self._num_classes != 2 and not self._multilabel:
            # since pytorch-ignite takes probs as input for >2 classes
            preds = probs

        for _, metric in self._pred_metrics.items():
            metric.update((preds, labels))

        if not self._multilabel:
            labels = self._get_one_hot_labels(labels, num_classes=self._num_classes)
        for _, metric in self._prob_metrics.items():
            metric.update((probs, labels))

    def compute(self):
        '''Compute the metrics.'''
        metrics = {}
        for name, metric in chain(self._pred_metrics.items(), self._prob_metrics.items()):
            metrics[name] = metric.compute()

        return metrics


def _get_single_column_label(output):
    y_prob, y_truth = output
    return y_prob.view(-1), y_truth.view(-1)
