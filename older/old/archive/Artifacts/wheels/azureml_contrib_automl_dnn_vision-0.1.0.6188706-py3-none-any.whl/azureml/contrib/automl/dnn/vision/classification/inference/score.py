# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Scoring functions that can load a serialized model and predict.'''

import os
from PIL import Image
import json
import torch
from torch.utils.data import DataLoader, Dataset
from azureml.core.experiment import Experiment
from azureml.core.run import Run
from ..common.constants import ArtifactsLiterals, PredictionLiterals
from . import InferenceModelWrapper


class _PredictionDataset(Dataset):
    '''Dataset file so that score.py can process images in batches.

    '''
    def __init__(self, root_dir=None, image_list_file=None, transforms=None):
        '''

        :param root_dir: prefix to be added to the paths contained in image_list_file
        :type root_dir: str
        :param image_list_file: path to file containing list of images
        :type image_list_file: str
        :param transforms: function that takes in a pillow image and can generate tensor
        :type transforms: function
        '''
        self._files = []
        for filename in open(image_list_file):
            self._files.append(filename.strip())
        # remove blank strings
        self._files = [f for f in self._files if f]
        self._root_dir = root_dir
        self._transform = transforms

    def __len__(self):
        '''Size of the dataset.'''
        return len(self._files)

    def __getitem__(self, idx):
        '''

        :param idx: index
        :type idx: int
        :return: item and label at index idx
        :rtype: tuple[str, image]
        '''
        filename = self._files[idx]
        full_path = os.path.join(self._root_dir, filename)
        image = Image.open(full_path).convert('RGB')
        if self._transform:
            image = self._transform(image)
        return filename, image


def _get_labels_as_array(num_to_labels):
    num_labels = max(num_to_labels.keys()) + 1
    labels = [0] * num_labels
    for i in range(num_labels):
        labels[i] = num_to_labels[i]

    return labels


def load_model_from_artifacts(run_id, experiment_name=None, artifacts_dir=None):
    '''

    :param run_id: run id of the run that produced the model
    :type run_id: str
    :param experiment_name: name of experiment that contained the run id
    :type experiment_name: str
    :return: InferenceModelWrapper object
    :rtype: InferenceModelWrapper
    '''
    if artifacts_dir is None:
        artifacts_dir = ArtifactsLiterals.OUTPUT_DIRECTORY
    current_experiment = Run.get_context().experiment
    if experiment_name is None:
        experiment = current_experiment
    else:
        ws = current_experiment.workspace
        experiment = Experiment(ws, experiment_name)

    run = Run(experiment=experiment, run_id=run_id)

    run.download_file(os.path.join(artifacts_dir, ArtifactsLiterals.MODEL_FILE_NAME),
                      output_file_path=ArtifactsLiterals.MODEL_FILE_NAME)
    run.download_file(os.path.join(artifacts_dir, ArtifactsLiterals.MODEL_WRAPPER_PKL),
                      output_file_path=ArtifactsLiterals.MODEL_WRAPPER_PKL)

    return InferenceModelWrapper.load_serialized_inference_model_wrapper(
        ArtifactsLiterals.MODEL_FILE_NAME, model_wrapper_pkl_file=ArtifactsLiterals.MODEL_WRAPPER_PKL)


def _score_with_model(inference_model_wrapper, output_file=None,
                      root_dir=None, image_list_file=None, batch_size=60):
    if output_file is None:
        output_file = os.path.join(ArtifactsLiterals.OUTPUT_DIRECTORY, PredictionLiterals.PREDICTION_FILE_NAME)

    model_wrapper = inference_model_wrapper.model_wrapper
    model_wrapper.model.eval()

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model_wrapper.model = model_wrapper.model.to(device)

    with open(output_file, 'w') as fw:
        dataset = _PredictionDataset(root_dir=root_dir, image_list_file=image_list_file,
                                     transforms=model_wrapper.transforms)
        dataloader = DataLoader(dataset, batch_size=batch_size, drop_last=False)
        with torch.no_grad():
            for filenames, batch in dataloader:
                batch = batch.to(device)
                outputs = model_wrapper.model(batch)
                probs = model_wrapper.predict_proba_from_outputs(outputs)
                for filename, prob in zip(filenames, probs):
                    fw.write(
                        json.dumps(
                            {
                                PredictionLiterals.FILENAME: filename,
                                PredictionLiterals.PROBS: prob.cpu().numpy().tolist(),
                                PredictionLiterals.LABELS: inference_model_wrapper.labels
                            }
                        )
                    )
                    fw.write('\n')


def _featurize_with_model(inference_model_wrapper, output_file=None,
                          root_dir=None, image_list_file=None, batch_size=80):
    if output_file is None:
        output_file = os.path.join(ArtifactsLiterals.OUTPUT_DIRECTORY, PredictionLiterals.FEATURE_FILE_NAME)
    model_wrapper = inference_model_wrapper.model_wrapper
    model_wrapper.featurizer.eval()

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model_wrapper.model = model_wrapper.featurizer.to(device)

    with open(output_file, 'w') as fw:
        dataset = _PredictionDataset(root_dir=root_dir, image_list_file=image_list_file,
                                     transforms=model_wrapper.transforms)
        dataloader = DataLoader(dataset, batch_size=batch_size, drop_last=False)
        with torch.no_grad():
            for filenames, batch in dataloader:
                batch = batch.to(device)
                features = model_wrapper.featurizer(batch).squeeze().cpu().numpy()
                if len(features.shape) == 1:
                    features = features.unsqueeze(0)
                for filename, feat in zip(filenames, features):
                    fw.write(
                        json.dumps(
                            {
                                PredictionLiterals.FILENAME: filename,
                                PredictionLiterals.FEATURE_VECTOR: feat.tolist(),
                            }
                        )
                    )
                    fw.write('\n')


def featurize(run_id, experiment_name=None, output_file=None, root_dir=None, image_list_file=None, batch_size=80):
    '''Generate predictions from input files.

    :param run_id: azureml run id
    :type run_id: str
    :param experiment_name: name of experiment
    :type experiment_name: str
    :param output_file: path to output file
    :type output_file: str
    :param root_dir: prefix to be added to the paths contained in image_list_file
    :type root_dir: str
    :param image_list_file: path to file containing list of images
    :type image_list_file: str
    :param batch_size: batch size for prediction
    :type batch_size: int
    '''
    inference_model_wrapper = load_model_from_artifacts(run_id, experiment_name=experiment_name)
    _featurize_with_model(inference_model_wrapper, output_file=output_file, root_dir=root_dir,
                          image_list_file=image_list_file, batch_size=batch_size)


def score(run_id, experiment_name=None, output_file=None, root_dir=None, image_list_file=None, batch_size=80):
    '''Generate predictions from input files.

    :param run_id: azureml run id
    :type run_id: str
    :param experiment_name: name of experiment
    :type experiment_name: str
    :param output_file: path to output file
    :type output_file: str
    :param root_dir: prefix to be added to the paths contained in image_list_file
    :type root_dir: str
    :param image_list_file: path to file containing list of images
    :type image_list_file: str
    :param batch_size: batch size for prediction
    :type batch_size: int
    '''
    inference_model_wrapper = load_model_from_artifacts(run_id, experiment_name=experiment_name)
    _score_with_model(inference_model_wrapper, output_file=output_file,
                      root_dir=root_dir, image_list_file=image_list_file, batch_size=batch_size)
