# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Functions to help save a trained model.'''

import os
import pickle
import shutil
import torch
from ..common import constants


def write_model(model_wrapper, dataset, output_conda_file, output_dir):
    '''Save a model to Artifacts

    :param model_wrapper: Wrapper that contains model
    :type model_wrapper: CommonObjectDetectionModelWrapper
    (see object_detection.models.base_model_wrapper)
    :param dataset: Wrapper that contains dataset model was trained on
    :type dataset: CommonObjectDetectionDatasetWrapper
    (see object_detection.data.dataset)
    :param output_conda_file: Name of conda file for conda output
    :type output_conda_file: String (filename)
    :param output_dir: Name of dir to save model files. If it does
    not exist, it will be created.
    :type output_dir: String
    '''

    os.makedirs(output_dir, exist_ok=True)

    model_location = os.path.join(output_dir,
                                  constants.ArtifactLiterals.MODEL_FILE_NAME)

    torch.save(model_wrapper.model.state_dict(), model_location)

    model_wrapper.model = None

    model_wrapper_location = os.path.join(output_dir,
                                          constants.ArtifactLiterals.PICKLE_FILE_NAME)

    with open(model_wrapper_location, "wb") as pickle_file:
        pickle.dump(model_wrapper, pickle_file)

    dirname = os.path.dirname(os.path.abspath(__file__))

    shutil.copy(os.path.join(dirname, constants.ArtifactLiterals.SCORE_SCRIPT),
                os.path.join(output_dir, constants.ArtifactLiterals.SCORE_SCRIPT))
