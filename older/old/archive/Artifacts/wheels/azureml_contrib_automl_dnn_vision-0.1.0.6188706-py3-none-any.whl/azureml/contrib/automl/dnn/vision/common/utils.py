# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Common utilities across classification and object detection.'''

from .constants import RunPropertyLiterals


def _add_run_properties(run, best_metric):
    if run is None:
        raise ValueError('run is None')
    properties_to_add = {RunPropertyLiterals.PIPELINE_SCORE: best_metric}
    run.add_properties(properties_to_add)
