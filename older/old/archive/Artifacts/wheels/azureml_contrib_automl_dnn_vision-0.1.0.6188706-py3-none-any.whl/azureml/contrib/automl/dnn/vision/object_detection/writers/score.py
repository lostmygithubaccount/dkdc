# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Functions for inference using a trained model'''

import os
import pickle
import json
from torch.utils.data import Dataset, DataLoader
from torchvision.transforms import functional
import torch
from PIL import Image
from ..common.constants import ArtifactLiterals
from azureml.core.experiment import Experiment
from azureml.core.run import Run


class PredictionDataset(Dataset):
    '''Dataset for inference.'''

    def __init__(self, root_dir=None, image_list_file=None):
        '''

        :param dirname: Directory containing images to be labeled
        :type dirname: String
        '''
        self._files = []
        for filename in open(image_list_file):
            self._files.append(filename.strip())
        # remove blank strings
        self._files = [f for f in self._files if f]
        self._root_dir = root_dir

    def __len__(self):
        '''Get number of images.

        :return: Number of images
        :rtype: Int
        '''
        return len(self._files)

    def __getitem__(self, idx):
        '''Get image by index

        :param idx: Index of image to get
        :type idx: Int
        :return: Filename and Image
        :rtype: (String, Pytorch Tensor)
        '''

        filename = self._files[idx]
        image = Image.open(os.path.join(self._root_dir, self._files[idx]))
        return filename, functional.to_tensor(image)


def _load_model_wrapper(torch_model_file, model_wrapper_pkl):

    with open(model_wrapper_pkl, 'rb') as fp:
        model_wrapper = pickle.load(fp)

    model_weights = torch.load(torch_model_file)
    model_wrapper.restore_model(model_weights)

    return model_wrapper


def _fetch_model_from_artifacts(run_id, experiment_name=None):
    current_experiment = Run.get_context().experiment

    if experiment_name is None:
        experiment = current_experiment
    else:
        workspace = current_experiment.workspace
        experiment = Experiment(workspace, experiment_name)

    run = Run(experiment=experiment, run_id=run_id)

    run.download_file(os.path.join(ArtifactLiterals.OUTPUT_DIR, ArtifactLiterals.MODEL_FILE_NAME),
                      ArtifactLiterals.MODEL_FILE_NAME)
    run.download_file(os.path.join(ArtifactLiterals.OUTPUT_DIR, ArtifactLiterals.PICKLE_FILE_NAME),
                      ArtifactLiterals.PICKLE_FILE_NAME)

    return _load_model_wrapper(ArtifactLiterals.MODEL_FILE_NAME,
                               ArtifactLiterals.PICKLE_FILE_NAME)


def _test_fetch_model(model_file, model_wrapper_pkl):
    return _load_model_wrapper(model_file, model_wrapper_pkl)


def _score_with_model(model_wrapper, output_file, root_dir, image_list_file, target_device=None, batch_size=1):

    model = model_wrapper.model
    classes = model_wrapper.classes
    model.eval()

    device = "cuda:0" if torch.cuda.is_available() else "cpu"
    model.to(device)

    dataset = PredictionDataset(root_dir=root_dir, image_list_file=image_list_file)
    dataloader = DataLoader(dataset,
                            batch_size=batch_size)

    bounding_boxes = []
    box_keys = ['topX', 'topY', 'bottomX', 'bottomY']

    with torch.no_grad():
        with open(output_file, "w") as fw:
            for filenames, image_batch in dataloader:
                image_batch = image_batch.to(device)
                labels = model(image_batch)
                __, _, height, width = image_batch.shape

                for filename, label in zip(filenames, labels):
                    for box, label_index, score in zip(
                            label['boxes'], label['labels'], label['scores']):
                        box_dims = dict(zip(box_keys, [coordinate.item() for coordinate in box]))

                        box_dims['topX'] = box_dims['topX'] * 1.0 / width
                        box_dims['bottomX'] = box_dims['bottomX'] * 1.0 / width
                        box_dims['topY'] = box_dims['topY'] * 1.0 / height
                        box_dims['bottomY'] = box_dims['bottomY'] * 1.0 / height

                        box_record = {'box': box_dims,
                                      'label': classes[label_index],
                                      'score': score.item()}

                        bounding_boxes.append(box_record)

                    annotation = {'filename': filename,
                                  'boxes': bounding_boxes}

                    fw.write('{}\n'.format(json.dumps(annotation)))


def score(run_id, experiment_name=None, output_file=None, root_dir=None, image_list_file=None, batch_size=1):
    '''Load model and infer on new data

    :param run_id: Name of the run to load model from
    :type run_id: String
    :param experiment_name: Name of experiment to load model from
    :type experiment_name: String
    :param output_file: Name of file to write results to
    :type output_file: String
    :param root_dir: prefix to be added to the paths contained in image_list_file
    :type root_dir: str
    :param image_list_file: path to file containing list of images
    :type image_list_file: str
    :batch_size: Inference batch size
    :type batch_size: Int
    '''

    model_wrapper = _fetch_model_from_artifacts(run_id, experiment_name)
    _score_with_model(model_wrapper, output_file, root_dir, image_list_file, batch_size)


def _score_from_files(weights_file, wrapper_file, output_file, root_dir, image_list_file, batch_size):

    model_wrapper = _test_fetch_model(weights_file, wrapper_file)
    _score_with_model(model_wrapper, output_file, root_dir, image_list_file, batch_size)
