# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Classes that wrap training steps'''

import torch
import copy
import time
from ..eval import cocotools
from ..common import boundingbox
from ..common.constants import TrainingParameters
from ..writers import utils
from ...common.utils import _add_run_properties


class train_settings:
    '''Settings for training.'''

    def __init__(self, **kwargs):
        '''

        :params **kwargs: Optional training parameters. Currently supports
          -number_of_epochs: Number of epochs to train for (int)
          -max_patience_iteratations: Number of epochs with no validation
          improvement before stopping.
        :type **kwargs: Dictionary
        '''

        self._number_of_epochs = kwargs.get(
            'number_of_epochs', TrainingParameters.DEFAULT_NUMBER_EPOCHS)
        self._max_patience_iterations = kwargs.get(
            'max_patience_iterations', TrainingParameters.DEFAULT_PATIENCE_ITERATIONS)

    @property
    def number_of_epochs(self):
        '''Get number of epochs

        :return: number_of_epochs
        :rtype: int
        '''
        return self._number_of_epochs

    @property
    def max_patience_iteratations(self):
        '''Get number of patience iterations

        :return: max_patience_iteratations
        :rtype: int
        '''
        return self._max_patience_iterations


def move_images_to_device(images, device):
    '''Convenience function to move images to device (gpu/cpu).

    :param images: Batch of images
    :type images: Pytorch tensor
    :param device: Target device
    :type device: Pytorch device
    '''

    return [image.to(device) for image in images]


def move_targets_to_device(targets, device):
    '''Convenience function to move training targets to device (gpu/cpu)

    :param targets: Batch Training targets (bounding boxes and classes)
    :type targets: Dictionary
    :param device: Target device
    :type device: Pytorch device
    '''

    return [{k: v.to(device) for k, v in target.items()} for
            target in targets]


def train_one_epoch(model, optimizer, scheduler, train_data_loader, device, criterion, epoch, print_freq):
    '''Train a model for one epoch

    :param model: Model to be trained
    :type model: Pytorch nn.Module
    :param optimizer: Optimizer used in training
    :type optimizer: Pytorch optimizer
    :param scheduler: Learning Rate Scheduler
    :type scheduler: Pytorch Learning Rate Scheduler
    :param train_data_loader: Data loader for training data
    :type train_data_loader: Pytorch data loader
    :param device: Target device
    :type device: Pytorch device
    :param criterion: Loss function wrapper
    :type criterion: Object derived from BaseCriterionWrapper (see
    object_detection.train.criterion)
    :param epoch: Current training epoch
    :type epoch: int
    :param print_freq: How often you want to print the output
    :type print_freq: int
    '''

    batch_time = utils.AverageMeter()
    data_time = utils.AverageMeter()
    losses = utils.AverageMeter()
    megabyte = 1024.0 * 1024.0

    model.train()

    end = time.time()
    for i, (images, targets, info) in enumerate(train_data_loader):
        # measure data loading time
        data_time.update(time.time() - end)

        images = move_images_to_device(images, device)
        targets = move_targets_to_device(targets, device)

        loss_dict = criterion.evaluate(model, images, targets)
        loss = sum(loss_dict.values())
        loss_value = loss.item()

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # record loss and measure elapsed time
        losses.update(loss_value, len(images))
        batch_time.update(time.time() - end)
        end = time.time()

        if i % print_freq == 0 or i == len(train_data_loader) - 1:
            if torch.cuda.is_available():
                print('Epoch: [{0}][{1}/{2}]\t'
                      'lr: {3}\t'
                      'Max Mem: {4:.0f}\t'
                      'Time {batch_time.value:.4f} ({batch_time.avg:.4f})\t'
                      'Data {data_time.value:.4f} ({data_time.avg:.4f})\t'
                      'Loss {loss.value:.4f}'
                      ' ({loss.avg:.4f})\t'.format(epoch, i,
                                                   len(train_data_loader), optimizer.param_groups[0]["lr"],
                                                   torch.cuda.max_memory_allocated() / megabyte,
                                                   batch_time=batch_time, data_time=data_time, loss=losses))
            else:
                print('Epoch: [{0}][{1}/{2}]\t'
                      'lr: {3}\t'
                      'Time {batch_time.value:.4f} ({batch_time.avg:.4f})\t'
                      'Data {data_time.value:.4f} ({data_time.avg:.4f})\t'
                      'Loss {loss.value:.4f} ({loss.avg:.4f})\t'.format(epoch, i, len(train_data_loader),
                                                                        optimizer.param_groups[0]["lr"],
                                                                        batch_time=batch_time,
                                                                        data_time=data_time, loss=losses))

    scheduler.step()


def validate(model, val_data_loader, device, val_index_map):
    '''Gets model results on validation set.

    :param model: Model to score
    :type mode: Pytorch nn.Module
    :param val_data_loader: Data loader for validation data
    :type val_data_loader: Pytorch Data Loader
    :param device: Target device
    :type device: Pytorch device
    :param val_index_map: Map from numerical indices to class names
    :type val_index_map: List of strings
    :returns: List of detections
    :rtype: List of ImageBoxes (see object_detection.common.boundingbox)
    '''

    batch_time = utils.AverageMeter()
    megabyte = 1024.0 * 1024.0

    model.eval()

    bounding_boxes = []
    end = time.time()
    with torch.no_grad():
        for i, (images, targets, info) in enumerate(val_data_loader):
            images = move_images_to_device(images, device)

            labels = model(images)

            for info, label in zip(info, labels):
                image_boxes = boundingbox.ImageBoxes(
                    info['filename'], val_index_map)

                image_boxes.add_boxes(label['boxes'],
                                      label['labels'],
                                      label['scores'])

                bounding_boxes.append(image_boxes)

            # measure elapsed time
            batch_time.update(time.time() - end)
            end = time.time()

            if i % 100 == 0 or i == len(val_data_loader) - 1:
                if torch.cuda.is_available():
                    print('Test: [{0}/{1}]\t'
                          'Max Mem: {2:.0f}\t'
                          'Time {batch_time.value:.4f}'
                          ' ({batch_time.avg:.4f})\t'.format(i, len(val_data_loader),
                                                             torch.cuda.max_memory_allocated() / megabyte,
                                                             batch_time=batch_time))
                else:
                    print('Test: [{0}/{1}]\t'
                          'Time {batch_time.value:.4f} ({batch_time.avg:.4f})\t'.format(i, len(val_data_loader),
                                                                                        batch_time=batch_time))

    return bounding_boxes


def train(model, optimizer, scheduler,
          train_data_loader, device, criterion,
          train_settings, val_data_loader=None, val_coco_index=None,
          val_index_map=None, run=None):
    '''
    Train a model

    :param model: Model to train
    :type model: Object derived from CommonObjectDetectionModelWrapper
    (see object_detection.models.base_model_wrapper)
    :param optimizer: Model Optimizer
    :type optimizer: Pytorch Optimizer
    :param scheduler: Learning Rate Scheduler
    :type scheduler: Pytorch Learning Rate Scheduler
    :param train_data_loader: Data loader with training data
    :type train_data_loader: Pytorch data loader
    :param device: Target device (gpu/cpu)
    :type device: Pytorch Device
    :param criterion: Loss function
    :type criterion: Object dervied from CommonCriterionWrapper (see
    object_detection.train.criterion)
    :param train_settings: Settings for training.
    :type train_settings: train_settings object
    :param val_data_loader (optional): Data loader with validation
    data.
    :type val_data_loader (optional): Pytorch data loader
    :param val_coco_index (optional): Cocoindex created from validation
    data
    :type val_coco_index (optional): Pycocotool Cocoindex object
    :param val_index_map (optional): Map from class indices to class names
    :type val_index_map (optional): List of strings
    :param run: azureml run object
    :type run: azureml.core.run.Run
    :returns: Trained model
    :rtype: Object derived from CommonObjectDetectionModelWrapper
    '''

    base_model = model.model
    base_model.to(device)

    best_score = 0.0
    best_model = copy.deepcopy(base_model.state_dict())

    patience_iterations = 0

    for epoch in range(train_settings.number_of_epochs):

        train_one_epoch(base_model, optimizer, scheduler,
                        train_data_loader, device, criterion, epoch, print_freq=100)

        if val_data_loader is not None:
            bounding_boxes = validate(
                base_model, val_data_loader, device, val_index_map)
            eval_bounding_boxes = cocotools.prepare_bounding_boxes_for_coco(bounding_boxes)
            if not eval_bounding_boxes:
                print('no detected bboxes for evaluation')
            score = cocotools.score_from_index(val_coco_index, eval_bounding_boxes)

            patience_iterations += 1

            if score[0] > best_score:
                best_model = copy.deepcopy(base_model.state_dict())
                patience_iterations = 0
                best_score = score[0]

            if patience_iterations > train_settings.max_patience_iteratations:
                break
            if run is not None:
                run.log('MAP', score[0])

    base_model.load_state_dict(best_model)
    if run is not None:
        _add_run_properties(run, best_score)
