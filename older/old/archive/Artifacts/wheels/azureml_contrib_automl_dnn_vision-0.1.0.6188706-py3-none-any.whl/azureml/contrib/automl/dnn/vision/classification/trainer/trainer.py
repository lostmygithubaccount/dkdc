# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Training functions.'''

import copy
try:
    import torch
except ImportError:
    print('ImportError: torch not installed. If on windows, install torch, pretrainedmodels, torchvision and '
          'pytorch-ignite separately before running the package.')

from ..common.constants import TrainingLiterals
from ..common.transforms import _get_common_train_transforms, _get_common_valid_transforms
from ..common.utils import _split_train_val
from ...metrics import ClassificationMetrics
from ..models import ModelFactory
from ..io.read.dataloader import _get_data_loader
from .optimize import _get_criterion, _get_optimizer
from ...common.utils import _add_run_properties


def train_model(model_name, strategy=None, dataset_wrapper=None, valid_dataset=None, device=None,
                train_transforms=None, valid_transforms=None, azureml_run=None,
                settings=None):
    '''

    :param model_name: name of model
    :type model_name: str
    :param strategy: strategy
    :type strategy: str
    :param dataset_wrapper: datasetwrapper object for training
    :type dataset_wrapper: azureml.automl.contrib.dnn.vision.io.read.DatasetWrapper
    :param valid_dataset: datasetwrapper object for validation
    :type valid_dataset: azureml.contrib.automl.dnn.vision.io.read.DatasetWrapper
    :param device: device where model should be run (usually 'cpu' or 'cuda:0' if it is the first gpu
    :type device: str
    :param train_transforms: transformation function to apply to a pillow image object
    :type train_transforms: function
    :param valid_transforms: transformation function to apply to a pillow image object
    :type valid_transforms: function
    :param azureml_run: azureml run object
    :type azureml_run: azureml.core.Run
    :param settings: dictionary containing settings for training
    :type settings: dict
    :return: model wrapper object
    :rtype: azureml.contrib.automl.dnn.vision.models.base_model_wrapper.ModelWrapper
    '''
    if any([strategy is None, dataset_wrapper is None, settings is None]):
        raise ValueError('one of required args is None')

    multilabel = settings.get(TrainingLiterals.MULTILABEL, False)

    model_wrapper = ModelFactory.get_model_wrapper(model_name, num_classes=dataset_wrapper.num_classes,
                                                   multilabel=multilabel)
    model_wrapper.model = model_wrapper.model.to(device)

    num_epochs = settings[TrainingLiterals.NUM_EPOCHS]

    patience = settings[TrainingLiterals.EARLY_STOPPING_PATIENCE]
    batch_size = settings[TrainingLiterals.BATCH_SIZE]

    metrics = ClassificationMetrics(num_classes=dataset_wrapper.num_classes, multilabel=multilabel)

    optimizer = _get_optimizer(model_wrapper, strategy=strategy)
    criterion = _get_criterion(multilabel=multilabel)

    best_model_wts = copy.deepcopy(model_wrapper.model.state_dict())
    best_metric = 0

    if valid_dataset is None:
        train_indices, test_indices = _split_train_val(dataset_wrapper, settings[TrainingLiterals.TEST_RATIO],
                                                       multilabel=multilabel)

    primary_metric = settings[TrainingLiterals.PRIMARY_METRIC]

    no_progress_counter = 0
    for epoch in range(num_epochs):
        print('Running epoch {}'.format(epoch))
        if valid_dataset is None:
            train_dataloader, valid_dataloader = _get_train_test_dataloaders(
                dataset_wrapper,
                resize_to_size=model_wrapper.resize_to_size,
                crop_size=model_wrapper.crop_size,
                train_indices=train_indices,
                test_indices=test_indices,
                train_transforms=train_transforms,
                valid_transforms=valid_transforms,
                batch_size=batch_size
            )
        else:
            train_dataloader, valid_dataloader = _get_train_test_dataloaders(
                dataset_wrapper,
                valid_dataset=valid_dataset,
                resize_to_size=model_wrapper.resize_to_size,
                crop_size=model_wrapper.crop_size,
                train_transforms=train_transforms,
                valid_transforms=valid_transforms,
                batch_size=batch_size
            )

        _train(model_wrapper, dataloader=train_dataloader, criterion=criterion, optimizer=optimizer, device=device)
        _validate(model_wrapper, dataloader=valid_dataloader, metrics=metrics, device=device)
        computed_metrics = metrics.compute()

        if computed_metrics[primary_metric] > best_metric:
            best_metric = computed_metrics[primary_metric]
            best_model_wts = copy.deepcopy(model_wrapper.model.state_dict())
            no_progress_counter = 0
        else:
            no_progress_counter += 1

        print('current best metric {}'.format(best_metric))
        if azureml_run is not None:
            _log_all_metrics(computed_metrics, run=azureml_run)
        metrics.reset()

        if no_progress_counter >= patience:
            break

    model_wrapper.model.load_state_dict(best_model_wts)
    if azureml_run is not None:
        _add_run_properties(azureml_run, best_metric)

    # set transformations on model wrapper object
    if valid_transforms is None:
        valid_transforms = _get_common_valid_transforms(
            resize_to=model_wrapper.resize_to_size,
            crop_size=model_wrapper.crop_size
        )
    model_wrapper.transforms = valid_transforms

    return model_wrapper


def _get_train_test_dataloaders(
        dataset,
        valid_dataset=None,
        resize_to_size=None,
        crop_size=None,
        train_indices=None,
        test_indices=None,
        train_transforms=None,
        valid_transforms=None,
        batch_size=None):
    if train_transforms is None:
        train_transforms = _get_common_train_transforms(crop_size)

    if valid_transforms is None:
        valid_transforms = _get_common_valid_transforms(resize_to=resize_to_size, crop_size=crop_size)

    if valid_dataset is None:
        train_dataloader = _get_data_loader(dataset, indices=train_indices, transform_fn=train_transforms,
                                            batch_size=batch_size)
        valid_dataloader = _get_data_loader(dataset, indices=test_indices, transform_fn=valid_transforms,
                                            batch_size=batch_size)
    else:
        train_dataloader = _get_data_loader(dataset, transform_fn=train_transforms, batch_size=batch_size)
        valid_dataloader = _get_data_loader(valid_dataset, transform_fn=valid_transforms, batch_size=batch_size)

    return train_dataloader, valid_dataloader


def _log_all_metrics(computed_metrics, run=None):
    if run is None:
        raise ValueError('run is None')

    for metric_name, value in computed_metrics.items():
        run.log(metric_name, value)


def _train(
        model_wrapper,
        dataloader=None,
        criterion=None,
        optimizer=None,
        device=None):
    model_wrapper.model.train()
    current_loss = 0
    for inputs, labels in dataloader:
        inputs = inputs.to(device)
        labels = labels.to(device)

        optimizer.zero_grad()

        with torch.set_grad_enabled(True):
            outputs = model_wrapper.model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            current_loss += loss.item() * inputs.shape[0]
    print('Loss at end of epoch: {}'.format(current_loss))


def _validate(model_wrapper, dataloader=None, metrics=None, device=None):
    model_wrapper.model.eval()
    with torch.no_grad():
        for inputs, labels in dataloader:
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = model_wrapper.model(inputs)
            probs = model_wrapper.predict_proba_from_outputs(outputs)
            preds = model_wrapper.predict_from_outputs(outputs)
            metrics.update(probs=probs, preds=preds, labels=labels)

    return metrics
