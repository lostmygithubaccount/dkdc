# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Helper classes that define object detection model behavior.'''

from abc import ABC, abstractmethod

from ..common.constants import OutputFields


class PredictBoundingBoxMixin:
    '''Helper class that defines required bounding box methods'''

    def predict(self, inputs):
        '''Predicts bounding boxes from images.

        :param inputs: Batch of images
        :type inputs: Pytorch Tensor
        :return: Lists of bounding boxes, labels, and confidence
        scores
        :rtype: Tuple of lists of form (Boxes, Labels, Scores)
        '''

        if self.transforms is not None:
            inputs = self.transforms(inputs)

        outputs = self.model(inputs)

        return self._get_boxes(outputs)

    def _get_boxes(self, outputs):

        boxes = outputs[OutputFields.BOXES_LABEL]
        labels = outputs[OutputFields.CLASSES_LABEL]
        scores = outputs[OutputFields.SCORES_LABEL]

        return boxes, labels, scores


class BaseObjectDetectionModelWrapper(ABC, PredictBoundingBoxMixin):
    '''Abstract base class that defines behavior of object detection models.'''

    def __init__(self, model=None, number_of_classes=None, specs=None, **kwargs):
        '''

        :param model: Model to wrap
        :type model: Pytorch nn.Module
        :param number_of_classes: Number of object classes
        :type number_of_classes: Int
        :param specs: Model speifications
        :type specs: Class contianing specifications
        :param **kwargs: Keyword arguments
        :type **kwargs: Dictionary
        '''
        self._transforms = None
        self._model = model
        self._specs = specs
        self._number_of_classes = number_of_classes
        self._classes = None

    @abstractmethod
    def _create_model(self, number_of_classes, specs):
        '''Abstract method defining how to create a model from
        number of classes required and model specific specifications.

        :param number_of_classes: Number of classes
        :type number_of_classes: Int
        :param specs: Model specific specifications
        :type specs: Class contianing specifications
        '''
        pass

    def restore_model(self, model_dict=None):
        '''Restores a saved model state.

        :param model_dict (optional): Saved pytorch dict with model weights
        :type model_dict: Pytorch state dict
        '''
        self._model = self._create_model(self._number_of_classes,
                                         self._specs)

        if model_dict is not None:
            self._model.load_state_dict(model_dict)

    @property
    def model(self):
        '''Get pytorch model from wrapper

        :return: Model
        :rtype: Pytorch nn.Module
        '''
        return self._model

    @model.setter
    def model(self, value):
        '''Set pytorch model in wrapper

        :param value: Model to set
        :type value: Pytorch nn.Module
        '''
        self._model = value

    @property
    def transforms(self):
        '''Get image transforms

        :return: Image transforms
        :rtype: Function
        '''
        return self._transforms

    @transforms.setter
    def transforms(self, value):
        '''Set image transforms

        :param value: Transforms to apply to image
        :type value: Function
        '''
        self._transforms = value

    @property
    def parameters(self):
        '''Get model parameters

        :return: Model parameters
        :rtype: Pytorch state dictionary
        '''
        return self._model.parameters

    @property
    def classes(self):
        '''Get the classes in a list that corresponds
        to class index

        :return: List of class names. If none is set, will
        simply return ['0', '1', '2',....]
        :rtype: List of strings
        '''
        if self._classes is not None:
            return self._classes
        else:
            numeric_map = [str(i) for i in range(self._number_of_classes)]
            return numeric_map

    @classes.setter
    def classes(self, classes):
        '''Set the image classes

        :param classes: Names of the different classes found in image
        :type classes: List of strings
        '''
        self._classes = classes
