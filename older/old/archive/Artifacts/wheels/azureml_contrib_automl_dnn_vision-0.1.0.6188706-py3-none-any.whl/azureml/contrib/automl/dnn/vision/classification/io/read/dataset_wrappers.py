# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Defines dataset wrapper class. To add a new dataset, implement the BaseDatasetWrapper interface.'''

from abc import ABC, abstractmethod
import csv
import itertools
import os
from PIL import Image
try:
    from torch.utils.data import Dataset
    from torchvision.datasets import ImageFolder
except ImportError:
    print('ImportError: torch not installed. If on windows, install torch, pretrainedmodels, torchvision and '
          'pytorch-ignite separately before running the package.')


class BaseDatasetWrapper(ABC, Dataset):
    '''A wrapper class that provides exposes string labels and number of classes for a torch.utils.Dataset.

    Inheriting classes should call the base constructor.
    '''
    def __init__(self, labels=None, multilabel=False):
        '''Constructor

        :param labels: list of labels
        :type labels: list[str]
        '''
        self.reset_labels(labels)
        self.__multilabel = multilabel

    @abstractmethod
    def __len__(self):
        '''

        :return: number of items in dataset
        :rtype: int
        '''
        pass

    @abstractmethod
    def item_at_index(self, index):
        '''Return image at index.

        :param index: index
        :type index: int
        :return: pillow image object
        :rtype: Image
        '''
        pass

    @abstractmethod
    def label_at_index(self, index):
        '''Return label at index.

        :param index: index
        :type index: int
        :return: string label or list of string labels if multilabel
        :rtype: str or list[str]
        '''
        pass

    def __getitem__(self, index):
        '''Get item at index from the dataset.

        :param index: index in the dataset
        :type index: int
        :return: Tuple (tensor, label) where label is an int or list of ints for multilabel
        :rtype: tuple[torch.Tensor, type] where type is int or [int]
        '''
        integer_labels = None
        if self.__multilabel:
            integer_labels = [self.label_to_index_map[i] for i in self.label_at_index(index)]
        else:
            integer_labels = self.label_to_index_map[self.label_at_index(index)]
        return (self.item_at_index(index), integer_labels)

    @property
    def index_to_label(self):
        '''List of labels.'''
        return self.__labels

    @property
    def label_to_index_map(self):
        '''Dictionary from string labels to integers.'''
        return self.__labels_to_num

    @property
    def labels(self):
        '''Return list of string labels.'''
        return self.__labels

    @property
    def multilabel(self):
        '''Boolean flag indicating whether this is a multilabel dataset.'''
        return self.__multilabel

    @property
    def num_classes(self):
        '''

        :return: number of classes
        :rtype: int
        '''
        return len(self.__labels_to_num)

    def reset_labels(self, labels):
        '''

        :param labels: list of labels
        :type labels: list[str]
        '''
        self.__labels_to_num = dict([(label_name, i) for i, label_name in enumerate(labels)])
        self.__labels = labels


class _CommonImageDatasetWrapper(BaseDatasetWrapper):
    '''Utility class for getting the DatasetWrapper class once the image files, labels and whether this is multilabel
    dataset are known.

    '''
    def __init__(self, files_to_labels_dict=None, all_labels=None, multilabel=False):
        '''

        :param files_to_labels_dict: dictionary of file names to labels
        :type files_to_labels_dict: dict
        :param all_labels: list of all labels if there are more labels than those that are in files_to_labels_dict
        :type all_labels: list[str]
        :param multilabel: boolean flag on whether this is multilabel task
        :type multilabel: bool
        '''
        self.__files_to_labels_dict = files_to_labels_dict
        self.__files = list(files_to_labels_dict.keys())
        uniq_labels = all_labels if all_labels is not None else self.__get_uniq_labels(files_to_labels_dict)

        super().__init__(labels=list(uniq_labels), multilabel=multilabel)

    def __len__(self):
        return len(self.__files)

    def __get_uniq_labels(self, files_to_labels_dict):
        if isinstance(next(iter(files_to_labels_dict.values())), list):
            return list(set(list(itertools.chain.from_iterable(files_to_labels_dict.values()))))
        else:
            return list(set(files_to_labels_dict.values()))

    def item_at_index(self, index):
        filename = self.__files[index]
        return Image.open(filename).convert('RGB')

    def label_at_index(self, index):
        filename = self.__files[index]
        return self.__files_to_labels_dict[filename]


class ImageFolderDatasetWrapper(_CommonImageDatasetWrapper):
    '''DatasetWrapper for image folders.

    '''
    def __init__(self, root_dir=None, all_labels=None):
        '''

        :param root_dir: Root directory below which there are subdirectories per label.
        :type root_dir: str
        :param all_labels: list of all labels provided if the list of labels is different from those in input_file
        :type all_labels: list[str]
        '''
        _, labels = self._generate_labels_files_from_imagefolder(root_dir)
        return super().__init__(files_to_labels_dict=labels, all_labels=all_labels)

    def _generate_labels_files_from_imagefolder(self, root_dir):
        folder = ImageFolder(root_dir, loader=lambda x: x)
        files = []
        labels = {}
        for i in range(len(folder)):
            file_path, label = folder[i]
            files.append(file_path)
            labels[file_path] = folder.classes[label]

        return files, labels


class ImageFolderLabelFileDatasetWrapper(_CommonImageDatasetWrapper):
    '''DatasetWrapper for folder plus labels file.

    '''
    column_separator = '\t'
    label_separator = ','

    def __init__(self, root_dir=None, input_file=None, all_labels=None, multilabel=False):
        '''

        :param root_dir: root directory containing all images
        :type root_dir: str
        :param input_file: path to label file containing name of the image and list of labels
        :type input_file: str
        :param all_labels: list of all labels provided if the list of labels is different from those in input_file
        :type all_labels: list[str]
        :param multilabel: flag for multilabel
        :type multilabel: bool
        '''
        labels_dict = self._get_files_to_labels_dict(root_dir=root_dir, input_file=input_file, multilabel=multilabel)

        # add missing labels in labels_list to this list
        augmented_all_labels = None if all_labels is None else list(all_labels)
        if all_labels is not None:
            # if there is a label in labels_dict not in labels, then error out
            if multilabel:
                set_found_labels = set(list(itertools.chain.from_iterable(labels_dict.values())))
            else:
                set_found_labels = set(labels_dict.values())

            set_all_labels = set(all_labels)
            new_labels = set_found_labels.difference(set_all_labels)
            if len(new_labels):
                augmented_all_labels.extend([label for label in new_labels])

        return super().__init__(files_to_labels_dict=labels_dict, all_labels=augmented_all_labels,
                                multilabel=multilabel)

    def _get_files_to_labels_dict(self, root_dir=None, input_file=None, multilabel=False):
        files_to_labels_dict = {}
        with open(input_file, newline='') as csvfile:
            csv_reader = csv.reader(csvfile, delimiter=ImageFolderLabelFileDatasetWrapper.column_separator,
                                    skipinitialspace=True)
            for row in csv_reader:
                if len(row) > 2:
                    raise ValueError('More than 2 columns encountered in {}'.format(input_file))
                if row:
                    filename, file_labels = row
                    files_labels_as_list = [
                        x
                        for x in list(csv.reader([file_labels],
                                                 delimiter=ImageFolderLabelFileDatasetWrapper.label_separator,
                                                 quotechar='\'',
                                                 skipinitialspace=True))[0]
                    ]
                    full_path = os.path.join(root_dir, filename)
                    if multilabel:
                        files_to_labels_dict[full_path] = files_labels_as_list
                    else:
                        if len(files_labels_as_list) > 1:
                            raise ValueError('Encountered multilabel in input data')
                        files_to_labels_dict[full_path] = files_labels_as_list[0]

        return files_to_labels_dict


class OverSamplingDatasetWrapper(BaseDatasetWrapper):
    '''Takes a datasetwrapper and oversamples to make sure the class sizes are balanced.

    '''
    def __init__(self, dataset_wrapper):
        '''

        :param dataset_wrapper: datasetwrapper object implementing BaseDatasetWrapper
        :type dataset_wrapper: azureml.contrib.automl.dnn.vision.classification.io.read.BaseDatasetWrapper
        '''
        label_to_indices_dict = self._get_samples_by_classes(dataset_wrapper)
        oversampling_ratios = self._get_oversampling_ratios(label_to_indices_dict, dataset_wrapper)
        num_labels = len(oversampling_ratios)

        self._total_size = 0
        label_sizes = [len(label_to_indices_dict[i]) for i in range(num_labels)]
        for i in label_to_indices_dict.keys():
            self._total_size += oversampling_ratios[i] * label_sizes[i]

        # generate new indices
        self._indices = []
        self._labels = []

        for i in range(num_labels):
            self._indices.extend(label_to_indices_dict[i] * oversampling_ratios[i])
            self._labels.extend([dataset_wrapper.labels[i]] * label_sizes[i] * oversampling_ratios[i])

        self._dataset_wrapper = dataset_wrapper

    def _get_samples_by_classes(self, dataset_wrapper):
        '''

        :param dataset_wrapper: datasetwrapper object implementing BaseDatasetWrapper
        :type dataset_wrapper: azureml.contrib.automl.dnn.vision.classification.io.read.BaseDatasetWrapper
        :return: dictionary of labels to list of indices
        :rtype: dict[int, list[int]]
        '''
        label_to_indices_dict = {}
        label_str_to_index = {}
        for i, label in enumerate(dataset_wrapper.labels):
            label_to_indices_dict[i] = []
            label_str_to_index[label] = i

        for i in range(len(dataset_wrapper)):
            label_to_indices_dict[label_str_to_index[dataset_wrapper.label_at_index(i)]].append(i)

        return label_to_indices_dict

    def _get_oversampling_ratios(self, label_to_indices_dict, dataset_wrapper):
        '''

        :param label_to_indices_dict: dictionary of labels to list of indices
        :type label_to_indices_dict: dict[int, list[int]]
        :param dataset_wrapper: object of type BaseDatasetWrapper
        :type dataset_wrapper: azureml.contrib.automl.dnn.vision.classification.io.read.BaseDatasetWrapper
        :return: list of oversampling ratios by label
        :rtype: list[int]
        '''
        num_labels = len(dataset_wrapper.labels)

        label_sizes = []
        for i in range(num_labels):
            label_sizes.append(len(label_to_indices_dict[i]))

        max_label_size = max(label_sizes)

        over_sampling_ratios = [0] * num_labels

        # now oversample other classes
        for i in range(num_labels):
            if label_sizes[i] != 0:
                over_sampling_ratios[i] = int(max_label_size / label_sizes[i])

        return over_sampling_ratios

    def __len__(self):
        '''

        :return: number of items in dataset
        :rtype: int
        '''
        return self._total_size

    def item_at_index(self, index):
        '''Return image at index.

        :param index: index
        :type index: int
        :return: pillow image object
        :rtype: Image
        '''
        return self._dataset_wrapper.item_at_index(self._indices[index])

    def label_at_index(self, index):
        '''Return label at index.

        :param index: index
        :type index: int
        :return: string label or list of string labels if multilabel
        :rtype: str or list[str]
        '''
        return self._dataset_wrapper.label_at_index(self._indices[index])
