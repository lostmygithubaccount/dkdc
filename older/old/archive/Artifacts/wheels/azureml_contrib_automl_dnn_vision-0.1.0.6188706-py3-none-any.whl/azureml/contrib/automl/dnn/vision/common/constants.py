# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Constants for the package.'''


class RunPropertyLiterals:
    '''String keys important for finding the best run.'''
    PIPELINE_SCORE = 'score'


class PretrainedModelNames:
    '''Pre trained model names.'''
    RESNET18 = 'resnet18'
    RESNET50 = 'resnet50'
    MOBILENET_V2 = 'mobilenet_v2'
    SE_RESNEXT50_32X4D = 'se_resnext50_32x4d'
    FASTERRCNN_RESNET50_FPN_COCO = 'fasterrcnn_resnet50_fpn_coco'


class PretrainedModelUrls:
    '''The urls of the pretrained models which are stored in the CDN.'''

    MODEL_FOLDER_RUL = 'https://automlcesdkdataresources.blob.core.windows.net/models-vision-pretrained'

    MODEL_URLS = {
        PretrainedModelNames.RESNET18:
        '{}/{}'.format(MODEL_FOLDER_RUL, 'resnet18-5c106cde.pth'),
        PretrainedModelNames.RESNET50:
        '{}/{}'.format(MODEL_FOLDER_RUL, 'resnet50-19c8e357.pth'),
        PretrainedModelNames.MOBILENET_V2:
        '{}/{}'.format(MODEL_FOLDER_RUL, 'mobilenet_v2-b0353104.pth'),
        PretrainedModelNames.SE_RESNEXT50_32X4D:
        '{}/{}'.format(MODEL_FOLDER_RUL, 'se_resnext50_32x4d-a260b3a4.pth'),
        PretrainedModelNames.FASTERRCNN_RESNET50_FPN_COCO:
        '{}/{}'.format(MODEL_FOLDER_RUL, 'fasterrcnn_resnet50_fpn_coco-258fb6c6.pth')
    }
