# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Defines literals and constants for the object detection part of the package.'''


class ArtifactLiterals:
    '''Filenames for artifacts.'''
    MODEL_FILE_NAME = "model.pt"
    PICKLE_FILE_NAME = "model_wrapper.pkl"
    OUTPUT_DIR = "train_artifacts"
    SCORE_SCRIPT = "score_script.py"


class CriterionNames:
    '''String names for different loss functions.'''
    FASTER_RCNN = "FASTER_RCNN"


class DataLoaderParameters:
    '''Default parameters for dataloaders.'''
    DEFAULT_BATCH_SIZE = 4
    DEFAULT_SHUFFLE = True
    DEFAULT_NUM_WORKERS = 4


class DatasetFieldLabels:
    '''Keys for input datasets.'''
    X_0_PERCENT = "topX"
    Y_0_PERCENT = "topY"
    X_1_PERCENT = "bottomX"
    Y_1_PERCENT = "bottomY"
    IS_CROWD = "isCrowd"
    IMAGE_URL = "imageUrl"
    IMAGE_DETAILS = "imageDetails"
    IMAGE_LABEL = "label"
    CLASS_LABEL = "label"
    WIDTH = "width"
    HEIGHT = "height"


class LearningParameters:
    '''Default learning parameters.'''
    SGD_DEFAULT_LEARNING_RATE = 0.005
    SGD_DEFAULT_MOMENTUM = 0.9
    SGD_DEFAULT_WEIGHT_DECAY = 0.0001


class LRSchedulerNames:
    '''String names for scheduler parameters.'''
    DEFAULT_LR_SCHEDULER = 'STEP'
    STEP = 'STEP'


class ModelNames:
    '''String names for model backbones.'''
    FASTER_RCNN_RESNET50_FPN = 'fasterrcnn_resnet50_fpn'
    FASTER_RCNN_RESNET18_FPN = 'fasterrcnn_resnet18_fpn'
    FASTER_RCNN_MOBILENETV2 = 'fasterrcnn_mobilenet_v2'


class OutputFields:
    '''Keys for the outputs of the object detection network.'''
    BOXES_LABEL = 'boxes'
    CLASSES_LABEL = 'labels'
    SCORES_LABEL = 'scores'


class OptimizerNames:
    '''String names and defaults for optimizers.'''
    DEFAULT_OPTIMIZER = 'SGD'
    SGD = 'SGD'


class RCNNBackbones:
    '''String keys for the different faster rcnn backbones.'''
    RESNET_50_FPN_BACKBONE = "resnet50fpn"
    RESNET_18_FPN_BACKBONE = "resnet18fpn"
    RESNET_152_FPN_BACKBONE = "resnet152fpn"
    MOBILENET_V2_BACKBONE = "mobilenet_v2"


class RCNNSpecifications:
    '''String keys for different faster rcnn speficiations'''
    BACKBONE = "backbone"
    DEFAULT_BACKBONE = RCNNBackbones.RESNET_50_FPN_BACKBONE
    RESNET_FPN_BACKBONES = [RCNNBackbones.RESNET_18_FPN_BACKBONE,
                            RCNNBackbones.RESNET_50_FPN_BACKBONE,
                            RCNNBackbones.RESNET_152_FPN_BACKBONE]
    CNN_BACKBONES = [RCNNBackbones.MOBILENET_V2_BACKBONE]


class SchedulerParameters:
    '''Default learning rate scheduler parameters.'''
    DEFAULT_STEP_LR_STEP_SIZE = 5
    DEFAULT_STEP_LR_GAMMA = 0.1


class TrainingParameters:
    '''Default training parameters.'''
    DEFAULT_NUMBER_EPOCHS = 30
    DEFAULT_TRAINING_BATCH_SIZE = 2
    DEFAULT_VALIDATION_BATCH_SIZE = 1
    DEFAULT_PATIENCE_ITERATIONS = 2
