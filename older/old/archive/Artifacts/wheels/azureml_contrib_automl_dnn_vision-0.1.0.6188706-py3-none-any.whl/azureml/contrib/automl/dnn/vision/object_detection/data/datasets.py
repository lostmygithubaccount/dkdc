# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Classes and functions to injest data for object detection.'''

from abc import ABC, abstractmethod
from PIL import Image
import os
from torch.utils.data import Dataset
from collections import defaultdict
import torch
import random
from torchvision.transforms import functional
from ..common.constants import DatasetFieldLabels


def convert_dimension_string(dimension):
    '''Helper function that converts labels to image dimensions

    :param dimension: Description of dimension, suchs "420px"
    :type dimension: string
    :return: Dimension
    :rtype: Int
    '''

    if dimension.endswith("px"):
        return int(dimension[:-2])


class ObjectDetectionDatasetBaseWrapper(ABC, Dataset):
    '''Class the establishes interface for object detection datasets'''

    @abstractmethod
    def __getitem__(self, index):
        '''Get item by index

        :param index: Index of object
        :type index: Inte
        :return: Item at Index
        :rtype: Object Detection Record
        '''
        pass

    @abstractmethod
    def __len__(self):
        '''Get the number of items in dataset

        :return: Number of items in dataset
        :rtype: Int
        '''
        pass

    @property
    @abstractmethod
    def num_classes(self):
        '''Get the number of classes in dataset

        :return: Number of classes
        :rtype: Int
        '''
        pass

    @abstractmethod
    def label_to_index_map(self, label):
        '''Get the index associated with a given class

        :param label: Label name
        :type: String
        :return: Index associated with label
        :rtype: Int
        '''
        pass

    @abstractmethod
    def index_to_label(self, index):
        '''Get the label associated with a certain index

        :param index: Index
        :type index: Int
        :return: Class name
        :rtype: String
        '''
        pass

    @property
    @abstractmethod
    def classes(self):
        '''Get a list of classes ordered by index.

        :return: List of classes
        :rtype: List of Strings
        '''
        pass


class ObjectAnnotation:
    '''Class that contains all of the information associated with
    a single bounding box.'''

    def __init__(self, image_details, labels):
        '''

        :param image_details: Information about the image,
        must contain image_width and image_height
        :type image_details: Dictionary
        :param labels: Information about the bounding box in
        the image, must contain label, topX, topY, bottomX, bottomY.
        :type labels: Dictionary
        '''

        self._bounding_box = None
        self._label = None
        self._area = None
        self._iscrowd = 0
        self._height = 0
        self._width = 0

        self._init_details(image_details)
        self._init_labels(labels)

    @property
    def bounding_box(self):
        '''Get bounding box coordinates

        :return: Bounding box in form
        [top, left, bottom, right] in pixel coordinates
        :rtype: List of floats
        '''
        return self._bounding_box

    @property
    def label(self):
        '''Get bounding box classification

        :return: Classification for bounding box object
        :rtype: String
        '''
        return self._label

    @property
    def area(self):
        '''Get bounding box area

        :return: Area of bounding box
        :rtype: Float
        '''
        return self._area

    @property
    def iscrowd(self):
        '''Get image is iscrowd

        :return: 0 for not crowd, 1 for crowd
        :rtype: int
        '''
        return self._iscrowd

    @property
    def height(self):
        '''Get height of bounding box

        :return: Height of bounding box
        :rtype: Float
        '''
        return self._height

    @height.setter
    def height(self, value):
        '''Set height of bounding box

        :param value: Height bounding box in pixels
        :type value: Float
        '''
        self._height = value

    @property
    def width(self):
        '''Get width of bounding box

        :return: Width of bounding box
        :rtype: Float
        '''
        return self._width

    @width.setter
    def width(self, value):
        '''Set width of bounding box

        :param value: Width of the bounding box
        :type value: Float
        '''
        self._width = value

    def _init_details(self, image_details):

        if (DatasetFieldLabels.WIDTH not in image_details or
                DatasetFieldLabels.HEIGHT not in image_details):
            raise ValueError("Incomplete Record")

        self.width = convert_dimension_string(
            image_details[DatasetFieldLabels.WIDTH])
        self.height = convert_dimension_string(
            image_details[DatasetFieldLabels.HEIGHT])

    def _init_labels(self, labels):

        if (DatasetFieldLabels.CLASS_LABEL not in labels or
            DatasetFieldLabels.X_0_PERCENT not in labels or
            DatasetFieldLabels.Y_0_PERCENT not in labels or
            DatasetFieldLabels.X_1_PERCENT not in labels or
                DatasetFieldLabels.Y_1_PERCENT not in labels):
            raise ValueError("Incomplete Record")

        self._label = labels[DatasetFieldLabels.CLASS_LABEL]
        x0_percentage = float(labels[DatasetFieldLabels.X_0_PERCENT])
        y0_percentage = float(labels[DatasetFieldLabels.Y_0_PERCENT])
        x1_percentage = float(labels[DatasetFieldLabels.X_1_PERCENT])
        y1_percentage = float(labels[DatasetFieldLabels.Y_1_PERCENT])

        self._bounding_box = [x0_percentage * self._width,
                              y0_percentage * self._height,
                              x1_percentage * self._width,
                              y1_percentage * self._height]

        self._area = (self._bounding_box[2] - self._bounding_box[0]) * \
            (self._bounding_box[3] - self._bounding_box[1])

        self._iscrowd = int(labels[DatasetFieldLabels.IS_CROWD] == 'true')


class CommonObjectDetectionDatasetWrapper(ObjectDetectionDatasetBaseWrapper):
    '''Wrapper for object detection dataset'''

    def __init__(self, annotations=None, image_folder=".", is_train=False, prob=0.5):
        '''

        :param annotations: List of annotations that define dataset
        :type annotations: List of dictionaries
        :param image_folder: target image path
        :type image_folder: str
        :param is_train: which mode (training, inferencing) is the network in?
        :type is_train: boolean
        :param prob: target probability of random horizontal flipping
        :type prob: float
        '''
        self._image_urls = []
        self._annotations = defaultdict(list)
        self._object_classes = []
        self._class_to_index_map = {}
        self._is_train = is_train
        self._prob = prob

        if annotations is not None:
            self._init_dataset(annotations, image_folder)

    def __len__(self):
        '''Get number of records in dataset

        :return: Number of records
        :rtype: Int
        '''
        return len(self._image_urls)

    def __getitem__(self, index):
        '''Get dataset item by index

        :return: Image, bounding box information,
        and image information, with form:
        -Image: Torch tensor
        -Labels: Dictionary with keys 'boxes' and
        'labels', where boxes is a list of lists of pixel coordinates,
        and 'labels' is a list of integers with the class of each bounding box,
        -Image Information: is a dictionary with the image url, image width and
        height, and a list of areas of the different bounding boxes
        :rtype: Tuple of form (Torch Tensor, Dictionary, Dictionary)
        '''
        image_url = self._image_urls[index]

        image = Image.open(image_url).convert('RGB')
        image = functional.to_tensor(image)

        bounding_boxes = []
        classes = []
        areas = []
        iscrowd = []
        height = 0
        width = 0

        for annotation in self._annotations[image_url]:
            bounding_boxes.append(annotation.bounding_box)
            annotation_index = self._class_to_index_map[annotation.label]
            classes.append(annotation_index)
            areas.append(annotation.area)
            iscrowd.append(annotation.iscrowd)
            height = annotation.height
            width = annotation.width

        boxes = torch.as_tensor(bounding_boxes, dtype=torch.float32)
        labels = torch.as_tensor(classes, dtype=torch.int64)

        # TODO - separate class for transform
        # transform
        if self._is_train:
            if random.random() < self._prob:
                height, width = image.shape[-2:]
                image = image.flip(-1)
                boxes[:, [0, 2]] = width - boxes[:, [2, 0]]

        return (image,
                {'boxes': boxes, 'labels': labels},
                {'areas': areas, 'iscrowd': iscrowd, 'filename': image_url,
                 'height': height, 'width': width})

    def _init_dataset(self, annotations, image_folder):

        image_urls = set()
        object_classes = set()

        if not annotations:
            raise ValueError("No annotations to initialize datasets.")

        for annotation in annotations:

            if (DatasetFieldLabels.IMAGE_URL not in annotation or
                DatasetFieldLabels.IMAGE_DETAILS not in annotation or
                    DatasetFieldLabels.IMAGE_LABEL not in annotation):
                continue

            try:
                object_info = ObjectAnnotation(annotation[DatasetFieldLabels.IMAGE_DETAILS],
                                               annotation[DatasetFieldLabels.IMAGE_LABEL])
            except ValueError:
                continue

            image_url = os.path.join(image_folder, annotation[DatasetFieldLabels.IMAGE_URL])
            image_urls.add(image_url)

            self._annotations[image_url].append(object_info)

            object_classes.add(
                annotation[DatasetFieldLabels.IMAGE_LABEL][DatasetFieldLabels.CLASS_LABEL])

        self._object_classes = ['--bg--'] + list(object_classes)    # "-" is smaller than capital letter
        self._object_classes = sorted(self._object_classes, reverse=False)  # make sure --bg-- is mapped to zero index
        self._image_urls = list(image_urls)
        self._class_to_index_map = {object_class: i for
                                    i, object_class in
                                    enumerate(self._object_classes)}

    @property
    def num_classes(self):
        '''Get number of classes in dataset

        :return: Number of classes in dataset
        :rtype: Int
        '''
        return len(self._object_classes)

    @property
    def classes(self):
        '''Get list of classes in dataset

        :return: List of classses
        :rtype: List of strings
        '''
        return self._object_classes

    def label_to_index_map(self, label):
        '''Get mapping from class name to numeric
        class index.

        :param label: Class name
        :type label: String
        :return: Numeric class index
        :rtype: Int
        '''
        return self._index_map[label]

    def index_to_label(self, index):
        '''Get the class name associated with numeric index

        :param index: Numeric class index
        :type index: Int
        :return: Class name
        :rtype: String
        '''
        return self._object_classes[index]

    def train_val_split(self, valid_portion=0.2):
        '''Splits a dataset into two datasets, one for
        training and and for validation

        :param valid_portion (optional): Portion of dataset to
        use for validation. Defaults to 0.2.
        :type valid_portion: Float between 0.0 and 1.0
        :return: Training dataset and validation dataset
        :rtype: Tuple of form (CommonObjectDetectionSubsetWrapper,
        CommonObjectDetectionSubsetWrapper)
        '''
        number_of_samples = len(self._image_urls)
        number_of_validation_samples = int(valid_portion * number_of_samples)

        all_indices = list(range(number_of_samples))
        random.shuffle(all_indices)
        training_indices = all_indices[:-number_of_validation_samples]
        validation_indices = all_indices[-number_of_validation_samples:]

        train_dataset = CommonObjectDetectionSubsetWrapper(
            self, training_indices)

        validation_dataset = CommonObjectDetectionSubsetWrapper(
            self, validation_indices)

        return train_dataset, validation_dataset


class CommonObjectDetectionSubsetWrapper(CommonObjectDetectionDatasetWrapper):
    '''Creates a subset of a larger CommonObjectDetectionDatasetWrapper'''

    def __init__(self, parent_dataset, indices):
        '''

        :param parent_dataset: Dataset to take a subset of
        :type parent_dataset: CommonObjectDetectionDatasetWrapper
        :param indices: Indices to use in subset
        :type indices: List of Ints
        '''
        self._image_urls = parent_dataset._image_urls
        self._annotations = parent_dataset._annotations
        self._object_classes = parent_dataset._object_classes
        self._class_to_index_map = parent_dataset._class_to_index_map
        self._indices = indices
        self._is_train = parent_dataset._is_train

    def _set_indices(self, indices):
        self._indices = indices

    def __len__(self):
        '''Get the number of records in subset

        :return: Number of records
        :rtype: Int
        '''
        return len(self._indices)

    def __getitem__(self, idx):
        '''Get a record at a certain subset index

        :return: Dataset record (see __getitem__
        of CommonObjectDetectionDatasetWrapper)
        :rtype: Tuple (see __getitem__ of
        CommonObjectDetectionDatasetWrapper)
        '''

        index = self._indices[idx]

        return super().__getitem__(index)
