# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Functions to write the model at the end of training.'''

import os
import pickle
import shutil
try:
    import torch
except ImportError:
    print('ImportError: torch not installed. If on windows, install torch, pretrainedmodels, torchvision and '
          'pytorch-ignite separately before running the package.')

from ...common.constants import ArtifactsLiterals
from ...inference import InferenceModelWrapper
from ...common.utils import _CondaUtils


def _write_model(model_wrapper, labels=None, output_conda_file_name=None, output_score_script_name=None,
                 output_featurize_script_name=None, output_dir=None):
    '''Write artifacts.

    :param model_wrapper: model wrapper to output
    :type model_wrapper: azureml.contrib.automl.dnn.vision
    :param output_conda_file_name: path to output conda environment file
    :type output_conda_file_name: str
    :param output_dir: path to output directory
    :type output_dir: str
    '''
    os.makedirs(output_dir, exist_ok=True)
    torch.save(model_wrapper.model, os.path.join(output_dir, ArtifactsLiterals.MODEL_FILE_NAME))

    model_wrapper.model = None
    inference_model_wrapper = InferenceModelWrapper(model_wrapper, labels=labels)
    with open(os.path.join(output_dir, ArtifactsLiterals.MODEL_WRAPPER_PKL), 'wb') as fp:
        pickle.dump(inference_model_wrapper, fp)

    dirname = os.path.dirname(os.path.abspath(__file__))
    if output_conda_file_name is None:
        output_conda_file_name = ArtifactsLiterals.CONDA_YML

    if output_score_script_name is None:
        output_score_script_name = ArtifactsLiterals.SCORE_SCRIPT

    if output_featurize_script_name is None:
        output_featurize_script_name = ArtifactsLiterals.FEATURIZE_SCRIPT

    cd = _CondaUtils.get_conda_dependencies()
    cd.save(os.path.join(output_dir, output_conda_file_name))

    shutil.copy(os.path.join(dirname, ArtifactsLiterals.SCORE_SCRIPT),
                os.path.join(output_dir, output_score_script_name))
    shutil.copy(os.path.join(dirname, ArtifactsLiterals.FEATURIZE_SCRIPT),
                os.path.join(output_dir, output_featurize_script_name))
