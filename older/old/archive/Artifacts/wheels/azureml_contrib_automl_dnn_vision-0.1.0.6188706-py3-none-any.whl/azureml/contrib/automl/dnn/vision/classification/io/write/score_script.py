# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

'''Score images from model produced by another run.'''

from azureml.contrib.automl.dnn.vision.classification.inference.score import score
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--run_id', help='run id of the experiment that generated the model')
parser.add_argument('--experiment_name', help='experiment that ran the run which generated the model')
parser.add_argument('--output_file', help='path to output file')
parser.add_argument('--root_dir', help='path to root dir for files listed in image_list_file')
parser.add_argument('--image_list_file', help='image files list')

args = parser.parse_args()

score(args.run_id, experiment_name=args.experiment_name, output_file=args.output_file,
      root_dir=args.root_dir, image_list_file=args.image_list_file)
