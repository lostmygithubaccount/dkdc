import unittest
import pandas as pd
import numpy as np
from azureml.contrib.featureengineering.featurizer import FeatureType, Featurizer, FeaturizerConfig
from azureml.contrib.featureengineering.featurizer.transformer import CategoricalFeaturizers


class TestFeaturizerStrategy(unittest.TestCase):
    def test_get_featurizer_strategy(self):
        transactions_df = pd.DataFrame({
            "transaction_id": [1, 2, 3, 4, 5, 6, 7, 8],
            "user_id": [1, 1, 2, 1, np.nan, 2, 3, 3],
            "amount": [500, 600, 300, 100, 80, 120, 30, 20],
            "transaction_time": pd.date_range('2014-01-01 08:00:50', periods=8, freq='12h')
        })

        featurizer = Featurizer(client_id="test")
        featurizer.fit(transactions_df)
        featurizer_strategy = featurizer._featurizer_strategy
        column_strategy_dic = featurizer_strategy.get_featurizer_strategy()[0]
        self.assertTrue(len(column_strategy_dic['user_id'].transformers) == 2)
        self.assertTrue(len(column_strategy_dic['user_id'].transformers[0]) == 1)
        self.assertTrue(len(column_strategy_dic['transaction_id'].transformers) == 1)
        self.assertTrue(len(column_strategy_dic['transaction_id'].transformers[0]) == 1)

        cat_imputer = CategoricalFeaturizers.cat_imputer()
        featurizer.add_column_transformer(['user_id'], [cat_imputer])
        column_strategy_dic = featurizer_strategy.get_featurizer_strategy()[0]
        self.assertTrue(len(column_strategy_dic['user_id'].transformers) == 3)
        self.assertTrue(len(column_strategy_dic['user_id'].transformers[0]) == 1)
        self.assertTrue(len(column_strategy_dic['transaction_id'].transformers) == 1)
        self.assertTrue(len(column_strategy_dic['transaction_id'].transformers[0]) == 1)

        cat_imputer = CategoricalFeaturizers.cat_imputer()
        featurizer.add_feature_type_transformer(FeatureType.Numeric, [cat_imputer])
        column_strategy_dic = featurizer_strategy.get_featurizer_strategy()[0]
        self.assertTrue(len(column_strategy_dic['user_id'].transformers) == 4)
        self.assertTrue(len(column_strategy_dic['user_id'].transformers[0]) == 1)
        self.assertTrue(len(column_strategy_dic['transaction_id'].transformers) == 2)
        self.assertTrue(len(column_strategy_dic['transaction_id'].transformers[0]) == 1)

        featurizer.set_column_transformer(['user_id'], [cat_imputer])
        column_strategy_dic = featurizer_strategy.get_featurizer_strategy()[0]
        self.assertTrue(len(column_strategy_dic['user_id'].transformers) == 1)
        self.assertTrue(len(column_strategy_dic['user_id'].transformers[0]) == 1)
        self.assertTrue(len(column_strategy_dic['transaction_id'].transformers) == 2)
        self.assertTrue(len(column_strategy_dic['transaction_id'].transformers[0]) == 1)

        featurizer.set_feature_type_transformer(FeatureType.Numeric, [cat_imputer])
        column_strategy_dic = featurizer_strategy.get_featurizer_strategy()[0]
        self.assertTrue(len(column_strategy_dic['user_id'].transformers) == 1)
        self.assertTrue(len(column_strategy_dic['user_id'].transformers[0]) == 1)
        self.assertTrue(len(column_strategy_dic['transaction_id'].transformers) == 1)
        self.assertTrue(len(column_strategy_dic['transaction_id'].transformers[0]) == 1)

        featurizer.add_column_transformer(['user_id', 'transaction_id'], [cat_imputer])
        column_strategy_dic = featurizer_strategy.get_featurizer_strategy()[0]
        self.assertTrue(len(column_strategy_dic['transaction_id-user_id'].column_names) == 2)

        featurizer.set_feature_type('user_id', FeatureType.Categorical)
        column_strategy_dic = featurizer_strategy.get_featurizer_strategy()[0]
        self.assertTrue(len(column_strategy_dic['user_id'].transformers) == 1)

        featurizer_strategy.set_column_transformer(['user_id'], [cat_imputer])
        column_strategy_dic = featurizer_strategy.get_featurizer_strategy()[0]
        self.assertTrue(len(column_strategy_dic['user_id'].transformers) == 1)

    def test_set_featurizer_timeseries_param(self):
        ts_param_dict_1 = {
            'time_column_name': 'date',
            'use_stl': None
        }

        ts_param_dict_2 = {
            'time_column_name': 'date',
            'grain_column_names': 'type',
            'use_stl': None
        }

        x = pd.DataFrame(
            np.array([["2011-01-01", 5, "A"], ["2011-01-02", 12, "A"], ["2011-01-03", 10, "A"],
                      ["2011-01-04", 17, "A"], ["2011-01-05", 10, "A"]]),
            columns=["date", "sales", "type"]
        )
        x['date'] = pd.to_datetime(x['date'])
        x['sales'] = pd.to_numeric(x['sales'])
        y = np.array([1.0, 1.1, 1.2, 1.3, 1.4])

        config = FeaturizerConfig(enable_general_transform=True, enable_timeseries_transform=True, **ts_param_dict_1)
        featurizer = Featurizer(client_id="test", featurizer_config=config)

        featurizer.fit(x, y)
        featurizer.set_featurizer_timeseries_params(True, ts_param_dict_2)

        self.assertTrue(featurizer._featurizer_config.enable_timeseries_transform)
        column_strategy = featurizer._featurizer_strategy.get_featurizer_strategy()[0]
        # column strategy should only contains 'sales' column, since date and type are timeseries columns.
        self.assertEqual(len(column_strategy), 1)
        self.assertTrue('sales' in column_strategy)
