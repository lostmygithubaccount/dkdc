# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Init for data module."""

from .mock_embeddings_provider import MockWordEmbeddingsProvider