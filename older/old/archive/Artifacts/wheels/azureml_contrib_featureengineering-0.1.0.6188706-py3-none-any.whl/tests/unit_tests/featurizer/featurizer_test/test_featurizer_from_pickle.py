import unittest
import pandas as pd
import os

from sklearn.model_selection import train_test_split
from azureml.contrib.featureengineering.common import utilities
from azureml.contrib.featureengineering.featurizer import Featurizer, FeatureType, FeaturizerConfig

from tests.unit_tests.test_data.dominicks_oj import load_dominicks_oj_features_dataframe


class FeaturizerTest(unittest.TestCase):

    def test_load_from_pickle_data_transformer(self):
        print("----------------Test load model from pickle for data transformer----------------")

        featurizer = Featurizer()
        fitted_model = self._load_pickle("../../data/loan_processed_fitted_model.pkl")
        featurizer.load_from_model(fitted_model)
        assert len(featurizer.transformer_and_mapper_list) > 0
        assert len(featurizer.get_engineered_feature_names()) > 0
        assert len(featurizer._featurizer_strategy.get_featurizer_strategy()) > 0

        X_all, y_all = self._load_csv_data("../../data/loan_processed.csv", 'loan_status')

        # Split to train and test sets
        seed = 42
        X_train, X_test, y_train, y_test = train_test_split(X_all, y_all, random_state=seed,
                                                            test_size=0.2)
        feature_matrix_train = featurizer.transform(X_train)
        feature_matrix_test = featurizer.transform(X_test)

        featurizer.set_feature_type(column_name='inq_last_6mths', feature_type=FeatureType.Categorical)
        X_train_cus = featurizer.fit_transform(X_train)
        engineered_feature_names = featurizer.get_engineered_feature_names()
        transform_metadata = featurizer.get_json_strs_for_engineered_feature_names(
            engineered_feature_names)

        user_friendly_engineered_names = featurizer.get_user_friendly_engineered_feature_names()
        feature_def = featurizer.get_feature_definition()
        feature_def_json = feature_def.get_transformation_meta_json()

        assert len(transform_metadata) > 0
        assert len(user_friendly_engineered_names) > 0
        assert len(feature_def_json) > 0

    def test_load_from_pickle_time_series_transformer(self):
        print("----------------Test load model from pickle for time series transformer----------------")

        # Load pickle file
        time_series_settings = {
            'time_column_name': 'WeekLastDay',
            'grain_column_names': ['store', 'brand'],
            'max_horizon': 20  # optional
        }
        config = FeaturizerConfig(enable_timeseries_transform=True, **time_series_settings)
        featurizer = Featurizer(featurizer_config=config, client_id="test")
        fitted_model = self._load_pickle("../../data/dominicks_oj_features_fitted_model.pkl")
        featurizer.load_from_model(fitted_model)

        # Check TimeSeriesTransformer object is populated
        self.assertTrue(featurizer._ts_transformer is not None)
        self.assertTrue(len(featurizer.transformer_and_mapper_list) == 0)

        # Prepare Data
        data = load_dominicks_oj_features_dataframe()
        label_name = 'Quantity'
        X_all = data.drop(columns=[label_name])
        y_all = data[label_name]

        # Split to train and test sets
        seed = 42
        X_train, X_test, y_train, y_test = train_test_split(X_all, y_all, random_state=seed,
                                                            test_size=0.2)

        transformed_data = featurizer.transform(X_train, y=y_train)

        engineered_feature_names = featurizer.get_engineered_feature_names()

        expected_feature_names = ['feat', 'price', 'AGE60', 'EDUC', 'ETHNIC', 'INCOME', 'HHLARGE', 'WORKWOM',
                                  'HVAL150', 'SSTRDIST', 'SSTRVOL', 'CPDIST5', 'CPWVOL5', 'year', 'day',
                                  'feat_WASNULL', 'price_WASNULL', 'AGE60_WASNULL', 'EDUC_WASNULL', 'ETHNIC_WASNULL',
                                  'INCOME_WASNULL', 'HHLARGE_WASNULL', 'WORKWOM_WASNULL', 'HVAL150_WASNULL',
                                  'SSTRDIST_WASNULL', 'SSTRVOL_WASNULL', 'CPDIST5_WASNULL', 'CPWVOL5_WASNULL',
                                  'year_WASNULL', 'day_WASNULL', 'grain_store_WASNULL', 'half', 'quarter', 'month',
                                  'qday', 'grain_brand_dominicks', 'grain_brand_minute.maid', 'grain_brand_tropicana',
                                  'grain_store_2', 'grain_store_5', 'grain_store_8']

        self.assertListEqual(expected_feature_names, engineered_feature_names)

    def _load_pickle(self, fl_rel_path):
        # function to load model pickle file
        script_dir = os.path.dirname(__file__)
        fl_path = os.path.join(script_dir, fl_rel_path)
        fitted_model = utilities.load_pickle(fl_path)
        return fitted_model

    def _load_csv_data(self, fl_rel_path, y_col_name):
        # function to load data, generate feature matrix and encode outcome
        script_dir = os.path.dirname(__file__)
        fl_path = os.path.join(script_dir, fl_rel_path)
        df = pd.read_csv(fl_path, low_memory=False)
        y = df.pop(y_col_name)
        y = y.values.reshape(-1)
        X = df
        return X, y

if __name__ == "__main__":
    unittest.main()
