# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import unittest

import numpy as np
import pandas as pd
import scipy as sp
from azureml.automl.core.featurization import DataTransformer
from pandas.util.testing import assert_frame_equal
from sklearn.exceptions import NotFittedError

from azureml.contrib.featureengineering.common.logging import _LoggerFactory
from azureml.contrib.featureengineering.evaluator import SelectTopFeatures
from azureml.contrib.featureengineering.evaluator import constants


class SelectTopFeaturesTesting(unittest.TestCase):
    def setUp(self):
        self.logger = _LoggerFactory.get_logger(__name__, client_id="test")
        self.label_column = 'label'
        self.task = constants.Tasks.CLASSIFICATION
        # create feature matrices to evaluate
        self.train_all_numeric_no_nan = pd.DataFrame({"A": range(10),
                                                      self.label_column: [0] * 5 + [1] * 5,
                                                      "C": 1.01,
                                                      "S": range(10, 0, -1),
                                                      "D": [2] * 2 + [3] * 8})
        self.train_all_numeric_no_nan.C.iloc[4] = 0.98

        self.train_label_non_numeric = pd.DataFrame({"A": range(10),
                                                     self.label_column: ["a", "a", "a", "a", "a", "u", "u", "u", "u",
                                                                         "u"],
                                                     "C": 1.01,
                                                     "S": range(10, 0, -1),
                                                     "D": [2] * 2 + [3] * 8})

        self.test_all_numeric_no_nan = pd.DataFrame({"A": np.nan,
                                                     self.label_column: [1] * 4 + [0] * 6,
                                                     "C": range(10, 0, -1),
                                                     "S": 5,
                                                     "D": [7] * 7 + [3] * 3})

        self.test_all_numeric_no_nan_one_row = pd.DataFrame({"A": np.nan,
                                                             self.label_column: [1],
                                                             "C": 10,
                                                             "S": 5,
                                                             "D": 3})

        self.train_all_numeric_no_var_C_nan_F = pd.DataFrame({"A": range(4),
                                                              "B": range(4),
                                                              self.label_column: [0] * 1 + [1] * 3,
                                                              "C": 1.05,
                                                              "F": np.nan,
                                                              "S": range(4, 0, -1),
                                                              "D": [2] * 3 + [3] * 1})

        self.train_categorical_nan_F = pd.DataFrame({"A": range(10),
                                                     "B": range(10),
                                                     self.label_column: [0] * 5 + [1] * 5,
                                                     "C": 1.05,
                                                     "F": np.nan,
                                                     "S": range(10, 0, -1),
                                                     "D": [2] * 2 + [3] * 8,
                                                     "CATE": ["a", "a", "c", "c", "e", "e", "u", "u", "u",
                                                              "u"]})
        self.train_categorical_nan_F.C.iloc[7] = 6.5
        self.train_categorical_nan_F.F.iloc[1:6] = 3
        self.train_categorical_nan_F.F.iloc[7:9] = 5

        self.test_categorical_nan_F = pd.DataFrame({"A": range(10),
                                                    "B": 1,
                                                    self.label_column: [0] * 8 + [1] * 2,
                                                    "C": 5.1,
                                                    "F": 6,
                                                    "S": [6] * 7 + [8] * 3,
                                                    "D": [2] * 2 + [3] * 8,
                                                    "CATE": ["c", "a", "c", "c", "d", "e", "u", "u", "z",
                                                             "y"]})

        self.train_no_var_C_nan_F = pd.DataFrame({"A": range(10),
                                                  "B": [True, True, False, True, np.nan, None, True,
                                                        False, True, np.nan],
                                                  self.label_column: [0] * 5 + [1] * 5,
                                                  "C": [5] * 10,
                                                  "F": np.nan,
                                                  "S": range(10, 0, -1),
                                                  "Z": pd.date_range(start='4/2/2019', periods=10),
                                                  "D": [2] * 2 + [3] * 8,
                                                  "CATE": ["a", "a", "c", "c", "e", "e", "u", "u", "u",
                                                           "u"]})
        self.train_no_var_C_nan_F.F.iloc[1:6] = 3
        self.train_no_var_C_nan_F.CATE.iloc[4] = np.nan

        self.train_hash_B = pd.DataFrame({"A": range(10, 0, -1),
                                          "B": ["https://www.lendingclub.com/browse/loanDetail.action?loan_id=1077501",
                                                "https://www.lendingclub.com/browse/loanDetail.action?loan_id=1077430",
                                                "https://www.lendingclub.com/browse/loanDetail.action?loan_id=1076863",
                                                "https://www.lendingclub.com/browse/loanDetail.action?loan_id=1069908",
                                                "https://www.lendingclub.com/browse/loanDetail.action?loan_id=1065775",
                                                "https://www.lendingclub.com/browse/loanDetail.action?loan_id=1064687",
                                                "https://www.lendingclub.com/browse/loanDetail.action?loan_id=1062474",
                                                "https://www.lendingclub.com/browse/loanDetail.action?loan_id=1039153",
                                                "https://www.lendingclub.com/browse/loanDetail.action?loan_id=1071570",
                                                "https://www.lendingclub.com/browse/loanDetail.action?loan_id=1070078"
                                                ],
                                          "C": [5] * 10,
                                          self.label_column: [0] * 4 + [1] * 6,
                                          "D": [True, True, False, True, np.nan, None, True, False, True, np.nan],
                                          "E": range(10),
                                          "F": 9})

        train_featurized_no_var_C_nan_F = pd.DataFrame({"A_MeanImputer": range(10),
                                                        "B_HashOneHotEncode_0": 0,
                                                        "B_HashOneHotEncode_1": 0,
                                                        "B_HashOneHotEncode_2": [1, 1, 0, 1, 0, 0, 1, 0, 1, 0],
                                                        "B_HashOneHotEncode_3": [0, 0, 1, 0, 0, 1, 0, 1, 0, 0],
                                                        "B_HashOneHotEncode_4": 0,
                                                        "B_HashOneHotEncode_5": 0,
                                                        "B_HashOneHotEncode_6": 0,
                                                        "B_HashOneHotEncode_7": [0, 0, 0, 0, 1, 0, 0, 0, 0, 1],
                                                        "S_MeanImputer": range(10, 0, -1),
                                                        "Z_ModeImputer_Year": 2019,
                                                        "Z_ModeImputer_Month": 4,
                                                        "Z_ModeImputer_Day": range(2, 12, 1),
                                                        "Z_ModeImputer_DayOfWeek": [1, 2, 3, 4, 5, 6, 0, 1, 2, 3],
                                                        "Z_ModeImputer_DayOfYear": range(92, 102, 1),
                                                        "Z_ModeImputer_QuarterOfYear": 2,
                                                        "Z_ModeImputer_WeekOfMonth": [1] * 6 + [2] * 4,
                                                        "Z_ModeImputer_Hour": 0,
                                                        "Z_ModeImputer_Minute": 0,
                                                        "Z_ModeImputer_Second": 0,
                                                        "D_MeanImputer": [2] * 2 + [3] * 8,
                                                        "CATE_HashOneHotEncode_0": [1] * 2 + [0] * 8,
                                                        "CATE_HashOneHotEncode_1": 0,
                                                        "CATE_HashOneHotEncode_2": [0, 0, 1, 1, 0, 0, 1, 1, 1, 1],
                                                        "CATE_HashOneHotEncode_3": 0,
                                                        "CATE_HashOneHotEncode_4": 0,
                                                        "CATE_HashOneHotEncode_5": [0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
                                                        "CATE_HashOneHotEncode_6": 0,
                                                        "CATE_HashOneHotEncode_7": [0, 0, 0, 0, 1, 0, 0, 0, 0, 0]
                                                        })
        self.sparse_train_featurized_no_var_C_nan_F = sp.sparse.csr_matrix(train_featurized_no_var_C_nan_F.values)

        self.sparse_df_train_featurized_no_var_C_nan_F = train_featurized_no_var_C_nan_F.to_sparse()

        test_featurized_no_var_C_nan_F = pd.DataFrame({"A_MeanImputer": range(10),
                                                       "B_HashOneHotEncode_0": 0,
                                                       "B_HashOneHotEncode_1": 0,
                                                       "B_HashOneHotEncode_2": [1, 1, 0, 1, 0, 0, 1, 0, 1, 0],
                                                       "B_HashOneHotEncode_3": [0, 0, 1, 0, 0, 1, 0, 1, 0, 0],
                                                       "B_HashOneHotEncode_4": 0,
                                                       "B_HashOneHotEncode_5": 0,
                                                       "B_HashOneHotEncode_6": 0,
                                                       "B_HashOneHotEncode_7": [0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
                                                       "S_MeanImputer": range(10, 0, -1),
                                                       "Z_ModeImputer_Year": 2019,
                                                       "Z_ModeImputer_Month": 4,
                                                       "Z_ModeImputer_Day": range(2, 12, 1),
                                                       "Z_ModeImputer_DayOfWeek": [1, 2, 3, 4, 5, 6, 0, 1, 2, 3],
                                                       "Z_ModeImputer_DayOfYear": range(92, 102, 1),
                                                       "Z_ModeImputer_QuarterOfYear": 2,
                                                       "Z_ModeImputer_WeekOfMonth": [1] * 6 + [2] * 4,
                                                       "Z_ModeImputer_Hour": 0,
                                                       "Z_ModeImputer_Minute": 0,
                                                       "Z_ModeImputer_Second": 0,
                                                       "D_MeanImputer": [2] * 2 + [3] * 8,
                                                       "CATE_HashOneHotEncode_0": [1] * 2 + [0] * 8,
                                                       "CATE_HashOneHotEncode_1": 0,
                                                       "CATE_HashOneHotEncode_2": [0, 0, 1, 1, 0, 0, 1, 1, 1, 1],
                                                       "CATE_HashOneHotEncode_3": 0,
                                                       "CATE_HashOneHotEncode_4": 0,
                                                       "CATE_HashOneHotEncode_5": [0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
                                                       "CATE_HashOneHotEncode_6": 0,
                                                       "CATE_HashOneHotEncode_7": [0, 0, 0, 0, 1, 0, 0, 0, 0, 0]
                                                       })
        self.sparse_test_featurized_no_var_C_nan_F = sp.sparse.csr_matrix(test_featurized_no_var_C_nan_F.values)
        self.sparse_df_test_featurized_no_var_C_nan_F = test_featurized_no_var_C_nan_F.to_sparse()


        train_featurized_no_var_C_nan_F_non_numeric_label = pd.DataFrame({"A_MeanImputer": range(10),
                                                                          "S_MeanImputer": range(10, 0, -1),
                                                                          "D_MeanImputer": [2] * 2 + [3] * 8,
                                                                          "B_HashOneHotEncode_0": 0,
                                                                          "B_HashOneHotEncode_1": 0,
                                                                          "B_HashOneHotEncode_2": [1, 1, 0, 1, 0, 0, 1,
                                                                                                   0, 1, 0],
                                                                          "B_HashOneHotEncode_3": [0, 0, 1, 0, 0, 1, 0,
                                                                                                   1, 0, 0],
                                                                          "B_HashOneHotEncode_4": 0,
                                                                          "B_HashOneHotEncode_5": 0,
                                                                          "B_HashOneHotEncode_6": 0,
                                                                          "B_HashOneHotEncode_7": [0, 0, 0, 0, 1, 0, 0,
                                                                                                   0, 0, 1],

                                                                          "CATE_HashOneHotEncode_0": [1] * 2 + [0] * 8,
                                                                          "CATE_HashOneHotEncode_1": 0,
                                                                          "CATE_HashOneHotEncode_2": [0, 0, 1, 1, 0, 0,
                                                                                                      1, 1, 1, 1],
                                                                          "CATE_HashOneHotEncode_3": 0,
                                                                          "CATE_HashOneHotEncode_4": 0,
                                                                          "CATE_HashOneHotEncode_5": [0, 0, 0, 0, 1, 1,
                                                                                                      0, 0, 0, 0],
                                                                          "CATE_HashOneHotEncode_6": 0,
                                                                          "CATE_HashOneHotEncode_7": 0,
                                                                          "Z_ModeImputer_Year": 2019,
                                                                          "Z_ModeImputer_Month": 4,
                                                                          "Z_ModeImputer_Day": range(2, 12, 1),
                                                                          "Z_ModeImputer_DayOfWeek": [1, 2, 3, 4, 5, 6,
                                                                                                      0, 1, 2, 3],
                                                                          "Z_ModeImputer_DayOfYear": range(92, 102, 1),
                                                                          "Z_ModeImputer_QuarterOfYear": 2,
                                                                          "Z_ModeImputer_WeekOfMonth": [1] * 6 + [
                                                                              2] * 4,
                                                                          "Z_ModeImputer_Hour": 0,
                                                                          "Z_ModeImputer_Minute": 0,
                                                                          "Z_ModeImputer_Second": 0,
                                                                          })
        self.sparse_train_featurized_no_var_C_nan_F_non_numeric_label = sp.sparse.csr_matrix(
            train_featurized_no_var_C_nan_F_non_numeric_label.values)
        self.sparse_non_numeric_label = np.array(["business", "business", "business", "business", "business", "tech",
                                                  "tech", "tech", "tech", "tech"])

        self.sparse_df_train_featurized_no_var_C_nan_F_non_numeric_label = \
            train_featurized_no_var_C_nan_F_non_numeric_label.to_sparse()

    def test_fit_prepprocess_false(self):
        selector = SelectTopFeatures(self.task, n=3, preprocess=False, client_id="test", logger=self.logger)
        X = self.train_all_numeric_no_nan.drop(columns=self.label_column)
        y = self.train_all_numeric_no_nan[self.label_column]
        selector.fit(X, y)

        expected_raw_cols = ["A", "S", "D", "C"]
        expected_eng_scoring = pd.DataFrame()

        self.assertListEqual(selector.raw_scoring_.index.tolist(), expected_raw_cols)
        self.assertListEqual(selector.raw_scoring_[constants.NON_NULL_RATIO].values.tolist(),
                             [1.0] * len(expected_raw_cols))
        assert_frame_equal(selector.eng_scoring_, expected_eng_scoring)

    def test_fit_preprocess_true(self):
        selector = SelectTopFeatures(self.task, n=2, client_id="test", logger=self.logger)
        X = self.train_all_numeric_no_var_C_nan_F.drop(columns=self.label_column)
        y = self.train_all_numeric_no_var_C_nan_F[self.label_column]
        selector.fit(X, y)

        expected_raw_cols = ["A", "B", "S", "D", "C", "F"]
        expected_eng_cols = ["A_MeanImputer", "B_MeanImputer", "S_MeanImputer", "D_MeanImputer"]

        self.assertListEqual(selector.raw_scoring_.index.tolist(), expected_raw_cols)
        # self.assertListEqual(selector.eng_scoring_.index.tolist(), expected_eng_cols)
        self.assertEqual(len(selector.eng_scoring_.index), len(expected_eng_cols))
        self.assertListEqual(selector.eng_scoring_[constants.NON_NULL_RATIO].values.tolist(),
                             [1.0] * len(expected_eng_cols))

    def test_fit_label_not_numeric_preprocess_false(self):
        selector = SelectTopFeatures(self.task, n=2, preprocess=False, client_id="test", logger=self.logger)
        X = self.train_label_non_numeric.drop(columns=self.label_column)
        y = self.train_label_non_numeric[self.label_column]
        self.assertRaises(ValueError, selector.fit, X, y)

    def test_fit_label_not_numeric_preprocess_true(self):
        selector = SelectTopFeatures(self.task, n=3, client_id="test", logger=self.logger)
        X = self.train_label_non_numeric.drop(columns=self.label_column)
        y = self.train_label_non_numeric[self.label_column]
        selector.fit(X, y)

        expected_raw_cols = ["A", "S", "D", "C"]
        expected_eng_cols = ["A_MeanImputer", "S_MeanImputer", "D_MeanImputer"]

        self.assertListEqual(selector.raw_scoring_.index.tolist(), expected_raw_cols)
        self.assertListEqual(selector.raw_scoring_[constants.NON_NULL_RATIO].values.tolist(),
                             [1.0] * len(expected_raw_cols))
        # self.assertListEqual(selector.eng_scoring_.index.tolist(), expected_eng_cols)
        self.assertEqual(len(selector.eng_scoring_.index), len(expected_eng_cols))
        self.assertListEqual(selector.eng_scoring_[constants.NON_NULL_RATIO].values.tolist(),
                             [1.0] * len(expected_eng_cols))

    def test_transform_unfitted(self):
        selector = SelectTopFeatures(self.task, n=3, preprocess=False, client_id="test", logger=self.logger)
        X = self.train_categorical_nan_F.drop(columns=self.label_column)
        self.assertRaises(NotFittedError, selector.transform, X)

    def test_transform_preprocess_false(self):
        selector = SelectTopFeatures(self.task, n=2, preprocess=False, client_id="test", logger=self.logger)
        X_train = self.train_all_numeric_no_nan.drop(columns=self.label_column)
        y_train = self.train_all_numeric_no_nan[self.label_column]
        X_train_fs = selector.fit(X_train, y_train).transform(X_train)

        expected_cols = ["A", "S"]
        assert_frame_equal(X_train_fs, X_train[expected_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_cols)
        assert_frame_equal(selector.transformed_X_eng_, pd.DataFrame())
        self.assertListEqual(selector.transformed_X_eng_column_names_.tolist(), [])

        X_test = self.test_all_numeric_no_nan.drop(columns=self.label_column)
        X_test_fs = selector.transform(X_test)
        assert_frame_equal(X_test_fs, X_test[expected_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_cols)
        assert_frame_equal(selector.transformed_X_eng_, pd.DataFrame())
        self.assertListEqual(selector.transformed_X_eng_column_names_.tolist(), [])

        X_test_one_row = self.test_all_numeric_no_nan_one_row.drop(columns=self.label_column)
        X_test_one_row_fs = selector.transform(X_test_one_row)
        assert_frame_equal(X_test_one_row_fs, X_test_one_row[expected_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_cols)
        assert_frame_equal(selector.transformed_X_eng_, pd.DataFrame())
        self.assertListEqual(selector.transformed_X_eng_column_names_.tolist(), [])

    def test_transform_preprocess_true(self):
        selector = SelectTopFeatures(self.task, client_id="test", logger=self.logger)
        X_train = self.train_all_numeric_no_var_C_nan_F.drop(columns=self.label_column)
        y_train = self.train_all_numeric_no_var_C_nan_F[self.label_column]
        X_train_fs = selector.fit(X_train, y_train).transform(X_train)

        expected_raw_cols = ["A", "B", "S", "D"]
        assert_frame_equal(X_train_fs, X_train[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)
        expected_eng_cols = ["A_MeanImputer", "B_MeanImputer", "S_MeanImputer", "D_MeanImputer"]
        np.testing.assert_array_equal(selector.transformed_X_eng_.values, X_train[expected_raw_cols].values)
        # self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_cols)
        self.assertEqual(len(selector.transformed_X_eng_column_names_), len(expected_eng_cols))

    def test_fit_transform_preprocess_false(self):
        selector = SelectTopFeatures(self.task, n=2, preprocess=False, client_id="test", logger=self.logger)
        X_train = self.train_all_numeric_no_nan.drop(columns=self.label_column)
        y_train = self.train_all_numeric_no_nan[self.label_column]
        X_train_fs = selector.fit_transform(X_train, y_train)

        expected_cols = ["A", "S"]
        assert_frame_equal(X_train_fs, X_train[expected_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_cols)
        assert_frame_equal(selector.transformed_X_eng_, pd.DataFrame())
        self.assertListEqual(selector.transformed_X_eng_column_names_.tolist(), [])

    def test_fit_transform_preprocess_true(self):
        selector = SelectTopFeatures(self.task, n=4, preprocess=True, client_id="test", logger=self.logger)
        X_train = self.train_no_var_C_nan_F.drop(columns=self.label_column)
        y_train = self.train_no_var_C_nan_F[self.label_column]
        X_train_fs = selector.fit_transform(X_train, y_train)

        expected_raw_cols = ["A", "S", "Z", "CATE"]
        assert_frame_equal(X_train_fs, X_train[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)

        expected_eng_cols = ["A_MeanImputer", "S_MeanImputer", "Z_ModeImputer_Year", "Z_ModeImputer_Month",
                             "Z_ModeImputer_Day", "Z_ModeImputer_Hour", "Z_ModeImputer_Minute", "Z_ModeImputer_Second",
                             "Z_ModeImputer_QuarterOfYear", "Z_ModeImputer_DayOfYear", "Z_ModeImputer_WeekOfMonth",
                             "Z_ModeImputer_DayOfWeek", "CATE_HashOneHotEncode_0", "CATE_HashOneHotEncode_1",
                             "CATE_HashOneHotEncode_2", "CATE_HashOneHotEncode_3", "CATE_HashOneHotEncode_4",
                             "CATE_HashOneHotEncode_5", "CATE_HashOneHotEncode_6", "CATE_HashOneHotEncode_7"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, sp.sparse.csr_matrix))
        self.assertEqual((X_train.shape[0], 16), selector.transformed_X_eng_.shape)
        # self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_cols)
        self.assertEqual(16, len(selector.transformed_X_eng_column_names_))

    def test_fit_transform_preprocess_true_featurization_drop_col(self):
        selector = SelectTopFeatures(self.task, n=4, client_id="test", logger=self.logger)
        X_train = self.train_hash_B.drop(columns=self.label_column)
        y_train = self.train_hash_B[self.label_column]
        X_train_fs = selector.fit_transform(X_train, y_train)

        expected_raw_cols = ["A", "D", "E"]
        assert_frame_equal(X_train_fs, X_train[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)

        expected_eng_cols = ["A_MeanImputer", "D_HashOneHotEncode_0", "D_HashOneHotEncode_1",
                             "D_HashOneHotEncode_2", "D_HashOneHotEncode_3", "D_HashOneHotEncode_4",
                             "D_HashOneHotEncode_5", "D_HashOneHotEncode_6", "D_HashOneHotEncode_7", "E_MeanImputer"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, sp.sparse.csr_matrix))
        self.assertEqual((X_train.shape[0], 6), selector.transformed_X_eng_.shape)
        # self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_cols)
        self.assertEqual(6, len(selector.transformed_X_eng_column_names_))

    def test_set_top_n_top_percentile_preprocess_true(self):
        selector = SelectTopFeatures(self.task, n=5, preprocess=True, client_id="test", logger=self.logger)
        X_train = self.train_no_var_C_nan_F.drop(columns=self.label_column)
        y_train = self.train_no_var_C_nan_F[self.label_column]
        X_train_fs = selector.fit_transform(X_train, y_train)
        expected_raw_cols = ["A", "S", "Z", "D", "CATE"]
        assert_frame_equal(X_train_fs, X_train[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)

        expected_eng_cols = ["A_MeanImputer", "S_MeanImputer", "Z_ModeImputer_Year", "Z_ModeImputer_Month",
                             "Z_ModeImputer_Day", "Z_ModeImputer_Hour", "Z_ModeImputer_Minute", "Z_ModeImputer_Second",
                             "Z_ModeImputer_QuarterOfYear", "Z_ModeImputer_DayOfYear", "Z_ModeImputer_WeekOfMonth",
                             "Z_ModeImputer_DayOfWeek", "D_MeanImputer", "CATE_HashOneHotEncode_0",
                             "CATE_HashOneHotEncode_1", "CATE_HashOneHotEncode_2", "CATE_HashOneHotEncode_3",
                             "CATE_HashOneHotEncode_4", "CATE_HashOneHotEncode_5", "CATE_HashOneHotEncode_6",
                             "CATE_HashOneHotEncode_7"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, sp.sparse.csr_matrix))
        self.assertEqual((X_train.shape[0], 17), selector.transformed_X_eng_.shape)
        # self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_cols)
        self.assertEqual(17, len(selector.transformed_X_eng_column_names_))

        selector.set_top_n(3)
        X_train_fs_change_n = selector.transform(X_train)
        expected_raw_cols = ["A", "S", "Z"]
        assert_frame_equal(X_train_fs_change_n, X_train[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)

        expected_eng_cols = ["A_MeanImputer", "S_MeanImputer", "Z_ModeImputer_Year", "Z_ModeImputer_Month",
                             "Z_ModeImputer_Day", "Z_ModeImputer_Hour", "Z_ModeImputer_Minute", "Z_ModeImputer_Second",
                             "Z_ModeImputer_QuarterOfYear", "Z_ModeImputer_DayOfYear", "Z_ModeImputer_WeekOfMonth",
                             "Z_ModeImputer_DayOfWeek"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, sp.sparse.csr_matrix))
        self.assertEqual(selector.transformed_X_eng_.shape, (X_train.shape[0], len(expected_eng_cols)))
        # self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_cols)
        self.assertEqual(len(selector.transformed_X_eng_column_names_), len(expected_eng_cols))

        selector.set_top_n(10)
        X_train_fs_n_larger_than_total = selector.transform(X_train)
        expected_raw_cols = ["A", "B", "S", "Z", "D", "CATE"]
        assert_frame_equal(X_train_fs_n_larger_than_total, X_train[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)

        expected_eng_cols = ["A_MeanImputer", "B_HashOneHotEncode_0", "B_HashOneHotEncode_1", "B_HashOneHotEncode_2",
                             "B_HashOneHotEncode_3", "B_HashOneHotEncode_4", "B_HashOneHotEncode_5",
                             "B_HashOneHotEncode_6", "B_HashOneHotEncode_7", "S_MeanImputer", "Z_ModeImputer_Year",
                             "Z_ModeImputer_Month", "Z_ModeImputer_Day", "Z_ModeImputer_Hour", "Z_ModeImputer_Minute",
                             "Z_ModeImputer_Second", "Z_ModeImputer_QuarterOfYear", "Z_ModeImputer_DayOfYear",
                             "Z_ModeImputer_WeekOfMonth", "Z_ModeImputer_DayOfWeek", "D_MeanImputer",
                             "CATE_HashOneHotEncode_0", "CATE_HashOneHotEncode_1", "CATE_HashOneHotEncode_2",
                             "CATE_HashOneHotEncode_3", "CATE_HashOneHotEncode_4", "CATE_HashOneHotEncode_5",
                             "CATE_HashOneHotEncode_6", "CATE_HashOneHotEncode_7"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, sp.sparse.csr_matrix))
        self.assertEqual((X_train.shape[0], 21), selector.transformed_X_eng_.shape)
        # self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_cols)
        self.assertEqual(21, len(selector.transformed_X_eng_column_names_))

        selector.set_top_percentile(0.9)
        X_train_fs_change_percentile = selector.transform(X_train)
        expected_raw_cols = ["A", "S", "Z", "CATE"]
        assert_frame_equal(X_train_fs_change_percentile, X_train[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)

        expected_eng_cols = ["A_MeanImputer", "S_MeanImputer", "Z_ModeImputer_Year", "Z_ModeImputer_Month",
                             "Z_ModeImputer_Day", "Z_ModeImputer_Hour", "Z_ModeImputer_Minute", "Z_ModeImputer_Second",
                             "Z_ModeImputer_QuarterOfYear", "Z_ModeImputer_DayOfYear", "Z_ModeImputer_WeekOfMonth",
                             "Z_ModeImputer_DayOfWeek", "CATE_HashOneHotEncode_0", "CATE_HashOneHotEncode_1",
                             "CATE_HashOneHotEncode_2", "CATE_HashOneHotEncode_3", "CATE_HashOneHotEncode_4",
                             "CATE_HashOneHotEncode_5", "CATE_HashOneHotEncode_6", "CATE_HashOneHotEncode_7"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, sp.sparse.csr_matrix))
        self.assertEqual((X_train.shape[0], 16), selector.transformed_X_eng_.shape)
        # self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_cols)
        self.assertEqual(16, len(selector.transformed_X_eng_column_names_))

    def test_set_top_percentile_preprocess_true(self):
        selector = SelectTopFeatures(self.task, percentile=0.8, preprocess=True, client_id="test", logger=self.logger)
        X_train = self.train_categorical_nan_F.drop(columns=self.label_column)
        y_train = self.train_categorical_nan_F[self.label_column]
        X_train_fs = selector.fit_transform(X_train, y_train)
        expected_raw_cols = ["A", "B", "S", "CATE"]
        assert_frame_equal(X_train_fs, X_train[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)

        expected_eng_cols = ["A_MeanImputer", "B_MeanImputer", "S_MeanImputer", "CATE_HashOneHotEncode_0",
                             "CATE_HashOneHotEncode_1", "CATE_HashOneHotEncode_2", "CATE_HashOneHotEncode_3",
                             "CATE_HashOneHotEncode_4", "CATE_HashOneHotEncode_5", "CATE_HashOneHotEncode_6",
                             "CATE_HashOneHotEncode_7"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, sp.sparse.csr_matrix))
        self.assertEqual((X_train.shape[0], 7), selector.transformed_X_eng_.shape)
        # self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_cols)
        self.assertEqual(7, len(selector.transformed_X_eng_column_names_))

        selector.set_top_percentile(-1)
        X_test = self.test_categorical_nan_F.drop(columns=self.label_column)
        X_test_fs_change_percentile = selector.transform(X_test)
        expected_raw_cols = ["A", "B", "C", "F", "S", "D", "CATE"]
        assert_frame_equal(X_test_fs_change_percentile, X_test[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)

        expected_eng_cols = ["A_MeanImputer", "B_MeanImputer", "C_MeanImputer", "F_MeanImputer", "F_ImputationMarker",
                             "S_MeanImputer", "D_MeanImputer", "CATE_HashOneHotEncode_0",
                             "CATE_HashOneHotEncode_1", "CATE_HashOneHotEncode_2", "CATE_HashOneHotEncode_3",
                             "CATE_HashOneHotEncode_4", "CATE_HashOneHotEncode_5", "CATE_HashOneHotEncode_6",
                             "CATE_HashOneHotEncode_7"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, sp.sparse.csr_matrix))
        self.assertEqual((X_train.shape[0], 11), selector.transformed_X_eng_.shape)
        # self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_cols)
        self.assertEqual(11, len(selector.transformed_X_eng_column_names_))

        selector.set_top_percentile(0.2)
        X_train_fs_change_percentile = selector.transform(X_train)
        expected_raw_cols = ["A"]
        assert_frame_equal(X_train_fs_change_percentile, X_train[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)

        expected_eng_cols = ["A_MeanImputer"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, sp.sparse.csr_matrix))
        self.assertEqual(selector.transformed_X_eng_.shape, (X_train.shape[0], len(expected_eng_cols)))
        # self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_cols)
        self.assertEqual(len(selector.transformed_X_eng_column_names_), len(expected_eng_cols))

    def test_get_selected_feature_importance_preprocess_true(self):
        selector = SelectTopFeatures(self.task, percentile=0.8, preprocess=True, client_id="test", logger=self.logger)
        X_train = self.train_categorical_nan_F.drop(columns=self.label_column)
        y_train = self.train_categorical_nan_F[self.label_column]
        X_train_fs = selector.fit_transform(X_train, y_train)
        feat_importance = selector.get_selected_feature_importance()

        expected_raw_cols_ordered = ["A", "S", "B", "CATE"]
        self.assertListEqual(feat_importance.index.tolist(), expected_raw_cols_ordered)
        self.assertListEqual(feat_importance.columns.tolist(), [constants.FEATURE_IMPORTANCE])

        expected_raw_cols = ["A", "B", "S", "CATE"]
        assert_frame_equal(X_train_fs, X_train[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)

        expected_eng_cols = ["A_MeanImputer", "B_MeanImputer", "S_MeanImputer", "CATE_HashOneHotEncode_0",
                             "CATE_HashOneHotEncode_1", "CATE_HashOneHotEncode_2", "CATE_HashOneHotEncode_3",
                             "CATE_HashOneHotEncode_4", "CATE_HashOneHotEncode_5", "CATE_HashOneHotEncode_6",
                             "CATE_HashOneHotEncode_7"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, sp.sparse.csr_matrix))
        self.assertEqual((X_train.shape[0], 7), selector.transformed_X_eng_.shape)
        # self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_cols)
        self.assertEqual(7, len(selector.transformed_X_eng_column_names_))

        feat_importance = selector.get_selected_feature_importance(verbose=True)
        expected_score_list = [constants.NON_NULL_RATIO, constants.VARIANCE, constants.MUTUAL_INFO,
                               constants.PEARSON_CORR,
                               constants.LIGHTGBM_IMPORTANCE, constants.LASSO_IMPORTANCE, constants.FEATURE_IMPORTANCE]
        self.assertListEqual(feat_importance.index.tolist(), expected_raw_cols_ordered)
        self.assertListEqual(feat_importance.columns.tolist(), expected_score_list)

        selector.set_top_percentile(0.2)
        self.assertRaises(NotFittedError, selector.get_selected_feature_importance)

        X_train_fs_change_percentile = selector.transform(X_train)
        feat_importance = selector.get_selected_feature_importance()
        expected_raw_cols = ["A"]
        self.assertListEqual(feat_importance.index.tolist(), expected_raw_cols)
        assert_frame_equal(X_train_fs_change_percentile, X_train[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)

        expected_eng_cols = ["A_MeanImputer"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, sp.sparse.csr_matrix))
        self.assertEqual(selector.transformed_X_eng_.shape, (X_train.shape[0], len(expected_eng_cols)))
        # self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_cols)
        self.assertEqual(len(selector.transformed_X_eng_column_names_), len(expected_eng_cols))

    def test_fit_sparse_preprocess_false(self):
        selector = SelectTopFeatures(self.task, n=3, preprocess=False, client_id="test", logger=self.logger)
        X = self.train_no_var_C_nan_F.drop(columns=["C", "F", self.label_column])
        data_transformer = DataTransformer(task=self.task)
        X = data_transformer.fit_transform_with_logger(X)
        y = self.train_no_var_C_nan_F[self.label_column]

        selector.fit(X, y)

        expected_raw_index = [str(x) for x in range(X.shape[1])]
        expected_eng_scoring = pd.DataFrame()

        self.assertCountEqual(selector.raw_scoring_.index.tolist(), expected_raw_index)
        self.assertListEqual(selector.raw_scoring_[constants.NON_NULL_RATIO].values.tolist(),
                             [1.0] * len(expected_raw_index))
        assert_frame_equal(selector.eng_scoring_, expected_eng_scoring)

    def test_transform_sparse_preprocess_false(self):
        n = 2
        selector = SelectTopFeatures(self.task, n=n, preprocess=False, client_id="test", logger=self.logger)
        X_train = self.sparse_train_featurized_no_var_C_nan_F
        y_train = self.train_no_var_C_nan_F[self.label_column]

        X_train_fs = selector.fit(X_train, y_train).transform(X_train)

        expected_cols = [0, 9]
        mask = np.full(X_train.shape[1], False, dtype=bool)
        mask[expected_cols] = True
        expected_X_train = X_train[:, mask]

        self.assertTrue(isinstance(X_train_fs, sp.sparse.csr_matrix))
        self.assertEqual(X_train_fs.shape, (X_train.shape[0], n))
        np.testing.assert_array_equal(X_train_fs.A, expected_X_train.A)
        expected_col_names = ["0", "9"]
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_col_names)
        np.testing.assert_array_equal(selector.transformed_X_eng_, np.empty(0))
        self.assertListEqual(selector.transformed_X_eng_column_names_.tolist(), [])

        X_test = self.sparse_test_featurized_no_var_C_nan_F
        X_test_fs = selector.transform(X_test)
        expected_X_test = X_test[:, mask]
        self.assertTrue(isinstance(X_test_fs, sp.sparse.csr_matrix))
        self.assertEqual(X_test_fs.shape, (X_test.shape[0], n))
        np.testing.assert_array_equal(X_test_fs.A, expected_X_test.A)
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_col_names)
        np.testing.assert_array_equal(selector.transformed_X_eng_, np.empty(0))
        self.assertListEqual(selector.transformed_X_eng_column_names_.tolist(), [])

    def test_fit_transform_sparse_preprocess_true(self):
        n = 4
        selector = SelectTopFeatures(self.task, n=n, preprocess=True, client_id="test", logger=self.logger)
        X_train = self.sparse_train_featurized_no_var_C_nan_F_non_numeric_label
        y_train = self.sparse_non_numeric_label
        X_train_fs = selector.fit_transform(X_train, y_train)

        expected_cols = [0, 1, 21, 23]
        mask = np.full(X_train.shape[1], False, dtype=bool)
        mask[expected_cols] = True
        expected_X_train = X_train[:, mask]

        self.assertTrue(isinstance(X_train_fs, sp.sparse.csr_matrix))
        self.assertEqual(X_train_fs.shape, (X_train.shape[0], n))
        np.testing.assert_array_equal(X_train_fs.A, expected_X_train.A)
        expected_col_names = ["0", "1", "21", "23"]
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_col_names)
        expected_eng_col_names = ["0", "1", "21", "23"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, sp.sparse.csr_matrix))
        self.assertEqual(selector.transformed_X_eng_.shape, (X_train.shape[0], len(expected_eng_col_names)))
        self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_col_names)

    def test_fit_transform_sparse_data_frame_preprocess_false(self):
        n = 4
        selector = SelectTopFeatures(self.task, n=n, preprocess=False, client_id="test", logger=self.logger)
        X_train = self.sparse_df_train_featurized_no_var_C_nan_F
        y_train = self.train_no_var_C_nan_F[self.label_column]
        X_train_fs = selector.fit_transform(X_train, y_train)

        self.assertTrue(isinstance(X_train_fs, pd.SparseDataFrame))
        expected_cols = ["A_MeanImputer", "S_MeanImputer", "Z_ModeImputer_Day", "Z_ModeImputer_DayOfYear"]
        assert_frame_equal(X_train_fs, X_train[expected_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_cols)
        assert_frame_equal(selector.transformed_X_eng_, pd.SparseDataFrame())
        self.assertListEqual(selector.transformed_X_eng_column_names_.tolist(), [])

    def test_fit_transform_sparse_data_frame_preprocess_true(self):
        n = 5
        selector = SelectTopFeatures(self.task, n=n, preprocess=True, client_id="test", logger=self.logger)
        X_train = self.sparse_df_train_featurized_no_var_C_nan_F_non_numeric_label
        y_train = self.sparse_non_numeric_label
        X_train_fs = selector.fit_transform(X_train, y_train)

        self.assertTrue(isinstance(X_train_fs, pd.SparseDataFrame))
        expected_raw_cols = ["A_MeanImputer", "S_MeanImputer", "Z_ModeImputer_Day", "Z_ModeImputer_DayOfYear",
                             "Z_ModeImputer_WeekOfMonth"]
        assert_frame_equal(X_train_fs, X_train[expected_raw_cols])
        self.assertListEqual(selector.transformed_X_raw_column_names_.tolist(), expected_raw_cols)

        expected_eng_col_names = ["A_MeanImputer", "S_MeanImputer", "Z_ModeImputer_Day", "Z_ModeImputer_DayOfYear",
                             "Z_ModeImputer_WeekOfMonth"]
        self.assertTrue(isinstance(selector.transformed_X_eng_, pd.SparseDataFrame))
        self.assertEqual(selector.transformed_X_eng_.shape, (X_train.shape[0], len(expected_eng_col_names)))
        self.assertCountEqual(selector.transformed_X_eng_column_names_.tolist(), expected_eng_col_names)

    def test_save_no_transform(self):
        selector = SelectTopFeatures(self.task, n=2, preprocess=False, client_id="test", logger=self.logger)
        X_train = self.train_all_numeric_no_nan.drop(columns=self.label_column)
        y_train = self.train_all_numeric_no_nan[self.label_column]
        selector.fit(X_train, y_train)
        self.assertRaises(NotFittedError, selector.save_selected_features)

    def test_save_load_selected_features(self):
        selector = SelectTopFeatures(self.task, percentile=0.8, preprocess=True, client_id="test", logger=self.logger)
        X_train = self.train_categorical_nan_F.drop(columns=self.label_column)
        y_train = self.train_categorical_nan_F[self.label_column]
        selector.fit_transform(X_train, y_train)
        json_dump = selector.save_selected_features()

        expected_raw_cols = ["A", "B", "S", "CATE"]
        expected_raw_col_indices = [X_train.columns.get_loc(col) for col in expected_raw_cols]
        mask = np.full(X_train.shape[1], False, dtype=bool)
        mask[expected_raw_col_indices] = True

        self.assertTrue('column_names' in json_dump)
        self.assertTrue('mask' in json_dump)

        json_load = selector.load_selected_features()
        self.assertEqual(json_load['column_names'], expected_raw_cols)
        self.assertEqual(json_load['mask'], mask.tolist())

        X_test = self.test_categorical_nan_F.drop(columns=self.label_column)
        X_test_selected = X_test.iloc[:, json_load['mask']]
        self.assertEqual(X_test_selected.columns.tolist(), expected_raw_cols)

        self.assertRaises(FileNotFoundError, selector.load_selected_features, filename='top_features.json')

    def test_save_load_selected_features_sparse_data_frame(self):
        selector = SelectTopFeatures(self.task, n=5, preprocess=True, client_id="test", logger=self.logger)
        X_train = self.sparse_df_train_featurized_no_var_C_nan_F
        y_train = self.train_no_var_C_nan_F[self.label_column]
        selector.fit_transform(X_train, y_train)
        json_dump = selector.save_selected_features()

        expected_raw_cols = ["A_MeanImputer", "S_MeanImputer", "Z_ModeImputer_Day", "Z_ModeImputer_DayOfYear",
                             "Z_ModeImputer_WeekOfMonth"]
        expected_raw_col_indices = [X_train.columns.get_loc(col) for col in expected_raw_cols]
        mask = np.full(X_train.shape[1], False, dtype=bool)
        mask[expected_raw_col_indices] = True

        self.assertTrue('column_names' in json_dump)
        self.assertTrue('mask' in json_dump)

        json_load = selector.load_selected_features()
        self.assertEqual(json_load['column_names'], expected_raw_cols)
        self.assertEqual(json_load['mask'], mask.tolist())

        X_test = self.sparse_df_test_featurized_no_var_C_nan_F
        X_test_selected = X_test.iloc[:, json_load['mask']]
        self.assertEqual(X_test_selected.columns.tolist(), expected_raw_cols)
        self.assertRaises(FileNotFoundError, selector.load_selected_features, filename='top_features.json')

    def tearDown(self):
        try:
            import os
            os.remove(constants.FEATURE_SELECTION_SELECTED_FEATURES_JSON_OUTPUT)
        except:
            pass
