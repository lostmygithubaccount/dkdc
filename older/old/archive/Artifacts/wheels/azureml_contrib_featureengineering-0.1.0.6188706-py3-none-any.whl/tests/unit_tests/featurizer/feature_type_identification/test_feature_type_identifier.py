import unittest

import numpy as np
import pandas as pd

from azureml.contrib.featureengineering.featurizer import FeatureTypeIdentifier
from azureml.contrib.featureengineering.featurizer import FeatureType


class FeatureTypeIdentifierTest(unittest.TestCase):

    def test_feature_type_identifier(self):
        transactions_df = pd.DataFrame({
            "transaction_id": [1, 2, 3, 4, 5, 6, 7, 8],
            "user_id": [1, 1, 2, 1, np.nan, 2, 3, 3],
            "amount": [500, 600, 300, 100, 80, 120, 30, 20],
            "descriptions": [
                "Machine learning tasks are classified into several broad categories.",
                "Classification and regression are types of supervised learning. ",
                "Machine learning and data mining often overlap significantly",
                "Machine learning and statistics are closely related fields. ",
                "A core objective of a learner is to generalize from its experience.",
                "Three broad categories of anomaly detection techniques exist",
                "An ANN is a model based on a collection of connected units or nodes.",
                "Deep learning consists of multiple hidden layers in an artificial neural network."
            ],
            "tuples": [[1, 2], [3, 4], [5, 6], [7, 8], [9, 10], [11, 12], [13, 14], [15, 16]],
            "transaction_time": pd.date_range('2014-01-01 08:00:50', periods=8, freq='12h')
        })

        feature_type_identifier = FeatureTypeIdentifier(is_inference_type=False)
        feature_type_identifier.identify_feature_types(transactions_df)
        columns_info = feature_type_identifier.get_columns_info()

        self.assertTrue(columns_info["transaction_id"].feature_type, FeatureType.Numeric)
        self.assertTrue(columns_info["user_id"].feature_type, FeatureType.Numeric)
        self.assertTrue(columns_info["amount"].feature_type, FeatureType.Numeric)
        self.assertTrue(columns_info["descriptions"].feature_type, FeatureType.Text)
        self.assertTrue(columns_info["tuples"].feature_type, FeatureType.Ignore)
        self.assertTrue(columns_info["transaction_time"].feature_type, FeatureType.DateTime)


if __name__ == '__main__':
    unittest.main()
