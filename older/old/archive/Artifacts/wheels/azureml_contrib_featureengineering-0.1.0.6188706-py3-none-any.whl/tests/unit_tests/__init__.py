from azureml.telemetry import set_diagnostics_collection
from azureml.dataprep import set_diagnostics_collection as set_diagnostics_collection_dataprep

print('Set send_diagnostics to False')
set_diagnostics_collection(send_diagnostics=False)
set_diagnostics_collection_dataprep(send_diagnostics=False)
