# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import unittest

import azureml.dataprep as dprep
import numpy as np
import pandas as pd
from azureml.dataprep.api.engineapi.typedefinitions import FieldType
from azureml.contrib.featureengineering.common import utilities


class DataflowConventionTest(unittest.TestCase):
    def setUp(self):
        self.transactions_df = pd.DataFrame({
            "transaction_id": ['1', '2', '3', '4', 5, 6, 7, 8],
            "user_id": [1, 1, 2, 1, np.nan, 2, 3, 3],
            "amount": [500, 600, 300, 100, 80, 120, 30, 20],
            "transaction_time": ['2014-01-01 08:00:50', '2014-01-02 08:00:50',
                                 '2014-01-03 08:00:50', '2014-01-03 08:00:50',
                                 '2014-01-03 08:00:50', '2014-01-03 08:00:50',
                                 '2014-01-06', '2014-01-05']
        })

    def test_convert_to_dataflow(self):
        dataflow = utilities.generate_dataflow(self.transactions_df)
        self.assertTrue(isinstance(dataflow, dprep.Dataflow), "should convert to dataflow")
        profile = dataflow.get_profile()
        self.assertEqual(profile.columns['transaction_id'].type, FieldType.STRING)
        self.assertEqual(profile.columns['user_id'].type, FieldType.DECIMAL)
        self.assertEqual(profile.columns['amount'].type, FieldType.INTEGER)
        self.assertEqual(profile.columns['transaction_time'].type, FieldType.STRING)

    def test_get_dataflow_conversion_candidates(self):
        dataflow: dprep.Dataflow = utilities.generate_dataflow(self.transactions_df)
        self.assertTrue(isinstance(dataflow, dprep.Dataflow), "should convert to dataflow")
        dataflow = utilities.proceed_dataflow_type_conversion(dataflow)
        data_profile = dataflow.get_profile()
        self.assertTrue(dataflow[-1:]._steps[0].step_type, "Microsoft.DPrep.SetColumnTypesBlock")
        self.assertEqual(data_profile.columns['transaction_id'].type, FieldType.INTEGER)
        self.assertEqual(data_profile.columns['user_id'].type, FieldType.DECIMAL)
        self.assertEqual(data_profile.columns['amount'].type, FieldType.INTEGER)
        self.assertEqual(data_profile.columns['transaction_time'].type, FieldType.DATE)
        self.assertTrue(True)

    def test_convert_dataflow_with_conversion_candidates(self):
        dataflow = utilities.generate_dataflow(self.transactions_df)
        dataflow = utilities.proceed_dataflow_type_conversion(dataflow)

        self.validation_transactions_df = pd.DataFrame({
            "transaction_id": ['1', '2', '3', '4', '5', '6', '7', '8'],
            "user_id": [1, 1, 2, 1, np.nan, 2, 3, 3],
            "amount": ['500', '600', '300', '100', '80', '120', '30', 20],
            "transaction_time": ['2014-01-01 08:00:50', '2014-01-02 08:00:50',
                                 '2014-01-03 08:00:50', '2014-01-03 08:00:50',
                                 '2014-01-03 08:00:50', '2014-01-03 08:00:50',
                                 '2014-01-06', '2014-01-0t5']
        })

        new_dataflow = utilities.generate_dataflow(self.validation_transactions_df)
        new_dataflow = utilities.convert_dataflow_with_conversion_step(new_dataflow, dataflow._steps[-1])

        profile = new_dataflow.get_profile()
        self.assertTrue(new_dataflow._steps[-1].step_type, "Microsoft.DPrep.SetColumnTypesBlock")
        self.assertEqual(profile.columns['transaction_id'].type, FieldType.INTEGER)
        self.assertEqual(profile.columns['user_id'].type, FieldType.DECIMAL)
        self.assertEqual(profile.columns['amount'].type, FieldType.INTEGER)
        self.assertEqual(profile.columns['transaction_time'].type, FieldType.DATE)


if __name__ == "__main__":
    unittest.main()
