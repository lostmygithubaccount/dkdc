import os
import unittest

import pandas as pd
import numpy as np

from numpy.ma.testutils import assert_array_equal
from pandas.testing import assert_frame_equal

from azureml.contrib.featureengineering.featurizer.transformer.timeseries.rolling_window import RollingWindow
from azureml.contrib.featureengineering.featurizer.transformer.timeseries.forecasting_pipeline import AzureMLForecastPipeline
from azureml.contrib.featureengineering.core.time_series_data_frame import TimeSeriesDataFrame

from tests.unit_tests.test_data.rossmann import load_rossmann_dataset


directory = os.path.dirname(os.path.abspath(__file__))

test_data_path = os.path.join(directory, "..\\..\\test_data", 'rollingwindow')

# Prepare testing data
train_ts, _ = load_rossmann_dataset()
train_ts = train_ts.loc[train_ts.grain_index.isin([1, 2])].copy()
train_ts = train_ts[train_ts.time_index <= '2013-01-10']

train_ts_multi_grain = train_ts.copy()
train_ts_multi_grain['Department'] = 1
train_ts_multi_grain = train_ts_multi_grain.reindex(time_colname='Date', grain_colnames=['Store', 'Department'])

train_ts_no_grain = train_ts.loc[train_ts.grain_index == 1].copy()
train_ts_no_grain.reset_index(level=train_ts_no_grain.grain_colnames, inplace=True)
train_ts_no_grain.grain_colnames = None

# test data for origin_time_colname
data_with_origin = pd.DataFrame({
    'date': pd.to_datetime((['2014'] * 4 + ['2015'] * 4 + ['2016'] * 4 +
                            ['2017'] * 4 + ['2018'] * 4) * 3),
    'store': [1, 2] * 30,
    'brand': (['A'] * 2 + ['B'] * 2) * 15,
    'origin': pd.to_datetime(['2011'] * 4 + ['2012'] * 4 + ['2013'] * 4 +
                             ['2014'] * 4 + ['2015'] * 4 + ['2012'] * 4 +
                             ['2013'] * 4 + ['2014'] * 4 + ['2015'] * 4 +
                             ['2016'] * 4 + ['2013'] * 4 + ['2014'] * 4 +
                             ['2015'] * 4 + ['2016'] * 4 + ['2017'] * 4),
    'sales': [i for i in range(0, 20)] * 3})

tsdf_with_origin = TimeSeriesDataFrame(
    data_with_origin, time_colname='date', grain_colnames=['store', 'brand'],
    origin_time_colname='origin', ts_value_colname='sales')
tsdf_with_origin.sort_index(inplace=True)

data_with_origin_transformed_expected = tsdf_with_origin.copy()
data_with_origin_transformed_expected['sales_sum_window2AS-JAN'] = \
    [np.nan] * 26 + [4.0, np.nan, np.nan, 8.0, np.nan, np.nan, 6.0, np.nan,
                     np.nan, 10.0, np.nan, 4.0, 12.0, np.nan, 8.0, 16.0, np.nan, 6.0, 14.0,
                     np.nan, 10.0, 18.0, 4.0, 12.0, 20.0, 8.0, 16.0, 24.0, 6.0, 14.0, 22.0,
                     10.0, 18.0, 26.0]

tsdf_with_origin_transformed_expected = TimeSeriesDataFrame(
    data_with_origin_transformed_expected, time_colname='date',
    grain_colnames=['store', 'brand'],
    origin_time_colname='origin', ts_value_colname='sales')
tsdf_with_origin_transformed_expected.sort_index(inplace=True)

# user defined rolling function for testing


def min_val(a):
    return min(a)


def quantile(a, q, *args, **kwargs):
    """
    This function is used to provide compatibility between versions of pandas having and
    not having interpolation parameter for the rolling window.
    The issue: pandas < 0.21.rc1 is using lower interpolation in pandas.DataFrame.rolling.quantile
    and this parameter is not tunable. pandas versions between 0.21.rc1 and  0.23.rc2 are
    using linear interpolation in pandas.DataFrame.rolling.quantile and this parameter is not tunable.
    pandas versions >= 0.23.rc2 allow to tune this parameter, but it is linear by default.
    To allow unit tests to go through in the lower versions of pandas we create our own quantile function which behaves
    in the way pandas.DataFrame.rolling.quantile used to work before 0.21.rc1.
    """
    return pd.Series(a).quantile(q, *args, **kwargs)


class TestRollingWindow(unittest.TestCase):

    """
    Unit tests for the RollingWindow transformer class

    Test cases:
    (+) Test integer window size.
    (+) Test offset window size.
    (+) Test aggregation function specified by string.
    (+) Test custom aggregation function.
    (+) Test window_opts.
    (+) Test transform_opts.
    (+) Test single aggregation function.
    (+) Test multiple aggregation function.
    (+) Test single column.
    (+) Test multiple columns.
    (+) Test multiple grain columns
    (+) Test train/test splitting
    (+) Test transform with non-ts_value column
    """

    def rw_common(self, rolling_window_transformer, expected_result_file, data):
        """
        This function perform the common tasks in all test cases.
        1) transform the testing data with the fitted transformer
        2) read the expected result from pickled result file
        3) assert that newly transformed result is the same as expected result
        4) write the results to a csv file for code review purpose
        """
        data_transformed = rolling_window_transformer.fit_transform(data)

        # Convert to pandas data frame, because the pickled result was saved from a pandas data frame. This is because
        # TSDF saved with to_pickle cannot be read by pd.read_pickle.
        data_transformed = pd.DataFrame(data_transformed)
        data_transformed = data_transformed.reindex(columns=sorted(data_transformed.columns))
        expected_result = pd.read_pickle(os.path.join(test_data_path, expected_result_file + '.pkl'))

        assert_frame_equal(data_transformed, expected_result)
        # Uncomment to write out new transform results in case of major changes to transform
        #
        # data_transformed.to_pickle(os.path.join(test_data_path, expected_result_file + '.pkl'))

    def _rename_columns(self, tsdf):
        """Rename columns with addition of period."""
        # This function to be used in case of new column name sconvention change.
        dir_rename = {}
        for colname in tsdf.columns.values:
            if "_window" in colname:
                dir_rename[colname] = colname + 'D'
        tsdf.rename(columns=dir_rename, inplace=True)
        return tsdf

    def test_simple(self):
        """
        A simple test case for single aggregation function, single column rolling window transformation.
        """
        expected_result_file = 'test_simple'

        window_size = 5
        transform_dict = {'sum': 'Sales'}
        rolling_window_transformer = RollingWindow(window_size, transform_dict)

        self.rw_common(rolling_window_transformer, expected_result_file, train_ts)

    def test_single_func_multi_col(self):
        """
        Test for single aggregation function and multiple columns rolling window transformation.
        """
        expected_result_file = 'test_single_func_multi_col'

        window_size = 5
        transform_dict = {'mean': ['Sales', 'Customers']}
        rolling_window_transformer = RollingWindow(window_size, transform_dict)

        self.rw_common(rolling_window_transformer, expected_result_file, train_ts)

    def test_multi_func_multi_col(self):
        """
        Test for multiple aggregation functions and multiple columns rolling window transformations
        """
        expected_result_file = 'test_multi_func_multi_col'

        window_size = '3D'
        transform_dict = {min_val: ['Sales', 'Customers'], 'mean': ['Sales']}
        rolling_window_transformer = RollingWindow(window_size, transform_dict)

        self.rw_common(rolling_window_transformer, expected_result_file, train_ts)

    def test_simple_opts(self):
        """
        A simple test case for single aggregation function, single column rolling window transformation, with
        window_opts and transform_opts.
        """
        expected_result_file = 'test_simple_opts'

        window_size = 5
        transform_dict = {quantile: 'Sales'}
        window_opts = {'min_periods': 2}
        # Pandas 0.23 added an interpolation option for quantiles when
        #  the quantile is between two data points.
        # Use interpolation=lower to get old behavior
        transform_opts = {quantile: {'args': [0.25],
                                     'kwargs': {'interpolation': 'lower'}}}
        rolling_window_transformer = RollingWindow(window_size, transform_dict,
                                                   window_opts, transform_opts)

        self.rw_common(rolling_window_transformer, expected_result_file,
                       train_ts)

    def test_single_func_multi_col_opts(self):
        """
        Test for single aggregation function and multiple columns rolling window transformation, with window_opts
        and transform_opts.
        """
        expected_result_file = 'test_single_func_multi_col_opts'

        window_size = 5
        transform_dict = {quantile: ['Sales', 'Customers']}
        window_opts = {'min_periods': 2}
        transform_opts = {quantile: {'args': [0.25], 'kwargs': {'interpolation': 'lower'}}}
        rolling_window_transformer = RollingWindow(window_size, transform_dict, window_opts, transform_opts)

        self.rw_common(rolling_window_transformer, expected_result_file, train_ts)

    def test_multi_func_multi_col_opts(self):
        """
        Test for multiple aggregation functions and multiple columns rolling window transformations, with window_opts
        and transform_opts.
        """
        expected_result_file = 'test_multi_func_multi_col_opts'

        window_size = '3D'
        transform_dict = {min_val: ['Sales', 'Customers'], quantile: ['Sales']}
        window_opts = {'min_periods': 1}
        transform_opts = {quantile: {'args': [0.25], 'kwargs': {'interpolation': 'lower'}}}
        rolling_window_transformer = RollingWindow(window_size, transform_dict, window_opts, transform_opts)

        self.rw_common(rolling_window_transformer, expected_result_file, train_ts)

    def test_no_grain(self):
        """
        Test for TimeSeriesDataFrame without grain property.
        """
        expected_result_file = 'test_no_grain'

        window_size = '3D'
        transform_dict = {min_val: ['Sales', 'Customers'], quantile: ['Sales']}
        window_opts = {'min_periods': 1}
        transform_opts = {quantile: {'args': [0.25], 'kwargs': {'interpolation': 'lower'}}}
        rolling_window_transformer = RollingWindow(window_size, transform_dict, window_opts, transform_opts)

        self.rw_common(rolling_window_transformer, expected_result_file, train_ts_no_grain)

    def test_multi_grain(self):
        """
        Test for when TSDF has multiple grain columns.
        """
        expected_result_file = 'test_multi_grain'

        window_size = '3D'
        transform_dict = {min_val: ['Sales', 'Customers'], quantile: ['Sales']}
        window_opts = {'min_periods': 1}
        transform_opts = {quantile: {'args': [0.25], 'kwargs': {'interpolation': 'lower'}}}
        rolling_window_transformer = RollingWindow(window_size, transform_dict, window_opts, transform_opts)

        self.rw_common(rolling_window_transformer, expected_result_file, train_ts_multi_grain)

    def test_pipeline(self):
        """
        Test using the rolling window transformer within a pipeline
        """

        expected_result_file = 'test_pipeline'

        window_size = '3D'
        transform_dict = {min_val: ['Sales', 'Customers'],
                          quantile: ['Sales']}
        window_opts = {'min_periods': 1}
        transform_opts = {quantile: {'args': [0.25],
                                     'kwargs': {'interpolation': 'lower'}}}
        rolling_window_transformer = RollingWindow(window_size, transform_dict,
                                                   window_opts, transform_opts)

        pipeline = AzureMLForecastPipeline(steps=[('rolling_transform',
                                                   rolling_window_transformer)])

        data_transformed = pipeline.fit_transform(train_ts)

        data_transformed = pd.DataFrame(data_transformed)
        data_transformed = data_transformed.reindex_axis(sorted(data_transformed.columns), axis=1)

        expected_result = pd.read_pickle(os.path.join(test_data_path, expected_result_file + '.pkl'))

        assert_frame_equal(data_transformed, expected_result)
        # Uncomment to write out new transform results in case of major changes to transform
        #
        # data_transformed.to_pickle(os.path.join(test_data_path, expected_result_file + '.pkl'))

    def test_with_origin(self):
        # Test on data with origin_time_colname
        window_size = 2
        transform_dict = {'sum': 'sales'}
        rolling_window_transformer = RollingWindow(window_size, transform_dict)
        tsdf_with_origin_transformed = rolling_window_transformer.fit_transform(
            tsdf_with_origin).sort_index()

        # Assert frame equal
        assert_frame_equal(tsdf_with_origin_transformed,
                           tsdf_with_origin_transformed_expected)

        # Assert meta data equal
        for attr in tsdf_with_origin_transformed_expected._metadata:
            attr_1 = getattr(tsdf_with_origin_transformed_expected, attr, None)
            attr_2 = getattr(tsdf_with_origin_transformed, attr, None)
            if isinstance(attr_1, list):
                attr_1 = sorted(attr_1)
            if isinstance(attr_2, list):
                attr_2 = sorted(attr_2)
            self.assertTrue(attr_1 == attr_2)

        # we expect that values will be the same for all slice_keys
        grouped = tsdf_with_origin_transformed['sales_sum_window2AS-JAN'].groupby(
            level=tsdf_with_origin_transformed.slice_key_colnames, group_keys=False)
        all_equal = grouped.apply(
            lambda X: np.array_equiv(X[0], X.values) or
            np.all(pd.isnull(X).values))
        self.assertTrue(np.all(all_equal.values))

    def test_train_test_split(self):
        """
        Test that train/test split works -
        i.e. is the train data caching in fit working?

        Use a rolling window transform with max_horizon=2
        to make sure caching works with multi-horizon
        features.

        train/test dataframes:

        >>> train_tsdf
                         Sales
        Date       Type
        2012-03-01 a         0
        2012-03-02 a         1
        2012-03-03 a         2
        2012-03-04 a         3
        2012-03-01 b         1
        2012-03-02 b         2
        2012-03-03 b         3
        2012-03-04 b         4

        >>> test_tsdf
                         Sales
        Date       Type
        2012-03-05 a         4
                   b         5

        Expected result of RollingWindow.transform(test_tsdf):

        >>> expected_tsdf
                                    Sales  Sales_sum_window2
        Date       Type OriginDate
        2012-03-05 a    2012-03-03      4               3.00
                        2012-03-04      4               5.00
                   b    2012-03-03      5               5.00
                        2012-03-04      5               7.00
        """

        # Make the train and test TSDFs
        train_range = pd.date_range(start='2012-03-01', periods=4, freq='D')
        train_dict = {'Type': ['a'] * 4 + ['b'] * 4,
                      'Date': list(train_range) * 2,
                      'Sales': list(range(4)) + list(range(1, 5))}
        train_tsdf = TimeSeriesDataFrame(train_dict, time_colname='Date',
                                         grain_colnames='Type',
                                         ts_value_colname='Sales')

        test_dict = {'Type': ['a', 'b'],
                     'Date': [pd.Timestamp('2012-03-05')] * 2,
                     'Sales': [4, 5]}
        test_tsdf = TimeSeriesDataFrame(test_dict, time_colname='Date',
                                        grain_colnames='Type',
                                        ts_value_colname='Sales')

        # Make a rolling window that sums the sales over previous two days
        window_size = 2
        transform_dict = {'sum': 'Sales'}
        xform = RollingWindow(window_size, transform_dict,
                              max_horizon=2,
                              origin_time_column_name='OriginDate')

        # Fit on training data, transform on the test set
        xform = xform.fit(train_tsdf)
        test_xformed = xform.transform(test_tsdf)

        # Make expected TSDF
        origin_list = [pd.Timestamp('2012-03-03'), pd.Timestamp('2012-03-04')]
        expected_dict = {'Date': [pd.Timestamp('2012-03-05')] * 4,
                         'Type': ['a', 'a', 'b', 'b'],
                         'OriginDate': origin_list * 2,
                         'Sales': [4, 4, 5, 5],
                         'Sales_sum_window2D': [3.0, 5.0, 5.0, 7.0]}

        expected_tsdf = TimeSeriesDataFrame(expected_dict, time_colname='Date',
                                            origin_time_colname='OriginDate',
                                            grain_colnames='Type',
                                            ts_value_colname='Sales')

        assert_frame_equal(test_xformed.sort_index(),
                           expected_tsdf.sort_index())

    def test_non_ts_value(self):
        """
        Test that rolling window transforms work on non-ts_value columns.

        Dataset is the same as in test_train_test_split, but with an
        extra column for customers.
        """
        train_range = pd.date_range(start='2012-03-01', periods=4, freq='D')
        train_dict = {'Type': ['a'] * 4 + ['b'] * 4,
                      'Date': list(train_range) * 2,
                      'Sales': list(range(4)) + list(range(1, 5)),
                      'Customers': [1] * 4 + [2] * 4}
        train_tsdf = TimeSeriesDataFrame(train_dict, time_colname='Date',
                                         grain_colnames='Type',
                                         ts_value_colname='Sales')

        # Make a rolling window that sums the sales over previous two days
        window_size = 2
        transform_dict = {'sum': 'Customers'}
        xform = RollingWindow(window_size, transform_dict,
                              max_horizon=1,
                              origin_time_column_name='OriginDate')

        # Fit on training data, transform on the test set
        train_xformed = xform.fit_transform(train_tsdf)
        train_xformed.sort_index(axis=1, inplace=True)

        # Make expected TSDF
        origin_range = train_range.shift(-1, freq='D')
        type_a_customer_rsum = np.array([np.nan, np.nan, 2.0, 2.0])
        expected_dict = train_dict.copy()
        expected_dict.update({'OriginDate': list(origin_range) * 2,
                              'Customers_sum_window2D':
                              np.concatenate([type_a_customer_rsum,
                                              2 * type_a_customer_rsum])})

        expected_tsdf = TimeSeriesDataFrame(expected_dict, time_colname='Date',
                                            origin_time_colname='OriginDate',
                                            grain_colnames='Type',
                                            ts_value_colname='Sales')

        assert_frame_equal(train_xformed.sort_index(),
                           expected_tsdf.sort_index(), check_like=True)

    def test_preview_column_names(self):
        """
        Test that we can preview new column names prior to
        applying the transform
        """

        train_range = pd.date_range(start='2012-03-01', periods=4, freq='D')
        train_dict = {'Type': ['a'] * 4 + ['b'] * 4,
                      'Date': list(train_range) * 2,
                      'Sales': list(range(4)) + list(range(1, 5)),
                      'Customers': [1] * 4 + [2] * 4}
        train_tsdf = TimeSeriesDataFrame(train_dict, time_colname='Date',
                                         grain_colnames='Type',
                                         ts_value_colname='Sales')

        window_size = 3
        transform_dict = {min_val: ['Customers', 'Sales'], 'mean': 'Sales'}
        xform = RollingWindow(window_size, transform_dict)

        expected_cols = ['Customers_min_val_window3D', 'Sales_min_val_window3D',
                         'Sales_mean_window3D']

        self.assertSetEqual(set(xform.preview_column_names(train_tsdf)),
                            set(expected_cols))

    def test_dropna(self):
        """
        Make sure the dropna option, when set, drops rows
        where the rolling window features are NA.

        Training frame is the same as in test_train_test_split.

        Expected output from RollingWindow.fit_transform(train_tsdf):

        >>> expected_tsdf
                                    Sales  Sales_mean_window2
        Date       Type OriginDate
        2012-03-03 a    2012-03-02      2                0.50
        2012-03-04 a    2012-03-03      3                1.50
        2012-03-03 b    2012-03-02      3                1.50
        2012-03-04 b    2012-03-03      4                2.50
        """

        train_range = pd.date_range(start='2012-03-01', periods=4, freq='D')
        train_dict = {'Type': ['a'] * 4 + ['b'] * 4,
                      'Date': list(train_range) * 2,
                      'Sales': list(range(4)) + list(range(1, 5))}
        train_tsdf = TimeSeriesDataFrame(train_dict, time_colname='Date',
                                         grain_colnames='Type',
                                         ts_value_colname='Sales')
        window_size = 2
        transform_dict = {'mean': 'Sales'}
        xform = RollingWindow(window_size, transform_dict,
                              origin_time_column_name='OriginDate',
                              dropna=True)

        train_xformed = xform.fit_transform(train_tsdf)

        # Form the expected output -
        #  should be missing the earliest two dates from the training data
        xform_range = train_range[2:]
        origin_range = xform_range.shift(-1, freq='D')
        expected_dict = {'Type': ['a'] * 2 + ['b'] * 2,
                         'Date': list(xform_range) * 2,
                         'OriginDate': list(origin_range) * 2,
                         'Sales': [2, 3, 3, 4],
                         'Sales_mean_window2D': [0.5, 1.5, 1.5, 2.5]}
        expected_tsdf = TimeSeriesDataFrame(expected_dict, time_colname='Date',
                                            origin_time_colname='OriginDate',
                                            grain_colnames='Type',
                                            ts_value_colname='Sales')

        assert_frame_equal(train_xformed.sort_index(),
                           expected_tsdf.sort_index())

    def test_max_horizon_as_dict(self):
        """
        Test rolling window transform when maximum horizon
        varies by grain

        The horizons are set by:
        >>> max_horizon = {'a': 2, 'b': 1}

        The train/test sets are the same as in test_train_test_split

        The expected data frame is:
        >>> expected_tsdf
                                    Sales  Sales_sum_window2
        Date       Type OriginDate
        2012-03-05 a    2012-03-03      4               3.00
                        2012-03-04      4               5.00
                   b    2012-03-04      5               7.00

        """
        # Make the train and test TSDFs
        train_range = pd.date_range(start='2012-03-01', periods=4, freq='D')
        train_dict = {'Type': ['a'] * 4 + ['b'] * 4,
                      'Date': list(train_range) * 2,
                      'Sales': list(range(4)) + list(range(1, 5))}
        train_tsdf = TimeSeriesDataFrame(train_dict, time_colname='Date',
                                         grain_colnames='Type',
                                         ts_value_colname='Sales')

        test_dict = {'Type': ['a', 'b'],
                     'Date': [pd.Timestamp('2012-03-05')] * 2,
                     'Sales': [4, 5]}
        test_tsdf = TimeSeriesDataFrame(test_dict, time_colname='Date',
                                        grain_colnames='Type',
                                        ts_value_colname='Sales')

        # Make a rolling window that sums the sales over previous two days
        window_size = 2
        transform_dict = {'sum': 'Sales'}
        max_horizon = {'a': 2, 'b': 1}
        xform = RollingWindow(window_size, transform_dict,
                              max_horizon=max_horizon,
                              origin_time_column_name='OriginDate')

        # Fit on training data, transform on the test set
        xform = xform.fit(train_tsdf)
        test_xformed = xform.transform(test_tsdf)

        # Make expected TSDF
        origin_list = [pd.Timestamp('2012-03-03'), pd.Timestamp('2012-03-04'),
                       pd.Timestamp('2012-03-04')]
        expected_dict = {'Date': [pd.Timestamp('2012-03-05')] * 3,
                         'Type': ['a', 'a', 'b'],
                         'OriginDate': origin_list,
                         'Sales': [4, 4, 5],
                         'Sales_sum_window2D': [3.0, 5.0, 7.0]}

        expected_tsdf = TimeSeriesDataFrame(expected_dict, time_colname='Date',
                                            origin_time_colname='OriginDate',
                                            grain_colnames='Type',
                                            ts_value_colname='Sales')

        assert_frame_equal(test_xformed.sort_index(),
                           expected_tsdf.sort_index())

    def test_force_horizon(self):
        """Test if setting force_horizon is obeyed."""
        data_ts = TimeSeriesDataFrame({'date': np.repeat(pd.date_range('2014-01-01', freq="AS", periods=4), 2),
                                       'store': [1, 2] * 4,
                                       'origin': np.repeat(pd.date_range('2013-01-01', freq="AS", periods=4), 2),
                                       'sales': np.arange(100, 108)
                                       },
                                      time_colname='date',
                                      grain_colnames=['store'],
                                      ts_value_colname='sales',
                                      origin_time_colname='origin'
                                      )
        # The presence of origin which lags to 1 should force rolling window to max_horizon=1.
        # Here is an expected data frame:
        expected_ts = TimeSeriesDataFrame({'date': np.repeat(pd.date_range('2014-01-01', freq="AS", periods=4), 2),
                                           'store': [1, 2] * 4,
                                           'origin': np.repeat(pd.date_range('2013-01-01', freq="AS", periods=4), 2),
                                           'sales': np.arange(100, 108),
                                           'sales_mean_window2AS-JAN': (list(np.repeat(np.NaN, 4)) +
                                                                        [101., 102., 103., 104.])
                                           },
                                          time_colname='date',
                                          grain_colnames=['store'],
                                          ts_value_colname='sales',
                                          origin_time_colname='origin'
                                          )
        test_rw = RollingWindow(window_size=2, transform_dictionary={'mean': 'sales'}, dropna=False, max_horizon=2)
        returned_val = test_rw.fit_transform(data_ts)
        assert_frame_equal(expected_ts, returned_val, check_like=True)
        # Next test if setting force_horizon to true will actually change horizon.
        self.assertEqual(test_rw.max_horizon, {1: 1, 2: 1}, "The max horizon was not inferred correctly")
        test_rw = RollingWindow(window_size=2,
                                transform_dictionary={'mean': 'sales'},
                                dropna=False,
                                max_horizon=2,
                                check_max_horizon=False
                                )
        returned_val = test_rw.fit_transform(data_ts)
        assert_frame_equal(expected_ts, returned_val, check_like=True)
        self.assertEqual(test_rw.max_horizon, 2, "The max horizon was inferred when check_max_horizon was False.")

    @unittest.skip('Big test which implicitly checks if rolling window creates memory issues.')
    def test_big_data_with_origin(self):
        """Temporary test to check memory issue. Implicitly test for out of memory error."""
        data_length = 50000
        window_size = 5
        target = 'demand'
        data = pd.DataFrame({
            'timeStamp': pd.date_range(start='2000-01-01', periods=data_length, freq='D'),
            'origin': pd.date_range(start='1999-12-31', periods=data_length, freq='D'),
            'demand': range(data_length),
            'grain': ['g'] * data_length
        })
        split_point = '2136-10-30'  # Take only 24 time points.
        X_train = TimeSeriesDataFrame(data[data['timeStamp'] < split_point],
                                      time_colname='timeStamp',
                                      origin_time_colname='origin',
                                      grain_colnames='grain',
                                      ts_value_colname=target)
        X_test = TimeSeriesDataFrame(data[data['timeStamp'] >= split_point],
                                     time_colname='timeStamp',
                                     origin_time_colname='origin',
                                     grain_colnames='grain',
                                     ts_value_colname=target)
        max_horizon = X_test.shape[0]
        transform_dict = {'max': 'demand', 'min': 'demand', 'mean': 'demand'}
        xform = RollingWindow(window_size, transform_dict,
                              max_horizon=max_horizon,
                              origin_time_column_name='origin')

        # Fit on training data, transform on the test set
        xform = xform.fit(X_train)
        xform.transform(X_test)

    def test_no_column_in_test(self):
        """Test column management in train and test."""
        data_length = 60
        window_size = 5
        target = 'demand'
        # Take 10 values for test set.
        X_train, X_test = self._get_train_test(data_length=data_length,
                                               target=target,
                                               split_point='2000-02-19')
        max_horizon = X_test.shape[0]
        transform_dict = {'max': 'demand', 'min': 'demand', 'mean': 'demand'}
        xform = RollingWindow(window_size, transform_dict,
                              max_horizon=max_horizon)
        # Fit on training data, transform on the test set
        xform = xform.fit(X_train)
        test_xformed = xform.transform(X_test)
        # Base case the target column is present and it should not be removed.
        self.assertTrue(target in test_xformed.columns, "The demand column was removed.")
        # The target column was not marked as target, but it should still remain in the data frame.
        X_test.ts_value_colname = None
        test_xformed = xform.transform(X_test)
        self.assertTrue(target in test_xformed.columns, "The demand column was removed.")
        # Now remove the column. It should not re appear, but the data should be featurised.
        X_test.drop(target, inplace=True, axis=1)
        test_xformed = xform.transform(X_test)
        self.assertFalse(target in test_xformed.columns, "The demand column is still in the data frame.")

    def test_cache_backfill(self):
        """Test if cache was backfilled."""
        data_length = 60
        window_size = 5
        target = 'demand'
        # Take 11 values for test set.
        X_train, X_test = self._get_train_test(data_length=data_length,
                                               target=target,
                                               split_point='2000-02-19')
        # Replace end of test by np.NaN-s.
        target_ar = X_train.ts_value.values.astype(float)
        target_ar[39] = np.nan
        target_ar[42:44] = np.nan
        target_ar[45:48] = np.nan
        X_train[X_train.ts_value_colname] = target_ar
        transform_dict = {'max': 'demand', 'min': 'demand', 'mean': 'demand'}
        xform = RollingWindow(window_size, transform_dict,
                              max_horizon=X_test.shape[0],
                              origin_time_column_name='origin')
        xform.fit(X_train)
        self.assertEqual(xform._cache[target].isna().sum(), 6, "The NA did not get to cache.")
        xform = RollingWindow(window_size, transform_dict,
                              max_horizon=X_test.shape[0],
                              origin_time_column_name='origin',
                              backfill_cache=True)
        xform.fit(X_train)
        self.assertEqual(xform._cache[target].isna().sum(), 0, "The na were not filled in.")
        expected = np.array([40., 40., 41., 44., 44., 44., 48., 48., 48., 48.])
        assert_array_equal(xform._cache[target].values[-10:], expected)

    def test_shape_issues(self):
        """Test if the output does not impose the shape issues."""
        data_length = 60
        window_size = 5
        target = 'demand'
        # Take 11 values for test set.
        X_train, X_test = self._get_train_test(data_length=data_length,
                                               target=target,
                                               split_point='2000-02-20')
        target_ar = X_train.ts_value.values.astype(float)
        target_ar[47] = np.nan
        X_train[X_train.ts_value_colname] = target_ar
        transform_dict = {'max': 'demand', 'min': 'demand', 'mean': 'demand'}
        xform = RollingWindow(window_size, transform_dict,
                              max_horizon=X_test.shape[0],
                              origin_time_column_name='origin', dropna=True)
        xform.fit(X_train)
        X_test.ts_value_colname = None
        X_test.drop(target, axis=1, inplace=True)
        transformed = xform.transform(X_test)
        self.assertEqual(transformed.shape[0], 28, "The NA-s were not cut.")
        # Now we want to backfill the NA-s
        xform = RollingWindow(window_size, transform_dict,
                              max_horizon=X_test.shape[0],
                              origin_time_column_name='origin',
                              dropna=True, backfill_cache=True)
        xform.fit(X_train)
        transformed = xform.transform(X_test)
        self.assertEqual(transformed.shape[0], 55, "The shape is wrong.")

    def _get_train_test(self, data_length, target, split_point='2000-02-19'):
        """Create the train and test data sets."""
        data = pd.DataFrame({
            'timeStamp': pd.date_range(start='2000-01-01', periods=data_length, freq='D'),
            target: range(data_length),
            'grain': ['g'] * data_length
        })
        X_train = TimeSeriesDataFrame(data[data['timeStamp'] < split_point],
                                      time_colname='timeStamp',
                                      grain_colnames='grain',
                                      ts_value_colname=target)
        X_test = TimeSeriesDataFrame(data[data['timeStamp'] >= split_point],
                                     time_colname='timeStamp',
                                     grain_colnames='grain',
                                     ts_value_colname=target)
        return X_train, X_test


if __name__ == '__main__':
    unittest.main()
