import unittest

from azureml.contrib.featureengineering.core.constants import TimeSeries, TimeSeriesInternal
from azureml.contrib.featureengineering.featurizer import Featurizer, FeaturizerConfig, TimeSeriesFeatureType

class TestFeaturizerConfig(unittest.TestCase):
    def test_default_config(self):
        config = FeaturizerConfig()
        self.assertTrue(config.enable_general_transform)
        self.assertFalse(config.enable_timeseries_transform)

    def test_default_in_featurizer(self):
        featurizer = Featurizer()
        self.assertTrue(featurizer._featurizer_config.enable_general_transform)
        self.assertFalse(featurizer._featurizer_config.enable_timeseries_transform)
        self.assertFalse(featurizer._is_onnx_compatible)

    def test_default_config_in_featurizer(self):
        config = FeaturizerConfig()
        featurizer = Featurizer(featurizer_config=config)
        self.assertTrue(featurizer._featurizer_config.enable_general_transform)
        self.assertFalse(featurizer._featurizer_config.enable_timeseries_transform)
        self.assertFalse(featurizer._is_onnx_compatible)

    def test_verify_settings(self):
        # for timeseries, enable_timeseries_transform=True and timeseries_param_dict needs to be available
        with self.assertRaises(ValueError):
            config = FeaturizerConfig(enable_general_transform=False, enable_timeseries_transform=True)

        # timeseries_param_dict 'time_column_name' must be provided
        timeseries_param_dict = {
            TimeSeries.MAX_HORIZON: 3
        }
        with self.assertRaises(ValueError):
            config = FeaturizerConfig(enable_general_transform=False, enable_timeseries_transform=True,
                                      **timeseries_param_dict)

    def test_enable_both_transforms(self):
        config = FeaturizerConfig(enable_general_transform=True, enable_timeseries_transform=True,
                                  **self._get_timeseries_param_dict())

        featurizer = Featurizer(featurizer_config=config)
        self.assertTrue(featurizer._featurizer_config.enable_general_transform)
        self.assertTrue(featurizer._featurizer_config.enable_timeseries_transform)
        self.assertFalse(featurizer._is_onnx_compatible)
        self.assertIsNotNone(featurizer._featurizer_config.get_ts_params_dict())

    def test_get_ts_columns_time_index_only(self):
        timeseries_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date'
        }
        config = FeaturizerConfig(enable_general_transform=True, enable_timeseries_transform=True,
                                  **timeseries_param_dict)
        ts_columns = config.get_ts_columns()
        self.assertTrue(len(ts_columns) == 1)
        self.assertTrue(ts_columns[0] == ('date', TimeSeriesFeatureType.Time))

    def test_get_ts_columns_grain_and_drop_column(self):
        timeseries_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'grain',
            TimeSeries.DROP_COLUMN_NAMES: 'drop',
        }
        config = FeaturizerConfig(enable_general_transform=True, enable_timeseries_transform=True,
                                  **timeseries_param_dict)
        ts_columns = config.get_ts_columns()
        self.assertTrue(len(ts_columns) == 3)
        self.assertTrue(('date', TimeSeriesFeatureType.Time) in ts_columns)
        self.assertTrue(('grain', TimeSeriesFeatureType.Grain) in ts_columns)
        self.assertTrue(('drop', TimeSeriesFeatureType.Drop) in ts_columns)

    def test_get_ts_columns_grain_columns(self):
        timeseries_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: ['grain1', 'grain2']
        }
        config = FeaturizerConfig(enable_general_transform=True, enable_timeseries_transform=True,
                                  **timeseries_param_dict)
        ts_columns = config.get_ts_columns()
        self.assertTrue(len(ts_columns) == 3)
        self.assertTrue(('date', TimeSeriesFeatureType.Time) in ts_columns)
        self.assertTrue(('grain1', TimeSeriesFeatureType.Grain) in ts_columns)
        self.assertTrue(('grain2', TimeSeriesFeatureType.Grain) in ts_columns)

    def test_get_ts_columns_rolling_window(self):
        transform_dict = {'min': ['Sales', 'Customers'], 'mean': ['Sales']}
        timeseries_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeriesInternal.WINDOW_SIZE: 3,
            TimeSeriesInternal.TRANSFORM_DICT: transform_dict
        }
        config = FeaturizerConfig(enable_general_transform=True, enable_timeseries_transform=True,
                                  **timeseries_param_dict)
        ts_columns = config.get_ts_columns()
        self.assertTrue(len(ts_columns) == 3)
        self.assertTrue(('date', TimeSeriesFeatureType.Time) in ts_columns)
        self.assertTrue(('Sales', TimeSeriesFeatureType.Transform) in ts_columns)
        self.assertTrue(('Customers', TimeSeriesFeatureType.Transform) in ts_columns)

    def test_get_ts_columns_lag_lead(self):
        timeseries_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.MAX_HORIZON: TimeSeriesInternal.MAX_HORIZON_DEFAULT,
            TimeSeriesInternal.LAGS_TO_CONSTRUCT: {'Sales': [-1, 0, 1]}
        }
        config = FeaturizerConfig(enable_general_transform=True, enable_timeseries_transform=True,
                                  **timeseries_param_dict)
        ts_columns = config.get_ts_columns()
        self.assertTrue(len(ts_columns) == 2)
        self.assertTrue(('date', TimeSeriesFeatureType.Time) in ts_columns)
        self.assertTrue(('Sales', TimeSeriesFeatureType.Transform) in ts_columns)

    def test_get_ts_columns_time_column_do_not_override(self):
        timeseries_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.MAX_HORIZON: TimeSeriesInternal.MAX_HORIZON_DEFAULT,
            TimeSeriesInternal.LAGS_TO_CONSTRUCT: {'date': [-1, 0, 1]}
        }
        config = FeaturizerConfig(enable_general_transform=True, enable_timeseries_transform=True,
                                  **timeseries_param_dict)
        ts_columns = config.get_ts_columns()
        self.assertTrue(len(ts_columns) == 1)
        self.assertTrue(('date', TimeSeriesFeatureType.Time) in ts_columns)

    @staticmethod
    def _get_timeseries_param_dict():
        return {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'grain',
            TimeSeries.MAX_HORIZON: 1
        }
