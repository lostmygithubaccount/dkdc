# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import unittest

from sklearn.preprocessing import Imputer

from azureml.contrib.featureengineering.featurizer.transformer import ImputationMarker
from azureml.contrib.featureengineering.featurizer.transformer import LambdaTransformer
from azureml.contrib.featureengineering.featurizer.transformer import GenericFeaturizers

from azureml.contrib.featureengineering.common.utilities import check_pickleable


class TestGenericFeaturizers(unittest.TestCase):

    def test_instance_creation(self):
        tr = GenericFeaturizers.imputer()
        self.assertTrue(isinstance(tr, Imputer))
        self.assertTrue(check_pickleable(tr), msg="Failed to pickle {}".format(type(tr).__name__))

        tr = GenericFeaturizers.imputation_marker()
        self.assertTrue(isinstance(tr, ImputationMarker))
        self.assertTrue(check_pickleable(tr), msg="Failed to pickle {}".format(type(tr).__name__))

        tr = GenericFeaturizers.lambda_featurizer(func=lambda x: x)
        self.assertTrue(isinstance(tr, LambdaTransformer))
        self.assertIsNone(tr.logger)
        self.assertTrue(check_pickleable(tr), msg="Failed to pickle {}".format(type(tr).__name__))


if __name__ == '__main__':
    unittest.main()
