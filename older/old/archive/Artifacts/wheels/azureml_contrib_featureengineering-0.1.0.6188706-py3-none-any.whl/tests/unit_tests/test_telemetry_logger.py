import logging
import sys
import unittest

from azureml.telemetry import set_diagnostics_collection
from azureml.telemetry.logging_handler import AppInsightsLoggingHandler

from azureml.contrib.featureengineering.common.logging import _LoggerFactory, cleanup_all_loggers


class TelemetryLoggerTests(unittest.TestCase):

    def test_telemetry_logger_without_appinsights(self):
        set_diagnostics_collection(send_diagnostics=False)
        logger = _LoggerFactory.get_logger(__name__, client_id="test")
        self.assertEqual(len(logger.handlers), 2)
        self.assertTrue(isinstance(logger.handlers[0], logging.FileHandler))
        self.assertTrue(isinstance(logger.handlers[1], logging.NullHandler))
        cleanup_all_loggers()

    def test_telemetry_logger_with_appinsights(self):
        set_diagnostics_collection(send_diagnostics=True)
        logger = _LoggerFactory.get_logger(__name__, client_id="test")
        self.assertEqual(len(logger.handlers), 2)
        self.assertTrue(isinstance(logger.handlers[0], logging.FileHandler))
        self.assertTrue(isinstance(logger.handlers[1], AppInsightsLoggingHandler))
        cleanup_all_loggers()
        set_diagnostics_collection(send_diagnostics=False)

    def test_telemetry_logger_with_extra_handlers(self):
        set_diagnostics_collection(send_diagnostics=True)
        logger = _LoggerFactory.get_logger(__name__, client_id="test", extra_handlers=[logging.StreamHandler(sys.stdout)])
        self.assertEqual(len(logger.handlers), 3)
        self.assertTrue(isinstance(logger.handlers[0], logging.FileHandler))
        self.assertTrue(isinstance(logger.handlers[1], logging.StreamHandler))
        self.assertTrue(isinstance(logger.handlers[2], AppInsightsLoggingHandler))
        cleanup_all_loggers()
        set_diagnostics_collection(send_diagnostics=False)