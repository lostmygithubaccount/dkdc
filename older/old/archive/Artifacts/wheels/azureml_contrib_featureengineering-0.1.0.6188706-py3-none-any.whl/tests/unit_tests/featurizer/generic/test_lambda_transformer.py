# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import unittest

import numpy as np
from azureml.contrib.featureengineering.featurizer.transformer import GenericFeaturizers as Gf


class LambdaTransformerTests(unittest.TestCase):
    def __init__(self, *args, **kwargs):
        super(LambdaTransformerTests, self).__init__(*args, **kwargs)
        self.lambda_transformer = Gf.lambda_featurizer(lambda x: x*x)

    def test_square_vals(self):
        x = np.array([1, 2])
        actual_array = self.lambda_transformer.fit_transform(x)
        expected_array = np.array([1, 4])
        self.assertTrue(np.all(actual_array == expected_array))


if __name__ == "__main__":
    unittest.main()
