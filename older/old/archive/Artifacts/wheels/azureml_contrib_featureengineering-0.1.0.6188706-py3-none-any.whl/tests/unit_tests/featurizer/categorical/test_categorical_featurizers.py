# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import unittest

from azureml.contrib.featureengineering.common.utilities import check_pickleable

from azureml.contrib.featureengineering.featurizer.transformer import CategoricalFeaturizers
from azureml.contrib.featureengineering.featurizer.transformer import CatImputer
from azureml.contrib.featureengineering.featurizer.transformer import HashOneHotVectorizerTransformer
from azureml.contrib.featureengineering.featurizer.transformer import LabelEncoderTransformer
from azureml.contrib.featureengineering.featurizer.transformer import OneHotEncoderTransformer
from azureml.contrib.featureengineering.featurizer.transformer.generic import CrossValidationTargetEncoder



class TestCategoricalFeaturizers(unittest.TestCase):

    def test_instance_creation(self):
        tr = CategoricalFeaturizers.hashonehot_vectorizer()
        self.assertTrue(isinstance(tr, HashOneHotVectorizerTransformer))
        self.assertTrue(check_pickleable(tr), msg="Failed to pickle {}".format(type(tr).__name__))

        tr = CategoricalFeaturizers.labelencoder()
        self.assertTrue(isinstance(tr, LabelEncoderTransformer))
        self.assertTrue(check_pickleable(tr), msg="Failed to pickle {}".format(type(tr).__name__))

        tr = CategoricalFeaturizers.cat_imputer()
        self.assertTrue(isinstance(tr, CatImputer))
        self.assertTrue(check_pickleable(tr), msg="Failed to pickle {}".format(type(tr).__name__))

        tr = CategoricalFeaturizers.cat_targetencoder()
        self.assertTrue(isinstance(tr, CrossValidationTargetEncoder))
        self.assertTrue(check_pickleable(tr), msg="Failed to pickle {}".format(type(tr).__name__))

        tr = CategoricalFeaturizers.woe_targetencoder()
        self.assertTrue(isinstance(tr, CrossValidationTargetEncoder))
        self.assertTrue(check_pickleable(tr), msg="Failed to pickle {}".format(type(tr).__name__))

        tr = CategoricalFeaturizers.onehotencoder()
        self.assertTrue(isinstance(tr, OneHotEncoderTransformer))
        self.assertTrue(check_pickleable(tr), msg="Failed to pickle {}".format(type(tr).__name__))


if __name__ == '__main__':
    unittest.main()
