import numpy as np
import pandas as pd
import unittest
import functools
import logging
import os
import shutil

from sklearn.preprocessing import MaxAbsScaler
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.pipeline import Pipeline
from sklearn.pipeline import make_pipeline
from sklearn import datasets

from azureml.contrib.featureengineering.featurizer.onnx_converter import OnnxConverter
from azureml.contrib.featureengineering.featurizer.onnx_converter import OnnxConvertConstants
from azureml.contrib.featureengineering.featurizer.onnx_converter import OnnxInferenceHelper
from azureml.contrib.featureengineering.featurizer import Featurizer, FeaturizerConfig
from azureml.contrib.featureengineering.featurizer.onnx_converter import OnnxInferenceHelper as automlOnnxInferenceHelper
from azureml.contrib.featureengineering.featurizer.transformer import LaggingTransformer

# to compare with automl onnx converter
from azureml.automl.core import featurization as automlpp
from azureml.automl.core.featurizer.transformer import LaggingTransformer as automlLaggingTransformer
from azureml.automl.core.onnx_convert import OnnxConverter as AutoMLOnnxConverter

# TODO. Add onnxruntime package in the test build pipeline, after all the latest
# needed onnx ops are supported and published to public.

# In core common, we don't do the prediction, since the latest
# onnxruntime python package is not published to public yet.
# In the AzureMlCli repo, we use a private wheel of onnxruntime only for the
# test depencency,
# and we compare the prediction results of Python model and ONNX model.
# The test enforces importing the onnxruntime package.
import onnxruntime as onnxrt

def function_log_print_wrapped(f):
    """Add logs wrapper around test case function."""
    @functools.wraps(f)
    def debug_log_wrapped(self, *args, **kwargs):
        print("----------------------------------------")
        print("[Test:{}.{}] Started.".format(self.__class__.__name__, f.__name__))
        r = f(self, *args, **kwargs)
        print("[Test:{}.{}] Ended.".format(self.__class__.__name__, f.__name__))
        print("----------------------------------------")
        return r
    return debug_log_wrapped


class OnnxConverterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.converter = OnnxConverter(logger=logging.getLogger('OnnxConverterTest'))
        cls.automl_converter = AutoMLOnnxConverter(logger=logging.getLogger('AutoMLOnnxConverterTest'))
        cls._compare_with_automl = True
        script_dir = os.path.dirname(__file__)
        cls.directory = os.path.join(script_dir, 'test_output')
        if not os.path.exists(cls.directory):
            os.makedirs(cls.directory)

    @function_log_print_wrapped
    def test_convert_with_transformer_numeric_without_imputationmarker(self):

        # Initialize data
        X = pd.DataFrame([[1, 2.5], [2, 3.1], [np.nan, 3.5], [6, 7.8], [16, 20.3],
                          [12, 23.5], [22, 33.1], [52, 13.5], [62, 67.8], [162, 210.3],
                          [13, 52.5], [23, 13.1], [53, 23.5], [63, 67.8], [163, 320.3],
                          [11, 22.5], [12, 13.1], [15, 33.5], [6, 17.8], [16, 210.3],
                          [15, 25.5], [25, 3.1], [5, 3.5], [6, 7.8], [26, 20.3],
                          [3, 32.5], [4, 33.1], [35, 43.5], [36, 37.8], [316, 30.3],
                          [2, 1.5], [1, 1.1], [1, 23.5], [68, 71.8], [36, 21.3],
                          [3, 3.5], [3, 4.1], [20, 1.5], [2, 7.28], [103, 22.3],
                          [40, 4.5], [6, 2.1], [300, 2.5], [30, 72.8], [14, 23.3],
                          [5, 2.7], [50, 6.1], [40, 4.5], [4, 73.8], [15, 204.3],
                          [60, 2.6], [8, 32.1], [66, 5.5], [5, 74.8], [17, 25.3],
                          [7, 22.8], [79, 7.1], [107, 6.5], [73, 7.58], [36, 26.3],
                          [88, 3.5], [6, 8.1], [8, 7.5], [8, 76.8], [66, 27.3],
                          [9, 21.5], [26, 9.1], [123, 9.5], [32, 77.8], [56, 28.3],
                          [5, 2.7], [5, 6.001], [4, 4.5], [4, 73.8], [150, 24.3],
                          [6, 2.6], [8, 32.1], [66, 5.5], [5, 74.8], [17, 25.3],
                          [67, 22.8], [17, 7.1], [67, 6.5], [37, 7.58], [36, 26.3],
                          [78, 13.5], [26, 18.1], [58, 27.5], [84, 736.8], [66, 47.3],
                          [96, 21.5], [236, 91.1], [123, 59.5], [32, 77.8], [56, 23.3],
                          [85, 2.07], [53, 6.01], [421, 17.05], [64, 730.8], [15, 26.3],
                          [25, 20.7], [123, 60.1], [131, 17.5], [321, 73.8], [15, 206.3],
                          [68, 3.5], [63, 8.1], [8, 24.5], [58, 76.8], [66, 17.3],
                          [91, 21.5], [536, 19.1], [1233, 39.5], [32, 77.8], [56, 38.3],
                          [51, 2.7], [53, 60.1], [224, 4.5], [47, 73.8], [15, 242.3],
                          [311, 3.51], [372, 4.21], [92, 1.35], [20, 7.28], [131, 223.3],
                          [433, 4.345], [61, 2.51], [30, 2.75], [83, 72.88], [143, 223.33]],
                         columns=["C0", "C1"]).astype(np.float32)
        y = [1, 3, 5, 3, 16, 12, 33, 54, 35, 166,
             10, 30, 50, 30, 106, 10, 30, 50, 30, 106,
             11, 13, 15, 13, 116, 11, 13, 15, 13, 116,
             21, 23, 25, 23, 216, 21, 23, 25, 23, 216,
             31, 33, 35, 33, 316, 31, 33, 35, 33, 316,
             41, 43, 45, 43, 416, 41, 43, 45, 43, 416,
             51, 53, 55, 53, 516, 51, 53, 55, 53, 516,
             16, 36, 56, 36, 166, 16, 36, 56, 36, 166,
             17, 37, 57, 37, 167, 17, 37, 57, 37, 167,
             71, 73, 75, 73, 716, 71, 73, 75, 73, 716,
             61, 63, 65, 63, 616, 61, 63, 65, 63, 616,
             19, 39, 59, 39, 169, 19, 93, 59, 39, 196,
             18, 38, 58, 38, 168, 18, 38, 58, 38, 186, ]

        # Run Featurizer ONNX Converter
        onnx_mdl = self._test_featurizer_onnx_converter(X, y, "test_numeric_without_imputationmarker.onnx",
                                                                  "test_numeric_without_imputationmarker_res.pkl")

        if self._compare_with_automl:
            Xs = pd.DataFrame([[11, 12.5], [12, 3.1], [61, 13.5], [np.nan, 7.8], [136, 210.3]],
                              columns=["C0", "C1"]).astype(np.float32)
            input_feed = {"C0": Xs['C0'].values.reshape(-1, 1), "C1": Xs['C1'].values.reshape(-1, 1)}
            # Run AutoML ONNX Converter
            automl_onnx_mdl, automl_onnx_res = self._test_automl_onnx_converter(X, y, "test_numeric_without_imputationmarker_automl.onnx")
            self._compare_onnx_converters("test_numeric_without_imputationmarker.onnx",
                                          "test_numeric_without_imputationmarker_automl.onnx",
                                          input_feed)

    @function_log_print_wrapped
    def test_convert_with_transformer_numeric_with_imputationmarker(self):

        # Initialize Data
        X = pd.DataFrame([[1, 2.5], [2, 3.1], [np.nan, 3.5], [6, 7.8], [16, 20.3]], columns=["C0", "C1"]).astype(np.float32)
        y = [1, 3, 5, 3, 16]

        # Run Featurizer ONNX Converter
        onnx_mdl = self._test_featurizer_onnx_converter(X, y, "test_numeric_with_imputationmarker.onnx",
                                                                  "test_numeric_with_imputationmarker_res.pkl")

        if self._compare_with_automl:
            Xs = pd.DataFrame([[11, 12.5], [12, 3.1], [61, 13.5], [np.nan, 7.8], [136, 210.3]],
                              columns=["C0", "C1"]).astype(np.float32)
            input_feed = {"C0": Xs['C0'].values.reshape(-1, 1), "C1": Xs['C1'].values.reshape(-1, 1)}
            # Run AutoML ONNX Converter
            automl_onnx_mdl, automl_onnx_res = self._test_automl_onnx_converter(X, y, "test_numeric_with_imputationmarker_automl.onnx")
            self._compare_onnx_converters("test_numeric_with_imputationmarker.onnx",
                                          "test_numeric_with_imputationmarker_automl.onnx",
                                          input_feed)

    @function_log_print_wrapped
    def test_convert_with_transformer_categorical_int(self):

        # Initialize data
        X = pd.DataFrame([5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, np.nan, 5, 5], dtype='int64', columns=["C0"])
        # Note, np.nan will be converted to min_val of the int64 type.
        y = [1, 9, 9, 9, 16, 1, 9, 9, 9, 16,
             1, 9, 9, 9, 16, 1, 9, 9, 9, 16,
             9, 9, 9, 16, 1, 9, 9, 1, 9, 9,
             1, 9, 9, 9, 16, 1, 9, 9, 9, 16,
             9, 9, 9, 16, 1, 9, 9, 1, 9, 9,
             1, 9, 9, 9, 16, 1, 9, 9, 9, 16,
             1, 9, 9, 9, 16, 1, 9, 9, 9, 16,
             9, 9, 9, 16, 1, 9, 9, 1, 9, 9,
             1, 9, 9, 9, 16, 1, 9, 9, 9, 16,
             9, 9, 9, 16, 1, 9, 9, 1, 9, 9]

        # Run Featurizer ONNX Converter
        onnx_mdl = self._test_featurizer_onnx_converter(X, y, "test_categorical_int.onnx",
                                                                  "test_categorical_int_res.pkl")

        if self._compare_with_automl:
            # re-init X since it got altered above
            X = pd.DataFrame([5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, np.nan, 5, 5], dtype='int64', columns=["C0"])
            Xs = pd.DataFrame([5, 5, 5, 5, 5, 5, 5, 16, 5, 3,
                               5, 5, 15, 5, 5, 5, 5, 5, 5, 3,
                               5, 5, 5, 5, 15, 5, 5, 16, 5, 3,
                               5, 5, 5, 5, 5, 5, 5, np.nan, 5, 3,
                               5, 16, 15, 5, 5, 5, 35, 5, 5, 3,
                               5, 16, 15, 5, 5, 5, 15, 5, 5, 3,
                               5, 16, 12, 5, 5, 5, 65, 5, 5, 3,
                               5, 16, 15, 5, np.nan, 5, 4, 5, 5, 3,
                               5, 16, 15, 5, 5, 5, 7, 5, 5, 3,
                               5, 16, 12, 5, 5, 5, 65, 5, 5, 5], dtype='int64', columns=["C0"])
            input_feed = {"C0": Xs.values}
            # Run AutoML ONNX Converter
            automl_onnx_mdl, automl_onnx_res = self._test_automl_onnx_converter(X, y, "test_categorical_int_automl.onnx")
            self._compare_onnx_converters("test_categorical_int.onnx",
                                          "test_categorical_int_automl.onnx",
                                          input_feed)

    @function_log_print_wrapped
    def test_convert_with_transformer_and_with_lagging_transformer_cat_int(self):

        X = pd.DataFrame([5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                          5, 5, 5, 5, 5, 5, 5, np.nan, 5, 5], dtype='int64', columns=['C0'])
        y = [1, 5, 5, 5, 16, 1, 5, 5, 5, 16,
             1, 5, 5, 5, 16, 1, 5, 5, 5, 16,
             5, 5, 5, 16, 1, 5, 5, 1, 5, 5,
             1, 5, 5, 5, 16, 1, 5, 5, 5, 16,
             5, 5, 5, 16, 1, 5, 5, 1, 5, 5,
             1, 5, 5, 5, 16, 1, 5, 5, 5, 16,
             1, 5, 5, 5, 16, 1, 5, 5, 5, 16,
             5, 5, 5, 16, 1, 5, 5, 1, 5, 5,
             1, 5, 5, 5, 16, 1, 5, 5, 5, 16,
             5, 5, 5, 16, 1, 5, 5, 1, 5, 5]

        featurizer = Featurizer(is_onnx_compatible=True, client_id="test")
        X_train = featurizer.fit_transform(X)

        # Lag lengh is 1.
        lag_transformer = LaggingTransformer(1)
        X_train = lag_transformer.fit_transform(X_train)

        new_pipe = make_pipeline(featurizer, lag_transformer)

        # Convert.
        onnx_mdl, err = featurizer.to_onnx(new_pipe, 'test with transformer', 'test with transformer')
        self.assertTrue(onnx_mdl is not None, msg=str(err))

        if self._compare_with_automl:
            X = pd.DataFrame([5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                              5, 5, 5, 5, 5, 5, 5, np.nan, 5, 5], dtype='int64', columns=['C0'])
            Xs = pd.DataFrame([5, 5, 5, 5, 5, 5, 5, 16, 5, 3,
                               5, 5, 15, 5, 5, 5, 5, 5, 5, 3,
                               5, 5, 5, 5, 15, 5, 5, 16, 5, 3,
                               5, 5, 5, 5, 5, 5, 5, np.nan, 5, 3,
                               5, 16, 15, 5, 5, 5, 35, 5, 5, 3,
                               5, 16, 15, 5, 5, 5, 15, 5, 5, 3,
                               5, 16, 12, 5, 5, 5, 65, 5, 5, 3,
                               5, 16, 15, 5, np.nan, 5, 4, 5, 5, 3,
                               5, 16, 15, 5, 5, 5, 7, 5, 5, 3,
                               5, 16, 12, 5, 5, 5, 65, 5, 5, 5], dtype='int64')

            self.automl_converter.initialize_input(X)

            transformer = automlpp.DataTransformer(is_onnx_compatible=True)
            automl_X_train = transformer.fit_transform(X)
            automl_lag_transformer = automlLaggingTransformer(1)
            automl_X_train = automl_lag_transformer.fit_transform(automl_X_train)
            automl_pipe = make_pipeline(transformer, automl_lag_transformer)
            # Convert.
            automl_onnx_mdl, err = self.automl_converter.convert(automl_pipe, 'test automl onnx converter',
                                                          'test automl onnx converter')
            self.assertTrue(automl_onnx_mdl is not None, msg=str(err))

            # input_feed = {"C0": Xs.values}

            # Compare results
            # self._compare_onnx_converters("test_lagging_trans_cat_int.onnx",
            #                               "test_lagging_trans_cat_int_automl.onnx",
            #                               input_feed)

    @function_log_print_wrapped
    def test_convert_with_transformer_and_with_hashonehotvectorizer(self):

        # Initialize data
        nparr = np.array(['cat', 'bear', 'elephant', 'dear', 'cat', 'cat'])
        X = pd.DataFrame(data=nparr, columns=["animal"])
        y = [1, 3, 5, 6, 1, 1]

        # Run Featurizer ONNX Converter
        onnx_mdl = self._test_featurizer_onnx_converter(X, y, "test_hashonehotvectorizer.onnx",
                                                                  "test_hashonehotvectorizer_res.pkl")

        if self._compare_with_automl:
            x_t = np.array(['cat', 'bear'])
            Xs = pd.DataFrame(data=x_t, columns=["animal"])
            input_feed = {"animal": x_t.reshape(-1, 1)}
            # Run AutoML ONNX Converter
            automl_onnx_mdl, automl_onnx_res = self._test_automl_onnx_converter(X, y, "test_hashonehotvectorizer_automl.onnx")
            # self._compare_onnx_converters("test_hashonehotvectorizer.onnx",
            #                               "test_hashonehotvectorizer_automl.onnx",
            #                               input_feed)

    @function_log_print_wrapped
    def test_convert_with_trans_and_with_datetime_trans_and_catimputer_for_string_input_1(self):
        X = pd.DataFrame([["2018-02-03 10:11:16", np.float32(2.3)],
                          ["2018-02-05 11:11:16", np.float32(3.3)],
                          ["2018-02-06 12:11:16", np.float32(4.3)],
                          ["2018-02-07 13:11:16", np.float32(5.13)],
                          ["2018-02-08 14:11:16", np.float32(6.53)],
                          ["2018-02-09 15:11:16", np.float32(8.3)],
                          ["2018-02-11 16:11:16", np.float32(6.6)],
                          ["2018-02-12 17:11:16", np.float32(11.6)]],
                         columns=['date col', 'val'])
        y = [5, 6, 7, 9, 11, 12, 11, 15]

        expected_onnx_res = {
            OnnxConvertConstants.InputOnnxColumnSchema: {
                'date_col': 'StringTensorType', 'val': 'FloatTensorType'
            },
            OnnxConvertConstants.InputRawColumnSchema: {
                'date col': 'datetime64', 'val': 'floating'
            },
            OnnxConvertConstants.RawColumnNameToOnnxNameMap: {
                'date col': 'date_col', 'val': 'val'
            }
        }
        # Run Featurizer ONNX Converter
        onnx_mdl = self._test_featurizer_onnx_converter(X, y, "test_datetime_transformer_1.onnx",
                                                                  "test_datetime_transformer_1_res.pkl",
                                                                  expected_onnx_res)

        if self._compare_with_automl:
            Xs = pd.DataFrame([["2018-02-07 18:56:35", np.float32(3.5)],
                               ["2018-02-08 08:12:35", np.float32(11.5)],
                               ["2018/02/09 9:51:35", np.float32(12.3)],
                               ["2018/02/10 11:16:19", np.float32(15.3)],
                               ["2018-02-11 13:16:19", np.float32(13.3)],
                               ["2018-02-12 15:16:19", np.float32(19.0)],
                               ["2018-02-13 19:16:19", np.float32(10.9)]
                               ],
                              columns=['date col', 'val'])
            input_feed = {"date_col": Xs['date col'].values.reshape(-1, 1),
                                       "val": Xs['val'].values.reshape(-1, 1).astype(np.float32)}
            # Run AutoML ONNX Converter
            automl_onnx_mdl, automl_onnx_res = self._test_automl_onnx_converter(X, y, "test_datetime_transformer_automl_1.onnx")
            self._compare_onnx_converters("test_datetime_transformer_1.onnx",
                                          "test_datetime_transformer_automl_1.onnx",
                                          input_feed)

    @function_log_print_wrapped
    def test_convert_with_trans_and_with_datetime_trans_and_catimputer_for_string_input_2(self):
        X = pd.DataFrame([["2018-02-03 10:11:16", np.float32(2.3)],
                          ["2018-02-05 11:11:16", np.float32(3.3)],
                          ["2018-02-06 12:11:16", np.float32(4.3)],
                          ["2018-02-07 13:11:16", np.float32(5.13)],
                          ["2018-02-08 14:11:16", np.float32(6.53)],
                          ["2018-02-09 15:11:16", np.float32(8.3)],
                          ["2018-02-11 16:11:16", np.float32(6.6)],
                          ["2018-02-12 17:11:16", np.float32(11.6)]],
                         columns=['date col', 'val'])
        y = [5, 6, 7, 9, 11, 12, 11, 15]

        # Explicitly indicate the 'date' column as pandas
        X['date col'] = pd.to_datetime(X['date col'])

        expected_onnx_res = {
            OnnxConvertConstants.InputOnnxColumnSchema: {
                'date_col': 'StringTensorType', 'val': 'FloatTensorType'
            },
            OnnxConvertConstants.InputRawColumnSchema: {
                'date col': 'datetime64', 'val': 'floating'
            },
            OnnxConvertConstants.RawColumnNameToOnnxNameMap: {
                'date col': 'date_col', 'val': 'val'
            }
        }
        # Run Featurizer ONNX Converter
        onnx_mdl = self._test_featurizer_onnx_converter(X, y, "test_datetime_transformer_2.onnx",
                                                                  "test_datetime_transformer_2_res.pkl",
                                                                  expected_onnx_res)

        if self._compare_with_automl:
            Xs = pd.DataFrame([["2018-02-07 18:56:35", np.float32(3.5)],
                               ["2018-02-08 08:12:35", np.float32(11.5)],
                               ["2018/02/09 9:51:35", np.float32(12.3)],
                               ["2018/02/10 11:16:19", np.float32(15.3)],
                               ["2018-02-11 13:16:19", np.float32(13.3)],
                               ["2018-02-12 15:16:19", np.float32(19.0)],
                               ["2018-02-13 19:16:19", np.float32(10.9)]
                               ],
                              columns=['date col', 'val'])
            Xs['date col'] = pd.to_datetime(Xs['date col'])

            # Run AutoML ONNX Converter
            automl_onnx_mdl, automl_onnx_res = self._test_automl_onnx_converter(X, y, "test_datetime_transformer_automl_2.onnx")
            self._compare_onnx_converters_using_inference_helper("test_datetime_transformer_2.onnx", "test_datetime_transformer_2_res.pkl",
                                                                 automl_onnx_mdl, automl_onnx_res,
                                                                 Xs)

    @function_log_print_wrapped
    def test_convert_with_trans_and_with_datetime_trans_and_catimputer_for_string_input_3(self):
        X = pd.DataFrame([["2018-02-03", np.float32(2.3)],
                          ["2018-02-05 11:11:16", np.float32(3.3)],
                          ["2018-02-06 12:11:16", np.float32(4.3)],
                          ["2018-02-07 13:11:16", np.float32(5.13)],
                          ["2018-02-08 14:11:16", np.float32(6.53)],
                          ["2018-02-09 15:11:16", np.float32(8.3)],
                          ["2018-02-11 16:11:16", np.float32(6.6)],
                          ["2018-02-12 17:11:16", np.float32(11.6)]],
                         columns=['date col', 'val'])
        y = [5, 6, 7, 9, 11, 12, 11, 15]

        expected_onnx_res = {
            OnnxConvertConstants.InputOnnxColumnSchema: {
                'date_col': 'StringTensorType', 'val': 'FloatTensorType'
            },
            OnnxConvertConstants.InputRawColumnSchema: {
                'date col': 'datetime64', 'val': 'floating'
            },
            OnnxConvertConstants.RawColumnNameToOnnxNameMap: {
                'date col': 'date_col', 'val': 'val'
            }
        }
        # Run Featurizer ONNX Converter
        onnx_mdl = self._test_featurizer_onnx_converter(X, y, "test_datetime_transformer_3.onnx",
                                                                  "test_datetime_transformer_3_res.pkl",
                                                                  expected_onnx_res)

        if self._compare_with_automl:
            Xs = pd.DataFrame([["2018-02-07 18:56:35", np.float32(3.5)],
                               ["2018-02-08 08:12:35", np.float32(11.5)],
                               ["2018/02/09 9:51:35", np.float32(12.3)],
                               ["2018/02/10 11:16:19", np.float32(15.3)],
                               ["2018-02-11 13:16:19", np.float32(13.3)],
                               ["2018-02-12 15:16:19", np.float32(19.0)],
                               ["2018-02-13 19:16:19", np.float32(10.9)],
                               ["None", np.float32(10.9)],
                               [None, np.float32(10.9)]
                               ],
                              columns=['date col', 'val'])
            input_feed = {"date_col": Xs['date col'].values.reshape(-1, 1),
                          "val": Xs['val'].values.reshape(-1, 1).astype(np.float32)}
            # Run AutoML ONNX Converter
            automl_onnx_mdl, automl_onnx_res = self._test_automl_onnx_converter(X, y, "test_datetime_transformer_automl_3.onnx")
            self._compare_onnx_converters("test_datetime_transformer_3.onnx",
                                          "test_datetime_transformer_automl_3.onnx",
                                          input_feed)

    @function_log_print_wrapped
    def test_convert_with_trans_and_with_text(self):
        text = [['this is text one'],
                ['next is two'],
                ['last is three']]
        X = pd.DataFrame(data=text, columns=['C0'])
        y = np.array([0, 1, 2])

        # Run Featurizer ONNX Converter
        onnx_mdl = self._test_featurizer_onnx_converter(X, y, "test_convert_with_trans_and_with_text.onnx",
                                                                  "test_convert_with_trans_and_with_text_res.pkl")

        if self._compare_with_automl:
            # Run AutoML ONNX Converter
            # TODO: add onnxrt session run
            automl_onnx_mdl, automl_onnx_res = self._test_automl_onnx_converter(X, y, "test_convert_with_trans_and_with_text_automl.onnx")
            self.assertTrue(onnx_mdl.graph.input == automl_onnx_mdl.graph.input)
            self.assertTrue(str(onnx_mdl.graph.node) == str(automl_onnx_mdl.graph.node))
            self.assertTrue(onnx_mdl.graph.output == automl_onnx_mdl.graph.output)

    @function_log_print_wrapped
    def test_convert_with_trans_cat_greater_than_two_categories(self):

        # Initialize data
        nparr = np.repeat(np.array([0, 1, 2], dtype=np.int64), 100)
        x_column_names = np.array(['C0'])
        X = pd.DataFrame(data=nparr, columns=x_column_names)
        y = np.repeat([5, 6, 7], 100)

        # Run Featurizer ONNX Converter
        onnx_mdl = self._test_featurizer_onnx_converter(X, y, "test_convert_with_trans_cat_greater_than_two_categories.onnx",
                                                                  "test_convert_with_trans_cat_greater_than_two_categories_res.pkl")

        if self._compare_with_automl:
            # Run AutoML ONNX Converter
            # TODO: add onnxrt session run
            automl_onnx_mdl, automl_onnx_res = self._test_automl_onnx_converter(X, y, "test_convert_with_trans_cat_greater_than_two_categories_automl.onnx")
            self.assertTrue(onnx_mdl.graph.input == automl_onnx_mdl.graph.input)
            self.assertTrue(str(onnx_mdl.graph.node) == str(automl_onnx_mdl.graph.node))
            self.assertTrue(onnx_mdl.graph.output == automl_onnx_mdl.graph.output)

    @function_log_print_wrapped
    def test_convert_with_trans_digits_classification_missing_data(self):

        # Initialize data
        digits = datasets.load_digits()
        test_size = 10
        train_size = 200
        X_train = digits.data[test_size:test_size + train_size, :]
        y_train = digits.target[test_size:test_size + train_size]

        X = pd.DataFrame(data=X_train)
        X.rename(columns=lambda x: str(x), inplace=True)
        y = y_train

        # Run Featurizer ONNX Converter
        onnx_mdl = self._test_featurizer_onnx_converter(X, y, "test_convert_with_trans_digits_classification_missing_data.onnx",
                                                                  "test_convert_with_trans_digits_classification_missing_data_res.pkl")

        if self._compare_with_automl:
            # Run AutoML ONNX Converter
            automl_onnx_mdl, automl_onnx_res = self._test_automl_onnx_converter(X, y, "test_convert_with_trans_digits_classification_missing_data_automl.onnx")
            self.assertTrue(onnx_mdl.graph.input == automl_onnx_mdl.graph.input)
            self.assertTrue(str(onnx_mdl.graph.node) == str(automl_onnx_mdl.graph.node))
            self.assertTrue(onnx_mdl.graph.output == automl_onnx_mdl.graph.output)

    @function_log_print_wrapped
    def test_convert_with_trans_boolean_mixed_data(self):
        X = pd.DataFrame([[True, True, np.float32(2.3)],
                          [True, np.nan, np.float32(3.3)],
                          [True, 11.0, np.float32(4.3)],
                          [False, np.nan, np.float32(5.13)],
                          [True, np.nan, np.float32(6.53)],
                          [False, 10.0, np.float32(8.3)],
                          [False, True, np.float32(6.6)],
                          [True, np.nan, np.float32(11.6)]],
                         columns=['bool_col', 'mixed_col', 'val'])
        y = [1, 2, 1, 2, 1, 3, 2, 1]

        # Run Featurizer ONNX Converter
        onnx_mdl = self._test_featurizer_onnx_converter(X, y, "test_convert_with_trans_boolean_mixed_data.onnx",
                                                                  "test_convert_with_trans_boolean_mixed_data_res.pkl")

        if self._compare_with_automl:
            # Run AutoML ONNX Converter
            automl_onnx_mdl, automl_onnx_res = self._test_automl_onnx_converter(X, y, "test_convert_with_trans_boolean_mixed_data_automl.onnx")
            # TODO: need investigation
            # self.assertTrue(onnx_mdl.graph.input == automl_onnx_mdl.graph.input)
            # self.assertTrue(str(onnx_mdl.graph.node) == str(automl_onnx_mdl.graph.node))
            # self.assertTrue(onnx_mdl.graph.output == automl_onnx_mdl.graph.output)

    @function_log_print_wrapped
    def test_convert_failure_cases(self):
        X = pd.DataFrame([[1, 2.5], [2, 3.1], [7, 6.6], [9, 9.0]]).astype(np.float32)
        y = [1, 3, 5, 3]
        self.converter.initialize_input(None)
        self.assertTrue(not self.converter.is_initialized())
        self.converter.initialize_input(X)
        scaler = MaxAbsScaler()
        classifier = ExtraTreesClassifier(bootstrap=True, n_jobs=1, max_features=0.9, n_estimators=25,
                                          criterion='entropy', random_state=42,
                                          min_samples_split=0.01, oob_score=False,
                                          min_samples_leaf=0.01, class_weight=None)
        pipe = Pipeline([('scale', scaler), ('extratree', classifier)])
        pipe.fit(X, y)
        onnx_mdl, err = self.converter.convert(None, 'test without featurizer', 'test without featurizer')
        self.assertTrue(onnx_mdl is None, msg=err)
        self.assertTrue(err is not None, msg=err)

    @function_log_print_wrapped
    def test_convert_with_trans_ignore_and_none_and_stringnumber_data(self):
        X_train, y_train = self._load_csv_data(fl_rel_path='../../test_data/onnx_converter/test_dataset_1.csv',
                                               y_col_name='Label')
        # Test the data frame x.
        self._test_featurizer_onnx_converter(X_train, y_train,
                                             "test_convert_with_trans_ignore_and_none_and_stringnumber_data.onnx",
                                             "test_convert_with_trans_ignore_and_none_and_stringnumber_data_res.pkl")

        # TODO: Enable after Featurizer supports no column name data
        # Test the ndarray x.
        # self._test_featurizer_onnx_converter(X_train=X_train.values, y_train=y_train)

    # --------------------------------
    # Utils.

    def _test_featurizer_onnx_converter(self, X_train, y_train, onnx_mdl_path, resource_path, expected_onnx_res=None):
        config = FeaturizerConfig()
        featurizer = Featurizer(is_onnx_compatible=True, client_id="test", featurizer_config=config)
        X = X_train
        y = y_train
        X = featurizer.fit_transform(X)
        onnx_res = None

        # Convert
        onnx_mdl, err = featurizer.to_onnx(model_name='test onnx converter', model_desc='test onnx converter')
        self.assertTrue(onnx_mdl is not None, msg=str(err))

        if expected_onnx_res is not None:
            onnx_res = featurizer.get_converted_onnx_model_resource()
            self.assertEqual(onnx_res, expected_onnx_res)

        # Save Converted Model
        featurizer.save_onnx_model(onnx_mdl, self._get_file_path(onnx_mdl_path), self._get_file_path(resource_path))

        return onnx_mdl

    def _test_automl_onnx_converter(self, X_train, y_train, onnx_mdl_path):
        transformer = automlpp.DataTransformer(is_onnx_compatible=True)
        X = X_train
        y = y_train
        self.automl_converter.initialize_input(X)
        X = transformer.fit_transform(X)
        new_pipe = make_pipeline(transformer)

        # Convert.
        onnx_mdl, err = self.automl_converter.convert(new_pipe, 'test automl onnx converter',
                                                      'test automl onnx converter')
        self.assertTrue(onnx_mdl is not None, msg=str(err))
        onnx_res = self.automl_converter.get_converted_onnx_model_resource()

        self.automl_converter.save_onnx_model(onnx_mdl, self._get_file_path(onnx_mdl_path))

        return onnx_mdl, onnx_res

    def _compare_onnx_converters(self, featurizer_mdl_path, automl_mdl_path, input_feed):

        #Predict with the ONNX Runtime
        sess = onnxrt.InferenceSession(self._get_file_path(featurizer_mdl_path))
        pred_onnx = sess.run(None, input_feed)

        sess_automl = onnxrt.InferenceSession(self._get_file_path(automl_mdl_path))
        pred_onnx_automl = sess_automl.run(None, input_feed)

        self.assertTrue(str(pred_onnx[0]) == str(pred_onnx_automl[0]))

    def _compare_onnx_converters_using_inference_helper(self,
                                                        featurizer_mdl_path, featurizer_onnx_res_path,
                                                        automl_mdl, automl_onnx_res,
                                                        Xs):
        featurizer_Xs = Xs
        automl_Xs = Xs

        # Test loading ONNX model for Featurizer
        tempFeaturizer = Featurizer(client_id="test")
        featurizer_mdl = tempFeaturizer.load_onnx_model(self._get_file_path(featurizer_mdl_path))
        featurizer_onnx_res = tempFeaturizer.get_converted_onnx_model_resource(self._get_file_path(featurizer_onnx_res_path))

        # Predict with the onnxruntime using the inference helper.
        mdl_bytes = featurizer_mdl.SerializeToString()
        onnxrt_helper = OnnxInferenceHelper(mdl_bytes, featurizer_onnx_res)
        pred_onnx = onnxrt_helper.predict(featurizer_Xs)
        print("onnxruntime predict: " + str(pred_onnx))

        # Predict AutoML model
        automl_mdl_bytes = automl_mdl.SerializeToString()
        automl_onnxrt_helper = automlOnnxInferenceHelper(automl_mdl_bytes, automl_onnx_res)
        pred_onnx_automl = automl_onnxrt_helper.predict(automl_Xs)
        print("onnxruntime predict with automl: " + str(pred_onnx_automl))

        self.assertTrue(str(pred_onnx[0]) == str(pred_onnx_automl[0]))

    def _load_csv_data(self, fl_rel_path, y_col_name):
        # function to load data, generate feature matrix and encode outcome
        script_dir = os.path.dirname(__file__)
        fl_path = os.path.join(script_dir, fl_rel_path)
        df = pd.read_csv(fl_path, low_memory=False)
        y = df.pop(y_col_name)
        y = y.values.reshape(-1)
        X = df
        return X, y

    def _get_file_path(self, fl_rel_path):
        fl_path = os.path.join(self.directory, fl_rel_path)
        return fl_path

    @classmethod
    def tearDownClass(cls) -> None:
        shutil.rmtree(cls.directory, ignore_errors=True)

if __name__ == "__main__":
    unittest.main()
