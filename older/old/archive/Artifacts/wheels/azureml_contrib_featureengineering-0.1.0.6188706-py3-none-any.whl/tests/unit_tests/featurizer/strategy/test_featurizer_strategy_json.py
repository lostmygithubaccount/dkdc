import unittest

from azureml.contrib.featureengineering.featurizer import FeatureType, FeaturizerStrategy
from azureml.contrib.featureengineering.featurizer.strategy import ColumnStrategy
from azureml.contrib.featureengineering.featurizer.transformer import NumericFeaturizers, \
    CategoricalFeaturizers, TextFeaturizers, GenericFeaturizers


class TestFeaturizerStrategyJSON(unittest.TestCase):
    def test_trategy_ser_deser(self):
        numeric_featurizers = NumericFeaturizers()
        categorical_featurizers = CategoricalFeaturizers()
        text_featurizers = TextFeaturizers()
        generic_featurizers = GenericFeaturizers()
        column_strategy1 = ColumnStrategy(column_names=["col1"],
                                          feature_type_name=FeatureType.Numeric.name,
                                          transformers=
                                          [
                                              [generic_featurizers.imputer(),
                                               generic_featurizers.maxabsscaler()],
                                              [
                                                  text_featurizers.averaged_perceptron_text_target_encoder()]
                                          ])
        column_strategy2 = ColumnStrategy(column_names=["col2, col3"], feature_type_name=None,
                                          transformers=
                                          [
                                              [generic_featurizers.minibatchkmeans_featurizer(),
                                               generic_featurizers.lambda_featurizer()],
                                              [text_featurizers.string_cast()]
                                          ])
        column_strategy3 = ColumnStrategy(column_names=["col4, col5"], feature_type_name=None,
                                          transformers=
                                          [
                                              [numeric_featurizers.bin_transformer(),
                                               categorical_featurizers.cat_imputer()],
                                              [categorical_featurizers.woe_targetencoder()]
                                          ])
        featurizer_strategy_origin = FeaturizerStrategy(is_onnx_compatible=True, client_id="test")
        featurizer_strategy_origin._column_strategy_dict = {
            "col1": column_strategy1,
            "col2-col3": column_strategy2,
            "col4-col5": column_strategy3
        }
        featurizer_strategy_origin._timeseries_strategy._enable_timeseries_transform = True
        json_string = featurizer_strategy_origin.save_json()
        assert json_string is not None
        assert len(json_string) > 0

        featurizer_strategy_new = FeaturizerStrategy(client_id="test")
        featurizer_strategy_new = featurizer_strategy_new.load_json(json_string)
        assert featurizer_strategy_new is not None
        assert featurizer_strategy_new._is_onnx_compatible is True
        assert featurizer_strategy_new._column_strategy_dict is not None
        self.assertTrue(featurizer_strategy_new.get_featurizer_strategy()[1]._enable_timeseries_transform)
        for k in featurizer_strategy_origin._column_strategy_dict:
            self._compare_transformers(featurizer_strategy_origin._column_strategy_dict[k],
                                       featurizer_strategy_new._column_strategy_dict[k])

    def _compare_transformers(self, column_strategy1: ColumnStrategy,
                              column_strategy2: ColumnStrategy):
        assert column_strategy1 is not None
        assert column_strategy2 is not None
        assert column_strategy1.feature_type_name == column_strategy2.feature_type_name
        assert len(column_strategy1.column_names) == len(column_strategy2.column_names)
        for i, name in enumerate(column_strategy1.column_names):
            assert name == column_strategy2.column_names[i]
        assert len(column_strategy1.transformers) == len(column_strategy2.transformers)
        for i, trans in enumerate(column_strategy1.transformers):
            assert len(trans) == len(column_strategy2.transformers[i])
            for j, tr in enumerate(trans):
                assert type(tr) is type(column_strategy2.transformers[i][j])


if __name__ == "__main__":
    unittest.main()
