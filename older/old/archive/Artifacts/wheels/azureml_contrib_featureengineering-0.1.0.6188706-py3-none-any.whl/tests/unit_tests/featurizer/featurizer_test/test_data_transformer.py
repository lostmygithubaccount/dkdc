import json
import unittest

import numpy as np
import pandas as pd
from azureml.automl.core.featurization import DataTransformer
from azureml.core import Dataset

from azureml.contrib.featureengineering.common import utilities
from azureml.contrib.featureengineering.core.constants import TimeSeries
from azureml.contrib.featureengineering.featurizer import Featurizer, FeaturizerConfig


class DebugTest(unittest.TestCase):

    def test_featurization_functions(self):
        transactions_df = pd.DataFrame({
            "transaction_id": [1, 2, 3, 4, 5, 6, 7, 8],
            "user_id": [1, 1, 2, 1, np.nan, 2, 3, 3],
            "amount": [500, 600, 300, 100, 80, 120, 30, 20],
            "transaction_time": pd.date_range('2014-01-01 08:00:50', periods=8, freq='12h')
        })
        print("----------------Test transform custom functions----------------")

        data_transformer = DataTransformer(task="regression")

        feature_matrix = data_transformer.fit_transform_with_logger(transactions_df)
        engineered_feature_names = data_transformer.get_engineered_feature_names()
        transform_metadata = data_transformer.get_json_strs_for_engineered_feature_names(
            engineered_feature_names)

        self.assertTrue(True)

    def test_featurizer_with_dataframe(self):
        transactions_df = pd.DataFrame({
            "transaction_id": [1, 2, 3, 4, 5, 6, 7, 8],
            "user_id": [1, 1, 2, 1, np.nan, 2, 3, 3],
            "amount": [500, 600, 300, 100, '80', 120, 30, 20],
            "transaction_time": ['2014-01-01 08:00:50', '2014-01-02 08:00:50',
                                 '2014-01-03 08:00:50', '2014-01-03 08:00:50',
                                 '2014-01-03 08:00:50', '2014-01-03 08:00:50',
                                 '2014-01-06', '2014-01-05']
        })
        print("----------------Test transform custom functions----------------")

        featurizer = Featurizer(client_id="test")
        feature_matrix = featurizer.fit_transform(transactions_df)
        engineered_feature_names = featurizer.get_engineered_feature_names()
        transformation_json = featurizer.get_json_strs_for_engineered_feature_names(
            engineered_feature_names)

        user_friendly_engineered_names = featurizer.get_user_friendly_engineered_feature_names()
        feature_def = featurizer.get_feature_definition()
        feature_def_json = feature_def.get_transformation_meta_json()
        selected_metadata_json1 = feature_def.get_transformation_meta_json(["transaction_id"])
        selected_metadata_json2 = featurizer.get_raw_feature_transformation_json(
            ["transaction_id", "transaction_time", 2])
        assert feature_matrix is not None
        assert len(user_friendly_engineered_names) == 14
        assert self._is_valid_json(feature_def_json)
        assert len(transformation_json) == 14
        assert feature_def is not None
        assert self._is_valid_json(selected_metadata_json1) > 0
        assert self._is_valid_json(selected_metadata_json2) > 0
        self.assertTrue(True)

    def test_featurizer_with_dataflow(self):
        transactions_df = pd.DataFrame({
            "transaction_id": [1, 2, 3, 4, 5, 6, 7, 8],
            "user_id": [1, 1, 2, 1, np.nan, 2, 3, 3],
            "amount": [500, 600, 300, 100, '80', 120, 30, 20],
            "transaction_time": ['2014-01-01 08:00:50', '2014-01-02 08:00:50',
                                 '2014-01-03 08:00:50', '2014-01-03 08:00:50',
                                 '2014-01-03 08:00:50', '2014-01-03 08:00:50',
                                 '2014-01-06', '2014-01-05']
        })
        import azureml.dataprep as dprep
        data_flow = utilities.generate_dataflow(transactions_df)
        featurizer = Featurizer(client_id="test")
        feature_matrix = featurizer.fit_transform(data_flow)
        engineered_feature_names = featurizer.get_engineered_feature_names()
        transformation_json = featurizer.get_json_strs_for_engineered_feature_names(
            engineered_feature_names)

        user_friendly_engineered_names = featurizer.get_user_friendly_engineered_feature_names()
        feature_def = featurizer.get_feature_definition()
        feature_def_json = feature_def.get_transformation_meta_json()
        selected_metadata_json1 = feature_def.get_transformation_meta_json(["transaction_id"])
        selected_metadata_json2 = featurizer.get_raw_feature_transformation_json(
            ["transaction_id", "transaction_time", 2])
        assert feature_matrix is not None
        assert len(user_friendly_engineered_names) == 14
        assert self._is_valid_json(feature_def_json)
        assert len(transformation_json) == 14
        assert feature_def is not None
        assert self._is_valid_json(selected_metadata_json1) > 0
        assert self._is_valid_json(selected_metadata_json2) > 0
        self.assertTrue(True)

    def test_featurizer_with_dataset(self):
        # TODO: Dataset dataflow exception due to build.learn exception
        transactions_df = pd.DataFrame({
            "transaction_id": [1, 2, 3, 4, 5, 6, 7, 8],
            "user_id": [1, 1, 2, 1, np.nan, 2, 3, 3],
            "amount": [500, 600, 300, 100, '80', 120, 30, 20],
            "transaction_time": ['2014-01-01 08:00:50', '2014-01-02 08:00:50',
                                 '2014-01-03 08:00:50', '2014-01-03 08:00:50',
                                 '2014-01-03 08:00:50', '2014-01-03 08:00:50',
                                 '2014-01-06', '2014-01-05']
        })
        ds = Dataset.from_pandas_dataframe(transactions_df, in_memory=False)
        featurizer = Featurizer(client_id="test")
        # feature_matrix = featurizer.fit_transform(ds)
        # engineered_feature_names = featurizer.get_engineered_feature_names()
        # transformation_json = featurizer.get_json_strs_for_engineered_feature_names(
        #     engineered_feature_names)
        #
        # user_friendly_engineered_names = featurizer.get_user_friendly_engineered_feature_names()
        # feature_def = featurizer.get_feature_definition()
        # feature_def_json = feature_def.get_transformation_meta_json()
        # selected_metadata_json1 = feature_def.get_transformation_meta_json(["transaction_id"])
        # selected_metadata_json2 = featurizer.get_raw_feature_transformation_json(
        #     ["transaction_id", "transaction_time", 2])
        # assert feature_matrix is not None
        # assert len(user_friendly_engineered_names) == 14
        # assert self._is_valid_json(feature_def_json)
        # assert len(transformation_json) == 14
        # assert feature_def is not None
        # assert self._is_valid_json(selected_metadata_json1) > 0
        # assert self._is_valid_json(selected_metadata_json2) > 0
        self.assertTrue(True)

    def _is_valid_json(self, myjson):
        try:
            json_object = json.loads(myjson)
        except ValueError:
            return False
        return True

    def _get_timeseries_param_dict(self):
        return {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'grain',
            TimeSeries.MAX_HORIZON: 1
        }

    def test_verify_settings(self):
        # timeseries not supported for onnx conversion yet
        with self.assertRaises(ValueError):
            config = FeaturizerConfig(enable_general_transform=False, enable_timeseries_transform=True,
                                      **self._get_timeseries_param_dict())
            featurizer = Featurizer(is_onnx_compatible=True, featurizer_config=config)

        # timeseries is enabled with enable onnx compat
        with self.assertRaises(ValueError):
            config = FeaturizerConfig(enable_general_transform=True, enable_timeseries_transform=True,
                                      **self._get_timeseries_param_dict())
            featurizer = Featurizer(is_onnx_compatible=True, featurizer_config=config)


if __name__ == "__main__":
    unittest.main()
