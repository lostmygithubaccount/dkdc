# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import os
import logging
import inspect
import unittest
from unittest.mock import patch

import pandas as pd
from sklearn.preprocessing import LabelEncoder

from azureml.contrib.featureengineering.evaluator import AutoFeatureSelector
from azureml.contrib.featureengineering.evaluator import constants
from azureml.contrib.featureengineering.featurizer import Featurizer

DATA_FILE_NAME = "../data/trip.csv"
FILE_PATH = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))


class AutoFeatureSelectorTesting(unittest.TestCase):
    def setUp(self):
        self.logger = logging.getLogger('test')
        self.logger.setLevel(logging.DEBUG)

        self.task = constants.Tasks.REGRESSION

        self.df = pd.read_csv(os.path.join(FILE_PATH, DATA_FILE_NAME))

        le = LabelEncoder()
        self.df["StationNumber"] = le.fit_transform(self.df["StationNumber"])

        self.label_column = 'trip_count'

    def test_auto_feature_selector_not_sparse_preprocess_true(self):
        auto_selector = AutoFeatureSelector(task=self.task, client_id="test")
        X, y = self.df.drop([self.label_column], axis=1), self.df[self.label_column]
        X_selected = auto_selector.fit_transform(X, y)
        self.assertEqual(X_selected.shape[1], 6, "Selected Wrong Number of Features")

    def test_auto_feature_selector_not_sparse_preprocess_false(self):
        auto_selector = AutoFeatureSelector(task=self.task, preprocess=False, client_id="test")
        X, y = self.df.drop([self.label_column], axis=1), self.df[self.label_column]
        X_selected = auto_selector.fit_transform(X, y)
        self.assertEqual(X_selected.shape[1], 6, "Selected Wrong Number of Features")

    def test_auto_feature_selector_sparse_preprocess_True(self):
        auto_selector = AutoFeatureSelector(task=self.task, client_id="test")
        X, y = self.df.drop([self.label_column], axis=1), self.df[self.label_column]
        featurizer = Featurizer(client_id="test")
        X_sparse = featurizer.fit_transform(X)
        X_selected = auto_selector.fit_transform(X_sparse, y)
        self.assertEqual(X_selected.shape[1], 43, "Selected Wrong Number of Features")

    def test_auto_feature_selector_sparse_preprocess_false(self):
        auto_selector = AutoFeatureSelector(task=self.task, preprocess=False, client_id="test")
        X, y = self.df.drop([self.label_column], axis=1), self.df[self.label_column]
        featurizer = Featurizer(client_id="test")
        X_sparse = featurizer.fit_transform(X)
        X_selected = auto_selector.fit_transform(X_sparse, y)
        self.assertEqual(X_selected.shape[1], 43, "Selected Wrong Number of Features")

    @patch("matplotlib.pyplot.show")
    def test_auto_feature_selector_plot(self, mock_show):
        auto_selector = AutoFeatureSelector(task=self.task, plot=True)
        X, y = self.df.drop([self.label_column], axis=1), self.df[self.label_column]
        X_selected = auto_selector.fit_transform(X, y)
        mock_show.assert_called()
