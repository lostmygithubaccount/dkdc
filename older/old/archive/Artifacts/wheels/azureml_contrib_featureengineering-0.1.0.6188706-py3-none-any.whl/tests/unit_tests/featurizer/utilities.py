import contextlib
import os
import pandas as pd
import pickle
import shutil
import tempfile
import inspect
import json

from io import BytesIO
from unittest import TestCase

from azureml.contrib.featureengineering.featurizer._engineered_feature_names import \
    FeatureTypeRecognizer
from azureml.contrib.featureengineering.featurizer.transformer.timeseries import (TimeSeriesTransformer,
                                                                                  NumericalizeTransformer)
from azureml.automl.core import preprocess as pp


def engineered_names_test_helper(data_frame_train, data_frame_test, y_train, feature_type, test_data):
    """
    Test engineered feature names for input data frame. Test the following:-
    1. Raw feature names
    2. Engineered feature names
    3. JSON object for the engineered feature names
    """
    testcase = TestCase()

    # Validations on input parameters
    testcase.assertIsNotNone(data_frame_train, "Input train data frame is not valid")
    testcase.assertIsInstance(data_frame_train, pd.DataFrame)
    testcase.assertIsNotNone(data_frame_test, "Input test data frame is not valid")
    testcase.assertIsInstance(data_frame_test, pd.DataFrame)
    testcase.assertIsNotNone(feature_type, "Feature type is not valid")
    testcase.assertIn(feature_type, FeatureTypeRecognizer.FULL_SET,
                      "{} not in {}".format(feature_type, FeatureTypeRecognizer.FULL_SET))
    testcase.assertIsNotNone(test_data, "Test data is not valid")

    # Transform the input data using the pre-processors
    tr = pp.DataTransformer("classification")
    transformed_train_data = tr.fit_transform(data_frame_train, y_train)
    transformed_test_data = tr.transform(data_frame_test)

    # Test the number of features detected
    testcase.assertEqual(tr._pre_processing_stats.num_raw_feature_type_detected[
        feature_type], test_data['num_feature_detected'],
        "Mismatch detected for number of {} features".format(feature_type))

    # Test the number of raw feature names
    testcase.assertTrue(len(tr._raw_feature_names) == test_data['num_raw_feature_names'],
                        "Mismatch detected for the number of raw feature names")

    # Make sure number of engineered names is same as the number of features detected
    testcase.assertEqual(transformed_train_data.shape[1], len(tr.get_engineered_feature_names()))
    testcase.assertEqual(transformed_test_data.shape[1], len(tr.get_engineered_feature_names()))

    # Test for the equality of the engineered feature names
    testcase.assertListEqual(tr.get_engineered_feature_names(),
                             test_data['expected_engineered_feature_names'],
                             "Mismatch detected for the engineered feature name list")

    # Test for the equality of lengths of lists of engineered feature names and their JSON representations
    testcase.assertEqual(len(tr.get_engineered_feature_names()),
                         len(tr.get_json_strs_for_engineered_feature_names()))

    # Test the JSON object for one of the engineered feature names
    actual_json_obj = json.loads(
        tr.get_json_strs_for_engineered_feature_names(
            [test_data['engineered_feature_name']])[0])

    # Load the expected JSON for engineered name
    expected_json_obj = test_data['engineered_feature_name_json']

    # Compare the actual and expected JSON formats
    testcase.assertTrue(actual_json_obj == expected_json_obj,
                        "The JSON format of the engineered feature is not expected")

    # Test pickleness of engineered name calss inside the data transformer
    testcase.assertTrue(check_pickleable(tr._engineered_feature_names_class))


def raw_feature_featurization_test(data_frame_train, y, test_data):
    """
    Test the featurization summary for the raw features. Test the following:-
    1. JSON objects for the featurization summary for the raw features
    """
    testcase = TestCase()

    # Validations on input parameters
    testcase.assertIsNotNone(data_frame_train, "Input train data frame is not valid")
    testcase.assertIsInstance(data_frame_train, pd.DataFrame)

    if test_data['is_timeseries']:
        # Prepare the data for time series transformations
        data_frame_train['date'] = pd.to_datetime(data_frame_train['date'])
        x_with_columns_to_be_dropped = data_frame_train.copy()
        x_with_columns_to_be_dropped['drop_column'] = pd.Series([3, 2, 1])
        x_with_columns_to_be_dropped['sales'] = \
            x_with_columns_to_be_dropped['sales'].apply(pd.to_numeric, errors='coerce')

        # Create a time-series transformer
        transformer = TimeSeriesTransformer(**test_data['ts_param_dict'])

        # Transform raw data
        transformer.fit_transform(x_with_columns_to_be_dropped, y)
    else:
        # Create a preprocessing transformer
        transformer = pp.DataTransformer("classification")

        # Transform raw data
        transformer.fit_transform(data_frame_train, y)

    # Get the featurization summary for the raw features
    actual_raw_feature_featurization_summary = transformer.get_featurization_summary()

    # Get the expected featurization summary for the raw features
    expected_raw_feature_featurization_summary = test_data['expected_raw_feature_featurization_summary']

    # Compare the lengths of the actual and expected featurization summaries
    testcase.assertEqual(len(actual_raw_feature_featurization_summary),
                         len(expected_raw_feature_featurization_summary))

    # Sort by feature name before comparing
    actual_raw_feature_featurization_summary.sort(key=lambda e: e['RawFeatureName'])
    expected_raw_feature_featurization_summary.sort(key=lambda e: e['RawFeatureName'])

    # Walk and compare the individual JSON formats for the featurization summaries
    for index in range(0, len(actual_raw_feature_featurization_summary)):

        actual_raw_feature_featurization_json_obj = actual_raw_feature_featurization_summary[index]
        expected_raw_feature_featurization_json_obj = expected_raw_feature_featurization_summary[index]
        # Compare the actual and expected JSON formats
        testcase.assertTrue(actual_raw_feature_featurization_json_obj == expected_raw_feature_featurization_json_obj,
                            "The JSON format of the raw feature featurization summary is not expected")


def check_pickleable(obj):
    try:
        with BytesIO() as f:
            pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)
        return True
    except Exception:
        return False


class ModelMock(object):
    """Mocked model."""

    def __init__(self, predict_results=None, predict_proba_results=None):
        """Initialize the mocked model."""
        self.predict_results = predict_results
        self.predict_proba_results = predict_proba_results

    def predict(self, X):
        """Return mocked predict results."""
        if self.predict_results is not None:
            return self.predict_results
        raise ValueError("did not expect a predict call")

    def predict_proba(self, X):
        """Return mocked predict_proba results."""
        if self.predict_proba_results is not None:
            return self.predict_proba_results
        raise ValueError("did not expect a predict_proba call")


@contextlib.contextmanager
def temp_dir_provider():
    """Temporary document provider."""
    temp_dir = tempfile.gettempdir()
    yield temp_dir


def get_dataset(dataset_name):
    """Get the data set from ts_utils by name."""
    tests_path = os.path.dirname(os.path.abspath(
        inspect.getfile(inspect.currentframe())))
    test_data_path = os.path.join(tests_path, '..', 'test_data', 'ts_utils')
    csv_fname = os.path.join(test_data_path, dataset_name + '.csv')
    df = pd.read_csv(csv_fname)
    return df
