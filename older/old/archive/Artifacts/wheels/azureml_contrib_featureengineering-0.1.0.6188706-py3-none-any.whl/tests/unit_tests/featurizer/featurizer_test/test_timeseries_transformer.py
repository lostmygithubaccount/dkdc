import math
import psutil
import unittest

import numpy as np
import pandas as pd
from pandas.testing import assert_frame_equal

from numpy.ma.testutils import assert_array_equal

from azureml.contrib.featureengineering.featurizer.transformer.timeseries import TimeSeriesTransformer
from azureml.contrib.featureengineering.core.constants import (TimeSeries, TimeSeriesInternal)
from azureml.contrib.featureengineering.core.exceptions import DataException, ConfigException
from azureml.contrib.featureengineering.core.forecasting_ts_utils import last_n_periods_split
from azureml.contrib.featureengineering.core.time_series_data_frame import TimeSeriesDataFrame
from azureml.contrib.featureengineering.core.memory_utilities import get_data_memory_size
from ..timeseries.test_rolling_window import quantile
from ..timeseries.test_stl_transformer import get_seasonal_trended_data
from tests.unit_tests.featurizer import utilities


class TimeSeriesTests(unittest.TestCase):
    # We want to keep the big table to avoid generating it multiple times.
    big_X = None
    big_y = None

    def __init__(self, *args, **kwargs):
        super(TimeSeriesTests, self).__init__(*args, **kwargs)
        self.x = pd.DataFrame(
            np.array([["2011-01-01", 5, "A"], ["2011-01-02", 12, "A"], ["2011-01-03", 10, "A"]]),
            columns=["date", "sales", "type"]
        )
        self.x['date'] = pd.to_datetime(self.x['date'])
        self.x['sales'] = pd.to_numeric(self.x['sales'])
        self.y = np.array([1.0, 1.1, 1.2])

    def test_tst_pickleable(self):
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'type',
            TimeSeriesInternal.LAGS_TO_CONSTRUCT: {'sales': [0]},
            TimeSeries.MAX_HORIZON: 2,
            TimeSeries.USE_STL: TimeSeries.STL_OPTION_SEASON_TREND
        }
        tst = TimeSeriesTransformer(**ts_param_dict).fit(self.x, self.y)
        self.assertTrue(utilities.check_pickleable(tst), msg="Failed to pickle {}".format(type(tst).__name__))

    def test_time_series_transformer_only_with_time_column_name(self):
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.USE_STL: None
        }

        expected_column = ['sales', 'year_iso', 'day', 'wday', '_automl_target_col',
                           'sales_WASNULL', 'type']
        expected_x = pd.DataFrame(
            np.array([[5, 2010, 1, 5, 1.0, 0, 0], [12, 2010, 2, 6, 1.1, 0, 0],
                      [10, 2011, 3, 0, 1.2, 0, 0]]),
            columns=expected_column
        )
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        transformed_data = time_series_transformer.fit_transform(self.x, self.y)
        self._check_data_frame(transformed_data, expected_x)

    def test_time_series_transformer_with_missing_value_in_time_column(self):
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.USE_STL: None
        }

        expected_column = ['sales', 'year_iso', 'day', 'wday', '_automl_target_col',
                           'sales_WASNULL', 'type']
        expected_x = pd.DataFrame(
            np.array([[5, 2010, 1, 5, 1.0, 0, 0], [12, 2010, 2, 6, 1.1, 0, 0],
                      [10, 2011, 3, 0, 1.2, 0, 0], [10, 2011, 4, 1, 1.2, 1, -1],
                      [10, 2011, 5, 2, 1.8, 0, 0]]),
            columns=expected_column
        )

        x = pd.DataFrame(
            np.array([["2011-01-01", 5, "A"], ["2011-01-02", 12, "A"], ["2011-01-03", 10, "A"],
                      [None, 17, "A"], ["2011-01-05", 10, "A"]]),
            columns=["date", "sales", "type"]
        )
        x['date'] = pd.to_datetime(x['date'])
        x['sales'] = pd.to_numeric(x['sales'])
        y = np.array([1.0, 1.1, 1.2, 1.6, 1.8])

        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        transformed_data = time_series_transformer.fit_transform(x, y)
        self._check_data_frame(transformed_data, expected_x)

    def test_time_series_transformer_drop_column_passed_in_list(self):
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.DROP_COLUMN_NAMES: ['drop_column'],
            TimeSeries.USE_STL: None
        }

        expected_column = ['sales', 'year_iso', 'day', 'wday', '_automl_target_col',
                           'sales_WASNULL', 'type']
        expected_x = pd.DataFrame(
            np.array([[5, 2010, 1, 5, 1.0, 0, 0], [12, 2010, 2, 6, 1.1, 0, 0],
                      [10, 2011, 3, 0, 1.2, 0, 0]]),
            columns=expected_column
        )
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        x_with_columns_to_be_dropped = self.x.copy()
        x_with_columns_to_be_dropped['drop_column'] = pd.Series([3, 2, 1])

        transformed_data = time_series_transformer.fit_transform(x_with_columns_to_be_dropped, self.y)
        self._check_data_frame(transformed_data, expected_x)

    def test_time_series_transformer_drop_column_passed_in_str(self):
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.DROP_COLUMN_NAMES: 'drop_column',
            TimeSeries.USE_STL: None
        }

        expected_column = ['sales', 'year_iso', 'day', 'wday', '_automl_target_col',
                           'sales_WASNULL', 'type']
        expected_x = pd.DataFrame(
            np.array([[5, 2010, 1, 5, 1.0, 0, 0], [12, 2010, 2, 6, 1.1, 0, 0],
                      [10, 2011, 3, 0, 1.2, 0, 0]]),
            columns=expected_column
        )
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        x_with_columns_to_be_dropped = self.x.copy()
        x_with_columns_to_be_dropped['drop_column'] = pd.Series([3, 2, 1])

        transformed_data = time_series_transformer.fit_transform(x_with_columns_to_be_dropped, self.y)
        self._check_data_frame(transformed_data, expected_x)

    def test_time_series_transformer_drop_nan_column(self):
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.USE_STL: None
        }

        expected_column = ['sales', 'year_iso', 'day', 'wday', '_automl_target_col',
                           'sales_WASNULL', 'type']
        expected_x = pd.DataFrame(
            np.array([[5, 2010, 1, 5, 1.0, 0, 0], [12, 2010, 2, 6, 1.1, 0, 0],
                      [10, 2011, 3, 0, 1.2, 0, 0]]),
            columns=expected_column
        )
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        x_with_columns_to_be_dropped = self.x.copy()
        x_with_columns_to_be_dropped['nan_column'] = pd.Series([np.nan, np.nan, np.nan])

        transformed_data = time_series_transformer.fit_transform(x_with_columns_to_be_dropped, self.y)
        self._check_data_frame(transformed_data, expected_x)

    def test_time_series_transformer_with_time_and_grain_column_name(self):
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'type',
            TimeSeries.USE_STL: None
        }

        expected_column = ['sales', 'year_iso', 'day', 'wday', '_automl_target_col',
                           'sales_WASNULL', 'grain_type']
        expected_x = pd.DataFrame(
            np.array([[5, 2010, 1, 5, 1.0, 0, 0], [12, 2010, 2, 6, 1.1, 0, 0],
                      [10, 2011, 3, 0, 1.2, 0, 0]]),
            columns=expected_column
        )
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        transformed_data = time_series_transformer.fit_transform(self.x, self.y)
        self._check_data_frame(transformed_data, expected_x)

    def test_time_series_transformer_with_datetime_column_has_nan(self):
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'type',
            TimeSeries.USE_STL: None
        }

        expected_column = ['sales', '_automl_target_col', 'sales_WASNULL', 'year_iso', 'day',
                           'wday', 'orderdate_Year', 'orderdate_Month', 'orderdate_Day',
                           'orderdate_DayOfWeek', 'orderdate_DayOfYear',
                           'orderdate_QuarterOfYear', 'orderdate_WeekOfMonth',
                           'orderdate_Hour', 'orderdate_Minute', 'orderdate_Second',
                           'grain_type']
        expected_x = pd.DataFrame(
            np.array([[5, 1.0, 0, 2010, 1, 5, 2014, 6, 19, 3, 170, 2, 3, 0, 0, 0, 0],
                      [12, 1.1, 0, 2010, 2, 6, 2014, 6, 19, 3, 170, 2, 3, 0, 0, 0, 0],
                      [10, 1.2, 0, 2011, 3, 0, 2014, 6, 19, 3, 170, 2, 3, 0, 0, 0, 0]]),
            columns=expected_column
        )
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        x_with_other_date = self.x.copy()
        x_with_other_date['orderdate'] = [np.nan, '2014-06-19', np.nan]
        x_with_other_date['orderdate'] = pd.to_datetime(x_with_other_date['orderdate'])
        transformed_data = time_series_transformer.fit_transform(x_with_other_date, self.y)
        self._check_data_frame(transformed_data, expected_x)

    def test_time_series_transformer_engineered_feature_names(self):
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'type',
            TimeSeries.USE_STL: None
        }

        expected_column = ['sales', 'sales_WASNULL', 'grain_type', 'year_iso', 'day', 'wday']

        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        time_series_transformer.fit_transform(self.x, self.y)
        self.assertEqual(len(time_series_transformer.get_engineered_feature_names()), len(expected_column))
        self.assertSequenceEqual(time_series_transformer.get_engineered_feature_names(), expected_column)

    def test_time_series_transformer_numeric_grain_columns(self):
        """
        Test that grain features are created and encoded to integer type
        """
        train_set = pd.DataFrame({'date': pd.date_range('2012', periods=3, freq='YS'),
                                  'type': ['a', 'a', 'b']})
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'type',
            TimeSeries.USE_STL: None
        }
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        train_trans = time_series_transformer.fit_transform(train_set,
                                                            y=np.arange(3))

        # Test that the grain feature is made
        self.assertTrue('grain_type' in train_trans.columns)
        self.assertTrue(np.issubdtype(train_trans['grain_type'].dtype, np.number))

        # Test that all columns have numeric type
        train_num_cols = (train_trans
                          .select_dtypes(include=[np.number]).columns)
        self.assertSetEqual(set(train_num_cols), set(train_trans.columns))

    def test_time_series_transformer_add_columns(self):
        """
        Test if adding rows by imputation will break the time series.
        TimeSeriesImputer, which is a part of a standard pipeline
        will add the rows for the dates which are lacking according the
        frequency inferred from the data.
        For example if data contain rows for dates 2011-01-01, 2011-01-02
        and 2011-01-04 the daily frequency will be assumed and the row for
        2011-01-03 will be inserted.

        """
        data_train = {
            'date': ["2011-01-01", "2011-01-02",
                     "2011-01-04", "2011-01-05",
                     "2011-01-06", "2011-01-07",
                     "2011-01-09", "2011-01-12"],
            'temperature': [10., 20., 30., 40., 10., 20., 30., 40.],
            'dummy_grain': np.repeat("grain", 8)
        }
        df_train = pd.DataFrame(data_train)
        y_train = np.array([1, 2, 3, 4, 5, 6, 7, 8])
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'dummy_grain',
            TimeSeries.USE_STL: None
        }
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        result = time_series_transformer.fit_transform(X=df_train, y=y_train)
        self.assertEqual(result.shape, (12, 7), "The returned shape of data frame is not correct")
        data_train = {
            'date': ["2012-01-01", "2012-01-02",
                     "2012-01-04", "2012-01-05"],
            'temperature': [10., 20., 30., 40.],
            'dummy_grain': np.repeat("grain", 4)
        }
        y_test = [9, 10, 11, 12]
        df_test = pd.DataFrame(data_train)
        result_with_y = time_series_transformer.transform(df=df_test.copy(), y=y_test)
        self.assertEqual(result_with_y.shape, (5, 7), "The returned shape of data frame is not correct")
        result_no_y = time_series_transformer.transform(df=df_test.copy())
        result_no_y.reset_index(inplace=True)
        # Remove the columns added by featurizers and cherck the order of rows.
        result_no_y = result_no_y.drop(['temperature_WASNULL', 'year_iso', 'day', 'wday', 'grain_dummy_grain'],
                                       axis=1)
        df_test['date'] = pd.to_datetime(df_test['date'])
        result_no_y['date'] = pd.to_datetime(result_no_y['date'])
        cols_order = ['date', 'temperature', 'dummy_grain']
        result_no_y = result_no_y[cols_order]
        assert_frame_equal(result_no_y, df_test, check_like=True)

    def test_column_drop(self):
        data_train = {
            'date': ["2011-01-01", "2011-01-02",
                     "2011-01-04", "2011-01-05",
                     "2011-01-06", "2011-01-07",
                     "2011-01-09", "2011-01-12"],
            'temperature': [10, 20, 30, 40, 10, 20, 30, 40],
            'dummy_grain': np.repeat("grain", 8)
        }
        df_train = pd.DataFrame(data_train)
        y_train = np.array([1, 2, 3, 4, 5, 6, 7, 8])
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'dummy_grain',
            TimeSeries.DROP_COLUMN_NAMES: 'temperature',
            TimeSeries.USE_STL: None
        }
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        test_lags = time_series_transformer.fit_transform(df_train, y=y_train)
        self.assertFalse('temperature' in test_lags.columns.values, "The column was not dropped")

    def test_lag_lead(self):
        """Test if lag-lead operator is plugged in."""
        y_train = np.array([1, 2, 3, 4, 5, 6, 7, 8])
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.DROP_COLUMN_NAMES: 'is_raining',
            TimeSeriesInternal.LAGS_TO_CONSTRUCT: {'temperature': [-1, 0, 1]},
            TimeSeries.MAX_HORIZON: 1,
            TimeSeriesInternal.DROP_NA: True,
            TimeSeriesInternal.ORIGIN_TIME_COLNAME: 'also_origin',
            TimeSeriesInternal.OVERWRITE_COLUMNS: True,
            TimeSeries.USE_STL: None
        }
        df_train, df_expected = self.get_mock_df_templates(ts_param_dict[TimeSeries.MAX_HORIZON])
        # Put some existing column to show it was removed.
        df_train.assign(**{'temperature_lag1': np.repeat(np.NaN, 8)})
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        result = time_series_transformer.fit_transform(df_train, y=y_train)
        # The columns generated by LagLeadOperator.
        assign_dict = {'also_origin': ["2011-01-01",
                                       "2011-01-02", "2011-01-03",
                                       "2011-01-04", "2011-01-05",
                                       "2011-01-06"],
                       'temperature_lead1D': [30., 40., 10., 20., 30., 40.],
                       'temperature_lead0D': [20, 30, 40, 10, 20, 30],
                       'temperature_lag1D': [10., 20., 30., 40., 10., 20.],
                       'horizon_origin': [1, 1, 1, 1, 1, 1]
                       }
        df_expected = df_expected.drop([0, df_expected.shape[0] - 1])
        df_expected = df_expected.assign(**assign_dict)
        df_expected['also_origin'] = pd.to_datetime(df_expected['also_origin'])
        df_expected.set_index(['date', '_automl_dummy_grain_col', 'also_origin'], inplace=True)
        assert_frame_equal(df_expected, result, check_like=True, check_dtype=False)
        ts_param_dict[TimeSeries.MAX_HORIZON] = 2
        df_train, df_expected = self.get_mock_df_templates(ts_param_dict[TimeSeries.MAX_HORIZON])
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        result = time_series_transformer.fit_transform(df_train, y=y_train)
        df_expected = df_expected.drop([0, 1, 2, df_expected.shape[0] - 1])
        assign_dict = {'also_origin': ["2011-01-01",
                                       "2011-01-01", "2011-01-02",
                                       "2011-01-02", "2011-01-03",
                                       "2011-01-03", "2011-01-04",
                                       "2011-01-04", "2011-01-05",
                                       "2011-01-05", "2011-01-06",
                                       "2011-01-06"],
                       'temperature_lead1D': [30., 30., 40., 40., 10., 10., 20., 20., 30., 30., 40., 40.],
                       'temperature_lead0D': [20., 20., 30., 30., 40., 40., 10., 10., 20., 20., 30., 30.],
                       'temperature_lag1D': [10., 10., 20., 20., 30., 30., 40., 40., 10., 10., 20., 20.],
                       'horizon_origin': [1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
                       }
        df_expected = df_expected.assign(**assign_dict)
        df_expected['also_origin'] = pd.to_datetime(df_expected['also_origin'])
        df_expected.set_index(['date', '_automl_dummy_grain_col', 'also_origin'], inplace=True)
        assert_frame_equal(df_expected, result, check_like=True, check_dtype=False)

    def test_rolling_window(self):
        """Test if rolling window operator is plugged in."""
        self._do_test_rolling_window(use_strings=False)

    def test_rolling_window_str(self):
        """Test if rolling window operator is plugged in with string instead of functor."""
        self._do_test_rolling_window(use_strings=True)

    def _do_test_rolling_window(self, use_strings=False):
        """Test if rolling window operator is plugged in."""
        y_train = np.array([1, 2, 3, 4, 5, 6, 7, 8])
        transform_dict = {sum: 'is_raining'}
        if use_strings:
            transform_dict = {'sum': 'is_raining'}
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.DROP_COLUMN_NAMES: 'temperature',
            TimeSeriesInternal.WINDOW_SIZE: 2,
            TimeSeriesInternal.TRANSFORM_DICT: transform_dict,
            TimeSeries.MAX_HORIZON: 2,
            TimeSeriesInternal.DROP_NA: True,
            TimeSeriesInternal.ORIGIN_TIME_COLNAME: 'also_origin',
            TimeSeriesInternal.OVERWRITE_COLUMNS: True,
            TimeSeries.USE_STL: None
        }
        df_train, _ = self.get_mock_df_templates(ts_param_dict[TimeSeries.MAX_HORIZON])
        # Put some existing column to show it was removed.
        df_train.assign(**{'is_raining_sum_window2': np.repeat(np.NaN, 8)})
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        result = time_series_transformer.fit_transform(df_train, y=y_train)
        window_dict = {'date': ['2011-01-03',
                                '2011-01-04', '2011-01-04',
                                '2011-01-05', '2011-01-05',
                                '2011-01-06', '2011-01-06',
                                '2011-01-07', '2011-01-07',
                                '2011-01-08', '2011-01-08'],
                       '_automl_dummy_grain_col': np.repeat('_automl_dummy_grain_col', 11),
                       'also_origin': ["2011-01-02",
                                       "2011-01-02", "2011-01-03",
                                       "2011-01-03", "2011-01-04",
                                       "2011-01-04", "2011-01-05",
                                       "2011-01-05", "2011-01-06",
                                       "2011-01-06", "2011-01-07"],
                       'is_raining_WASNULL': np.repeat(0, 11),
                       'day': [3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8],
                       'is_raining': [1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                       '_automl_target_col': [3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8],
                       'is_raining_sum_window2D': [1., 1., 1., 1., 2., 2., 1., 1., 0., 0., 0.],
                       'horizon_origin': [1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1]
                       }
        df_expected = pd.DataFrame(window_dict)
        df_expected['date'] = pd.to_datetime(df_expected['date'])
        df_expected['also_origin'] = pd.to_datetime(df_expected['also_origin'])
        df_expected.set_index(['date', '_automl_dummy_grain_col', 'also_origin'], inplace=True)
        assert_frame_equal(df_expected, result, check_like=True, check_dtype=False)

    def test_rolling_window_additional_params(self):
        """Test rolling window with additional parameters as functors."""
        self._do_test_params()

    @unittest.skip("Quantile used by pandas behaves differently then the one used for unit tests.")
    def test_rolling_window_additional_params_str(self):
        """Test rolling window with additional parameters as strings."""
        self._do_test_params(use_strings=True)

    def _do_test_params(self, use_strings=False):
        """Test rolling window with additional parameters"""
        y_train = np.array([1, 2, 3, 4, 5, 6, 7, 8])
        quant = 'quantile' if use_strings else quantile
        transform_opts = {quant: {'args': [0.25], 'kwargs': {'interpolation': 'lower'}}}
        transform_dict = {quant: 'temperature'}
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.DROP_COLUMN_NAMES: 'is_raining',
            TimeSeriesInternal.WINDOW_SIZE: 5,
            TimeSeriesInternal.TRANSFORM_DICT: transform_dict,
            TimeSeriesInternal.TRANSFORM_OPTS: transform_opts,
            TimeSeries.MAX_HORIZON: 2,
            TimeSeriesInternal.DROP_NA: True,
            TimeSeriesInternal.ORIGIN_TIME_COLNAME: 'also_origin',
            TimeSeriesInternal.OVERWRITE_COLUMNS: True,
            TimeSeriesInternal.WINDOW_OPTS: {'min_periods': 2},
            TimeSeries.USE_STL: None
        }
        df_train, _ = self.get_mock_df_templates(ts_param_dict[TimeSeries.MAX_HORIZON])
        # Put some existing column to show it was removed.
        df_train.assign(**{'temperature_quantile_window5': np.repeat(np.NaN, 8)})
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        result = time_series_transformer.fit_transform(df_train, y=y_train)
        window_dict = {'date': ['2011-01-03',
                                '2011-01-04', '2011-01-04',
                                '2011-01-05', '2011-01-05',
                                '2011-01-06', '2011-01-06',
                                '2011-01-07', '2011-01-07',
                                '2011-01-08', '2011-01-08'],
                       '_automl_dummy_grain_col': np.repeat('_automl_dummy_grain_col', 11),
                       'also_origin': ["2011-01-02",
                                       "2011-01-02", "2011-01-03",
                                       "2011-01-03", "2011-01-04",
                                       "2011-01-04", "2011-01-05",
                                       "2011-01-05", "2011-01-06",
                                       "2011-01-06", "2011-01-07"],
                       'temperature_WASNULL': np.repeat(0, 11),
                       'day': [3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8],
                       'temperature': [30, 40, 40, 10, 10, 20, 20, 30, 30, 40, 40],
                       '_automl_target_col': [3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8],
                       'temperature_quantile_window5D': [10., 10., 10., 10., 10., 10., 10., 10., 20., 20., 20.],
                       'horizon_origin': [1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1]
                       }
        df_expected = pd.DataFrame(window_dict)
        df_expected['date'] = pd.to_datetime(df_expected['date'])
        df_expected['also_origin'] = pd.to_datetime(df_expected['also_origin'])
        df_expected.set_index(['date', '_automl_dummy_grain_col', 'also_origin'], inplace=True)
        assert_frame_equal(df_expected, result, check_like=True, check_dtype=False)

    def test_train_rolling_window(self):
        """Test rolling window on train and test sets."""
        X_train, y_train, X_test = self.get_mock_data()
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: ['store', 'brand'],
            TimeSeriesInternal.WINDOW_SIZE: 3,
            TimeSeriesInternal.TRANSFORM_DICT: {'min': TimeSeriesInternal.DUMMY_TARGET_COLUMN,
                                                'max': TimeSeriesInternal.DUMMY_TARGET_COLUMN,
                                                'mean': TimeSeriesInternal.DUMMY_TARGET_COLUMN},
            TimeSeries.MAX_HORIZON: 1,
            TimeSeriesInternal.DROP_NA: True,
            TimeSeries.USE_STL: None
        }
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        result = time_series_transformer.fit_transform(X_train, y=y_train)
        expected_train = pd.DataFrame({
            'date': pd.to_datetime(['2017-01-01'] * 4 + ['2018-01-01'] * 4),
            'origin': pd.to_datetime(['2016-01-01'] * 4 + ['2017-01-01'] * 4),
            'store': [1, 2] * 4,
            'brand': (['A'] * 2 + ['B'] * 2) * 2,
            TimeSeriesInternal.DUMMY_TARGET_COLUMN: [112, 113, 114, 115, 116, 117, 118, 119],
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_min_window3AS-JAN': [100., 101., 102.,
                                                                            103., 104., 105.,
                                                                            106., 107.],
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_max_window3AS-JAN': [108., 109., 110.,
                                                                            111., 112., 113.,
                                                                            114., 115.],
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_mean_window3AS-JAN': [104., 105., 106.,
                                                                             107., 108., 109.,
                                                                             110., 111.]
        })
        expected_train['date'] = pd.to_datetime(expected_train['date'])
        expected_train['origin'] = pd.to_datetime(expected_train['origin'])
        expected_train.set_index(['date', 'store', 'brand', 'origin'], inplace=True)
        expected_train.sort_index(inplace=True)
        result.drop(['year', 'grain_store',
                     'grain_brand', 'horizon_origin'], axis=1, inplace=True)
        assert_frame_equal(expected_train, result, check_like=True, check_dtype=False)
        result = time_series_transformer.transform(X_test)
        expected_test = pd.DataFrame({
            'date': pd.to_datetime(['2019-01-01'] * 4),
            'origin': pd.to_datetime(['2018-01-01'] * 4),
            'store': [1, 2] * 2,
            'brand': ['A', 'A', 'B', 'B'],
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_min_window3AS-JAN': [108., 109., 110., 111.],
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_max_window3AS-JAN': [116., 117., 118., 119.],
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_mean_window3AS-JAN': [112., 113., 114., 115.]
        })
        result.drop(['year', 'grain_store', 'grain_brand', 'horizon_origin'], axis=1, inplace=True)
        expected_test['date'] = pd.to_datetime(expected_test['date'])
        expected_test['origin'] = pd.to_datetime(expected_test['origin'])
        expected_test.set_index(['date', 'store', 'brand', 'origin'], inplace=True)
        assert_frame_equal(expected_test, result, check_like=True, check_dtype=False)

    def test_lag_lead_train_test(self):
        """Test lag lead on train and test data."""
        # In this test we will train and fit data on multiple
        # grain data set, but will check just a tail of the data
        # frame for brevity.
        X_train, y_train, X_test = self.get_mock_data()
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: ['store', 'brand'],
            TimeSeriesInternal.LAGS_TO_CONSTRUCT: {TimeSeriesInternal.DUMMY_TARGET_COLUMN: [1]},
            TimeSeries.MAX_HORIZON: 3,
            TimeSeriesInternal.DROP_NA: True,
            TimeSeries.USE_STL: None
        }
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        result = time_series_transformer.fit_transform(X_train, y=y_train).sort_index()
        self.assertEqual(result.shape[0], 36, "Wrong dimension of transformed data frame.")
        result.drop(['year', 'grain_store',
                     'grain_brand', 'horizon_origin'], axis=1, inplace=True)
        expected_train = pd.DataFrame({
            'date': pd.to_datetime(['2018-01-01'] * 12),
            'origin': pd.to_datetime(['2015-01-01', '2016-01-01', '2017-01-01'] * 4),
            'store': np.repeat([1, 2], 6),
            'brand': (['A'] * 3 + ['B'] * 3) * 2,
            'year_iso': [2018] * 12,
            'wday': [0] * 12,
            'week': [1] * 12,
            TimeSeriesInternal.DUMMY_TARGET_COLUMN: [116., 116., 116., 118.,
                                                     118., 118., 117., 117.,
                                                     117., 119., 119., 119.],
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_lag1AS-JAN': [104., 108., 112., 106.,
                                                                     110., 114., 105., 109.,
                                                                     113., 107., 111., 115.]
        })
        expected_train['date'] = pd.to_datetime(expected_train['date'])
        expected_train['origin'] = pd.to_datetime(expected_train['origin'])
        expected_train.set_index(['date', 'store', 'brand', 'origin'], inplace=True)
        expected_train.sort_index(inplace=True)
        result_part = result.loc[(slice('2018-01-01', '2018-01-01'), slice(None), slice(None)), :]
        assert_frame_equal(expected_train, result_part, check_like=True, check_dtype=False)
        # Testing data set without y_test.
        result = time_series_transformer.transform(X_test).sort_index()
        expected_test = pd.DataFrame({
            'date': pd.to_datetime(['2019-01-01'] * 12),
            'origin': pd.to_datetime(['2016-01-01', '2017-01-01', '2018-01-01'] * 4),
            'store': np.repeat([1, 2], 6),
            'brand': (['A'] * 3 + ['B'] * 3) * 2,
            'year_iso': [2019] * 12,
            'wday': [1] * 12,
            'week': [1] * 12,
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_lag1AS-JAN': [108., 112., 116., 110.,
                                                                     114., 118., 109., 113.,
                                                                     117., 111., 115., 119.]
        })
        result.drop(['year', 'grain_store',
                     'grain_brand', 'horizon_origin'], axis=1, inplace=True)
        expected_test['date'] = pd.to_datetime(expected_test['date'])
        expected_test['origin'] = pd.to_datetime(expected_test['origin'])
        expected_test.set_index(['date', 'store', 'brand', 'origin'], inplace=True)
        result_part = result.loc[(slice('2019-01-01', '2019-01-01'), slice(None), slice(None)), :]
        assert_frame_equal(expected_test, result_part, check_like=True, check_dtype=False)
        # Test also last date.
        result_part = result.loc[(slice('2021-01-01', '2021-01-01'), slice(None), slice(None)), :]
        expected_test = pd.DataFrame({
            'date': pd.to_datetime(['2021-01-01'] * 4),
            'origin': pd.to_datetime(['2018-01-01'] * 4),
            'store': np.repeat([1, 2], 2),
            'brand': ['A', 'B'] * 2,
            'year_iso': [2020] * 4,
            'wday': [4] * 4,
            'week': [53] * 4,
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_lag1AS-JAN': [116., 118., 117., 119.]
        })
        expected_test.set_index(['date', 'store', 'brand', 'origin'], inplace=True)
        assert_frame_equal(expected_test, result_part, check_like=True, check_dtype=False)

    def test_lag_lead_rw(self):
        """Test lag lead and rolling window simultaneously."""
        # In this test we will train and fit data on multiple
        # grain data set, but will check just a tail of the data
        # frame for brevity.
        X_train, y_train, X_test = self.get_mock_data()
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: ['store', 'brand'],
            TimeSeriesInternal.LAGS_TO_CONSTRUCT: {TimeSeriesInternal.DUMMY_TARGET_COLUMN: [1]},
            TimeSeries.MAX_HORIZON: 1,
            TimeSeriesInternal.WINDOW_SIZE: 2,
            TimeSeriesInternal.TRANSFORM_DICT: {
                'max': TimeSeriesInternal.DUMMY_TARGET_COLUMN,
                'min': TimeSeriesInternal.DUMMY_TARGET_COLUMN,
                'mean': TimeSeriesInternal.DUMMY_TARGET_COLUMN
            },
            TimeSeriesInternal.DROP_NA: True,
            TimeSeries.USE_STL: None
        }
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        time_series_transformer.fit(X_train, y=y_train)
        result = time_series_transformer.transform(X_test)
        self.assertEqual(result.shape[0], 4, "Wrong dimension of transformed data frame.")
        result.drop(['year', 'grain_store',
                     'grain_brand', 'horizon_origin'], axis=1, inplace=True)
        expected_train = pd.DataFrame({
            'date': pd.to_datetime(['2019-01-01'] * 4),
            'origin': pd.to_datetime(['2018-01-01'] * 4),
            'store': np.repeat([1, 2], 2),
            'brand': ['A', 'B'] * 2,
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_lag1AS-JAN': [116., 118., 117., 119.],
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_min_window2AS-JAN': [112., 114., 113., 115.],
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_max_window2AS-JAN': [116., 118., 117., 119.],
            TimeSeriesInternal.DUMMY_TARGET_COLUMN + '_mean_window2AS-JAN': [114., 116., 115., 117.]
        })
        expected_train.set_index(['date', 'store', 'brand', 'origin'], inplace=True)
        expected_train.sort_index(inplace=True)
        assert_frame_equal(expected_train, result, check_like=True, check_dtype=False)

    @unittest.skip('This test is long and it is covered in tests below.')
    def test_big_data(self):
        """Test if lag lead operator and rolling window were removed if there is not enough memory."""
        self._do_check_lag_lead_rw_absent(target_window_size=5, target_lag=1, do_fit=True)

    def test_delete_no_ll_rw(self):
        """Test if lag lead operator and rolling window did not appear."""
        self._do_check_lag_lead_rw_absent()

    def test_delete_lag_lead(self):
        """Test if lag lead operator was removed if there is not enough memory."""
        self._do_check_lag_lead_rw_absent(target_lag=1)

    def test_delete_rw(self):
        """Test if rolling window removed if there is not enough memory."""
        self._do_check_lag_lead_rw_absent(target_window_size=5)

    def test_delete_lag_lead_and_rw(self):
        """Test if lag lead operator and rolling window were removed if there is not enough memory."""
        self._do_check_lag_lead_rw_absent(target_window_size=5, target_lag=1)

    def _do_check_lag_lead_rw_absent(self, target_window_size=None, target_lag=None, do_fit=False):
        """
        Do the actual test if lag lead operator and rolling window are removed/not created if memory is limited.

        :param target_window_size:
            The size of a rolling window.
            If None, the rolling window will not be used.
        :type target_window_size: int
        :param target_lag:
            The length of the lag in periods.
            If None, no lags will be applied.
        :type target_lag: int

        """
        MAX_HORIZON = 1000
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: ['grain'],
            TimeSeries.MAX_HORIZON: MAX_HORIZON,
            TimeSeriesInternal.TRANSFORM_DICT: {
                'max': TimeSeriesInternal.DUMMY_TARGET_COLUMN,
                'min': TimeSeriesInternal.DUMMY_TARGET_COLUMN,
                'mean': TimeSeriesInternal.DUMMY_TARGET_COLUMN
            },
            TimeSeriesInternal.DROP_NA: True,
            TimeSeries.USE_STL: None
        }
        if target_window_size:
            ts_param_dict[TimeSeriesInternal.WINDOW_SIZE] = target_window_size
        if target_lag:
            ts_param_dict[TimeSeriesInternal.LAGS_TO_CONSTRUCT] = {
                TimeSeriesInternal.DUMMY_TARGET_COLUMN: [target_lag]}
        if TimeSeriesTests.big_X is None:
            # Create a small data frame and figure out the number of bytes per line.
            LINES = 5000
            X_train, y_train = self.get_data_of_size(LINES)
            # Ask for a data frame which when horizon applied will occupy > then MEMORY_FRACTION_FOR_DF * total
            # memory bytes. It seems data frame have some optimizations in terms of memort that is why we add 0.2
            # to the memory fraction.
            # We take the big number of lines because we want to avoid inerestigating number of lines because
            # of object overheads.
            memory_per_df = get_data_memory_size(X_train) + get_data_memory_size(y_train)
            total_memory_to_occupy = (TimeSeriesInternal.MEMORY_FRACTION_FOR_DF + 0.1) * psutil.virtual_memory()[0]
            data_length = total_memory_to_occupy * LINES / (memory_per_df * MAX_HORIZON)
            TimeSeriesTests.big_X, TimeSeriesTests.big_y = self.get_data_of_size(math.ceil(data_length))
            self.assertGreater(
                MAX_HORIZON *
                (
                    get_data_memory_size(TimeSeriesTests.big_X) +
                    get_data_memory_size(TimeSeriesTests.big_y)) /
                psutil.virtual_memory()[0],
                TimeSeriesInternal.MEMORY_FRACTION_FOR_DF,
                "The created data frame will not trigger removing lag lead and rolling window.")
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        # Make sure we have actually created the lag lead and/or rolling window.
        if target_lag:
            self.assertIsNotNone(
                time_series_transformer._transforms.get(
                    TimeSeriesInternal.LAG_LEAD_OPERATOR),
                "Lag  lead operator was not created.")
        if target_window_size:
            self.assertIsNotNone(
                time_series_transformer._transforms.get(
                    TimeSeriesInternal.ROLLING_WINDOW_OPERATOR),
                "Rolling window was not created.")
        if do_fit:
            time_series_transformer.fit(TimeSeriesTests.big_X, TimeSeriesTests.big_y)
        else:
            time_series_transformer._remove_lag_lead_and_rw_maybe(TimeSeriesTests.big_X,
                                                                  TimeSeriesTests.big_y)
        # Make sure there is no lag lead operator or rolling window in the pipeline.
        if do_fit:
            self.assertIsNone(
                time_series_transformer.pipeline.get_pipeline_step(
                    TimeSeriesInternal.LAG_LEAD_OPERATOR),
                "Lag  lead operator was not deleted.")
            self.assertIsNone(
                time_series_transformer.pipeline.get_pipeline_step(
                    TimeSeriesInternal.ROLLING_WINDOW_OPERATOR),
                "Rolling window was not deleted.")

    def test_stl(self):
        """Test STL decomposition."""
        self._do_test_stl()

    def test_stl_manual_seasonality(self):
        self._do_test_stl(manual_seasonality_setting=True)

    def test_stl_bad_config(self):
        """Test STL decomposition."""
        with self.assertRaises(ConfigException):
            self._do_test_stl(use_stl='__dummy')

    def test_stl_lag_lead(self):
        """Test STL with lag lead operator enabled."""
        self._do_test_stl(target_lag=1)

    def test_stl_rw(self):
        """Test STL with rolling window."""
        self._do_test_stl(target_window_size=5)

    def test_stl_ll_rw(self):
        """Test STL with both lag lead operator and rolling window."""
        self._do_test_stl(target_window_size=5, target_lag=1)

    def _do_test_stl(self, target_window_size=None, target_lag=None, use_stl=TimeSeries.STL_OPTION_SEASON_TREND,
                     manual_seasonality_setting=False):
        """
        Do the actual test if lag lead operator and rolling window are removed/not created if memory is limited.

        :param target_window_size:
            The size of a rolling window.
            If None, the rolling window will not be used.
        :type target_window_size: int
        :param target_lag:
            The length of the lag in periods.
            If None, no lags will be applied.
        :type target_lag: int

        """
        date = 'date'
        MAX_HORIZON = 20
        seasonality = 3
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: date,
            TimeSeries.GRAIN_COLUMN_NAMES: ['grain'],
            TimeSeries.MAX_HORIZON: MAX_HORIZON,
            TimeSeriesInternal.TRANSFORM_DICT: {
                'max': TimeSeriesInternal.DUMMY_TARGET_COLUMN,
                'min': TimeSeriesInternal.DUMMY_TARGET_COLUMN,
                'mean': TimeSeriesInternal.DUMMY_TARGET_COLUMN
            },
            TimeSeriesInternal.DROP_NA: True,
            TimeSeries.USE_STL: use_stl
        }
        if target_window_size:
            ts_param_dict[TimeSeriesInternal.WINDOW_SIZE] = target_window_size
        if target_lag:
            ts_param_dict[TimeSeriesInternal.LAGS_TO_CONSTRUCT] = {
                TimeSeriesInternal.DUMMY_TARGET_COLUMN: [target_lag]}
        if manual_seasonality_setting:
            ts_param_dict[TimeSeries.SEASONALITY] = seasonality
        X_train, y_train, X_test, y_test = get_seasonal_trended_data(
            train_len=100,
            test_len=MAX_HORIZON,
            date_column_name=date,
            grain_columns=['grain'],
            grains_per_col=4,
            seasonality=seasonality,
            target_colname=TimeSeriesInternal.DUMMY_TARGET_COLUMN)
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        train_rv = time_series_transformer.fit_transform(X_train, y_train)
        if manual_seasonality_setting:
            stl_transformer = \
                time_series_transformer.pipeline.get_pipeline_step(TimeSeriesInternal.MAKE_SEASONALITY_AND_TREND)
            self.assertEqual(stl_transformer.seasonality, seasonality)
        self._validate_stl(train_rv, use_stl)
        self._validate_stl(time_series_transformer.transform(X_test), use_stl)
        self._validate_stl(time_series_transformer.transform(X_test, y_test), use_stl)

    def _validate_stl(self, df, use_stl):
        """See if df contains season and trend column populated by numeric values."""
        season_col = TimeSeriesInternal.DUMMY_TARGET_COLUMN + TimeSeriesInternal.STL_SEASON_SUFFIX
        trend_col = TimeSeriesInternal.DUMMY_TARGET_COLUMN + TimeSeriesInternal.STL_TREND_SUFFIX
        self.assertTrue(season_col in df.columns, "No seasonality column.")
        self.assertFalse(any([np.isnan(val) for val in df[season_col].values]), "Some seasonality values are nan.")
        if use_stl is TimeSeries.STL_OPTION_SEASON_TREND:
            self.assertTrue(trend_col in df.columns, "No trend column.")
            self.assertFalse(any([np.isnan(val) for val in df[trend_col].values]), "Some trend values are nan.")

    def get_data_of_size(self, data_length, ts_colname='date'):
        """
        Return the data frame and y of a data_length size.

        :param data_length: The size of X and y.
        :type data_length: int
        :param ts_colname: The name of a time column.
        :type ts_colname: str
        :returns: the tuple with data frame X and np array y.
        :rtype: tuple

        """
        target = 'demand'
        X = pd.DataFrame({
            ts_colname: pd.date_range(start='2000-01-01', periods=data_length, freq='H'),
            target: range(data_length),
            'grain': np.repeat('g', data_length)
        })
        y = X.pop(target).values
        return X, y

    def get_mock_data(self):
        """Return mock data set"""
        return (pd.DataFrame({  # X_train
            'date': pd.to_datetime(['2014'] * 4 + ['2015'] * 4 + ['2016'] * 4 + \
                                   ['2017'] * 4 + ['2018'] * 4),
            'store': [1, 2] * 10,
            'brand': (['A'] * 2 + ['B'] * 2) * 5}),
            # y_train
            [100 + i for i in range(0, 20)],
            # X_test
            pd.DataFrame({
                'date': pd.to_datetime(['2019'] * 4 + ['2020'] * 4 + ['2021'] * 4 + \
                                       ['2022'] * 4 + ['2023'] * 4),
                'store': [1, 2] * 10,
                'brand': (['A'] * 2 + ['B'] * 2) * 5}))

    def get_mock_df_templates(self, max_horizon):
        """
        Return the mock data frames to test LagLeadOperator and RollingWindow.

        :returns: The tuple of train and test data frames.
                  **Note:** Test data frame contains only columns created by
                  common featurizers like TimeSeriesImputer.
        :rtype: tuple

        """
        data_dict = {
            'date': ["2011-01-01", "2011-01-02",
                     "2011-01-03", "2011-01-04",
                     "2011-01-05", "2011-01-06",
                     "2011-01-07", "2011-01-08"],
            'is_raining': [1, 0, 1, 1, 0, 0, 0, 0],
            'temperature': [10, 20, 30, 40, 10, 20, 30, 40],
        }
        df_train = pd.DataFrame(data_dict)
        # Column is_raining should be dropped by DropColumns.
        del data_dict['is_raining']
        # The columns generated by TimeIndexFeaturizer
        data_dict['date'] = np.repeat(data_dict['date'], max_horizon)
        data_dict['temperature'] = np.repeat(data_dict['temperature'], max_horizon)
        data_dict['day'] = np.repeat([1, 2, 3, 4, 5, 6, 7, 8], max_horizon)
        data_dict['wday'] = np.repeat([5, 6, 0, 1, 2, 3, 4, 5], max_horizon)
        data_dict['year_iso'] = np.repeat([2010, 2010, 2011, 2011, 2011, 2011, 2011, 2011], max_horizon)
        # The target column which is actually our y_train.
        data_dict['_automl_target_col'] = np.repeat(range(1, 9), max_horizon)
        # Dummy grain column generated by transformer.
        data_dict['_automl_dummy_grain_col'] = np.repeat('_automl_dummy_grain_col', 8 * max_horizon)
        # Generated by TimeSeriesImputer.
        data_dict['temperature_WASNULL'] = np.repeat(np.repeat(0, 8), max_horizon)
        df_expected_template = pd.DataFrame(data_dict)
        df_expected_template['date'] = pd.to_datetime(df_expected_template['date'])
        return df_train, df_expected_template

    def _check_data_frame(self, df, expected_data):
        transformed_cols = set(df)
        for col in expected_data.columns:
            self.assertIn(col, transformed_cols)
            self.assertTrue(np.all(expected_data[col].values == df[col].values))

    def test_holiday_names(self):
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'type',
            TimeSeries.COUNTRY_OR_REGION: 'US'
        }

        expected_column = ['sales', 'grain_type', 'year_iso', 'day', 'wday', '_automl_target_col',
                           'sales_WASNULL', '_IsPaidTimeOff', "_Holiday_1 day after New Year's Day",
                           "_Holiday_2 days after New Year's Day", "_Holiday_New Year's Day"]
        expected_x = pd.DataFrame(
            np.array([[5, 0, 2010, 1, 5, 1.0, 0, 1, 0, 0, 1], [12, 0, 2010, 2, 6, 1.1, 0, 0, 1, 0, 0],
                      [10, 0, 2011, 3, 0, 1.2, 0, 0, 0, 1, 0]]),
            columns=expected_column
        )
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        transformed_data = time_series_transformer.fit_transform(self.x, self.y)
        self._check_data_frame(transformed_data, expected_x)

        # transform a dataset without holidays, it shouldn keep the shape.
        # We have validated the values in unittest, just check nan.
        test_data = self.get_no_holiday_data()
        no_holiday_data = time_series_transformer.transform(test_data)
        expected_column.remove('_automl_target_col')
        self.assertSetEqual(set(expected_column), set(no_holiday_data.columns.values))
        self.assertFalse(no_holiday_data.isnull().values.any())

    def test_holiday_fit_no_holiday(self):
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'type',
            TimeSeries.COUNTRY_OR_REGION: 'US'
        }

        test_data = self.get_no_holiday_data()

        # Fit the transformer with dates not has holidays
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        transformed_data = time_series_transformer.fit_transform(test_data, self.y)

        # transform a dataset with holidays, it should keep the shape.
        has_holiday_data = time_series_transformer.transform(self.x)
        expected_column = transformed_data.columns.values.tolist()
        expected_column.remove('_automl_target_col')
        self.assertSetEqual(set(expected_column), set(has_holiday_data.columns.values))
        self.assertFalse(has_holiday_data.isnull().values.any())

    def test_data_exception_on_inconsistent_freq(self):
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date'
        }

        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        time_series_transformer.fit_transform(self.x, self.y)

        monthly_data = pd.DataFrame(
            np.array([["2012-01-01", 5, "A"], ["2012-02-01", 12, "A"], ["2012-03-01", 10, "A"]]),
            columns=["date", "sales", "type"]
        )
        with self.assertRaises(DataException):
            time_series_transformer.transform(monthly_data)

    def test_lag_with_nan(self):
        """Test lag lead with nan in train."""
        self._do_test_nan_in_train(target_lag=1)

    def test_rw_with_nan(self):
        """Test rolling window with nan in train."""
        self._do_test_nan_in_train(target_window_size=3)

    def test_ll_rw_with_nan(self):
        """Test rolling window and lag lead with nan in train"""
        self._do_test_nan_in_train(target_lag=1, target_window_size=3)

    def test_force_time_index_features(self):
        force_features = ['year', 'second']
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'type',
            TimeSeriesInternal.FORCE_TIME_INDEX_FEATURES_NAME: force_features,
            TimeSeries.USE_STL: None
        }

        expected_column = ['sales', 'sales_WASNULL', 'grain_type'] + force_features

        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        time_series_transformer.fit_transform(self.x, self.y)

        self.assertSetEqual(set(time_series_transformer.time_index_non_holiday_features),
                            set(force_features))
        self.assertSetEqual(set(time_series_transformer.get_engineered_feature_names()),
                            set(expected_column))

    def test_boolean_column(self):
        """Test if boolean values are properly featurized."""
        X_train, y_train, X_test = self.get_mock_data()
        GRAINS = ['store', 'brand']
        BOOL_COL = 'boolean_col'
        BOOL_COL2 = 'boolean_col2'

        def add_bool_column(df):
            """Add one boolean column."""
            dfs = []
            for _, df in X_train.groupby(GRAINS):
                df[BOOL_COL] = [r % 2 > 0 for r in range(df.shape[0])]
                df[BOOL_COL2] = [r % 3 > 0 for r in range(df.shape[0])]
                dfs.append(df)
            return pd.concat(dfs)

        def assert_correct(df):
            """Check if df was correctly featurized."""
            for grain, df in X_train.groupby(GRAINS):
                expected = np.array([1 if r % 2 > 0 else 0 for r in range(df.shape[0])])
                assert_array_equal(expected, df[BOOL_COL])
                expected = np.array([1 if r % 3 > 0 else 0 for r in range(df.shape[0])])
                assert_array_equal(expected, df[BOOL_COL2])

        X_train = add_bool_column(X_train)
        X_test = add_bool_column(X_test)

        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: GRAINS,
            TimeSeries.USE_STL: None
        }
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        assert_correct(time_series_transformer.fit_transform(X_train, y=y_train))
        assert_correct(time_series_transformer.transform(X_test, y=y_train))

    def test_numeric_grain_exceptions(self):
        """Test exceptions if grain column has numeric name."""
        X_train, y_train, _, _ = self.get_train_test()
        # Common parameters.
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: [1, 'grain2'],
        }
        X_train.rename(columns={'grain1': 1}, inplace=True)
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        exc_regex = "Time and grain column names must be a string[.]"
        with self.assertRaisesRegex(DataException, exc_regex):
            time_series_transformer.construct_tsdf(X_train)

    def test_numeric_time_exceptions(self):
        """Test exceptions if time column has numeric name."""
        X_train, y_train, _, _ = self.get_train_test()
        # Common parameters.
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 1,
            TimeSeries.GRAIN_COLUMN_NAMES: ['grain1', 'grain2'],
        }
        X_train.rename(columns={'date': 1}, inplace=True)
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        exc_regex = "Time and grain column names must be a string[.]"
        with self.assertRaisesRegex(DataException, exc_regex):
            time_series_transformer.construct_tsdf(X_train)

    def test_no_special_column(self):
        """Test exception when user specified wrong time or date column"""
        X_train, y_train, _, _ = self.get_train_test()
        # Common parameters.
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'wrong_column',
            TimeSeries.GRAIN_COLUMN_NAMES: ['grain1', 'grain2'],
        }
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        with self.assertRaisesRegex(DataException, "The time column was not found in the dataframe[.]"):
            time_series_transformer.construct_tsdf(X_train)
        ts_param_dict[TimeSeries.TIME_COLUMN_NAME] = 'date'
        ts_param_dict[TimeSeries.GRAIN_COLUMN_NAMES][0] = 'wrong_column'
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        with self.assertRaisesRegex(DataException, "The grain column was not found in the dataframe[.]"):
            time_series_transformer.construct_tsdf(X_train)

    def test_non_unique_index(self):
        """Test exception when date and grains are not unique."""
        X_train, y_train, _, _ = self.get_train_test()
        X_train = pd.concat([X_train, X_train])
        y_train = np.concatenate([y_train, y_train])
        # Common parameters.
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: ['grain1', 'grain2'],
        }
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        with self.assertRaisesRegex(DataException, "There is more than one value for a "
                                    "time_index and grain combination[.]"):
            time_series_transformer.construct_tsdf(X_train, y_train)

    def test_dtype_of_category_and_grain(self):
        """Check if category was numericalized."""
        dates = pd.date_range('2000-01-01', freq='D', periods=12)
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: ['grains'],
        }
        X = pd.DataFrame({
            'date': np.repeat(dates, 2),
            'grains': ['g1', 'g2'] * 12,
            'type': ['A', 'A', 'B', 'B'] * 6,
            'is_raining': True * 24,
            'something': np.arange(24),
            'something_flt': np.arange(24).astype('float'),
            'y': np.arange(24)
        })
        X_train = X[:21]
        y_train = X_train.pop('y').values
        X_test = X[21:]
        y_test = X_test.pop('y').values
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)

        def _assert_dtypes(df):
            """Dtype assertions."""
            self.assertTrue(np.issubdtype(df['type'].dtype, np.signedinteger),
                            "Wrong type of categorical.")
            self.assertTrue(np.issubdtype(df['grain_grains'].dtype, np.signedinteger),
                            "Wrong type of grain column.")

        _assert_dtypes(time_series_transformer.fit_transform(X_train, y_train))
        _assert_dtypes(time_series_transformer.transform(X_test, y_test))
        _assert_dtypes(time_series_transformer.transform(X_test))

    def test_dtype_of_multi_column_grain_feature(self):
        """Check if multi-column grain feature was numericalized."""
        dates = pd.date_range('2000-01-01', freq='D', periods=12)
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: ['brand', 'store'],
        }
        X = pd.DataFrame({
            'date': np.repeat(dates, 4),
            'brand': ['acme', 'acme', 'vector', 'vector'] * 12,
            'store': ['1', '2', '1', '2'] * 12,
            'type': ['A', 'A', 'B', 'B'] * 12,
            'is_raining': True * 48,
            'something': np.arange(48),
            'something_flt': np.arange(48).astype('float'),
            'y': np.arange(48)
        })
        X_train = X[:21]
        y_train = X_train.pop('y').values
        X_test = X[21:]
        y_test = X_test.pop('y').values
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)

        def _assert_dtypes(df):
            """Dtype assertions."""
            self.assertTrue(np.issubdtype(df['type'].dtype, np.signedinteger),
                            "Wrong type of categorical.")
            self.assertTrue(np.issubdtype(df['grain_brand'].dtype, np.signedinteger),
                            "Wrong type of brand column.")
            self.assertTrue(np.issubdtype(df['grain_store'].dtype, np.signedinteger),
                            "Wrong type of store column.")

        _assert_dtypes(time_series_transformer.fit_transform(X_train, y_train))
        _assert_dtypes(time_series_transformer.transform(X_test, y_test))
        _assert_dtypes(time_series_transformer.transform(X_test))

    def test_data_frame_not_modified_grains(self):
        """Test that time series transform does not modify the initial dataframe."""
        X_train, y_train, X_test, _ = self.get_train_test()
        # Common parameters.
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: ['grain1', 'grain2'],
        }
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        X_before = X_train.copy()
        time_series_transformer.fit_transform(X_train, y_train)
        assert_frame_equal(X_train, X_before)
        X_before = X_test.copy()
        time_series_transformer.transform(X_test)
        assert_frame_equal(X_test, X_before)

    def test_data_frame_dtypes(self):
        """Test that data types are inferred correctly"""
        dates_train = list(pd.date_range(start='1991-01-01', freq='D', periods=40))
        dt = list(pd.date_range(start='2001-01-01', freq='D', periods=40))
        sales = np.arange(40)
        sales_flt = sales.astype(float)
        type = 20 * ['A', 'B']
        is_raining = np.array(20 * [True, False])
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: None,
        }
        dict_train = {'date': dates_train,
                      'another_date': dt,
                      'sales': sales,
                      'sales_flt': sales_flt,
                      'type': type,
                      'is_raining': is_raining
                      }
        df_train = pd.DataFrame(data=dict_train)
        X_train = df_train[0:30]
        # create a gap to initiate the inference.
        X_train.drop(12, inplace=True, axis=0)
        y_train = np.arange(0, X_train.shape[0])
        X_test = df_train[30:]
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        transformed = time_series_transformer.fit_transform(X_train, y_train)
        test_transformed = time_series_transformer.transform(X_test)
        for col in transformed.columns:
            if col not in df_train.columns:
                # Column created by featurization, skip.
                continue
            correct_type = df_train[col].dtype
            # We encode is_raining as int32
            if col == "is_raining" or col == "type":
                self.assertTrue(np.issubdtype(transformed[col].dtype, np.int))
            else:
                self.assertTrue(
                    correct_type == transformed[col].dtype,
                    "The dtype of column {} was not inferred: dtype {} was returned.".format(
                        col,
                        transformed[col].dtype))
                self.assertTrue(
                    correct_type == test_transformed[col].dtype,
                    "The dtype of column {} was not inferred: dtype {} was returned.".format(
                        col,
                        test_transformed[col].dtype))

    def test_data_frame_dtypes_nan(self):
        """Test that data types are inferred correctly"""
        dates_train = list(pd.date_range(start='1991-01-01', freq='D', periods=40))
        dt = list(pd.date_range(start='2001-01-01', freq='D', periods=40))
        sales = np.arange(40)
        sales_flt = sales.astype(float)
        type = 20 * ['A', 'B']
        is_raining = np.array(20 * [True, False])
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: None,
        }
        dict_train = {'date': dates_train,
                      'another_date': dt,
                      'sales': sales,
                      'sales_flt': sales_flt,
                      'type': type,
                      'is_raining': is_raining
                      }
        df_train = pd.DataFrame(data=dict_train)
        X_train = df_train[0:30]
        # create a gap to initiate the inference.
        X_train.drop(12, inplace=True, axis=0)
        y_train = np.arange(0, X_train.shape[0])
        X_test = df_train[30:]
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        transformed = time_series_transformer.fit_transform(X_train, y_train)
        test_transformed = time_series_transformer.transform(X_test)
        for col in transformed.columns:
            if col not in df_train.columns:
                # Column created by featurization, skip.
                continue
            correct_type = df_train[col].dtype
            # We encode is_raining as int32
            if col == "is_raining" or col == "type":
                self.assertTrue(np.issubdtype(transformed[col].dtype, np.int))
            else:
                self.assertTrue(
                    correct_type == transformed[col].dtype,
                    "The dtype of column {} was not inferred: dtype {} was returned.".format(
                        col,
                        transformed[col].dtype))
                self.assertTrue(
                    correct_type == test_transformed[col].dtype,
                    "The dtype of column {} was not inferred: dtype {} was returned.".format(
                        col,
                        test_transformed[col].dtype))

    def _do_test_nan_in_train(self, target_window_size=None, target_lag=None):
        """The series of tests for nan in train set."""
        # We check that it works on the train, but not on test set.
        X_train, y_train, X_test, y_test = self.get_train_test()
        # Common parameters.
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: ['grain1', 'grain2'],
            TimeSeries.MAX_HORIZON: X_test.shape[0] // 4,
            TimeSeriesInternal.TRANSFORM_DICT: {
                'max': TimeSeriesInternal.DUMMY_TARGET_COLUMN,
                'min': TimeSeriesInternal.DUMMY_TARGET_COLUMN,
                'mean': TimeSeriesInternal.DUMMY_TARGET_COLUMN
            },
            TimeSeriesInternal.DROP_NA: True,
            TimeSeries.USE_STL: None
        }
        if target_window_size:
            ts_param_dict[TimeSeriesInternal.WINDOW_SIZE] = target_window_size
        if target_lag:
            ts_param_dict[TimeSeriesInternal.LAGS_TO_CONSTRUCT] = {TimeSeriesInternal.DUMMY_TARGET_COLUMN: target_lag}
        # We need to align X with grain.
        X_train['y'] = y_train
        dfs = []
        for grain, X in X_train.groupby(ts_param_dict[TimeSeries.GRAIN_COLUMN_NAMES]):
            y = X.pop('y').values.astype(float)
            y[:2] = np.NaN  # Should be clipped.
            y[7:8] = np.NaN  # Should be imputed by ffill by 12|13|15|17.
            y[10:] = np.NaN  # Should be clipped.
            X['y'] = y
            dfs.append(X)
        X_train = pd.concat(dfs)
        y_train = X_train.pop('y').values
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        time_series_transformer.fit(X_train, y_train)
        tr = time_series_transformer.transform(X_test)
        if target_window_size or target_lag:
            self.assertEqual(tr.shape[0], 40, 'The shape of a data frame was degraded.')
        else:
            self.assertEqual(tr.shape[0], 24, 'The shape of a data frame was degraded.')

    def get_train_test(self):
        """Return train, and test sets with two grains."""
        LENGTH = 18
        train_test = TimeSeriesDataFrame({
            'date': list(pd.date_range('2001-01-01', periods=LENGTH, freq='M')) * 4,
            'grain1': np.repeat(np.array(['g1_1', 'g1_2']), LENGTH * 2),
            'grain2': (list(np.repeat('g2_1', LENGTH)) +
                       list(np.repeat('g1_2', LENGTH))) * 2,
            'temperature': list(np.arange(0, LENGTH)) +
            list(np.arange(1, 1 + LENGTH)) +
            list(np.arange(3, 3 + LENGTH)) +
            list(np.arange(5, 5 + LENGTH)),
            'y': list(np.arange(0, LENGTH * 2, step=2)) +
            list(np.arange(1, 1 + LENGTH * 2, step=2)) +
            list(np.arange(3, 3 + LENGTH * 2, step=2)) +
            list(np.arange(5, 5 + LENGTH * 2, step=2))},
            time_colname='date',
            grain_colnames=['grain1', 'grain2'],
            ts_value_colname='y')
        X_train, X_test = last_n_periods_split(train_test, 6)
        X_train = pd.DataFrame(X_train).reset_index(drop=False)
        X_test = pd.DataFrame(X_test).reset_index(drop=False)
        y_train = X_train.pop('y').values
        y_test = X_test.pop('y').values
        return X_train, y_train, X_test, y_test

    def get_no_holiday_data(self):
        test_data = pd.DataFrame(
            np.array([["2011-04-01", 5, "A"], ["2011-04-02", 12, "A"], ["2011-04-03", 10, "A"]]),
            columns=["date", "sales", "type"]
        )
        test_data['date'] = pd.to_datetime(test_data['date'])
        test_data['sales'] = pd.to_numeric(test_data['sales'])
        return test_data


class TimeseriesTransformerHorizonTests(unittest.TestCase):
    def test_featurizer_horizon_feature(self):
        """
        Test horizon feature creation from a tsdf.

        With grains
        """

        # First need to impute missing values for the ts value
        #  so that the recursive forecaster works
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'type',
            TimeSeriesInternal.LAGS_TO_CONSTRUCT: {'sales': [0]},
            TimeSeries.MAX_HORIZON: 2,
            TimeSeries.USE_STL: None
        }

        x = pd.DataFrame(
            np.array([["2011-01-01", 5, "A"], ["2011-01-02", 12, "A"], ["2011-01-03", 10, "A"],
                      ["2011-01-01", 5, "B"], ["2011-01-02", 12, "B"], ["2011-01-03", 10, "B"]]),
            columns=["date", "sales", "type"]
        )
        x['date'] = pd.to_datetime(x['date'])
        x['sales'] = pd.to_numeric(x['sales'])
        y = np.array([1.0, 1.1, 1.2, 2.0, 2.1, 2.2])

        expected_column = ['_automl_target_col', 'sales', 'sales_WASNULL', 'sales_lead0D',
                           'year_iso', 'day', 'wday', 'grain_type', 'horizon_origin']
        expected_x = pd.DataFrame(
            np.array([[1, 5, 0, 5, 2010, 1, 5, 0, 1],
                      [1.1, 12, 0, 5, 2010, 2, 6, 0, 2], [1.1, 12, 0, 12, 2010, 2, 6, 0, 1],
                      [1.2, 10, 0, 12, 2011, 3, 0, 0, 2], [1.2, 10, 0, 10, 2011, 3, 0, 0, 1],
                      [2, 5, 0, 5, 2010, 1, 5, 1, 1],
                      [2.1, 12, 0, 5, 2010, 2, 6, 1, 2], [2.1, 12, 0, 12, 2010, 2, 6, 1, 1],
                      [2.2, 10, 0, 12, 2011, 3, 0, 1, 2], [2.2, 10, 0, 10, 2011, 3, 0, 1, 1]]),
            columns=expected_column
        )
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        transformed_data = time_series_transformer.fit_transform(x, y)

        # Test for horizon feature existence and correct content
        horizon_colname = 'horizon_origin'
        self.assertTrue(horizon_colname in transformed_data)

        # We only care the the frames are of similar values
        transformed_data.sort_index(inplace=True, axis=1)
        expected_x.sort_index(inplace=True, axis=1)
        assert_frame_equal(transformed_data.reset_index(drop=True), expected_x.reset_index(drop=True),
                           check_dtype=False, check_column_type=False, check_names=False)

    def test_featurizer_horizon_feature_no_grain(self):
        """
        Test horizon feature creation from a tsdf.

        No grains
        """
        # First need to impute missing values for the ts value
        #  so that the recursive forecaster works
        ts_param_dict = {
            TimeSeries.TIME_COLUMN_NAME: 'date',
            TimeSeries.GRAIN_COLUMN_NAMES: 'type',
            TimeSeriesInternal.LAGS_TO_CONSTRUCT: {'sales': [0]},
            TimeSeries.MAX_HORIZON: 2,
            TimeSeries.USE_STL: None
        }

        x = pd.DataFrame(
            np.array([["2011-01-01", 5, "A"], ["2011-01-02", 12, "A"], ["2011-01-03", 10, "A"]]),
            columns=["date", "sales", "type"]
        )
        x['date'] = pd.to_datetime(x['date'])
        x['sales'] = pd.to_numeric(x['sales'])
        y = np.array([1.0, 1.1, 1.2])

        expected_column = ['_automl_target_col', 'sales', 'sales_WASNULL', 'sales_lead0D',
                           'year_iso', 'day', 'wday', 'grain_type', 'horizon_origin']
        expected_x = pd.DataFrame(
            np.array([[1, 5, 0, 5, 2010, 1, 5, 0, 1],
                      [1.1, 12, 0, 5, 2010, 2, 6, 0, 2], [1.1, 12, 0, 12, 2010, 2, 6, 0, 1],
                      [1.2, 10, 0, 12, 2011, 3, 0, 0, 2], [1.2, 10, 0, 10, 2011, 3, 0, 0, 1]]),
            columns=expected_column
        )
        time_series_transformer = TimeSeriesTransformer(**ts_param_dict)
        transformed_data = time_series_transformer.fit_transform(x, y)

        # Test for horizon feature existence and correct content
        horizon_colname = 'horizon_origin'
        self.assertTrue(horizon_colname in transformed_data)

        # We only care the the frames are of similar values
        transformed_data.sort_index(inplace=True, axis=1)
        expected_x.sort_index(inplace=True, axis=1)
        assert_frame_equal(transformed_data.reset_index(drop=True), expected_x.reset_index(drop=True),
                           check_dtype=False, check_column_type=False, check_names=False)


if __name__ == "__main__":
    unittest.main()
