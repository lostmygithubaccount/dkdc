# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import unittest

import numpy as np
import pandas as pd
import scipy as sp
from azureml.automl.core.featurization import DataTransformer
from pandas.util.testing import assert_frame_equal
from sklearn.exceptions import NotFittedError

from azureml.contrib.featureengineering.evaluator.feature_importance_evaluator import FeatureImportanceEvaluator
from azureml.contrib.featureengineering.evaluator import constants
from azureml.contrib.featureengineering.common.logging import _LoggerFactory


class FeatureImportanceEvaluatorTesting(unittest.TestCase):
    def setUp(self):
        self.logger = _LoggerFactory.get_logger(__name__, client_id="test")
        self.label_column = 'label'
        self.task = constants.Tasks.CLASSIFICATION
        # create feature matrices to evaluate
        self.all_numeric_no_nan = pd.DataFrame({"A": range(10),
                                                self.label_column: [0] * 5 + [1] * 5,
                                                "C": 1.01,
                                                "S": range(10, 0, -1),
                                                "D": [2] * 2 + [3] * 8})
        self.all_numeric_no_nan.C.iloc[4] = 0.98

        self.categorical_nan_F = pd.DataFrame({"A": range(10),
                                               "B": range(10),
                                               self.label_column: [0] * 5 + [1] * 5,
                                               "C": 1.05,
                                               "F": np.nan,
                                               "S": range(10, 0, -1),
                                               "D": [2] * 2 + [3] * 8,
                                               "CATE": ["a", "a", "c", "c", "e", "e", "u", "u", "u",
                                                        "u"]})
        self.categorical_nan_F.C.iloc[7] = 6.5
        self.categorical_nan_F.F.iloc[1:6] = 3
        self.categorical_nan_F.F.iloc[7:9] = 5

        self.no_var_C_nan_F = pd.DataFrame({"A": range(10),
                                            "B": [True, True, False, True, np.nan, None, True,
                                                  False, True, np.nan],
                                            self.label_column: [0] * 5 + [1] * 5,
                                            "C": [5] * 10,
                                            "F": np.nan,
                                            "S": range(10, 0, -1),
                                            "Z": pd.date_range(start='4/2/2019', periods=10),
                                            "D": [2] * 2 + [3] * 8,
                                            "CATE": ["a", "a", "c", "c", "e", "e", "u", "u", "u",
                                                     "u"]})
        self.no_var_C_nan_F.F.iloc[1:6] = 3
        self.no_var_C_nan_F.CATE.iloc[4] = np.nan

        featurized_no_var_C_nan_F = pd.DataFrame({"A_MeanImputer": range(10),
                                                  "B_HashOneHotEncode_0": 0,
                                                  "B_HashOneHotEncode_1": 0,
                                                  "B_HashOneHotEncode_2": [1, 1, 0, 1, 0, 0, 1, 0, 1, 0],
                                                  "B_HashOneHotEncode_3": [0, 0, 1, 0, 0, 1, 0, 1, 0, 0],
                                                  "B_HashOneHotEncode_4": 0,
                                                  "B_HashOneHotEncode_5": 0,
                                                  "B_HashOneHotEncode_6": 0,
                                                  "B_HashOneHotEncode_7": [0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
                                                  "S_MeanImputer": range(10, 0, -1),
                                                  "Z_ModeImputer_Year": 2019,
                                                  "Z_ModeImputer_Month": 4,
                                                  "Z_ModeImputer_Day": range(2, 12, 1),
                                                  "Z_ModeImputer_DayOfWeek": [1, 2, 3, 4, 5, 6, 0, 1, 2, 3],
                                                  "Z_ModeImputer_DayOfYear": range(92, 102, 1),
                                                  "Z_ModeImputer_QuarterOfYear": 2,
                                                  "Z_ModeImputer_WeekOfMonth": [1] * 6 + [2] * 4,
                                                  "Z_ModeImputer_Hour": 0,
                                                  "Z_ModeImputer_Minute": 0,
                                                  "Z_ModeImputer_Second": 0,
                                                  "D_MeanImputer": [2] * 2 + [3] * 8,
                                                  "CATE_HashOneHotEncode_0": [1] * 2 + [0] * 8,
                                                  "CATE_HashOneHotEncode_1": 0,
                                                  "CATE_HashOneHotEncode_2": [0, 0, 1, 1, 0, 0, 1, 1, 1, 1],
                                                  "CATE_HashOneHotEncode_3": 0,
                                                  "CATE_HashOneHotEncode_4": 0,
                                                  "CATE_HashOneHotEncode_5": [0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
                                                  "CATE_HashOneHotEncode_6": 0,
                                                  "CATE_HashOneHotEncode_7": [0, 0, 0, 0, 1, 0, 0, 0, 0, 0]
                                                  })

        self.sparse_featurized_no_var_C_nan_F = sp.sparse.csr_matrix(featurized_no_var_C_nan_F.values)

        self.sparse_mat_X = sp.sparse.csr_matrix(np.linspace(0, 100, num=200).reshape(40, 5))
        self.sparse_mat_y = np.ones((40))

        self.sparse_mat_X_no_var_3 = sp.sparse.csr_matrix(np.linspace(0, 100, num=200).reshape(40, 5))
        self.sparse_mat_X_no_var_3[:, 3] = 10
        self.sparse_mat_y_no_var_3 = np.ones((40))

        self.sparse_mat_X_nan_0 = sp.sparse.csr_matrix(np.linspace(0, 100, num=100).reshape(20, 5))
        self.sparse_mat_X_nan_0[:, 0] = np.nan
        self.sparse_mat_y_nan_0 = np.ones((20))

        self.label_missing_val = pd.DataFrame({"A": range(10),
                                               "B": range(10),
                                               self.label_column: np.nan,
                                               "C": range(10, 0, -1)})
        self.label_missing_val[self.label_column].iloc[0:4] = 7

        self.label_no_var = pd.DataFrame({"A": range(10),
                                          "B": range(10),
                                          self.label_column: 1,
                                          "C": range(10, 0, -1)})

        self.no_var_B = pd.DataFrame({"A": range(10),
                                      "B": [3] * 10,
                                      self.label_column: [0] * 5 + [1] * 5,
                                      "C": range(10, 0, -1)})

        self.all_nan_C = pd.DataFrame({"A": range(10),
                                       "B": [3] * 10,
                                       self.label_column: [0] * 5 + [1] * 5,
                                       "C": np.nan})

        self.sparse_mat_X_label_missing = sp.sparse.csr_matrix(np.linspace(0, 100, num=500).reshape(100, 5))
        self.sparse_mat_y_label_missing = sp.sparse.csr_matrix(np.full([100, 1], np.nan))
        self.sparse_mat_y_label_missing[1:10] = 1

    def test_convert_X_y_to_numeric_non_sparse_no_categorical_preprocess_true(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.all_numeric_no_nan.drop(columns=[self.label_column])
        y = self.all_numeric_no_nan[self.label_column]
        _, X, X_column_names, y, _ = evaluator._data_preprocessor.check_input_format_extract_data(X, y)
        X_numeric, y_numeric, _, _ = evaluator._convert_X_y_to_numeric(X, y, X_column_names)
        self.assertFalse(isinstance(X_numeric, sp.sparse.csr_matrix))

    def test_convert_X_y_to_numeric_non_sparse_has_categorical_preprocess_true(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.no_var_C_nan_F.drop(columns=[self.label_column])
        y = self.no_var_C_nan_F[self.label_column]
        _, X, X_column_names, y, _ = evaluator._data_preprocessor.check_input_format_extract_data(X, y)
        X_numeric, y_numeric, _, _ = evaluator._convert_X_y_to_numeric(X, y, X_column_names)
        self.assertTrue(isinstance(X_numeric, sp.sparse.csr_matrix))

    def test_convert_X_y_to_numeric_non_sparse_no_categorical_preprocess_false(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, preprocess=False, client_id="test")
        X = self.all_numeric_no_nan.drop(columns=[self.label_column])
        y = self.all_numeric_no_nan[self.label_column]
        _, X, X_column_names, y, _ = evaluator._data_preprocessor.check_input_format_extract_data(X, y)
        X_numeric, y_numeric, _, _ = evaluator._convert_X_y_to_numeric(X, y, X_column_names)
        self.assertFalse(isinstance(X_numeric, sp.sparse.csr_matrix))

    def test_filter_cols_non_sparse_label_missing(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.label_missing_val.drop(columns=[self.label_column])
        y = self.label_missing_val[self.label_column]
        X_column_names = np.asarray(X.columns)
        self.assertRaises(ValueError, evaluator._filter_cols, X, y, X_column_names)

    def test_filter_cols_non_sparse_label_no_var(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, preprocess=True, client_id="test",
                                               logger=self.logger)
        X = self.label_no_var.drop(columns=[self.label_column])
        y = self.label_no_var[self.label_column]
        X_column_names = np.asarray(X.columns)
        with self.assertLogs(self.logger) as cm:
            evaluator._filter_cols(X.values, y, X_column_names)
        self.assertIn('Labels are very unbalanced! 100.0% labels have the same value = 1.0. '
        'Please consider adding more under-represented labels.', cm.output[0])

    def test_filter_cols_non_sparse_no_var(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.no_var_B.drop(columns=[self.label_column])
        y = self.no_var_B[self.label_column]
        X_column_names = np.asarray(X.columns)
        X_filtered, X_filtered_column_names, cols_to_drop, missing_val_ratio, var = \
            evaluator._filter_cols(X.values, y, X_column_names)
        np.testing.assert_array_equal(X_filtered_column_names, np.array(["A", "C"]))
        self.assertListEqual(cols_to_drop, [1])
        expected_X = self.no_var_B.drop(columns=["B", self.label_column]).values
        np.testing.assert_array_equal(X_filtered, expected_X)

    def test_filter_cols_non_sparse_all_nan(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, missing_val_threshold=None,
                                               variance_threshold=None, client_id="test")
        X = self.all_nan_C.drop(columns=[self.label_column])
        y = self.all_nan_C[self.label_column]
        X_column_names = np.asarray(X.columns)
        X_filtered, X_filtered_column_names, cols_to_drop, missing_val_ratio, var = \
            evaluator._filter_cols(X.values, y, X_column_names)
        np.testing.assert_array_equal(X_filtered_column_names, np.array(["A", "B"]))
        self.assertListEqual(cols_to_drop, [2])
        expected_X = self.all_nan_C.drop(columns=["C", self.label_column]).values
        np.testing.assert_array_equal(X_filtered, expected_X)

    def test_build_feature_scoring_matrix_preprocess_false(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, preprocess=False, client_id="test")
        missing_val_ratio = pd.Series(data=[0.6, 0.7, 0], index=["A", "B", self.label_column])
        var = pd.Series(data=[0.2, 0.5, 0.3], index=["A", "B", self.label_column])
        mutual_info = pd.Series(data=[0.1, 0.5, 1], index=["A", "B", self.label_column])
        pearson = pd.Series(data=[0.8, 0.1, 0.2], index=["A", "B", self.label_column])
        lightgbm_score = pd.Series(data=[0.4, 0.3, 0.6], index=["A", "B", self.label_column])
        lasso_score = pd.Series(data=[0.6, 0.5, 0.4], index=["A", "B", self.label_column])
        raw_scoring, eng_scoring = evaluator._build_feature_scoring_matrix(missing_val_ratio, var, missing_val_ratio,
                                                                           var, mutual_info, pearson, lightgbm_score,
                                                                           lasso_score)

        expected_raw = pd.DataFrame(data={constants.NON_NULL_RATIO: [0.4, 0.3], constants.VARIANCE: [0.2, 0.5],
                                          constants.MUTUAL_INFO: [0.1, 0.5], constants.PEARSON_CORR: [0.8, 0.1],
                                          constants.LIGHTGBM_IMPORTANCE: [0.4, 0.3],
                                          constants.LASSO_IMPORTANCE: [0.6, 0.5],
                                          constants.FEATURE_IMPORTANCE: [100.0, 25]}, index=["A", "B"])

        expected_eng = pd.DataFrame()

        assert_frame_equal(raw_scoring, expected_raw)
        assert_frame_equal(eng_scoring, expected_eng)

    def test_calc_scores_preprocess_false_all_numeric_no_nan(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, preprocess=False, client_id="test")
        X = self.all_numeric_no_nan.drop(columns=[self.label_column])
        y = self.all_numeric_no_nan[self.label_column]
        _, X, X_column_names, y, _ = evaluator._data_preprocessor.check_input_format_extract_data(X, y)
        X_numeric, y_numeric, _, cols_to_drop_indices = evaluator._convert_X_y_to_numeric(X, y, X_column_names)
        filter_mask = np.full(X.shape[1], True, dtype=bool)
        filter_mask[cols_to_drop_indices] = False
        raw_scoring, eng_scoring = evaluator._calc_scores(X_numeric, y_numeric, X_column_names[filter_mask],
                                                          keep_original_order=False)
        expected_raw_index = ["A", "S", "D", "C"]
        expected_eng_scoring = pd.DataFrame()

        self.assertListEqual(raw_scoring.index.tolist(), expected_raw_index)
        self.assertListEqual(raw_scoring[constants.NON_NULL_RATIO].values.tolist(), [1.0] * len(expected_raw_index))
        assert_frame_equal(eng_scoring, expected_eng_scoring)

    def test_get_feature_scoring_preprocess_true_all_numeric_no_nan(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.all_numeric_no_nan.drop(columns=[self.label_column])
        y = self.all_numeric_no_nan[self.label_column]
        raw_scoring, eng_scoring = evaluator.get_feature_scoring(X, y)
        raw_scoring = raw_scoring.sort_values(by=[constants.FEATURE_IMPORTANCE], ascending=False)
        eng_scoring = eng_scoring.sort_values(by=[constants.FEATURE_IMPORTANCE], ascending=False)

        expected_raw_index = ["A", "S", "D", "C"]
        expected_eng_index = ["A_MeanImputer", "S_MeanImputer", "D_MeanImputer", "C_MeanImputer"]

        self.assertListEqual(raw_scoring.index.tolist(), expected_raw_index)
        self.assertListEqual(raw_scoring[constants.NON_NULL_RATIO].values.tolist(), [1.0] * len(expected_raw_index))
        # self.assertListEqual(eng_scoring.index.tolist(), expected_eng_index)
        self.assertEqual(len(eng_scoring.index), len(expected_eng_index))
        # not compare pandas dataframe index, as the index names are different
        np.array_equal(raw_scoring, eng_scoring)

    def test_get_feature_scoring_preprocess_false_has_categorical_nan(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, preprocess=False, client_id="test")
        X = self.categorical_nan_F.drop(columns=[self.label_column])
        y = self.categorical_nan_F[self.label_column]
        self.assertRaises(ValueError, evaluator.get_feature_scoring, X, y)

    def test_get_feature_scoring_preprocess_true(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.no_var_C_nan_F.drop(columns=[self.label_column])
        y = self.no_var_C_nan_F[self.label_column]
        raw_scoring, eng_scoring = evaluator.get_feature_scoring(X, y)

        raw_scoring = raw_scoring.sort_values(by=[constants.FEATURE_IMPORTANCE], ascending=False)
        eng_scoring = eng_scoring.sort_values(by=[constants.FEATURE_IMPORTANCE], ascending=False)

        expected_raw_index = ["Z", "A", "S", "CATE", "D", "B", "C", "F"]
        expected_eng_index = ["A_MeanImputer", "S_MeanImputer", "Z_ModeImputer_Day", "Z_ModeImputer_DayOfYear",
                              "Z_ModeImputer_WeekOfMonth", "D_MeanImputer", "CATE_HashOneHotEncode_0",
                              "CATE_HashOneHotEncode_2", "CATE_HashOneHotEncode_7", "CATE_HashOneHotEncode_5",
                              "Z_ModeImputer_DayOfWeek", "B_HashOneHotEncode_3", "B_HashOneHotEncode_2",
                              "B_HashOneHotEncode_7", "B_HashOneHotEncode_1", "B_HashOneHotEncode_0",
                              "Z_ModeImputer_QuarterOfYear", "B_HashOneHotEncode_4", "Z_ModeImputer_Hour",
                              "Z_ModeImputer_Minute", "Z_ModeImputer_Year", "B_HashOneHotEncode_6",
                              "CATE_HashOneHotEncode_1", "B_HashOneHotEncode_5", "CATE_HashOneHotEncode_3",
                              "CATE_HashOneHotEncode_4", "Z_ModeImputer_Month", "CATE_HashOneHotEncode_6",
                              "Z_ModeImputer_Second"]

        unchanged_raw_index = ["A", "S", "D"]
        unchanged_eng_index = ["A_MeanImputer", "S_MeanImputer", "D_MeanImputer"]

        raw_to_eng_index = {
            "Z": ["Z_ModeImputer_Year", "Z_ModeImputer_Month", "Z_ModeImputer_Day", "Z_ModeImputer_Hour",
                  "Z_ModeImputer_Minute", "Z_ModeImputer_Second", "Z_ModeImputer_QuarterOfYear",
                  "Z_ModeImputer_DayOfYear", "Z_ModeImputer_WeekOfMonth", "Z_ModeImputer_DayOfWeek"],
            "B": ["B_HashOneHotEncode_0", "B_HashOneHotEncode_1", "B_HashOneHotEncode_2",
                  "B_HashOneHotEncode_3", "B_HashOneHotEncode_4", "B_HashOneHotEncode_5",
                  "B_HashOneHotEncode_6", "B_HashOneHotEncode_7"],
            "CATE": ["CATE_HashOneHotEncode_0", "CATE_HashOneHotEncode_1", "CATE_HashOneHotEncode_2",
                     "CATE_HashOneHotEncode_3", "CATE_HashOneHotEncode_4", "CATE_HashOneHotEncode_5",
                     "CATE_HashOneHotEncode_6", "CATE_HashOneHotEncode_7"]}

        raw_index = ["Z", "B", "CATE"]
        dropped_index = ["C", "F"]
        not_calc_metrics = [constants.MUTUAL_INFO, constants.PEARSON_CORR, constants.LIGHTGBM_IMPORTANCE,
                            constants.LASSO_IMPORTANCE, constants.FEATURE_IMPORTANCE]

        self.assertListEqual(raw_scoring.index.tolist(), expected_raw_index)
        # not compare pandas dataframe index
        # np.array_equal(raw_scoring.loc[unchanged_raw_index, :], eng_scoring.loc[unchanged_eng_index, :])
        # check if raw mutual info is calculated by taking max of eng mutual info
        # for idx in raw_index:
        #     self.assertEqual(raw_scoring.loc[idx, constants.MUTUAL_INFO],
        #                      eng_scoring.loc[raw_to_eng_index[idx], constants.MUTUAL_INFO].max())
        # check if raw pearson corr is calculated by taking max of absolute eng pearson corr,
        # note the sign is preserved
        # for idx in raw_index:
        #     self.assertEqual(raw_scoring.loc[idx, constants.PEARSON_CORR],
        #                      max(eng_scoring.loc[raw_to_eng_index[idx], constants.PEARSON_CORR].fillna(0).values,
        #                          key=abs))
        # check if raw lightgbm importance is calculated by taking sum of eng lightgbm importance
        # for idx in raw_index:
        #     self.assertAlmostEqual(raw_scoring.loc[idx, constants.LIGHTGBM_IMPORTANCE],
        #                            eng_scoring.loc[raw_to_eng_index[idx], constants.LIGHTGBM_IMPORTANCE].sum())
        # check if raw lasso importance is calculated by taking sum of eng lasso importance
        # for idx in raw_index:
        #     self.assertAlmostEqual(raw_scoring.loc[idx, constants.LASSO_IMPORTANCE],
        #                            eng_scoring.loc[raw_to_eng_index[idx], constants.LASSO_IMPORTANCE].sum())

        self.assertTrue(all(raw_scoring.loc[dropped_index, not_calc_metrics].isnull()))
        self.assertListEqual([1.0] * 21, eng_scoring[constants.NON_NULL_RATIO].values.tolist())
        # self.assertCountEqual(eng_scoring.index.tolist(), expected_eng_index)
        self.assertEqual(21, len(eng_scoring.index))

    def test_select_top_features_all_preprocess_true_all_numeric_no_nan_unfitted(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.categorical_nan_F.drop(columns=[self.label_column])
        self.assertRaises(NotFittedError, evaluator.select_top_features, X)

    def test_select_top_features_all_preprocess_true_all_numeric_no_nan(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, preprocess=True, client_id="test")
        X = self.all_numeric_no_nan.drop(columns=[self.label_column])
        y = self.all_numeric_no_nan[self.label_column]
        evaluator.get_feature_scoring(X, y)
        returns = evaluator.select_top_features(X)
        selected_raw = returns['X_out']
        X_out_column_names = returns['X_out_column_names']
        selected_eng = returns['X_eng_out']
        X_eng_out_column_names = returns['X_eng_out_column_names']
        selected_raw_score = returns['selected_raw_score']
        selected_eng_score = returns['selected_eng_score']

        expected_raw_index = ["A", "C", "S", "D"]
        expected_eng_index = ["A_MeanImputer", "C_MeanImputer", "S_MeanImputer", "D_MeanImputer"]
        expected_raw = X.loc[:, expected_raw_index]

        self.assertEqual(selected_raw.columns.tolist(), expected_raw_index)
        assert_frame_equal(selected_raw, expected_raw)
        np.testing.assert_array_equal(X_out_column_names, np.asarray(expected_raw_index))
        self.assertEqual(selected_eng.shape, X.shape)
        # self.assertEqual(selected_eng.columns.tolist(), expected_eng_index)
        self.assertEqual(len(selected_eng.columns), len(expected_eng_index))
        # np.testing.assert_array_equal(X_eng_out_column_names, np.asarray(expected_eng_index))
        self.assertEqual(len(X_eng_out_column_names), len(expected_eng_index))
        self.assertCountEqual(selected_raw_score.index.tolist(), expected_raw_index)
        # self.assertCountEqual(selected_eng_score.index.tolist(), expected_eng_index)
        self.assertEqual(len(selected_eng_score.index), len(expected_eng_index))

    def test_select_top_features_n_preprocess_false_all_numeric_no_nan(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, preprocess=False, client_id="test")
        X = self.all_numeric_no_nan.drop(columns=[self.label_column])
        y = self.all_numeric_no_nan[self.label_column]
        evaluator.get_feature_scoring(X, y)
        returns = evaluator.select_top_features(X, n=8)
        selected_raw = returns['X_out']
        X_out_column_names = returns['X_out_column_names']
        selected_eng = returns['X_eng_out']
        X_eng_out_column_names = returns['X_eng_out_column_names']
        selected_raw_score = returns['selected_raw_score']
        selected_eng_score = returns['selected_eng_score']

        expected_raw_index = ["A", "C", "S", "D"]
        expected_raw = X.loc[:, expected_raw_index]

        self.assertEqual(selected_raw.columns.tolist(), expected_raw_index)
        assert_frame_equal(selected_raw, expected_raw)
        np.testing.assert_array_equal(X_out_column_names, np.asarray(expected_raw_index))
        self.assertEqual(selected_eng.columns.tolist(), list())
        assert_frame_equal(selected_eng, pd.DataFrame())
        np.testing.assert_array_equal(X_eng_out_column_names, np.empty(0))
        self.assertCountEqual(selected_raw_score.index.tolist(), expected_raw_index)
        self.assertCountEqual(selected_eng_score.index.tolist(), list())

    def test_select_top_features_n_preprocess_true(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.no_var_C_nan_F.drop(columns=[self.label_column])
        y = self.no_var_C_nan_F[self.label_column]
        evaluator.get_feature_scoring(X, y)
        returns = evaluator.select_top_features(X, n=4)
        selected_raw = returns['X_out']
        X_out_column_names = returns['X_out_column_names']
        selected_eng = returns['X_eng_out']
        X_eng_out_column_names = returns['X_eng_out_column_names']
        selected_raw_score = returns['selected_raw_score']
        selected_eng_score = returns['selected_eng_score']

        expected_raw_index = ["A", "S", "Z", "CATE"]
        expected_eng_index = ["A_MeanImputer", "S_MeanImputer", "Z_ModeImputer_Year", "Z_ModeImputer_Month",
                              "Z_ModeImputer_Day", "Z_ModeImputer_DayOfWeek", "Z_ModeImputer_DayOfYear",
                              "Z_ModeImputer_QuarterOfYear", "Z_ModeImputer_WeekOfMonth", "Z_ModeImputer_Hour",
                              "Z_ModeImputer_Minute", "Z_ModeImputer_Second", "CATE_HashOneHotEncode_0",
                              "CATE_HashOneHotEncode_1", "CATE_HashOneHotEncode_2", "CATE_HashOneHotEncode_3",
                              "CATE_HashOneHotEncode_4", "CATE_HashOneHotEncode_5", "CATE_HashOneHotEncode_6",
                              "CATE_HashOneHotEncode_7"]
        expected_raw = X.loc[:, expected_raw_index]

        self.assertEqual(selected_raw.columns.tolist(), expected_raw_index)
        assert_frame_equal(selected_raw, expected_raw)
        np.testing.assert_array_equal(X_out_column_names, np.asarray(expected_raw_index))
        self.assertEqual((X.shape[0], 16), selected_eng.shape)
        self.assertTrue(isinstance(selected_eng, sp.sparse.csr_matrix))
        # np.testing.assert_array_equal(X_eng_out_column_names, np.asarray(expected_eng_index))
        self.assertEqual(16, len(X_eng_out_column_names))
        self.assertCountEqual(selected_raw_score.index.tolist(), expected_raw_index)
        # self.assertCountEqual(selected_eng_score.index.tolist(), expected_eng_index)
        self.assertEqual(16, len(selected_eng_score.index))

    def test_select_top_features_percentile_preprocess_true(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.no_var_C_nan_F.drop(columns=[self.label_column])
        y = self.no_var_C_nan_F[self.label_column]
        evaluator.get_feature_scoring(X, y)
        returns = evaluator.select_top_features(X, percentile=.9)
        selected_raw = returns['X_out']
        X_out_column_names = returns['X_out_column_names']
        selected_eng = returns['X_eng_out']
        X_eng_out_column_names = returns['X_eng_out_column_names']
        selected_raw_score = returns['selected_raw_score']
        selected_eng_score = returns['selected_eng_score']

        expected_raw_index = ["A", "S", "Z", "CATE"]
        expected_eng_index = ["A_MeanImputer", "S_MeanImputer", "Z_ModeImputer_Year", "Z_ModeImputer_Month",
                              "Z_ModeImputer_Day", "Z_ModeImputer_DayOfWeek", "Z_ModeImputer_DayOfYear",
                              "Z_ModeImputer_QuarterOfYear", "Z_ModeImputer_WeekOfMonth", "Z_ModeImputer_Hour",
                              "Z_ModeImputer_Minute", "Z_ModeImputer_Second", "CATE_HashOneHotEncode_0",
                              "CATE_HashOneHotEncode_1", "CATE_HashOneHotEncode_2", "CATE_HashOneHotEncode_3",
                              "CATE_HashOneHotEncode_4", "CATE_HashOneHotEncode_5", "CATE_HashOneHotEncode_6",
                              "CATE_HashOneHotEncode_7"]
        expected_raw = X.loc[:, expected_raw_index]

        self.assertEqual(selected_raw.columns.tolist(), expected_raw_index)
        assert_frame_equal(selected_raw, expected_raw)
        np.testing.assert_array_equal(X_out_column_names, np.asarray(expected_raw_index))
        self.assertEqual((X.shape[0], 16), selected_eng.shape)
        self.assertTrue(isinstance(selected_eng, sp.sparse.csr_matrix))
        # np.testing.assert_array_equal(X_eng_out_column_names, np.asarray(expected_eng_index))
        self.assertEqual(16, len(X_eng_out_column_names))
        self.assertCountEqual(selected_raw_score.index.tolist(), expected_raw_index)
        # self.assertCountEqual(selected_eng_score.index.tolist(), expected_eng_index)
        self.assertEqual(16, len(selected_eng_score.index))

    def test_select_top_features_both_n_percentile_preprocess_true_has_categorical_nan(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.categorical_nan_F.drop(columns=[self.label_column])
        y = self.categorical_nan_F[self.label_column]
        evaluator.get_feature_scoring(X, y)
        returns = evaluator.select_top_features(X, percentile=.8)
        selected_raw = returns['X_out']
        X_out_column_names = returns['X_out_column_names']
        selected_eng = returns['X_eng_out']
        X_eng_out_column_names = returns['X_eng_out_column_names']
        selected_raw_score = returns['selected_raw_score']
        selected_eng_score = returns['selected_eng_score']

        expected_raw_index = ["A", "B", "S", "CATE"]
        expected_eng_index = ["A_MeanImputer", "B_MeanImputer", "S_MeanImputer",
                              "CATE_HashOneHotEncode_0", "CATE_HashOneHotEncode_1", "CATE_HashOneHotEncode_2",
                              "CATE_HashOneHotEncode_3", "CATE_HashOneHotEncode_4", "CATE_HashOneHotEncode_5",
                              "CATE_HashOneHotEncode_6", "CATE_HashOneHotEncode_7"]
        expected_raw = X.loc[:, expected_raw_index]

        self.assertEqual(selected_raw.columns.tolist(), expected_raw_index)
        assert_frame_equal(selected_raw, expected_raw)
        np.testing.assert_array_equal(X_out_column_names, np.asarray(expected_raw_index))
        self.assertEqual((X.shape[0], 7), selected_eng.shape)
        self.assertTrue(isinstance(selected_eng, sp.sparse.csr_matrix))
        # np.testing.assert_array_equal(X_eng_out_column_names, np.asarray(expected_eng_index))
        self.assertEqual(7, len(X_eng_out_column_names))
        self.assertCountEqual(selected_raw_score.index.tolist(), expected_raw_index)
        # self.assertCountEqual(selected_eng_score.index.tolist(), expected_eng_index)
        self.assertEqual(7, len(selected_eng_score.index))

    def test_select_top_features_n_preprocess_true_model_based_only(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column,
                                               methods=['LightGBM', 'lasso'], client_id="test")
        X = self.no_var_C_nan_F.drop(columns=[self.label_column])
        y = self.no_var_C_nan_F[self.label_column]
        evaluator.get_feature_scoring(X, y)
        returns = evaluator.select_top_features(X, n=2)
        selected_raw = returns['X_out']
        X_out_column_names = returns['X_out_column_names']
        selected_eng = returns['X_eng_out']
        X_eng_out_column_names = returns['X_eng_out_column_names']
        selected_raw_score = returns['selected_raw_score']
        selected_eng_score = returns['selected_eng_score']

        expected_raw_index = ["A", "S"]
        expected_eng_index = ["A_MeanImputer", "S_MeanImputer"]
        expected_raw = X.loc[:, expected_raw_index]

        self.assertEqual(selected_raw.columns.tolist(), expected_raw_index)
        assert_frame_equal(selected_raw, expected_raw)
        np.testing.assert_array_equal(X_out_column_names, np.asarray(expected_raw_index))
        self.assertEqual(selected_eng.shape, (X.shape[0], len(expected_eng_index)))
        self.assertTrue(isinstance(selected_eng, sp.sparse.csr_matrix))
        # np.testing.assert_array_equal(X_eng_out_column_names, np.asarray(expected_eng_index))
        self.assertEqual(len(X_eng_out_column_names), len(expected_eng_index))
        self.assertCountEqual(selected_raw_score.index.tolist(), expected_raw_index)
        # self.assertCountEqual(selected_eng_score.index.tolist(), expected_eng_index)
        self.assertEqual(len(selected_eng_score.index), len(expected_eng_index))

    # Test for sparse matrix
    def test_check_input_format_extract_data_sparse_label_missing(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.sparse_mat_X_label_missing
        y = self.sparse_mat_y_label_missing
        self.assertRaises(ValueError, evaluator._data_preprocessor.check_input_format_extract_data, X, y)

    def test_convert_X_y_to_numeric_sparse_preprocess_true(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.sparse_mat_X
        y = self.sparse_mat_y
        _, X, X_column_names, y, _ = evaluator._data_preprocessor.check_input_format_extract_data(X, y)
        X_numeric, y_numeric, _, _ = evaluator._convert_X_y_to_numeric(X, y, X_column_names)
        self.assertTrue(isinstance(X_numeric, sp.sparse.csr_matrix))

    def test_convert_X_y_to_numeric_sparse_preprocess_false(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, preprocess=False, client_id="test")
        X = self.sparse_mat_X_no_var_3
        y = self.sparse_mat_y_no_var_3
        _, X, X_column_names, y, _ = evaluator._data_preprocessor.check_input_format_extract_data(X, y)
        X_numeric, y_numeric, _, _ = evaluator._convert_X_y_to_numeric(X, y, X_column_names)
        self.assertTrue(isinstance(X_numeric, sp.sparse.csr_matrix))

    def test_filter_cols_sparse_no_var(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.sparse_mat_X_no_var_3
        y = self.sparse_mat_y_no_var_3
        _, X, X_column_names, y, _ = evaluator._data_preprocessor.check_input_format_extract_data(X, y)
        X_filtered, X_filtered_column_names, cols_to_drop, missing_val_ratio, var = \
            evaluator._filter_cols(X, y, X_column_names)
        np.testing.assert_array_equal(X_filtered_column_names, np.array(["0", "1", "2", "4"]))
        self.assertListEqual(cols_to_drop, [3])
        mask = np.full(X.shape[1], True, dtype=bool)
        mask[3] = False
        expected_X = self.sparse_mat_X_no_var_3[:, mask]
        np.testing.assert_array_equal(X_filtered.toarray(), expected_X.toarray())

    def test_filter_cols_sparse_all_nan(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, client_id="test")
        X = self.sparse_mat_X_nan_0
        y = self.sparse_mat_y_nan_0
        _, X, X_column_names, y, _ = evaluator._data_preprocessor.check_input_format_extract_data(X, y)
        X_filtered, X_filtered_column_names, cols_to_drop, missing_val_ratio, var = \
            evaluator._filter_cols(X, y, X_column_names)
        np.testing.assert_array_equal(X_filtered_column_names, np.array(["1", "2", "3", "4"]))
        self.assertListEqual(cols_to_drop, [0])
        mask = np.full(X.shape[1], True, dtype=bool)
        mask[0] = False
        expected_X = self.sparse_mat_X_nan_0[:, mask]
        np.testing.assert_array_equal(X_filtered.toarray(), expected_X.toarray())

    def test_calc_scores_preprocess_false_sparse(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, preprocess=False, client_id="test")
        X = self.no_var_C_nan_F.drop(columns=["C", "F", self.label_column])
        data_transformer = DataTransformer(task=self.task)
        X = data_transformer.fit_transform_with_logger(X)
        y = self.no_var_C_nan_F[self.label_column]
        _, X, X_column_names, y, _ = evaluator._data_preprocessor.check_input_format_extract_data(X, y)
        X_numeric, y_numeric, _, cols_to_drop_indices = evaluator._convert_X_y_to_numeric(X, y, X_column_names)
        filter_mask = np.full(X.shape[1], True, dtype=bool)
        filter_mask[cols_to_drop_indices] = False
        raw_scoring, eng_scoring = evaluator._calc_scores(X_numeric, y_numeric, X_column_names[filter_mask],
                                                          keep_original_order=False)
        expected_raw_index = [str(x) for x in range(X.shape[1])]
        expected_eng_scoring = pd.DataFrame()

        self.assertCountEqual(raw_scoring.index.tolist(), expected_raw_index)
        self.assertListEqual(raw_scoring[constants.NON_NULL_RATIO].values.tolist(), [1.0] * len(expected_raw_index))
        assert_frame_equal(eng_scoring, expected_eng_scoring)

    def test_get_feature_scoring_preprocess_false_sparse(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, preprocess=False, client_id="test")
        X = self.no_var_C_nan_F.drop(columns=["C", "F", self.label_column])
        data_transformer = DataTransformer(task=self.task)
        X = data_transformer.fit_transform_with_logger(X)
        y = self.no_var_C_nan_F[self.label_column]

        raw_scoring, eng_scoring = evaluator.get_feature_scoring(X, y)
        raw_scoring = raw_scoring.sort_values(by=[constants.FEATURE_IMPORTANCE], ascending=False)

        expected_raw_index = [str(x) for x in range(X.shape[1])]
        expected_eng_scoring = pd.DataFrame()

        self.assertCountEqual(raw_scoring.index.tolist(), expected_raw_index)
        self.assertListEqual(raw_scoring[constants.NON_NULL_RATIO].values.tolist(), [1.0] * len(expected_raw_index))
        assert_frame_equal(eng_scoring, expected_eng_scoring)

    def test_select_top_features_n_preprocess_false_sparse(self):
        evaluator = FeatureImportanceEvaluator(self.task, self.label_column, preprocess=False, client_id="test")
        X = self.sparse_featurized_no_var_C_nan_F
        y = self.no_var_C_nan_F[self.label_column]

        evaluator.get_feature_scoring(X, y)
        n = 5
        returns = evaluator.select_top_features(X, n=n)
        raw_mask = returns['raw_mask']
        eng_mask = returns['eng_mask']
        selected_raw = returns['X_out']
        X_out_column_names = returns['X_out_column_names']
        selected_eng = returns['X_eng_out']
        X_eng_out_column_names = returns['X_eng_out_column_names']
        selected_raw_score = returns['selected_raw_score']
        selected_eng_score = returns['selected_eng_score']

        expected_raw_index = [0, 9, 12, 14, 16]
        expected_raw_mask = np.full(X.shape[1], False, dtype=bool)
        expected_raw_mask[expected_raw_index] = True
        expected_raw = X[:, expected_raw_mask]

        expected_raw_column_names = ["0", "9", "12", "14", "16"]

        np.testing.assert_array_equal(raw_mask, expected_raw_mask)
        np.testing.assert_array_equal(eng_mask, np.empty(0))
        self.assertEqual(selected_raw.shape, (X.shape[0], n))
        np.testing.assert_array_equal(selected_raw.A, expected_raw.A)
        np.testing.assert_array_equal(X_out_column_names, np.array(expected_raw_column_names))
        np.testing.assert_array_equal(selected_eng, np.empty(0))
        np.testing.assert_array_equal(X_eng_out_column_names, np.empty(0))
        self.assertCountEqual(selected_raw_score.index.tolist(), expected_raw_column_names)
        assert_frame_equal(selected_eng_score, pd.DataFrame())
