# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import unittest
import numpy as np

from azureml.contrib.featureengineering.featurizer.transformer import BinTransformer


class TestBinningFeaturizer(unittest.TestCase):

    def test_binning_with_one_value_per_bin(self):
        x = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        expected_array = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
        tr = BinTransformer(10)
        self.assertTrue(np.all(tr.fit_transform(x) == expected_array))

    def test_binning_with_multiple_values_per_bin(self):
        x = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        expected_array = np.array([0, 0, 1, 1, 2, 2, 3, 3, 4, 4])
        tr = BinTransformer(5)
        self.assertTrue(np.all(tr.fit_transform(x) == expected_array))


if __name__ == '__main__':
    unittest.main()
