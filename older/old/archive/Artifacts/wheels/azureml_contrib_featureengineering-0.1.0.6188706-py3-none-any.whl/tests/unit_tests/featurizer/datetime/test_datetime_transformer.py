# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import numpy as np
import unittest

from azureml.contrib.featureengineering.featurizer.transformer import DateTimeFeaturesTransformer


class TestDatetimeFeaturizers(unittest.TestCase):

    def test_instance_creation(self):
        train_set_datetime_array = np.array(['2019-03-01', '2019-04-01'])
        expected_datetime_array = np.array([[2019, 3, 1, 4, 60, 1, 1, 0, 0, 0],
                                            [2019, 4, 1, 0, 91, 2, 1, 0, 0, 0]])
        tr = DateTimeFeaturesTransformer().fit(train_set_datetime_array)
        actually_featurized_datetime = tr.transform(train_set_datetime_array)
        self.assertTrue(np.all(expected_datetime_array == actually_featurized_datetime))


if __name__ == '__main__':
    unittest.main()
