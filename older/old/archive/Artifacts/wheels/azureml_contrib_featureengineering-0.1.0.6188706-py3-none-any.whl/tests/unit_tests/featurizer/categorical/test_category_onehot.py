# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import unittest
import numpy as np
from azureml.contrib.featureengineering.featurizer.transformer import CategoricalFeaturizers as Cf


class TestCategoryOneHot(unittest.TestCase):
    def __init__(self, *args, **kwargs):
        super(TestCategoryOneHot, self).__init__(*args, **kwargs)
        self._hashing_seed_value = 0

    def test_label_encoding_non_unique_values(self):
        # Test if training data is correctly encoded with one-hot vector
        train_set_category_array = np.array(['bear', 'cat'])
        onehot_encoder_transformer = Cf.hashonehot_vectorizer(self._hashing_seed_value, 2)
        expected_train_set_label_array = np.array([[1, 0], [0, 1]])
        actual_train_set_label_array = onehot_encoder_transformer.fit_transform(train_set_category_array).toarray()
        self.assertTrue(np.all(expected_train_set_label_array == actual_train_set_label_array))


if __name__ == '__main__':
    unittest.main()
