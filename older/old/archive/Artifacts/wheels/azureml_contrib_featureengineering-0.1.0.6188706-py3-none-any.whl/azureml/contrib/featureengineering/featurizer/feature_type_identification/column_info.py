# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""ColumnInfo class represents column information includes stats and feature types."""
import json

import pandas as pd
from azureml.automl.core.column_purpose_detection.types import StatsAndColumnPurposeType
from azureml.automl.core.stats_computation import RawFeatureStats
from azureml.dataprep.api.dataprofile import ColumnProfile
from azureml.dataprep.api.engineapi.typedefinitions import FieldType

from azureml.contrib.featureengineering.core.constants import DatetimeDtype
from .feature_type import FeatureType
from .ts_feature_type import TimeSeriesFeatureType


class ColumnInfo:
    """ColumnInfo class represents column information includes stats and feature types."""

    def __init__(
            self,
            column_profile: ColumnProfile = None,
            raw_stats_purpose: StatsAndColumnPurposeType = None):
        """
        Construct column info object from ColumnProfile object or StatsAndColumnPurposeType object.

        :param column_profile: ColumnProfile object which contains stats from DataPrep profile.
        :type column_profile: ColumnProfile
        :param raw_stats_purpose: StatsAndColumnPurposeType object which contains stats from azureml-automl-core.
        :type raw_stats_purpose: StatsAndColumnPurposeType
        """
        self.ts_feature_type = TimeSeriesFeatureType.NA
        if column_profile is not None:
            self.column_name = column_profile.column_name
            self.total_number_vals = column_profile.count
            self.num_missing_vals = column_profile.missing_count
            self.field_type = column_profile.type

            # TODO: value_count return None if too many values, hard limit 1000
            # unique value are limit to 1000 by design in dataprep
            self.num_unique_vals = self.total_number_vals if column_profile.value_counts is None \
                else \
                len(column_profile.value_counts)
            # Average lengths of an entry in the column
            self.average_entry_length = 0
            # Average number of spaces in an entry in the column
            self.average_number_spaces = 0
            self.is_all_nan = self.total_number_vals == self.num_missing_vals
            self.feature_type = FeatureType.Ignore
            self.cardinality_ratio = 1.0 * self.num_unique_vals / self.total_number_vals
            self.ngram_len = None
        elif raw_stats_purpose is not None:
            raw_stats = raw_stats_purpose[0]
            self.column_name = raw_stats_purpose[2]
            self.total_number_vals = raw_stats.total_number_vals
            self.num_missing_vals = raw_stats.num_na
            self.is_all_nan = raw_stats.is_all_nan
            self.num_unique_vals = raw_stats.num_unique_vals
            self.average_entry_length = raw_stats.average_entry_length
            self.average_number_spaces = raw_stats.average_number_spaces
            self.cardinality_ratio = raw_stats.cardinality_ratio
            self.feature_type = FeatureType.from_str(raw_stats_purpose[1])
            if raw_stats.lengths is not None:
                self.ngram_len = self.get_ngram_len(raw_stats.lengths)
            else:
                self.ngram_len = 3
            self.field_type = self._get_field_type_from_stats(raw_stats)

    def _to_dict(self):
        """
        Create dict for  serialization usage.

        :return: a dictionary
        """
        dct = dict()
        # convert as str since np type not serializable
        dct['column_name'] = self.column_name
        dct['total_number_values'] = str(self.total_number_vals)
        dct['num_missing_values'] = str(self.num_missing_vals)
        dct['field_type'] = str(self.field_type.name)
        dct['num_unique_values'] = str(self.num_unique_vals)
        dct['average_entry_length'] = str(self.average_entry_length)
        dct['average_number_spaces'] = str(self.average_number_spaces)
        dct['is_all_nan'] = str(self.is_all_nan)
        dct['feature_type'] = str(self.feature_type.name)
        dct['cardinality_ratio'] = str(self.cardinality_ratio)
        dct['ngram_len'] = str(self.ngram_len)
        dct['ts_feature_type'] = str(self.ts_feature_type)

        return dct

    def __str__(self):
        """
        Create dict for  serialization usage.

        :return: JSON string of column info object.
        :rtype: str
        """
        return json.dumps(self._to_dict())

    @staticmethod
    def _get_field_type_from_stats(raw_stats: RawFeatureStats):
        """
        Convert data types in RawFeatureStats to DataPrep supported field types.

        :param raw_stats: RawFeatureStats stats object.
        :type raw_stats: RawFeatureStats
        :return: dataprep FieldType Enum.
        :rtype: azureml.dataprep.api.engineapi.typedefinitions.FieldType
        """
        if raw_stats.column_type == "boolean":
            return FieldType.BOOLEAN
        elif raw_stats.column_type == "decimal" or raw_stats.column_type == "floating":
            return FieldType.DECIMAL
        elif raw_stats.column_type == "integer":
            return FieldType.INTEGER
        elif raw_stats.column_type == "string":
            return FieldType.STRING
        elif raw_stats.column_type in DatetimeDtype.FULL_SET:
            return FieldType.DATE
        return FieldType.UNKNOWN

    # TODO: utilize text stats in DataFlow profile.
    def fill_stats_with_text_type(self, raw_column: pd.Series):
        """
        Fill average space, length, and ngram length for text type.

        :param raw_column: The data to transform.
        :type raw_column: pandas.series
        """
        raw_column_str = raw_column.apply(str)
        lengths = raw_column_str.apply(len)
        for column_entry in raw_column_str:
            self.average_number_spaces += column_entry.count(' ')
        total_number_vals = raw_column.shape[0]
        self.average_entry_length = 1.0 * (sum(lengths) / total_number_vals)
        self.average_number_spaces /= 1.0 * total_number_vals
        self.ngram_len = self.get_ngram_len(lengths)

    @staticmethod
    def get_ngram_len(lens_series):
        """
        Get N-grams length required for text transforms.

        :param lens_series: Series of lengths for a string.
        :return: The ngram to use.
        """
        max_ngram_len = 3
        ngram_len = lens_series.apply(lambda x: min(x, max_ngram_len))
        return ngram_len.mode()[0]

    def set_timeseries_column_type(self, timeseries_column_type: TimeSeriesFeatureType):
        """
        Set feature type of the time series column.

        :param timeseries_column_type: time series feature type for the column.
        """
        self.ts_feature_type = timeseries_column_type

    def get_timeseries_column_type(self):
        """Get feature type of the time series column ."""
        return self.ts_feature_type

    def is_a_timeseries_column(self):
        """
        Check whether the column is a timeseries column .

        :return: bool. returns True if the column is timeseries column otherwise, return False.
        """
        return self.ts_feature_type != TimeSeriesFeatureType.NA
