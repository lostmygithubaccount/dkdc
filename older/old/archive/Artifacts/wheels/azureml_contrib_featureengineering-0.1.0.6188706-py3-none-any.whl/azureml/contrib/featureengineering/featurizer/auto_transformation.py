# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""AutoTransformation module manages auto mode default transformation generation."""
import logging
import math
from typing import List, Optional

from sklearn.base import TransformerMixin

from azureml.contrib.featureengineering.featurizer import FeatureType, ColumnInfo
from azureml.contrib.featureengineering.featurizer.transformer import CategoricalFeaturizers, \
    DateTimeFeaturesTransformer, GenericFeaturizers, TextFeaturizers
from azureml.contrib.featureengineering.featurizer.transformer.text import TFIDF_VECTORIZER_CONFIG


class AutoTransformation:
    """Default transformations for different feature types."""

    HASHING_SEED_VALUE = 314489979

    @classmethod
    def get_column_transformers(
            cls,
            column_info: ColumnInfo,
            is_onnx_compatible: bool = False,
            logger: Optional[logging.Logger] = None) -> List[List[TransformerMixin]]:
        """
        Create a list of transforms for text data.

        :param column_info: Column info which contains types and stats of a column.
        :type column_info: ColumnInfo
        :param is_onnx_compatible: Indicates whether transformer is onnx compatible or not.
        :type is_onnx_compatible: bool
        :param logger: External logger handler.
        :type logger: logging.Logger
        :return: Transformations used for a column in a list.
        :rtype: List[List[TransformerMixin]]
        """
        transforms = []

        if column_info.feature_type == FeatureType.Numeric:
            numeric_tr = AutoTransformation.get_numeric_transforms()
            transforms.append(numeric_tr)
            # if there are lot of imputed values, add an imputation marker
            if column_info.num_missing_vals > 0.01 * column_info.total_number_vals:
                numeric_imputer_marker_tr = AutoTransformation.get_imputation_marker_transforms()
                transforms.append(numeric_imputer_marker_tr)

        if column_info.feature_type == FeatureType.DateTime:
            transforms.append(AutoTransformation.get_datetime_transforms(logger))

        if column_info.feature_type == FeatureType.CategoricalHash:
            transforms.append(
                AutoTransformation.get_categorical_hash_transforms(column_info.num_unique_vals,
                                                                   logger))

        if column_info.feature_type == FeatureType.Categorical:
            transforms.append(
                AutoTransformation.get_categorical_transforms(column_info.num_unique_vals, logger))

        if column_info.feature_type == FeatureType.Text:
            if not is_onnx_compatible:
                transforms.append(AutoTransformation.get_text_transformers(column_info.ngram_len,
                                                                           False, logger))
            transforms.append(
                AutoTransformation.get_text_transformers(column_info.ngram_len, True, logger))

        return transforms

    @classmethod
    def get_categorical_hash_transforms(
            cls,
            num_unique_categories: int,
            logger: Optional[logging.Logger] = None) -> List[TransformerMixin]:
        """
        Create a list of transforms for categorical hash data.

        :param num_unique_categories: Number of unique categories.
        :type num_unique_categories: int
        :param logger: External logger handler.
        :type logger: logging.Logger
        :return: Categorical hash transformations to use in a list.
        :rtype: TransformerType
        """
        number_of_bits = pow(2, int(math.log(num_unique_categories, 2)))
        return [TextFeaturizers.string_cast(logger=logger),
                CategoricalFeaturizers.hashonehot_vectorizer(
                    hashing_seed_val=cls.HASHING_SEED_VALUE,
                    num_cols=int(number_of_bits),
                    logger=logger)]

    @classmethod
    def get_datetime_transforms(
            cls,
            logger: Optional[logging.Logger] = None) -> List[TransformerMixin]:
        """
        Create a list of transforms for date time data.

        :param logger: External logger handler.
        :type logger: logging.Logger
        :return: Date time transformations to use in a list.
        :rtype: TransformerType
        """
        return [CategoricalFeaturizers.cat_imputer(logger=logger),
                TextFeaturizers.string_cast(logger=logger),
                DateTimeFeaturesTransformer(logger=logger)]

    @classmethod
    def _wrap_in_lst(cls, x):
        """
        Wrap an element in list.

        :param x: Element like string or integer.
        :type x: str or int
        :return: List of x wrapped.
        :rtype: List
        """
        return [x]

    @classmethod
    def get_categorical_transforms(
            cls,
            num_unique_categories: int,
            logger: Optional[logging.Logger] = None) -> List[TransformerMixin]:
        """
        Create a list of transforms for categorical data.

        :param num_unique_categories: Number of unique categories.
        :type num_unique_categories: int
        :param logger: External logger handler.
        :type logger: logging.Logger
        :return: Categorical transformations to use in a list.
        :rtype: TransformerType

        """
        if num_unique_categories <= 2:

            # Add the transformations to be done and get the alias name
            # for the hashing label encode transform.
            return [CategoricalFeaturizers.cat_imputer(logger=logger),
                    TextFeaturizers.string_cast(logger),
                    CategoricalFeaturizers.labelencoder(
                        hashing_seed_val=cls.HASHING_SEED_VALUE,
                        logger=logger)]
        else:
            # Add the transformations to be done and get the alias name
            # for the hashing one hot encode transform.
            return [TextFeaturizers.string_cast(logger=logger),
                    TextFeaturizers.count_vectorizer(tokenizer=cls._wrap_in_lst, binary=True)]

    @classmethod
    def get_numeric_transforms(cls) -> List[TransformerMixin]:
        """
        Create a list of transforms for numerical data.

        :return: Numeric transformations to use in a list.
        :rtype: TransformerType
        """
        # for the imputation marker transform.
        # floats or ints go as they are, we only fix NaN
        return [GenericFeaturizers.imputer()]

    @classmethod
    def get_imputation_marker_transforms(
            cls,
            logger: Optional[logging.Logger] = None) -> List[TransformerMixin]:
        """
        Create a list of transforms for numerical imputation data.

        :param logger: External logger handler.
        :type logger: logging.Logger
        :return: Numerical imputation transformations to use in a list.
        :rtype: TransformerType
        """
        return [GenericFeaturizers.imputation_marker(logger=logger)]

    @classmethod
    def get_text_transformers(
            cls,
            ngram_len: int,
            is_onnx_compatible: bool = False,
            logger: Optional[logging.Logger] = None) -> List[TransformerMixin]:
        """
        Create a list of transforms for text data.

        :param ngram_len: Continuous length of characters or number of words.
        :type ngram_len: int
        :param is_onnx_compatible: Indicates whether transformer is onnx compatible or not.
        :type is_onnx_compatible: bool
        :param logger: External logger handler.
        :type logger: logging.Logger
        :return: Numerical imputation transformations to use in a list.
        :rtype: TransformerType
        """
        if not is_onnx_compatible:
            return [TextFeaturizers.string_cast(logger=logger),
                    TextFeaturizers.tfidf_vectorizer(
                        use_idf=False,
                        norm=TFIDF_VECTORIZER_CONFIG.NORM,
                        max_df=TFIDF_VECTORIZER_CONFIG.MAX_DF,
                        analyzer=TFIDF_VECTORIZER_CONFIG.CHAR_ANALYZER,
                        ngram_range=(1, ngram_len))]
        else:
            return [TextFeaturizers.string_cast(logger=logger),
                    TextFeaturizers.tfidf_vectorizer(
                        use_idf=False,
                        norm=TFIDF_VECTORIZER_CONFIG.NORM,
                        analyzer=TFIDF_VECTORIZER_CONFIG.WORD_ANALYZER,
                        ngram_range=TFIDF_VECTORIZER_CONFIG.WORD_NGRAM_RANGE)]
