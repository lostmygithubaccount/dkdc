# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Featurizer class that can be added in pipeline for input."""
import gc
import json
import logging
import os
import pickle
import sys
import uuid
from collections import OrderedDict
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.base import TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import Imputer
from sklearn_pandas import DataFrameMapper
from sklearn_pandas.pipeline import TransformerPipeline

from azureml.contrib.featureengineering.common import utilities
from azureml.contrib.featureengineering.common.logging import _LoggerFactory, function_log_activity
from azureml.contrib.featureengineering.core import constants, memory_utilities, logging_utilities
from azureml.contrib.featureengineering.core.constants import TimeSeriesInternal
from azureml.contrib.featureengineering.core.exceptions import ConfigException
from azureml.contrib.featureengineering.core.types import TransformerType, FeaturizationSummaryType, \
    DataSingleColumnInputType
from azureml.contrib.featureengineering.featurizer import (ColumnInfo, FeatureTypeIdentifier, FeatureType,
                                                           TimeSeriesFeatureType, FeaturizerStrategy,
                                                           TransformerAndMapper, FeatureDefinition, FeaturizerConfig)
from azureml.contrib.featureengineering.featurizer._engineered_feature_names import _Transformer, \
    _FeatureTransformers, _TransformationFunctionNames, _GenerateEngineeredFeatureNames
from azureml.contrib.featureengineering.featurizer.onnx_converter import OnnxConverter, OnnxConvertConstants
from azureml.contrib.featureengineering.featurizer.strategy import ColumnStrategy
from azureml.contrib.featureengineering.featurizer.transformer import BaseTransformer, \
    TimeSeriesTransformer


class Featurizer(BaseTransformer):
    """Featurizer class that used for featurization process."""

    def __init__(self,
                 is_onnx_compatible: bool = False,
                 client_id: str = "unknown",
                 logger: Optional[logging.Logger] = None,
                 featurizer_config: FeaturizerConfig = None):
        """
        Initialize for featurizer for pre-processing raw user data.

        :param is_onnx_compatible: if works in onnx compatible mode.
        :type is_onnx_compatible: bool
        :param client_id: client id of the caller.
        :type client_id: string
        :param logger: External logger handler.
        :type logger: Logging.Logger
        :param featurizer_config: holds transformation settings for featurizer
        :type featurizer_config: FeaturizerConfig
        """
        super().__init__()

        self._logger = _LoggerFactory.get_logger(__name__, client_id=client_id)
        if logger is not None:
            _LoggerFactory.add_handler(self._logger, logger)

        # if featurizer config is None, we will create a default config.
        if featurizer_config is None:
            featurizer_config = FeaturizerConfig()
        self._featurizer_config = featurizer_config

        self._is_onnx_compatible = is_onnx_compatible
        self._onnx_converter = OnnxConverter(logger=self._logger)
        self._enable_dataframe_output = True if featurizer_config is None \
            else featurizer_config.enable_dataframe_output
        self.mapper = None
        self.transformer_and_mapper_list = []
        # for time series transformation
        self._ts_transformer = None
        self._columns_info = None
        self._feature_type_identifier = FeatureTypeIdentifier()
        self._engineered_feature_names_class = _GenerateEngineeredFeatureNames()
        self._featurizer_strategy = FeaturizerStrategy(self._is_onnx_compatible, client_id, self._logger)
        self._feature_definition = None
        self._raw_column_names = None
        self._verify_config_with_onnx_settings()

    @function_log_activity
    def load_from_model(self, model):
        """
        Load info from fitted model object in AutoML Run.

        :param model: A Model object.
        :type model: Model
        :raise: Exception
        """
        try:
            from azureml.automl.core.featurization import DataTransformer
            from azureml.automl.core.featurization import TimeSeriesTransformer
            transformer = model.steps[0][1]
            if isinstance(transformer, DataTransformer):
                self._is_onnx_compatible = transformer._is_onnx_compatible
                self._enable_dataframe_output = False
                self.mapper = transformer.mapper
                self.transformer_and_mapper_list = transformer.transformer_and_mapper_list
                self._engineered_feature_names_class = transformer._engineered_feature_names_class
                columns_strategy_dic = OrderedDict()
                self._columns_info = {}
                self._raw_column_names = []
                for stats_and_column_purpose_type in transformer.stats_and_column_purposes:
                    column_name = stats_and_column_purpose_type[2]
                    column_info = ColumnInfo(None, stats_and_column_purpose_type)
                    self._columns_info[column_name] = column_info
                    self._raw_column_names.append(column_name)
                self._feature_type_identifier.set_columns_info(self._columns_info)
                if self._is_onnx_compatible and self.mapper is not None:
                    self._get_columns_strategy_from_mapper(columns_strategy_dic, self.mapper)
                else:
                    for transformer_mapper in self.transformer_and_mapper_list:
                        self._get_columns_strategy_from_mapper(columns_strategy_dic,
                                                               transformer_mapper.mapper)
                columns_strategy = []
                for column_name, column_strategy in columns_strategy_dic.items():
                    columns_strategy.append(column_strategy)
                self._featurizer_strategy.load_featurizer_strategy(self._is_onnx_compatible,
                                                                   columns_strategy, self._columns_info,
                                                                   self._featurizer_config.enable_timeseries_transform,
                                                                   self._featurizer_config.get_ts_params_dict())
            elif isinstance(transformer, TimeSeriesTransformer):
                self._is_onnx_compatible = False
                self._ts_transformer = transformer
        except Exception as e:
            self._logger_wrapper(
                "error", "Error loading data from AutoML model object. Error: {}".format(e))
            raise Exception("Error loading data from AutoML model object.")
        self._logger_wrapper("info", "Finished loading from AutoML model object.")

    def _get_columns_strategy_from_mapper(
            self,
            columns_strategy_dic: Dict[str, ColumnStrategy],
            mapper: DataFrameMapper):
        """
        Extract column strategies from DataFrameMapper object.

        :param columns_strategy_dic: Dictionary contains transformation info for each columns.
        :type columns_strategy_dic: Dict[str, ColumnStrategy]
        :param mapper: A DataFrameMapper object.
        :type mapper: DataFrameMapper
        """
        if mapper is not None:
            for transformer_type in mapper.features:
                cols = transformer_type[0]
                if isinstance(transformer_type[1], TransformerPipeline):
                    trans = list(map(lambda x: x[1], transformer_type[1].steps))
                else:
                    trans = transformer_type[1]
                columns = cols if isinstance(cols, list) else [cols]
                transformers = trans if isinstance(trans, list) else [trans]
                columns_name_key = self._featurizer_strategy.generate_column_name(columns)
                if columns_name_key in columns_strategy_dic:
                    columns_strategy_dic[columns_name_key].transformers.append(transformers)
                else:
                    columns_strategy = ColumnStrategy(column_names=columns,
                                                      transformers=[transformers])
                    if len(columns) == 1:
                        columns_strategy.feature_type_name = self._columns_info[
                            columns[0]].feature_type.name
                    columns_strategy_dic[columns_name_key] = columns_strategy

    @function_log_activity
    def fit(self, df, y=None):
        """
        Perform the raw data validation and identify the transformations to apply.

        :param df: Dataframe, DataFlow, DataSet, or Ndarray representing text, numerical or categorical input.
        :param y: To match fit signature.
        :return: DataTransform object.
        :raises: Value Error for non-dataframe and empty dataframes.
        """
        utilities.check_input(df)
        input_data = pd.DataFrame(df) if isinstance(df, np.ndarray) else df
        if (self._is_onnx_compatible and not self.mapper) or (not self.transformer_and_mapper_list):
            self._logger_wrapper('info', 'Featurizer mapper not found so learn all the transforms')
        if self._columns_info is None:
            data_flow = self._feature_type_identifier.identify_feature_types(input_data)
            self._columns_info = self._feature_type_identifier.get_columns_info()
            self._set_ts_column_type()
            self._featurizer_strategy.load_default_featurizer_strategy(
                self._columns_info,
                self._featurizer_config.enable_timeseries_transform,
                self._featurizer_config.get_ts_params_dict())
            transformers_count = 0
            for column_name, column_strategy in self._featurizer_strategy.get_featurizer_strategy()[0].items():
                if column_strategy.transformers is not None:
                    transformers_count = transformers_count + len(column_strategy.transformers)

            if len(self._columns_info) == 1 and transformers_count == 0:
                # Perform Feature Type swapping
                for column_name, column_info in self._columns_info.items():
                    new_feature_type = self._safe_convert_feature_type(column_info.feature_type)
                    if new_feature_type is not None:
                        self.set_feature_type(column_name, new_feature_type)

            input_df = data_flow.to_pandas_dataframe()
        else:
            self._feature_type_identifier.set_columns_info(self._columns_info)
            input_df = input_data if isinstance(input_data, pd.DataFrame) else df.to_pandas_dataframe()

        self._raw_column_names = input_df.columns.values.tolist()
        self._learn_transformations()
        if self._is_onnx_compatible and self.mapper is not None:
            self.mapper.fit(input_df, y)
        else:
            for transformer_mapper in self.transformer_and_mapper_list:
                transformer_mapper.mapper.fit(input_df, y)

                steps = transformer_mapper.transformers.steps \
                    if isinstance(transformer_mapper.transformers,
                                  Pipeline) else transformer_mapper.transformers

                transform_count = len(steps)
                if transform_count == 0:
                    continue
                # Only last transformer gets applied, all other are input to next transformer.
                last_transformer = steps[transform_count - 1]
                last_transformer = last_transformer[1] \
                    if isinstance(last_transformer, tuple) and len(last_transformer) > 1 \
                    else last_transformer
                memory_estimate = (0 if not issubclass(type(last_transformer), BaseTransformer)
                                   else last_transformer.get_memory_footprint(input_df, y))
                transformer_mapper.memory_footprint_estimate = memory_estimate

        if not self._onnx_converter.is_initialized():
            self._onnx_converter.initialize_input(input_df,
                                                  model_name='Featurizer ONNX converter',
                                                  model_desc='Featurizer ONNX converter')

        if self._enable_time_series_featurizer():
            if y is None:
                raise ValueError("label column y is required in fit while time series enabled.")
            combined_df = self._generate_timeseries_combined_df(input_df)
            self._ts_transformer = TimeSeriesTransformer(
                logger=self.logger, **self._featurizer_strategy.get_featurizer_strategy()[1]._ts_param_dict)
            self._ts_transformer.fit(combined_df, y)
        return self

    @function_log_activity
    def transform(self, df, y=None):
        """
        Transform the input raw data with the transformations idetified in fit stage.

        :param df: Dataframe representing text, numerical or categorical input.
        :type df: Dataframe, DataFlow, DataSet, or Ndarray
        :param y: To match fit signature.
        :type y: numpy.ndarray
        :return: pandas.DataFrame when time series enabled, otherwise sparse matrix or sparse DataFrame.
        :raises: Exception
        """
        utilities.check_input(df)
        input_data = pd.DataFrame(df) if isinstance(df, np.ndarray) else df
        input_df = self._feature_type_identifier.convert_to_dataflow(input_data).to_pandas_dataframe()

        if self._enable_time_series_featurizer():
            combined_df = self._generate_timeseries_combined_df(input_df)
            return self._ts_transformer.transform(combined_df, y)
        else:
            result = self._transform(input_df)
            if self._enable_dataframe_output:
                if isinstance(result, sparse.csr_matrix):
                    return pd.SparseDataFrame(result, columns=self.get_engineered_feature_names())
                else:
                    return pd.DataFrame(data=result, columns=self.get_engineered_feature_names())
            else:
                return result

    def fit_transform(self, X, y=None, **fit_params: Any):
        """
        Wrap fit and transform functions in the Data transformer class.

        :param X: Dataframe, DataFlow, DataSet, or Ndarray representing text, numerical or categorical input.
        :param X: Dataframe, DataFlow, DataSet, or Ndarray.
        :param y: To match fit signature.
        :type y: numpy.ndarray or pandas.DataFrame
        :return: Transformed data.

        """
        self.fit(X, y)
        return self.transform(X, y)

    def _transform(self, df):
        features = self._apply_transforms(df)
        any_sparse = any(sparse.issparse(fea) for fea in features)
        # TODO: refactor, engineered name generation and feature definition are duplicate to some
        #  extend
        if self._engineered_feature_names_class is not None:
            if not self._engineered_feature_names_class.are_engineered_feature_names_available():
                # Generate engineered feature names if they are not already generated
                if self._is_onnx_compatible:
                    self._engineered_feature_names_class.parse_raw_feature_names(
                        self.mapper.transformed_names_)
                else:
                    names = []  # type: List[str]
                    for transformer_mapper in self.transformer_and_mapper_list:
                        names.extend(transformer_mapper.mapper.transformed_names_)
                    self._engineered_feature_names_class.parse_raw_feature_names(names)
        if self._feature_definition is None:
            self._generate_feature_definition_from_mapper()
        if not self._feature_definition.are_engineered_feature_names_available():
            if self._is_onnx_compatible:
                self._feature_definition.parse_raw_feature_names(
                    self.mapper.transformed_names_, self._get_engineered_feature_names())
            else:
                names = []  # type: List[str]
                for transformer_mapper in self.transformer_and_mapper_list:
                    names.extend(transformer_mapper.mapper.transformed_names_)
                self._feature_definition.parse_raw_feature_names(
                    names, self._get_engineered_feature_names())

        max_available_memory = memory_utilities.get_all_ram()

        if any_sparse:
            current_available_memory = memory_utilities.get_available_physical_memory()
            self._logger_wrapper('info',
                                 'Total ram: {} bytes, Current Available memory: {} bytes. Low '
                                 'memory threshold: {}'
                                 .format(max_available_memory, current_available_memory,
                                         constants.LOW_MEMORY_THRESHOLD))
            if current_available_memory > constants.LOW_MEMORY_THRESHOLD * max_available_memory:
                return sparse.hstack(features).tocsr()
            # Memory is under pressure, trade of diskIO for a more memory-efficient way than
            # hstack to combine
            # feaure sets
            # Solution:
            # 1. convert each feature set into csr matrix, collecting information for the final
            # result arrays,
            #    then dump csr matrix into pickle file
            # 2. release memory held by feature sets
            # 3. allocation memory for final result arrays
            # 4. load csr matrix back from pickle and update the final result arrays
            # 5. construct final csr matrix from final result arrays without any copying
            try:
                self._logger_wrapper(
                    'debug', '1. convert each feature set into csr matrix, \
                                    collecting information for the final result arrays, \
                                    then dump csr matrix into pickle file')
                final_size = 0
                column_count = 0
                row_count = -1
                offset_by_row = []  # type: List[int]
                dtypes = []
                pickle_files = []

                tmp_dir = 'tmp_{}'.format(uuid.uuid4())
                os.mkdir(tmp_dir)

                for i, fea in enumerate(features):

                    csr = sparse.csr_matrix(fea)
                    # shape info
                    final_size += csr.size
                    column_count += csr.shape[1]

                    if row_count == -1:
                        row_count = csr.shape[0]
                        offset_by_row = np.zeros([row_count], dtype=np.int64)
                    elif not row_count == csr.shape[0]:
                        raise ValueError(
                            "features have inconsistent row count")

                    # offset for first element in each row
                    for row_index in range(row_count):
                        offset_by_row[row_index] += csr.indptr[row_index]

                    # dtype info
                    dtypes.append(csr.dtype)
                    # pickle info
                    file_name = '{}/fea_{}'.format(tmp_dir, i)
                    pickle_files.append(file_name)
                    with open(file_name, 'wb') as pickle_file:
                        pickle.dump(csr, pickle_file,
                                    protocol=constants.DEFAULT_PICKLE_PROTOCOL_VERSION)
                    del csr
                    gc.collect()

                final_shape = (row_count, column_count)
                data_dtype = np.find_common_type(dtypes, [])
                self._logger_wrapper(
                    'debug', '2. release memory held by feature sets')
                del features
                gc.collect()

                self._logger_wrapper(
                    'debug', '3. allocation memory for final result arrays')
                final_data = np.zeros([final_size], dtype=data_dtype)
                final_indices = np.zeros(
                    [final_size], dtype=sparse.sputils.get_index_dtype(maxval=max(final_shape)))
                final_indptr = np.zeros(
                    [row_count + 1], dtype=sparse.sputils.get_index_dtype(maxval=final_size))

                self._logger_wrapper(
                    'debug',
                    "4. load coo matrix back from pickle and update the final result arrays")

                col_offset = 0
                for file_name in pickle_files:
                    with open(file_name, 'rb') as pickle_file:
                        csr = pickle.load(pickle_file)
                    # reference for csr spec:
                    # https://en.wikipedia.org/wiki/Sparse_matrix#Compressed_sparse_row_(CSR,
                    # _CRS_or_Yale_format)
                    row_offset = 0

                    for i in range(row_count):
                        row_size = csr.indptr[i + 1] - csr.indptr[i]
                        row_offset += row_size
                        final_indptr[i + 1] += row_offset
                        if row_size == 0:
                            continue
                        from_slice = slice(
                            csr.indptr[i], csr.indptr[i] + row_size)
                        to_slice = slice(
                            offset_by_row[i], offset_by_row[i] + row_size)
                        final_data[to_slice] = csr.data[from_slice]
                        final_indices[to_slice] = csr.indices[from_slice] + col_offset
                        offset_by_row[i] += row_size

                    col_offset += csr.shape[1]
                    del csr
                    gc.collect()

                self._logger_wrapper(
                    'debug', '5. construct csr matrix from final result arrays without any copying')
                # the three numpy arrays won't be copied when constructing sparse matrix
                #  https://docs.scipy.org/doc/numpy/reference/generated/numpy.array.html
                csr = sparse.csr_matrix(
                    (final_data, final_indices, final_indptr), shape=final_shape, copy=False)

                self._logger_wrapper('debug', '6. done')
                return csr

            finally:
                for f in pickle_files:
                    try:
                        if os.path.exists(f):
                            os.remove(f)
                    except Exception as e:
                        self._logger_wrapper(
                            'error',
                            'Error while removing pickle files in featurizer.transform: {}'.format(
                                e))

                if len(os.listdir(tmp_dir)) == 0:
                    os.rmdir(tmp_dir)
        else:
            return np.hstack(features)

    def _generate_timeseries_combined_df(self, df):
        time_series_df = df[list({x[0] for x in self._featurizer_config.get_ts_columns()
                                  if x[0] != TimeSeriesInternal.DUMMY_TARGET_COLUMN})]
        if self.mapper is not None or len(self.transformer_and_mapper_list) > 0:
            # combine df with time series df
            result = self._transform(df)
            if isinstance(result, sparse.csr_matrix):
                result = result.toarray()
            if isinstance(result, np.ndarray):
                regular_transformed_df = pd.DataFrame(result)
                regular_transformed_df.columns = self._get_engineered_feature_names()
                combined_df = pd.concat([regular_transformed_df, time_series_df], axis=1)
            else:
                ValueError("Should output ndarray if time series transformation is enabled")
        else:
            combined_df = df
        return combined_df

    def _enable_time_series_featurizer(self):
        if self._featurizer_config is not None:
            return self._featurizer_config.enable_timeseries_transform
        else:
            return False

    def _learn_transformations(self):
        """Learn data transformation to be done on the from column strategies."""
        if not self._columns_info:
            raise ValueError("No columns_info exist during learn transformations.")

        self._engineered_feature_names_class = _GenerateEngineeredFeatureNames()
        self._feature_definition = FeatureDefinition()
        self.mapper = None
        self.transformer_and_mapper_list = []

        # Create transformations from strategy object
        column_strategies = self._featurizer_strategy.get_featurizer_strategy()[0]
        transformers_list = []  # type: List[TransformerType]
        for cat_column_name, column_strategy in column_strategies.items():
            columns = column_strategy.column_names
            if column_strategy.feature_type_name is not None:
                # persist JSON object for feature type are AllNan, Hashes, Ignore
                self._get_alias_name(columns, [], column_strategy.feature_type_name)
            for trans in column_strategy.transformers:
                alias_name = self._get_alias_name(columns, trans, column_strategy.feature_type_name)
                if alias_name is not None:
                    is_internal = isinstance(trans[0], BaseTransformer)\
                        or 'AutoMLTransformer' in str(trans[0].__class__.__base__)
                    if is_internal:
                        transformers_list.append((columns[0], trans, {'alias': alias_name}))
                    else:
                        transformers_list.append((columns, trans, {'alias': alias_name}))
        is_enable_time_series = self._enable_time_series_featurizer()
        if len(transformers_list) == 0 and is_enable_time_series is False:
            self._logger_wrapper(
                'warning', "No features could be identified or generated. Please inspect your data.")
            raise ValueError("No features could be identified or generated. Please inspect your data.")

        if len(transformers_list) != 0:
            self._feature_definition.generate_transformation_mapping(transformers_list)
            if self._is_onnx_compatible:
                self.mapper = DataFrameMapper(transformers_list, input_df=True, sparse=not is_enable_time_series)
            else:
                self.transformer_and_mapper_list = []
                for transformers in transformers_list:
                    transform_and_mapper = \
                        TransformerAndMapper(transformers=transformers[1],
                                             mapper=DataFrameMapper([transformers], input_df=True,
                                                                    sparse=not is_enable_time_series))
                    self.transformer_and_mapper_list.append(transform_and_mapper)

    @staticmethod
    def _safe_convert_feature_type(feature_type: FeatureType):
        safe_feature_type_conversions = {FeatureType.Hashes: FeatureType.Text}
        return safe_feature_type_conversions.get(feature_type, None)

    def _generate_feature_definition_from_mapper(self):
        """Generate feature definition from DataFrameMapper or transformer_and_mapper_list."""
        mapper_list = []
        if self._is_onnx_compatible and self.mapper is not None:
            mapper_list.append(self.mapper)
        else:
            for transformer_mapper in self.transformer_and_mapper_list:
                mapper_list.append(transformer_mapper.mapper)
        if len(mapper_list) > 0:
            transformers_list = []
            self._feature_definition = FeatureDefinition()
            for mapper in mapper_list:
                for feature in mapper.features:
                    if isinstance(feature[1], TransformerPipeline):
                        trans = list(map(lambda x: x[1], feature[1].steps))
                    else:
                        trans = feature[1]
                    transformers_list.append((feature[0], trans, feature[2]))
            self._feature_definition.generate_transformation_mapping(transformers_list)

    def _get_alias_name(self, columns: List[str], transformer_list: List[TransformerMixin],
                        feature_type_name: str = ""):
        """
        Take a list of transformations needed for raw columns and return the resulting  alias name.

        :param columns: A python object.
        :type columns: Object
        :param transformer_list: List of transformations.
        :type transformer_list: List[TransformerMixin]
        :param feature_type_name: Feature type name in string.
        :type feature_type_name: str
        :return: alias name in string, return None if transformer list is empty.
        :rtype: str
        """
        transformers = []  # type: List[_Transformer]
        if feature_type_name in [FeatureType.AllNan.name, FeatureType.Hashes.name,
                                 FeatureType.Ignore.name]:
            # Add the transformations to be done and get the alias name
            # for the drop transform.
            drop_transformer = _Transformer(
                parent_feature_list=columns,
                transformation_fnc=_TransformationFunctionNames.Drop,
                operator=None,
                feature_type=feature_type_name,
                should_output=True)
            transformers.append(drop_transformer)
        else:
            for index, transform in enumerate(transformer_list):
                if transform:
                    if hasattr(transform, 'transformer_name'):
                        transformer_name = transform.transformer_name
                    else:
                        transformer_name = transform.__class__.__name__

                    if hasattr(transform, 'operator_name'):
                        operator = transform.operator_name
                    else:
                        if transformer_name == TfidfVectorizer.__name__:
                            operator = transform.analyzer
                        elif transformer_name == Imputer.__name__:
                            operator = transform.strategy
                        else:
                            operator = None
                    if index == 0:
                        parent_feature_list = columns
                    else:
                        parent_feature_list = [index]

                    if transformer_name == _TransformationFunctionNames.StringCast:
                        show_output = False
                    else:
                        show_output = True

                    tr = _Transformer(parent_feature_list, transformer_name, operator,
                                      feature_type_name, show_output)
                    transformers.append(tr)
        if len(transformers) > 0:
            feature_transformers = _FeatureTransformers(transformers)
            json_obj = feature_transformers.encode_transformations_from_list()
            alias_column_name = self._engineered_feature_names_class.get_raw_feature_alias_name(
                json_obj)
            return alias_column_name
        else:
            return None

    def _apply_transforms(self, df: pd.DataFrame) -> List[Any]:
        """
        Apply transformation on a pandas DataFrame.

        :param df: A pandas DataFrame.
        :type df: Pandas.DataFrame
        :return: List of sparse matrix as transformation results.
        :rtype: List[Any]
        """
        features = []
        if (self._is_onnx_compatible and not self.mapper) and (
                not self.transformer_and_mapper_list):
            raise Exception("fit not called")

        if self._is_onnx_compatible:
            assert self.mapper is not None
            transformed_data = self.mapper.transform(df)
            features.append(transformed_data)
        else:
            total_ram = memory_utilities.get_all_ram(self.logger)
            self._logger_wrapper("info", "Starting to apply transforms. Total ram: {} bytes".format(total_ram))
            for transformer_mapper in self.transformer_and_mapper_list:
                current_available_physical_memory = memory_utilities.get_available_physical_memory()
                transform_memory_footprint = transformer_mapper.memory_footprint_estimate
                self._logger_wrapper("info", "Transform memory estimate: {} bytes, Current available memory: {} bytes"
                                     .format(transform_memory_footprint, current_available_physical_memory))
                apply_transform = (transform_memory_footprint < current_available_physical_memory)

                transformer_list = []
                if isinstance(transformer_mapper.transformers, Pipeline):
                    for tr in transformer_mapper.transformers.steps:
                        transform = tr[1]
                        if hasattr(transform, "steps"):
                            for substep in transform.steps:
                                transformer_list.append(substep[0])
                        elif isinstance(tr, tuple):
                            transformer_list.append(tr[1].__class__.__name__)
                        else:
                            transformer_list.append(tr.__class__.__name__)
                else:
                    transformer_list = [tr.__class__.__name__ for tr in
                                        transformer_mapper.transformers]

                transformer_names = ",".join(transformer_list)
                if apply_transform:
                    self._logger_wrapper(
                        "info", "{}: Applying transform.".format(transformer_names))
                    try:
                        transform_output = transformer_mapper.mapper.transform(df)
                        features.append(transform_output)
                        self._logger_wrapper("info",
                                             "{transformers}: Finished applying transform. Shape "
                                             "{shape}".format(
                                                 shape=transform_output.shape,
                                                 transformers=transformer_names))
                    except Exception as e:
                        self._logger_wrapper(
                            "error", "{}: Failed to apply transform. Error: {}".format(transformer_names, e))

                        logging_utilities.log_traceback(e, self._logger, is_critical=False)
                else:
                    self._logger_wrapper(
                        "info",
                        "{}: Transform not applied due to memory constraints.".format(transformer_names))
            self._logger_wrapper("info", "Finished applying transforms")
        return features

    @function_log_activity
    def save_pickle(self, file_path: str):
        """
        Save featurizer object into pickle file.

        :param file_path: location of pickle file that object will be saved.
        :type file_path: str
        :raise: ValueError
        """
        # logger is not pickleable, we can manual set it to false
        self._logger = None
        self._onnx_converter.logger = None
        self._featurizer_strategy._logger = None
        if utilities.check_pickleable(self):
            utilities.save_pickle(self, file_path)
        else:
            raise ValueError("Error: Featurizer is not pickleable.")

    @function_log_activity
    def load_pickle(self, file_path: str):
        """
        Load featurizer object content from pickle file .

        :param file_path: location of pickle file .
        :type file_path: str
        """
        obj = utilities.load_pickle(file_path)
        self._is_onnx_compatible = obj._is_onnx_compatible
        self._onnx_converter = obj._onnx_converter
        self.mapper = obj.mapper
        self.transformer_and_mapper_list = obj.transformer_and_mapper_list
        self._columns_info = obj._columns_info
        self._feature_type_identifier = obj._feature_type_identifier
        self._engineered_feature_names_class = obj._engineered_feature_names_class
        self._featurizer_strategy = obj._featurizer_strategy
        self._feature_definition = obj._feature_definition
        self._raw_column_names = obj._raw_column_names
        return self

    @function_log_activity
    def get_columns_info(self):
        """
        Get columns info object.

        Return a dictionary of column info object which contains data types, data statistics.

        :return: list of column info object
        :rtype: List[ColumnInfo]
        """
        return self._columns_info

    @function_log_activity
    def get_feature_definition(self):
        """
        Get feature definition object.

        Return transformed raw feature names into engineered feature names metadata info.

        :return: feature definition object
        :rtype: FeatureDefinition
        """
        return self._feature_definition

    @function_log_activity
    def get_raw_feature_names(self):
        """
        Get the engineered feature names.

        Return the list of raw feature names as string before data transformations.

        :return: The list of raw feature names as strings
        """
        return self._raw_column_names

    @function_log_activity
    def get_user_friendly_engineered_feature_names(self):
        """
        Get user friendly engineered feature names.

        :return: list of names, return empty list if feature definition is None.
        :rtype: List[str]
        """
        if self._feature_definition is not None:
            return self._feature_definition.get_user_friendly_engineered_feature_names()
        else:
            return []

    @function_log_activity
    def get_engineered_feature_names(self) -> Optional[List[str]]:
        """
        Get the engineered feature names.

        Return the list of engineered feature names as string after data transformations on the
        raw data have been finished.

        :return: The list of engineered feature names as strings
        """
        if self._enable_time_series_featurizer():
            if self._ts_transformer is not None:
                return self._ts_transformer.get_engineered_feature_names()
            else:
                return None
        else:
            return self._get_engineered_feature_names()

    def _get_engineered_feature_names(self) -> List[str]:
        return self._engineered_feature_names_class._engineered_feature_names

    def _get_json_str_for_engineered_feature_name(self,
                                                  engineered_feature_name) -> Optional[str]:
        """
        Return JSON string for engineered feature name.

        :param engineered_feature_name: Engineered feature name for
                                        whom JSON string is required
        :return: JSON string for engineered feature name
        """
        engineered_feature_name_json_obj = self._engineered_feature_names_class \
            .get_json_object_for_engineered_feature_name(engineered_feature_name)

        # If the JSON object is not valid, then return None
        if engineered_feature_name_json_obj is None:
            self._logger_wrapper(
                'info', "Not a valid feature name " + engineered_feature_name)
            return None

        # Convert JSON into string and return
        return json.dumps(engineered_feature_name_json_obj)

    @function_log_activity
    def get_json_strs_for_engineered_feature_names(self,
                                                   engi_feature_name_list: Optional[List[str]] = None,
                                                   is_timeseries: bool = False) -> List[str]:
        """
        Return JSON string list for engineered feature names.

        :param engi_feature_name_list: Engineered feature names for whom JSON strings are required.
        :param is_timeseries: whether to return time series JSON string.
        :return: JSON string list for engineered feature names
        """
        if is_timeseries and self._enable_time_series_featurizer() and self._ts_transformer is not None:
            return self._ts_transformer.get_json_strs_for_engineered_feature_names()

        engineered_feature_names_json_str_list = []
        if engi_feature_name_list is None:
            engi_feature_name_list = self._get_engineered_feature_names()

        # Walk engineering feature name list and get the corresponding
        # JSON string
        for engineered_feature_name in engi_feature_name_list:

            json_str = self._get_json_str_for_engineered_feature_name(
                engineered_feature_name)

            if json_str is not None:
                engineered_feature_names_json_str_list.append(json_str)

        # Return the list of JSON strings for engineered feature names
        return engineered_feature_names_json_str_list

    @function_log_activity
    def get_raw_feature_transformation_json(self, feature_list=None):
        """
        Return JSON string list for engineered feature names.

        :param feature_list: raw feature names or raw column index for getting subset of transformation
        metadata JSON. If None, getting full set metadata JSON.
        :type feature_list: List[str] or list[int] or None
        :return: JSON string list for engineered feature names
        :rtype: str
        """
        if self._feature_definition is None or self._raw_column_names is None:
            raise ValueError("Please run fit_transform/transform to generate feature definition.")
        selected_column_names = None if feature_list is None else []
        for val in feature_list:
            if isinstance(val, str) and val in self._raw_column_names:
                selected_column_names.append(val)
            elif isinstance(val, int) and val in range(len(self._raw_column_names)):
                selected_column_names.append(self._raw_column_names[val])
            else:
                raise ValueError(
                    "{} is neither a raw feature name or index of raw feature name.".format(val))
        return self._feature_definition.get_transformation_meta_json(selected_column_names)

    @function_log_activity
    def get_featurization_summary(self, is_timeseries: bool = False) -> FeaturizationSummaryType:
        """
        Return the featurization summary for all the input features seen by DataTransformer.

        :param is_timeseries: whether to return time series summary.
        :return: List of featurization summary for each input feature.
        """
        if is_timeseries and self._enable_time_series_featurizer() and self._ts_transformer is not None:
            return self._ts_transformer.get_featurization_summary()
        return self._engineered_feature_names_class.get_raw_features_featurization_summary()

    @function_log_activity
    def set_featurizer_timeseries_params(self, enable_timeseries_transform: bool, ts_param_dict: Dict[str, Any]):
        """
        Set parameters for timeseries featurizer.

        :param enable_timeseries_transform: whether to enable the timeseries transformer.
        :param ts_param_dict: the config dictionary.
        """
        self._featurizer_config.set_timeseries_transform_enabled_flag(enable_timeseries_transform)
        self._featurizer_config.set_from_timeseries_dict(ts_param_dict)
        self._set_ts_column_type()
        self._featurizer_strategy.set_timeseries_params(self._columns_info, enable_timeseries_transform, ts_param_dict)

    @function_log_activity
    def set_feature_type(self, column_name: str, feature_type: FeatureType):
        """
        Set feature type for one column.

        :param column_name: column name
        :param feature_type: feature type name.
        """
        if self._columns_info is None:
            raise ValueError(
                "Error: column information is empty, please make sure you call fit or fit_transform"
                " before setting the feature type for the column")
        if column_name not in self._columns_info:
            raise ValueError("Error: column name doesn't exist in column information.")
        feature_type_from = self._columns_info[column_name].feature_type.name
        self._feature_type_identifier.set_column_feature_type(column_name, feature_type)
        self._columns_info = self._feature_type_identifier.get_columns_info()
        self._featurizer_strategy.set_feature_type(column_name, self._columns_info[column_name],
                                                   feature_type_from, feature_type.name)

    @function_log_activity
    def add_column_transformer(self, cols: List[str], transformers: List[TransformerMixin]):
        """
        Add transformers to one or multiple columns.

        :param cols: List of column names.
        :param transformers: List of base/meta transformers.
        """
        return self._featurizer_strategy.add_column_transformer(cols, transformers)

    @function_log_activity
    def add_feature_type_transformer(self, feature_type: FeatureType,
                                     transformers: List[BaseTransformer]):
        """
        Add transformers to one feature type.

        :param feature_type: the feature type name.
        :param transformers: List of base/meta transformers.
        """
        return self._featurizer_strategy.add_feature_type_transformer(feature_type, transformers)

    @function_log_activity
    def set_column_transformer(self, cols: List[str], transformers: List[TransformerMixin]):
        """
        Set transformers for one or multiple columns.

        :param cols: List of column names.
        :param transformers: List of base/meta transformers.
        """
        return self._featurizer_strategy.set_column_transformer(cols, transformers)

    @function_log_activity
    def set_feature_type_transformer(self, feature_type: FeatureType,
                                     transformers: List[TransformerMixin]):
        """
        Set transformers for feature type.

        :param feature_type: the feature type name.
        :param transformers: List of base/meta transformers.
        """
        return self._featurizer_strategy.set_feature_type_transformer(feature_type, transformers)

    @function_log_activity
    def remove_column_transformer(self, cols: List[str]):
        """
        Remove transformers for one or multiple columns.

        :param cols: List of column names.
        """
        return self._featurizer_strategy.remove_column_transformer(cols)

    @function_log_activity
    def remove_feature_type_transformer(self, feature_type: FeatureType):
        """
        Remove transformers for one feature type.

        :param feature_type: feature type name.
        """
        return self._featurizer_strategy.remove_feature_type_transformer(feature_type)

    @function_log_activity
    def to_onnx(self, pipe=None, model_name='', model_desc=None):
        """
        Convert the Python model with given child run object into ONNX model.

        :param pipe: The sklearn pipeline object to convert to ONNX.
        :type pipe: sklearn.pipeline.Pipeline
        :param model_name: Name of the model.
        :type model_name: str
        :param model_desc: The sklearn pipeline object to convert to ONNX.
        :type model_desc: str or None
        :returns onnx_mdl: converted ONNX model, err: any error message received while converting
        :rtype (onnx_mdl, err): (onnx.ModelProto, dict)
        """
        if pipe is None:
            pipe = make_pipeline(self)
        onnx_mdl, err = self._onnx_converter.convert(pipe, model_name, model_desc)
        return onnx_mdl, err

    @function_log_activity
    def save_onnx_model(self, onnx_mdl, file_path, resource_path=''):
        """
        Save an ONNX model to a ProtoBuf object binary file.

        :param onnx_mdl: ONNX model
        :type onnx_mdl: onnx.ModelProto
        :param file_path: ONNX file (full file name)
        :type file_path: str
        :param resource_path: if not null, save ONNX model resource file to this path
        :type resource_path: str
        """
        if resource_path:
            self.save_onnx_model_resource(resource_path)
        self._onnx_converter.save_onnx_model(onnx_mdl, file_path)

    @function_log_activity
    def save_onnx_model_to_text_file(self, onnx_mdl, file_path):
        """
        Save the ONNX model in text format.

        :param onnx_mdl: ONNX model (object)
        :type onnx_mdl: ModelProto
        :param file_path: the path including file name to save the model
        :type file_path: str
        """
        self._onnx_converter.save_onnx_model_to_text_file(onnx_mdl, file_path)

    @function_log_activity
    def save_onnx_model_resource(self, resource_path):
        """
        Save converted ONNX model resource.

        :param resource_path: file path to save ONNX model resource info, saves as .pkl file
        :type resource_path: str
        """
        onnx_res = self._onnx_converter.get_converted_onnx_model_resource()
        if utilities.check_pickleable(onnx_res):
            utilities.save_pickle(onnx_res, resource_path)
        else:
            raise ValueError("Error: Onnx resource is not pickleable.")

    @function_log_activity
    def load_onnx_model(self, file_path):
        """
        Load the binary format ONNX model.

        :param file_path: the path including file name to load the model
        :type file_path: str
        :return: the loaded ONNX model object.
        :rtype: onnx.ModelProto
        """
        return self._onnx_converter.load_onnx_model(file_path)

    @function_log_activity
    def get_converted_onnx_model_resource(self, resource_file_path=''):
        """Get the resource of the converted ONNX model.

        :param resource_file_path: the path including file name to load the onnx resource (optional)
        :type resource_file_path: str
        :return: ONNX model resource
        :rtype: dict
        """
        if resource_file_path:
            onnx_resource_from_file = utilities.load_pickle(resource_file_path)
            return onnx_resource_from_file
        else:
            return self._onnx_converter.get_converted_onnx_model_resource()

    def _verify_config_with_onnx_settings(self):
        """Verify that input configuration settings are sensible."""
        if self._is_onnx_compatible:
            if sys.version_info >= OnnxConvertConstants.OnnxIncompatiblePythonVersion:
                raise ConfigException('The ONNX package does not support Python 3.8, '
                                      'please use lower version of Python to get the ONNX model.')
            if self._featurizer_config.enable_timeseries_transform:
                raise ValueError('Timeseries is not ONNX compatible, disable enable_onnx_compatible_models to run.')

    def _set_ts_column_type(self):
        """Set column info with time series parameter dictionary."""
        if self._columns_info is not None:
            if self._featurizer_config.enable_timeseries_transform:
                if not self._featurizer_config.get_ts_columns():
                    raise ValueError('To enable time series transformation, provide time series parameter dictionary.')
                for col, col_type in self._featurizer_config.get_ts_columns():
                    if col in self._columns_info:
                        self._columns_info[col].set_timeseries_column_type(col_type)
            else:
                for column_info in self._columns_info.values():
                    column_info.set_timeseries_column_type(TimeSeriesFeatureType.NA)
