# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Internal class to pre-process data for evaluator and validation."""
import logging
from datetime import datetime
from typing import Optional

import numpy as np
import pandas as pd
import scipy.sparse as sp
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder
from sklearn.utils.validation import check_X_y

from azureml.contrib.featureengineering.common.logging import _LoggerFactory, function_log_activity, log_msg
from azureml.contrib.featureengineering.evaluator import constants
from azureml.contrib.featureengineering.evaluator.feature_selection import feature_selection_utilities
from azureml.contrib.featureengineering.featurizer import Featurizer, FeaturizerConfig


class DataPreprocessor:
    """DataPreprocessor that pre-processes input data."""

    def __init__(self, task=constants.Tasks.REGRESSION, preprocess=True, client_id="unknown",
                 logger: Optional[logging.Logger] = None):
        """
        Initialize data preprocessor with params defined.

        :param task: 'classification' or 'regression' depending on what kind of ML problem to solve.
        :type task: str or constants.Tasks
        :param preprocess: whether to apply built-in featurization or not. True means apply built-in featurization to
        the input data before feature scoring. False means do not apply built-in featurization. Will report error if
        input data is not numeric when preprocess=False.
        :type preprocess: bool
        :param client_id: client id of the caller.
        :type client_id: str
        :param logger: External logger handler.
        :type logger: logging.Logger
        """
        self._task_type = task
        self._preprocess = preprocess
        self._logger = _LoggerFactory.get_logger(__name__, client_id=client_id)
        if logger is not None:
            _LoggerFactory.add_handler(self._logger, logger)
        self._client_id = client_id

        self.is_sparse = False

    @function_log_activity
    def check_input_format_extract_data(self, X, y=None):
        """
        Check input format.

        Check X type is in [numpy.ndarray, pandas.DataFrame, pandas.SparseDataFrame, scipy.sparse.csr_matrix].
        Extract X as numpy.ndarray, X column names or create names if not available. If y is not None, extract y
        as numpy.ndarray, y column name or create name if not available. Check X and y for
        consistent length, enforces X to be 2D and y 1D.

        :param X: The input data.
        :type X: numpy.ndarray, pandas.DataFrame, pandas.SparseDataFrame or scipy.sparse.csr_matrix
        :param y: The target values (class labels in classification, real numbers in regression).
        :type y: numpy.ndarray, pandas.Series or pandas.DataFrame
        :return: List with returns as the following:
        X_orig: original input X.
        X_raw: The converted and validated X, type is numpy.ndarray.
        X_raw_column_names: The extracted X column names, type is numpy.ndarray.
        If y is not None:
        y_raw: The converted and validated y, type is numpy.ndarray.
        target_name: The target column name, type is str.
        :rtype: list
        :raises: ValueError for sparse matrix with non-numeric values, ValueError for X not in [numpy.ndarray,
        pd.DataFrame, pandas.SparseDataFrame, scipy.sparse.csr_matrix], ValueError for y not in [numpy.ndarray,
        pd.Series, pd.DataFrame, scipy.sparse.csr_matrix]
        """
        y_raw = None
        target_name = None

        # do not accept sparse matrix with non-numeric values
        if isinstance(X, pd.SparseDataFrame) or isinstance(X, sp.csr_matrix):
            self.is_sparse = True
            X_arr = X
            if isinstance(X, pd.SparseDataFrame):
                # pandas sparse dataFrame to sparse matrix, without generating a dense matrix in memory
                X_arr = sp.csr_matrix(X.to_coo())
            if X_arr.dtype not in constants.PANDAS_NUMERIC_TYPES:
                raise ValueError('X dtype is {0}, X must be one of the dtypes in {1}'.
                                 format(X_arr.dtype, constants.PANDAS_NUMERIC_TYPES))

        X_orig, X_raw, X_raw_column_names = feature_selection_utilities.extract_X(X)

        if y is not None:
            y_raw, target_name = feature_selection_utilities.extract_y(y)
            convert_y_to_numeric = self._task_type is constants.Tasks.REGRESSION
            X_raw, y_raw = check_X_y(X_raw, y_raw, accept_sparse=True, dtype=None, force_all_finite='allow-nan',
                                     y_numeric=convert_y_to_numeric)

        return [X_orig, X_raw, X_raw_column_names, y_raw, target_name]

    def convert_X_to_numeric(self, X):
        """
        Convert X to numeric types.

        :param X: The input data.
        :type X: numpy.ndarray or pandas.DataFrame
        :return: The converted X.
        :rtype: numpy.ndarray
        """
        start = datetime.now()
        featurizer = Featurizer(client_id=self._client_id,
                                featurizer_config=FeaturizerConfig(enable_dataframe_output=False))
        X_numeric_mat = featurizer.fit_transform(X)
        time_elapsed = datetime.now() - start
        print('Featurizer: Time elpased (hh:mm:ss.ms) {}'.format(time_elapsed))
        log_msg(self._logger, logging.DEBUG, 'Featurizer in convert_X_to_numeric: Time elpased (hh:mm:ss.ms) {}'
                .format(time_elapsed))

        is_sparse = not isinstance(X_numeric_mat, np.ndarray)
        return X_numeric_mat, featurizer, is_sparse

    def convert_X_to_numeric_sparse(self, X):
        """
        Convert X to numeric types.

        :param X: The input data.
        :type X: scipy.sparse.csr_matrix
        :return: The converted X.
        :rtype: scipy.sparse.csr_matrix
        """
        if isinstance(X, sp.csr_matrix):
            X_numeric = sp.csr_matrix(X, copy=True)
            if np.isnan(X.data).any():
                log_msg(self._logger, logging.WARNING, 'Input contains nan, convert to zero')
                X_numeric.data = np.nan_to_num(X.data)
        else:
            raise ValueError('X cannot be {0}'.format(type(X)))
        return X_numeric

    def convert_y_to_numeric(self, y):
        """
        Convert y to numeric type.

        :param y: The target values.
        :type y: numpy.ndarray
        :return: The converted y.
        :rtype: numpy.ndarray
        """
        y_numeric = y
        # np.isnan cannot be called on strings
        num_missing_val = sum([feature_selection_utilities.isnan(x) for x in y_numeric])
        if num_missing_val > 0:
            if self._preprocess:
                y_numeric = SimpleImputer(missing_values=np.nan, strategy='most_frequent').fit_transform(y_numeric)
            else:
                raise ValueError('Found {0} % values in label column '
                                 'are missing.'.format(num_missing_val / y.shape[0]))
        if y_numeric.dtype not in constants.PANDAS_NUMERIC_TYPES:
            if self._preprocess:
                y_numeric = LabelEncoder().fit_transform(y_numeric)
            else:
                raise ValueError(
                    'Label column is not numeric! Please convert it to numeric or set preprocess as true to continue.')
        return y_numeric

    def validate_no_nan(self, df):
        """
        Validate input only has numeric types and there is no nan.

        :param df: The input data.
        :type df: pandas.DataFrame
        :return: The validated data.
        :rtype: pandas.DataFrame
        """
        non_numeric_cols = df.select_dtypes(exclude=['number']).columns.tolist()
        nan_cols = df.columns[df.isnull().sum() > 0].tolist()
        msg = ""
        if len(non_numeric_cols) != 0:
            msg += '{0} columns are not numeric type! Please transform them or set preprocess as true to continue.'. \
                format(non_numeric_cols)
        if len(nan_cols) != 0:
            if msg:
                msg += "\n\n"
            msg += '{0} columns contain missing value! Please fill the nan or set preprocess as true to continue.'. \
                format(nan_cols)
        if msg:
            log_msg(self._logger, logging.DEBUG, msg)
            raise ValueError(msg)
        return df
