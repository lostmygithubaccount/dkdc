# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Utilities used during feature selection."""
import json
from collections import OrderedDict

import numpy as np
import pandas as pd
import scipy.sparse as sp
from sklearn.linear_model import Lasso
from sklearn.preprocessing import MinMaxScaler, StandardScaler, MaxAbsScaler
from sklearn.svm import LinearSVC

from azureml.contrib.featureengineering.common import lightgbm
from azureml.contrib.featureengineering.evaluator import constants
from azureml.contrib.featureengineering.evaluator.feature_selection import _iterate_columns, mutual_info_pair


def to_X_y_df(X, y, X_column_names, target):
    """
    Concatenate X, y to create a pandas.DataFrame.

    :param X: The input data.
    :type X: numpy.ndarray
    :param y: The target values.
    :type y: numpy.ndarray
    :param X_column_names: The X column names.
    :type X_column_names: numpy.ndarray
    :param target: label column name.
    :type target: str
    :return: A pandas.DataFrame with X, y concatenated together.
    :rtype: pandas.DataFrame
    """
    X_y = np.concatenate([X, y[:, None]], axis=1)
    X_y_column_names = np.append(X_column_names, target)
    return pd.DataFrame(X_y, columns=X_y_column_names)


def to_X_y_sparse(X, y, X_column_names, target):
    """
    Concatenate sparse X and y to create a car_matrix.

    :param X: The input data.
    :type X: scipy.sparse.csr_matrix
    :param y: The target values.
    :type y: numpy.ndarray
    :param X_column_names: The X column names.
    :type X_column_names: numpy.ndarray.
    :param target: label column name.
    :type target: str
    :return: A sparse matrix with X, y concatenated together.
    :rtype: scipy.sparse.csr_matrix
    """
    X_y = sp.hstack((X, y[:, None]), format('csr'))
    X_y_column_names = np.append(X_column_names, target)
    return X_y, X_y_column_names


def extract_X(X):
    """
    Extract X as numpy.ndarray, X column names or create names if not available.

    :param X: The input data.
    :type X: numpy.ndarray, pandas.DataFrame, pandas.SparseDataFrame or scipy.sparse.csr_matrix
    :return: Tuple of the following:
    X_orig: original input X.
    X_raw: The converted and validated X, type is numpy.ndarray.
    X_raw_column_names: The extracted X column names, type is numpy.ndarray.
    :rtype: tuple
    :raises: ValueError for X not in [numpy.ndarray, pd.DataFrame, pandas.SparseDataFrame, scipy.sparse.csr_matrix]
    """
    X_orig = X
    if isinstance(X, pd.SparseDataFrame):
        X_raw = sp.csr_matrix(X.to_coo())
        X_raw_column_names = X.columns.values
    elif isinstance(X, pd.DataFrame):
        X_raw = X.values
        X_raw_column_names = X.columns.values
    elif isinstance(X, np.ndarray) or isinstance(X, sp.csr_matrix):
        X_raw = X
        X_raw_column_names = np.arange(X.shape[1]).astype(str)
    else:
        raise ValueError('X cannot be {0}'.format(type(X)))
    return X_orig, X_raw, X_raw_column_names


def extract_y(y):
    """
    Extract y as numpy.ndarray, y column name or create name if not available.

    :param y: The target values (class labels in classification, real numbers in regression).
    :type y: numpy.ndarray
    :return: Tuple of the following:
    y_raw: The converted and validated y.
    target_name: The target column name.
    :rtype: tuple(numpy.ndarray, str)
    :raises: ValueError for y not in [numpy.ndarray, pd.Series, pd.DataFrame, scipy.sparse.csr_matrix]
    """
    if isinstance(y, pd.DataFrame):
        y_raw = y.values.ravel()
        target_name = y.columns[0]
    elif isinstance(y, pd.Series):
        y_raw = y.values.ravel()
        target_name = y.name
    elif isinstance(y, np.ndarray):
        y_raw = y.ravel()
        target_name = constants.DEFAULT_LABEL_COLUMN_NAME
    elif isinstance(y, sp.csr_matrix):
        y_raw = y.toarray().ravel()
        target_name = constants.DEFAULT_LABEL_COLUMN_NAME
    else:
        raise ValueError('y cannot be {0}'.format(type(y)))
    return y_raw, target_name


def isnan(value):
    """
    Check if the value is nan no matter what data type it is.

    :param value: The input data.
    :type value: numpy data types
    :return: whether it is nan.
    :rtype: bool
    """
    try:
        import math
        return math.isnan(float(value))
    except:
        return False


def validate_no_nan_sparse(X, y):
    """
    Validate there is no nan in sparse input.

    :param X: The input data.
    :type X: scipy.sparse.csr_matrix
    :param y: The target values.
    :type y: numpy.ndarray
    :return: The validated X and y.
    :rtype: tuple(numpy.ndarray, scipy.sparse.csr_matrix)
    """
    if np.isnan(X.data).any():
        raise ValueError('X contains nan! Please fill the nan or set preprocess as true to continue.')
    if np.isnan(y.data).any():
        raise ValueError('y contains nan! Please fill the nan or set preprocess as true to continue.')
    return X, y


def get_eng_feat_dict(featurizer):
    """
    Get raw feature name to engineered feature indices mapping.

    :param featurizer: A Featurizer Object already fitted with some data set
    :type featurizer: Featurizer()
    :return: engineered feature names, raw feature name to engineered feature indices mapping.
    :rtype: tuple(numpy.ndarray, OrderedDict)
    """
    engineered_feature_names = featurizer.get_engineered_feature_names()
    engineered_features_json = [json.loads(s) for s in
                                featurizer.get_json_strs_for_engineered_feature_names(engineered_feature_names)]

    raw_to_engineered = OrderedDict()
    for eng_feat_index, eng_feat_graph in zip(range(len(engineered_feature_names)), engineered_features_json):
        # only look at first level of transformations after raw
        t1 = eng_feat_graph['Transformations']['Transformer1']
        raw_feature_name = t1["Input"][0]
        if raw_feature_name not in raw_to_engineered:
            raw_to_engineered[raw_feature_name] = []

        raw_to_engineered[raw_feature_name].append(eng_feat_index)

    return np.array(engineered_feature_names), raw_to_engineered


def calc_and_return_null_cols_to_drop(X, y, X_column_names, target, threshold):
    """
    Calculate missing value ratio and list of column indices to drop.

    :param X: The input data.
    :type X: numpy.ndarray or scipy.sparse.csr_matrix
    :param y: The target values.
    :type y: numpy.ndarray
    :param X_column_names: The X column names.
    :type X_column_names: numpy.ndarray
    :param target: label column name.
    :type target: str
    :param threshold: if number of missing value exceeds the threshold, drop the column.
    :type threshold: float or None
    :return: missing value ratio per feature, column indices to drop.
    :rtype: tuple(pandas.Series, list of ints)
    """
    if isinstance(X, sp.csr_matrix):
        X_y, X_y_column_names = to_X_y_sparse(X, y, X_column_names, target)
        count_row = X_y.shape[0]
        ratios = []
        cols_to_drop_indices = []
        if isinstance(X_y, sp.csr_matrix):
            X_y = X_y.asformat('csc')
        # Each col must fit in the memory
        for i, col in zip(range(X_y.shape[1]), _iterate_columns(X_y)):
            ratio = np.isnan(col).sum() / count_row if count_row != 0 else np.isnan(col).sum()
            ratios.append(ratio)
            if ratio > threshold:
                cols_to_drop_indices.append(i)
        missing_val_ratio = pd.Series(ratios, index=X_y_column_names)
    else:
        df = to_X_y_df(X, y, X_column_names, target)
        count_row = len(df.index)
        missing_val_ratio = df.isnull().sum() / count_row if count_row != 0 else df.isnull().sum()
        cols_to_drop = missing_val_ratio.loc[missing_val_ratio > threshold].index.tolist()
        cols_to_drop_indices = [df.columns.get_loc(c) for c in cols_to_drop if c in df]
    return missing_val_ratio, cols_to_drop_indices


def get_X_based_on_mask_and_input_dtype(X_input, X_out, X_out_column_names, mask, is_eng):
    """
    Get selected X and its column names based on input type.

    :param X_input: original input.
    :type X_input: numpy.ndarray, pandas.DataFrame, pandas.SparseDataFrame or scipy.sparse.csr_matrix
    :param X_out: output X.
    :type X_out: numpy.ndarray, pandas.DataFrame, pandas.SparseDataFrame or scipy.sparse.csr_matrix
    :param X_out_column_names: columns names for output X.
    :type X_out_column_names: numpy.ndarray
    :param mask: mask used to filter output X.
    :type mask: numpy.ndarray
    :param is_eng: whether input is eng X.
    :type is_eng: bool
    :return: selected X and its column names.
    X: selected X, type is consistent with input X, i.e. numpy.ndarray, pandas.DataFrame, pandas.SparseDataFrame or
    scipy.sparse.csr_matrix.
    X_column_names: column names for selected X, type is numpy.ndarray.
    :rtype: tuple
    """
    if mask.size != 0:
        X_column_names = X_out_column_names[mask]
    else:
        X_column_names = np.empty(0)

    if isinstance(X_input, pd.SparseDataFrame):
        if mask.size != 0:
            if not is_eng:
                X = X_input.iloc[:, mask]
            else:
                X = pd.SparseDataFrame(X_out[:, mask], columns=X_column_names)
        else:
            X = pd.SparseDataFrame()
    elif isinstance(X_input, pd.DataFrame):
        if mask.size != 0:
            if isinstance(X_out, sp.csr_matrix):
                X = X_out[:, mask]
            else:
                if not is_eng:
                    X = X_input.iloc[:, mask]
                else:
                    X = pd.DataFrame(X_out[:, mask], columns=X_column_names)
        else:
            X = pd.DataFrame()
    elif isinstance(X_input, sp.csr_matrix) or isinstance(X_input, np.ndarray):
        if mask.size != 0:
            X = X_out[:, mask]
        else:
            X = np.empty(0)
    else:
        raise ValueError('input X cannot be {0}'.format(type(X_input)))
    return X, X_column_names


def get_top_feature_percentile(df, percentile):
    """
    Get top features that cover certain percent of importance score.

    :param df: The input data.
    :type df: pandas.DataFrame
    :param percentile: The percent of importance score the top features cover.
    :type percentile: float
    :return: The selected features indices, in the order that would sort the raw feature importance ranking.
    :rtype: list
    """
    threshold = df[constants.FEATURE_IMPORTANCE].sum() * percentile
    ranking_order = df[constants.FEATURE_IMPORTANCE].values.argsort().tolist()
    ranking_order.reverse()
    df = df.sort_values(by=constants.FEATURE_IMPORTANCE, ascending=False)

    n = 0
    for index, row in df.iterrows():
        threshold -= row[constants.FEATURE_IMPORTANCE]
        n += 1
        if threshold <= 0:
            break

    return ranking_order[:n]


def get_mutual_info_pair(X, y, X_column_names, bins):
    """
    Get mutual information between each feature and target.

    :param X: The input data.
    :type X: numpy.ndarray or scipy.sparse.csr_matrix
    :param y: The target values.
    :type y: numpy.ndarray
    :param X_column_names: The X column names.
    :type X_column_names: numpy.ndarray
    :param bins: Number of bins to bucket X and y for joint distribution.
    :type bins: int
    :return: mutual information between each feature and target.
    :rtype: pandas.Series
    """
    if isinstance(X, sp.csr_matrix):
        X = X.asformat('csc')
    mi_score = mutual_info_pair(X, y, bins)
    mutual_info_matrix = pd.Series(mi_score, index=X_column_names)
    return mutual_info_matrix


def get_pearson_corr(X, y, X_column_names, target):
    """
    Get pearson correlation between each feature and target.

    :param X: The input data.
    :type X: numpy.ndarray or scipy.sparse.csr_matrix
    :param y: The target values.
    :type y: numpy.ndarray
    :param X_column_names: The X column names.
    :type X_column_names: numpy.ndarray
    :param target: label column name.
    :type target: str
    :return: Pearson correlation per feature.
    :rtype: pandas.Series
    """
    if isinstance(X, sp.csr_matrix):
        pearson_corr = pearson_corr_sparse(X, y, X_column_names, target)
    else:
        df = to_X_y_df(X, y, X_column_names, target)
        pearson_corr = df.corr()[target]
    return pearson_corr


def pearson_corr_sparse(X, y, X_column_names, target):
    """
    Get pearson correlation between each feature and target for sparse input.

    :param X: The input data.
    :type X: scipy.sparse.csr_matrix
    :param y: The target values.
    :type y: numpy.ndarray
    :param X_column_names: The X column names.
    :type X_column_names: numpy.ndarray
    :param target: label column name.
    :type target: str
    :return: Pearson correlation per feature.
    :rtype: pandas.Series
    """
    if not isinstance(X, sp.csr_matrix):
        raise ValueError('X cannot be {0}'.format(type(X)))

    X = X.asformat('csc')
    coeffs = []
    for col in _iterate_columns(X):
        coeff = np.corrcoef([col, y])[1, 0]
        coeffs.append(coeff)
    coeffs.append(1.0)
    X_y, X_y_column_names = to_X_y_sparse(X, y, X_column_names, target)

    return pd.Series(coeffs, index=X_y_column_names)


def get_feat_importance_from_lightgbm(X, y, X_column_names, task_type):
    """
    Get lightgbm feature importance per feature.

    :param X: The input data.
    :type X: numpy.ndarray or scipy.sparse.csr_matrix
    :param y: The target values.
    :type y: numpy.ndarray
    :param X_column_names: The X column names.
    :type X_column_names: numpy.ndarray
    :param task_type: 'classification' or 'regression' depending on what kind of ML problem to solve.
    :type task_type: str or constants.Tasks
    :return: lightgbm feature importance per feature.
    :rtype: pandas.Series
    """
    model = lightgbm.train_lightgbm_model(task_type, X, y, X_column_names=X_column_names)
    feat_importance = lightgbm.lightgbm_feature_importance(model, X_column_names)
    return model, feat_importance


def get_feat_importance_from_lasso(X, y, X_column_names, task_type):
    """
    Train lasso model and get feature importance per feature.

    :param X: The input data.
    :type X: numpy.ndarray or scipy.sparse.csr_matrix
    :param y: The target values.
    :type y: numpy.ndarray
    :param X_column_names: The X column names.
    :type X_column_names: numpy.ndarray
    :param task_type: 'classification' or 'regression' depending on what kind of ML problem to solve.
    :type task_type: str or constants.Tasks
    :return: lasso feature importance per feature.
    :rtype: pandas.Series
    """
    if task_type == constants.Tasks.REGRESSION:
        model = Lasso(alpha=0.01, random_state=1).fit(X, y)
    elif task_type == constants.Tasks.CLASSIFICATION:
        model = LinearSVC(C=0.5, penalty="l1", dual=False, random_state=1).fit(X, y)
    else:
        raise ValueError('Incorrect task_type {0}, not able to do '
                         'model feature importance analysis'.format(task_type))
    feat_importance = get_lasso_feat_importance(model, X_column_names)
    return feat_importance


def get_lasso_feat_importance(model, X_column_names):
    """
    Get lasso feature importance per feature.

    :param model: model used to train.
    :type model: sklearn.linear_model.Lasso
    :param X_column_names: X column names.
    :type X_column_names: numpy.ndarray
    :return: lasso feature importance per feature.
    :rtype: pandas.Series
    """
    if len(model.coef_.shape) > 1 and model.coef_.shape[0] > 1:
        importance = np.mean(abs(model.coef_), axis=0)
    else:
        importance = abs(model.coef_.ravel())
    return pd.Series(importance, index=X_column_names)


def get_featurized_raw_feat_index_to_eng_feat_indices_list(featurized_raw_feat_name_to_eng_feat_index):
    """
    Get featurized raw feature index to engineered feature indices as a list.

    :param featurized_raw_feat_name_to_eng_feat_index: Raw feature name to engineered feature index mapping.
    :type featurized_raw_feat_name_to_eng_feat_index: dict(raw name --> engineered index)
    :return: Featurized raw feature names, featurized raw feature index to engineered feature indices.
    :rtype: tuple(list of strs, list of list)
    """
    feat_map_as_list = []
    for name in featurized_raw_feat_name_to_eng_feat_index:
        feat_map_as_list.append(featurized_raw_feat_name_to_eng_feat_index.get(name, []))

    return list(featurized_raw_feat_name_to_eng_feat_index.keys()), feat_map_as_list


def normalize_cols(X):
    """
    Scale features.

    For non sparse, remove the mean and scaling to unit variance. For sparse, scale by its maximum absolute value.

    :param X: The input data.
    :type X: numpy.ndarray or scipy.sparse.csr_matrix
    :return: Scaled X.
    :rtype: numpy.ndarray or scipy.sparse.csr_matrix
    """
    return MaxAbsScaler().fit_transform(X) if isinstance(X, sp.csr_matrix) \
        else StandardScaler().fit_transform(X)


def min_max_normalize(df, column_names_to_normalize=[], feature_range=(0, 1)):
    """
    Normalize features by scaling each feature to a given range. This will convert min to the min of desired range.

    :param df: The input data.
    :type df: pandas.DataFrame
    :param column_names_to_normalize: column names to apply normalization.
    :type column_names_to_normalize: list of strs
    :param feature_range: Desired range of normalized data.
    :type feature_range: tuple(int, int)
    :return: The normalized data.
    :rtype: pandas.DataFrame
    """
    scaler = MinMaxScaler(feature_range=feature_range)
    X = df.values
    if len(column_names_to_normalize) > 0:
        X = df[column_names_to_normalize].values
    X_scaled = scaler.fit_transform(X.reshape(X.shape[0], 1 if len(X.shape) == 1 else X.shape[1]))
    if len(column_names_to_normalize) > 0:
        df[column_names_to_normalize] = pd.DataFrame(X_scaled, columns=column_names_to_normalize, index=df.index)
    else:
        df = pd.DataFrame(X_scaled, columns=df.columns, index=df.index)
    return df


def zero_max_normalize(df, column_names_to_normalize=[], feature_range=(0, 1)):
    """
    Normalize features by scaling each feature to a given range.

    This preserve the ratio between original min and max.

    :param df: The input data.
    :type df: pandas.DataFrame
    :param column_names_to_normalize: column names to apply normalization.
    :type column_names_to_normalize: list of strs
    :param feature_range: Desired range of normalized data.
    :type feature_range: tuple(int, int)
    :return: The normalized data.
    :rtype: pandas.DataFrame
    """
    X = df.values
    if len(column_names_to_normalize) > 0:
        X = df[column_names_to_normalize].values
    X_scaled = X / (np.nanmax(X, axis=0)) * (feature_range[1] - feature_range[0]) + feature_range[0]
    if len(column_names_to_normalize) > 0:
        df[column_names_to_normalize] = pd.DataFrame(X_scaled, columns=column_names_to_normalize, index=df.index)
    else:
        df = pd.DataFrame(X_scaled, columns=df.columns, index=df.index)
    return df
