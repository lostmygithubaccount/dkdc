# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""ColumnStrategy class contains columns and corresponding transformers."""

from typing import List, Dict, Any

from azureml.contrib.featureengineering.featurizer.transformer_ser_deser import transformer_to_dict,\
    transformer_from_dict
from sklearn.base import TransformerMixin


class ColumnStrategy:
    """Container for ColumnStrategy."""

    def __init__(self, column_names: List[str] = None, feature_type_name: str = "",
                 transformers: List[List[TransformerMixin]] = None):
        """
        Init column strategy object.

        :param column_names: the list of column names.
        :param feature_type_name: the feature type name.
        :param transformers: list of list of transformers.
        """
        self.column_names = column_names  # type: List[str]
        self.feature_type_name = feature_type_name
        self.transformers = transformers

    def to_dict(self):
        """
        Create dict from TypeStrategy for serialization usage.

        :return: a dictionary
        """
        dct = dict()
        dct['feature_type_name'] = self.feature_type_name
        dct['column_names'] = self.column_names
        transformers_dict_list = list()
        if self.transformers is not None:
            for column_transformer in self.transformers:
                transformers_dict_list.append(
                    list(map(lambda x: transformer_to_dict(x), column_transformer)))
            dct['transformers'] = transformers_dict_list
        return dct

    def from_dict(self, dct: Dict[str, Any]):
        """
        Create column strategy object from dictionary.

        :param dct: a dictionary.
        :return: a column strategy.
        """
        if 'transformers' in dct:
            transformers_dict_list = list()
            for trans_dict in dct['transformers']:
                transformers_dict_list.append(
                    list(map(lambda x: transformer_from_dict(x), trans_dict)))
            self.transformers = transformers_dict_list
        self.column_names = dct['column_names']
        self.feature_type_name = dct['feature_type_name']
        return self
