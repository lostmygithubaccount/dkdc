# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Utility module for logging."""
import functools
import logging
import logging.handlers as handlers
import os
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime

COMPONENT_NAME = "azureml.contrib.featureengineering"
INSTRUMENTATION_KEY = "059f306c-281d-4021-b173-21b5980d43db"
version = None
session_id = str(uuid.uuid4())
global_client_id = None

try:
    from azureml._base_sdk_common import _ClientSessionId

    session_id = _ClientSessionId
except ImportError:
    pass

try:
    from azureml.telemetry import get_telemetry_log_handler
    from azureml.telemetry.activity import log_activity as _log_activity, ActivityType
    from azureml.telemetry.logging_handler import AppInsightsLoggingHandler

    telemetry_imported = True
    DEFAULT_ACTIVITY_TYPE = ActivityType.INTERNALCALL
except ImportError:
    telemetry_imported = False
    DEFAULT_ACTIVITY_TYPE = "InternalCall"

file_handlers = {}  # type: Dict[str, logging.Handler]
file_loggers = {}  # type: Dict[Tuple[str, int], logging.Logger]
log_cache_lock = threading.Lock()


class _LoggerFactory:

    @staticmethod
    def get_logger(namespace, client_id="unknown", verbosity=logging.DEBUG, filename=None, extra_handlers=None):
        """
        Create logger with give params.

        :param namespace: The namespace for the logger.
        :type namespace: str
        :param client_id: client id of the caller.
        :type client_id: str
        :param verbosity: logging verbosity.
        :type verbosity: int
        :param filename: log file name.
        :type filename: str
        :param extra_handlers: any extra handlers to attach to the logger.
        :type extra_handlers: list of logging.Handler
        :return: logger with namespace and log file name if provided.
        :rtype: logging.Logger
        """
        local_log_path_dir = os.path.join('azureml-logs', COMPONENT_NAME)
        os.makedirs(local_log_path_dir, exist_ok=True)
        if filename is None:
            filename = 'sdk.log'
        filename = os.path.join(local_log_path_dir, filename)

        with log_cache_lock:
            if (filename, verbosity) in file_loggers:
                logger = file_loggers[(filename, verbosity)]
            else:
                if filename not in file_handlers:
                    handler = handlers.RotatingFileHandler(filename, maxBytes=1024 * 1024, backupCount=9)
                    log_format = '%(asctime)s - %(levelname)s - %(lineno)d : %(message)s'
                    formatter = logging.Formatter(log_format)
                    handler.setFormatter(formatter)
                    file_handlers[filename] = handler

                logger_name = '%s_%s' % (filename, str(verbosity))
                logger = logging.getLogger(namespace).getChild(logger_name)
                logger.addHandler(file_handlers[filename])
                logger.setLevel(verbosity)

            if extra_handlers is not None:
                for h in extra_handlers:
                    if not _LoggerFactory._found_handler_obj(logger, h):
                        logger.addHandler(h)

            logger.propagate = False
            file_loggers[(filename, verbosity)] = logger

            if telemetry_imported:
                try:
                    global version
                    if version is None:
                        import azureml.contrib.featureengineering as fe
                        version = fe.__version__
                except:
                    version = 'DEV'

                global global_client_id
                if global_client_id is None:
                    global_client_id = client_id

                if not _LoggerFactory._found_handler_type(logger, AppInsightsLoggingHandler):
                    logger.addHandler(get_telemetry_log_handler(instrumentation_key=INSTRUMENTATION_KEY,
                                                                component_name=COMPONENT_NAME))

            return logger

    @staticmethod
    def log_activity(logger, activity_name, activity_type=DEFAULT_ACTIVITY_TYPE, custom_dimensions=None):
        """
        Log the activity status with duration and custom dimensions.

        :param logger: logger passed in.
        :type logger: logging.Logger
        :param activity_name: activity name.
        :type activity_name: str
        :param activity_type: activity type.
        :type activity_type: str
        :param custom_dimensions: additional info to log.
        :type custom_dimensions: dict
        :return:
        :rtype:
        """
        custom_dimensions = custom_dimensions or {}
        custom_dimensions.update({'source': COMPONENT_NAME, 'version': version, 'sessionId': session_id,
                                  'clientId': global_client_id})
        if telemetry_imported:
            return _log_activity(logger, activity_name, activity_type, custom_dimensions)
        else:
            return _log_local_only(logger, activity_name, activity_type, custom_dimensions)

    @staticmethod
    def _found_handler_type(logger: logging.Logger, handle_type: logging.Handler) -> bool:
        """
        Check if the given handler type exists in logger.

        :param logger: Logger
        :type logger: logging.Logger
        :param handle_type: handler type
        :type handle_type: logging.Handler
        :return: True if found the handler type else False
        :rtype: bool
        """
        for log_handler in logger.handlers:
            if isinstance(log_handler, handle_type):
                return True

        return False

    @staticmethod
    def _found_handler_obj(logger: logging.Logger, handler: logging.Handler) -> bool:
        """
        Check if the given handler instance exists in logger.

        :param logger: Logger
        :type logger: logging.Logger
        :param handler: handler instance
        :type handler: logging.Handler
        :return: True if found else False
        :rtype: bool
        """
        for h in logger.handlers:
            # check if it is duplicate handler
            # check filename for file, so that we only log message to each file once
            if isinstance(h, logging.FileHandler) and isinstance(handler, logging.FileHandler) and \
                    h.baseFilename == handler.baseFilename:
                return True
            # check instrumentation_key for appinsightshandler
            if isinstance(h, AppInsightsLoggingHandler) and isinstance(handler, AppInsightsLoggingHandler) and \
                    h._default_client._context.instrumentation_key == \
                    handler._default_client._context.instrumentation_key:
                return True
        return False

    @staticmethod
    def add_handler(logger: logging.Logger, extra_logger: logging.Logger) -> logging.Logger:
        """
        Add handlers from extra_logger to logger.

        :param logger: Logger
        :type logger: logging.Logger
        :param extra_logger: extra logger
        :type extra_logger: logging.Logger
        :return: logger with new handlers from extra logger
        :rtype: logging.Logger
        """
        for log_handler in extra_logger.handlers:
            if not _LoggerFactory._found_handler_obj(logger, log_handler):
                logger.addHandler(log_handler)
        return logger


def cleanup_all_loggers() -> None:
    """
    Clean up all loggers without using logging.shutdown().

    :return:
    """
    with log_cache_lock:
        global file_loggers
        global file_handlers
        for k in file_loggers:
            logger = file_loggers[k]
            logger.handlers = []
        for k in file_handlers:
            handler = file_handlers[k]
            handler.close()
            del handler
        file_loggers = {}
        file_handlers = {}


@contextmanager
def _log_local_only(logger, activity_name, activity_type, custom_dimensions):
    """
    Log activity locally.

    :param logger: logger passed in.
    :type logger: logging.Logger
    :param activity_name: activity name.
    :type activity_name: str
    :param activity_type: activity type.
    :type activity_type: str
    :param custom_dimensions: additional info to log.
    :type custom_dimensions: dict
    :return:
    :rtype:
    """
    activity_info = {
        'activity_id': str(uuid.uuid4()),
        'activity_name': activity_name,
        'activity_type': activity_type}
    custom_dimensions = custom_dimensions or {}
    activity_info.update(custom_dimensions)

    start_time = datetime.utcnow()
    completion_status = "Success"

    message = "ActivityStarted, {}".format(activity_name)
    logger.info(message)
    exception = None

    try:
        yield logger
    except Exception as e:
        exception = e
        completion_status = "Failure"
        raise
    finally:
        end_time = datetime.utcnow()
        duration_ms = round((end_time - start_time).total_seconds() * 1000, 2)

        custom_dimensions["completionStatus"] = completion_status
        custom_dimensions["durationMs"] = duration_ms
        message = "{} | ActivityCompleted: Activity={}, HowEnded={}, Duration={} [ms], Info = {}".format(
            start_time, activity_name, completion_status, duration_ms, repr(activity_info))
        if exception:
            message += ", Exception={}; {}".format(type(exception).__name__, str(exception))
            logger.error(message)
        else:
            logger.info(message)


def log_msg(logger, level, msg):
    """
    Log message with given logging level.

    :param logger: logger passed in.
    :type logger: logging.Logger
    :param level: logging level.
    :type level: int
    :param msg: message to log.
    :type msg: str
    :return:
    :rtype:
    """
    if logger is not None:
        if level == logging.CRITICAL:
            logger.critical(msg)
        if level == logging.ERROR:
            logger.error(msg)
        elif level == logging.DEBUG:
            logger.debug(msg)
        elif level == logging.WARNING:
            logger.warning(msg)
        else:
            logger.info(msg)


def function_log_activity(arg):
    """
    Log wrapper around function.

    :param arg: additional info to log or function
    :type arg: dict or function
    :return:
    :rtype:
    """
    if callable(arg):
        @functools.wraps(arg)
        def wrapper(self, *args, **kwargs):
            if hasattr(self, '_logger') and self._logger is not None:
                activity_name = '[Class:{}][Function:{}]'.format(self.__class__.__name__, arg.__name__)
                with _LoggerFactory.log_activity(self._logger, activity_name, DEFAULT_ACTIVITY_TYPE):
                    return arg(self, *args, **kwargs)
            else:
                return arg(self, *args, **kwargs)

        return wrapper

    else:
        def _function_log_activity(func):
            @functools.wraps(func)
            def wrapper(self, *args, **kwargs):
                if hasattr(self, '_logger') and self._logger is not None:
                    activity_name = '[Class:{}][Function:{}]'.format(self.__class__.__name__, func.__name__)
                    with _LoggerFactory.log_activity(self._logger, activity_name, DEFAULT_ACTIVITY_TYPE, arg):
                        return func(self, *args, **kwargs)
                else:
                    return func(self, *args, **kwargs)

            return wrapper

        return _function_log_activity
