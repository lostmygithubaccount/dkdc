# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Transforms the transformed raw feature names into engineered feature names."""
import json
from typing import List

from azureml.contrib.featureengineering.featurizer.transformer_ser_deser import transformer_to_dict

from azureml.contrib.featureengineering.core.types import TransformerType
import re


class FeatureDefinition:
    """Transforms the transformed raw feature names into engineered feature names."""

    def __init__(self):
        """Initialize all attributes."""
        self.alias_name_transformation_mapping = {}
        self._ufi_engineered_feature_names = []

    def generate_transformation_mapping(self, transformer_type_list: List[TransformerType]):
        """
        Create a mapping which stores transformation detail information.

        :param transformer_type_list: List of transformer type
        :type transformer_type_list: List[TransformerType]

        """
        for transformer_type in transformer_type_list:
            transformation_meta = self._generate_transformation_meta(transformer_type)
            self.alias_name_transformation_mapping[
                transformation_meta.alias_name] = transformation_meta

    @staticmethod
    def _generate_transformation_meta(transformer_type: TransformerType):
        """
        Create a TransformationMeta object which stores column and transformer detail configuration.

        :param transformer_type: transformer type
        :type transformer_type: TransformerType = Tuple[str, List[TransformerMixin], Dict[str, str]]
        :return: Transformation metadata object.
        :rtype: TransformationMeta

        """
        parent_feature_list = transformer_type[0] if isinstance(transformer_type[0], list) else [
            transformer_type[0]]
        alias_name = transformer_type[2].get("alias")
        transformer_class_name_list = []
        transformer_dict = dict()
        last_transformer_name = ""
        for i, transformer in enumerate(transformer_type[1]):
            transformer_name = FeatureNamesHelper.get_transformer_name(i)
            transformer_class_name = transformer.__class__.__name__
            transformer_class_name_list.append(
                TransformerNameHelper.get_transformer_name_abbr(transformer_class_name))
            transformer_detail = transformer_to_dict(transformer)
            transformer_dict[transformer_name] = \
                _Transformer(transformer_class_name, transformer_detail).__dict__
            last_transformer_name = transformer_class_name
        if len(transformer_class_name_list) >= 2:
            transformation_name = "-".join(transformer_class_name_list)
        elif len(transformer_class_name_list) == 1:
            transformation_name = transformer_class_name_list[0]
        else:
            raise ValueError("Unable to generate transformation name due to empty transformer list")
        return TransformationMeta(parent_feature_list=parent_feature_list, alias_name=alias_name,
                                  transformation_name=transformation_name,
                                  transformer_dict=transformer_dict,
                                  last_transformer_name=last_transformer_name,
                                  ufi_feature_list=[], engineered_feature_names=[])

    def get_transformation_meta_json(self, selected_columns=None):
        """
        Encode featurizer transformations metadata to JSON format.

        :param selected_columns: user provided columns to query subset of definition metadata
        :type selected_columns: List[str]
        :return: JSON format of transformations metadata.
        :rtype: str

        """
        if self.alias_name_transformation_mapping is None or len(
                self.alias_name_transformation_mapping) == 0:
            raise ValueError(
                "Cannot generate transformation metadata json, please recall after transform().")
        if selected_columns is None:
            featurizer_metadata = [x.__dict__ for x in
                                   self.alias_name_transformation_mapping.values()]
        else:
            selected_transformation_mapping = dict()
            selected_columns_set = set(selected_columns)
            for key, val in self.alias_name_transformation_mapping.items():
                for column_name in val.parent_feature_list:
                    if column_name in selected_columns_set:
                        selected_transformation_mapping[key] = val
                        break
            featurizer_metadata = [x.__dict__ for x in selected_transformation_mapping.values()]
        return json.dumps(featurizer_metadata)

    def get_user_friendly_engineered_feature_names(self):
        """
        Get engineered feature names.

        :return: List of engineered feature names.
        :rtype: List[str]

        """
        return self._ufi_engineered_feature_names

    def are_engineered_feature_names_available(self):
        """
        Check if engineered feature name availability.

        :return: 'True' if engineered feature names have already been created; 'False' otherwise.
        :rtype: bool
        """
        return len(self._ufi_engineered_feature_names) != 0

    @classmethod
    def _generate_engineered_feature_str(cls, transformation_meta, value_str):
        """
        Generate engineered feature name.

        :param transformation_meta: Transformation metadata object.
        :type transformation_meta: TransformationMeta
        :param value_str: Value str from DataframeMapper transformed_names.
        :type value_str: str
        :return: Transformation name.
        :rtype: str
        """
        if transformation_meta.last_transformer_name != \
                TransformerNameHelper.datetime_transformer_name:
            column_name_suffix = value_str
        else:
            column_name_suffix = DateTimeHelper.get_datetime_transformation_name(int(value_str))

        parent_columns_name = "_".join(transformation_meta.parent_feature_list)

        engineered_feature_str = "{}-{}_{}".format(transformation_meta.transformation_name,
                                                   transformation_meta.alias_name,
                                                   parent_columns_name)
        if column_name_suffix != '':
            engineered_feature_str += "_" + column_name_suffix
        return engineered_feature_str

    def parse_raw_feature_names(self, transformed_raw_feature_names, engineered_feature_names=None):
        """
        Parse transformed raw feature names, fill in transformation metadata.

        :param transformed_raw_feature_names: Transformed feature names.
        :type transformed_raw_feature_names: List[str]
        :param engineered_feature_names: Engineered feature names.
        :type engineered_feature_names: List[str]
        """
        regex_transformed_feature_name = \
            FeatureNamesHelper.get_regular_exp_for_parsing_raw_feature_names()
        for raw_feature_name in transformed_raw_feature_names:
            # Parse transformed feature name with the regex
            transformed_feature_match_obj = \
                re.match(regex_transformed_feature_name, raw_feature_name)

            if transformed_feature_match_obj:
                # If there is a match, then extract the values out of the match object
                raw_feature_alias = transformed_feature_match_obj.group(1)
                value_str = transformed_feature_match_obj.group(3)
            else:
                # If the transformed feature names doesn't match the regular expression,
                # then raise exception
                raise ValueError(
                    "Unrecognized transformed feature name passed")
            transformation_meta = self.alias_name_transformation_mapping.get(raw_feature_alias)
            if transformation_meta is None:
                raise ValueError(
                    "transformation metadata is missing for transformed feature name alias")
            engineered_feature_str = self._generate_engineered_feature_str(transformation_meta,
                                                                           value_str)
            transformation_meta.user_friendly_engineered_names.append(engineered_feature_str)
            self._ufi_engineered_feature_names.append(engineered_feature_str)

            if engineered_feature_names is not None and len(
                    self._ufi_engineered_feature_names) <= len(engineered_feature_names):
                index = len(self._ufi_engineered_feature_names) - 1
                transformation_meta.engineered_feature_names.append(engineered_feature_names[index])
            else:
                raise ValueError("engineered feature names are mismatch with user friendly names")


class TransformationMeta:
    """Class represents Transformation metadata information."""

    def __init__(self, parent_feature_list=None, ufi_feature_list=None,
                 transformation_name=None, alias_name=None, transformer_dict=None,
                 last_transformer_name=None, engineered_feature_names=None):
        """
        Initialize transformation metadata class.

        :param parent_feature_list: Features parents column names.
        :type parent_feature_list: List[str]
        :param ufi_feature_list: Features friendly names.
        :type ufi_feature_list: List[str]
        :param transformation_name: Name represents transformations.
        :type transformation_name: str
        :param alias_name: Transformation alias name.
        :type alias_name: str
        :param transformer_dict: A dictionary of transformers.
        :type transformer_dict: Dict[str, TransformerMixin]
        :param last_transformer_name: Name of the last transformer.
        :type last_transformer_name: bool
        :param engineered_feature_names: Features engineered feature names.
        :type engineered_feature_names: List[str]
        """
        self.transformation_name = transformation_name
        self.parent_feature_list = parent_feature_list
        self.engineered_feature_names = engineered_feature_names
        self.user_friendly_engineered_names = ufi_feature_list
        self.transformer_dict = transformer_dict
        self.alias_name = alias_name
        self.last_transformer_name = last_transformer_name


class _Transformer:
    """Class represents transformer detail information."""

    def __init__(self, transformer_class_name=None, transformer_detail=None):
        """
        Initialize _Transformer class.

        :param transformer_class_name: Class name of a transformer object.
        :type transformer_class_name: str
        :param transformer_detail: A serializable dict of a transformer.
        :type transformer_detail: Dict[str, Any]
        """
        self.transformer_class_name = transformer_class_name
        self.transformer_detail = transformer_detail


class DateTimeHelper:
    """Helper class for Datetime engineered feature transformations."""

    # List of all date time sub-feature names
    _datetime_sub_feature_names = ['Year',
                                   'Month',
                                   'Day',
                                   'DayOfWeek',
                                   'DayOfYear',
                                   'QuarterOfYear',
                                   'WeekOfMonth',
                                   'Hour',
                                   'Minute',
                                   'Second']

    @classmethod
    def get_datetime_transformation_name(cls, index):
        """
        Get the date time sub-feature given an index value.

        :param cls:
        :type cls:
        :param index: An index value which can reference the list elements
            of _datetime_sub_feature_names.
        :type index: int
        :return: string for the date time sub-feature.
        :rtype: str
        """
        if index < 0 or index >= len(cls._datetime_sub_feature_names):
            raise ValueError(
                "Unsupported index passed for datetime sub-feature")

        return cls._datetime_sub_feature_names[index]


class FeatureNamesHelper:
    """Helper class for feature names."""

    @classmethod
    def get_regular_exp_for_parsing_raw_feature_names(cls):
        """
        Get the regular expression required for parsing the transformed feature names.

        :return: regex as string
        :rtype: str
        """
        return r"(\d+)(_?)(.*)"

    @classmethod
    def get_transformer_name(cls, transformer_number):
        """
        Get transformer name which is added in the json representation of the transformations.

        :param cls:
        :type cls:
        :param transformer_number: Index number of transformer in TransformerType.
        :type transformer_number: int
        :return: transformer name.
        :rtype: str
        """
        if transformer_number is None:
            raise ValueError("No transformer number was provided")

        if not isinstance(transformer_number, int):
            raise ValueError("The transformer number is not integer")

        return "transformer" + str(transformer_number)


class TransformerNameHelper:
    """Helper class transformer class name and abbreviation."""

    _transformer_name_abbr_dict = {
        "CatImputer": "CatImputer",
        "HashOneHotVectorizerTransformer": "HashOneHotVectorizer",
        "LabelEncoderTransformer": "LabelEncoder",
        "CrossValidationTargetEncoder": "CrossValidationTarget",
        "OneHotEncoderTransformer": "OneHotEncoder",
        "DateTimeFeaturesTransformer": "DateTime",
        "ImputationMarker": "ImputationMarker",
        "LambdaTransformer": "Lambda",
        "Imputer": "Imputer",
        "MiniBatchKMeans": "MiniBatchKMeans",
        "MaxAbsScaler": "MaxAbsScaler",
        "BinTransformer": "Bin",
        "BagOfWordsTransformer": "BagOfWords",
        "CountVectorizer": "CountVectorizer",
        "ModelBasedTargetEncoder": "ModelBasedTarget",
        "StringCastTransformer": "StringCast",
        "StatsTransformer": "StatsTransformer",
        "NimbusMLTextTargetEncoder": "NimbusMLText",
        "TfidfVectorizer": "TfidfVectorizer",
        "WordEmbeddingTransformer": "WordEmbedding"
    }

    datetime_transformer_name = "DateTimeFeaturesTransformer"

    @classmethod
    def get_transformer_name_abbr(cls, key):
        """
        Get transformer abbreviation name, if name not found, return transformer name(key).

        :param cls:
        :type cls:
        :param key: transformer class name in string.
        :type key: str
        :return: abbreviation name of transformer
        :rtype: str
        """
        abbr = cls._transformer_name_abbr_dict.get(key)
        return abbr if abbr is not None else key
