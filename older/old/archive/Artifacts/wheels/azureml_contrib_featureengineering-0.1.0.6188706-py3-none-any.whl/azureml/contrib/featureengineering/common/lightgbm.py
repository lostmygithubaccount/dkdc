# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Utility functions for lightgbm model training."""
import lightgbm as lgbm
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from azureml.contrib.featureengineering.evaluator import constants


def train_lightgbm_model(task_type, X, y, X_train=None, y_train=None, X_test=None, y_test=None, X_column_names=None,
                         epoch=500):
    """
    Train a lightgbm model.

    :param task_type: 'classification' or 'regression' depending on what kind of ML problem to solve.
    :type task_type: str or constants.Tasks
    :param X: The input data.
    :type X: numpy.ndarray or scipy.sparse.csr_matrix
    :param y: The target values.
    :type y: numpy.ndarray
    :param X_train: The training data.
    :type X_train: numpy.ndarray, pandas.DataFrame or scipy.sparse.csr_matrix
    :param y_train: The target values for training.
    :type y_train: numpy.ndarray, pandas.Series
    :param X_test: The testing data.
    :type X_test: numpy.ndarray, pandas.DataFrame or scipy.sparse.csr_matrix
    :param y_test: The target values for testing.
    :type y_test: numpy.ndarray, pandas.Series
    :param X_column_names: X column names.
    :type X_column_names: numpy.ndarray
    :param epoch: Number of boosting iterations.
    :type epoch: int
    :return: The trained lightgbm model.
    :rtype: lightgbm.Booster
    """
    if X_train is None and y_train is None and X_test is None and y_test is None:
        X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=50, test_size=.2)

    if X_column_names is not None:
        X_column_indices = list(str(x) for x in range(X_column_names.shape[0]))
    else:
        X_column_indices = 'auto'
    lgb_train = lgbm.Dataset(X_train, y_train, feature_name=X_column_indices)
    lgb_valid = lgbm.Dataset(X_test, y_test, reference=lgb_train)

    if y is None:
        if isinstance(y_train, pd.Series) and isinstance(y_test, pd.Series):
            y = pd.concat([y_train, y_test], ignore_index=True)
            y = y.values.ravel()
        if isinstance(y_train, np.ndarray) and isinstance(y_test, np.ndarray):
            y = np.concatenate((y_train, y_test), axis=0)

    if task_type == constants.Tasks.REGRESSION:
        params = {
            'boosting_type': 'gbdt',
            'objective': 'regression',
            'metric': {'l2'},
            'num_leaves': 31,
            'min_data': 1 if X_train.shape[0] < constants.LIGHTGBM_MIN_NUM_ROW else 20,
            'min_data_in_bin': 1 if X_train.shape[0] < constants.LIGHTGBM_MIN_NUM_ROW else 3,
        }

    elif task_type == constants.Tasks.CLASSIFICATION:
        unique_y, counts = np.unique(y, return_counts=True)
        num_of_class = len(unique_y)
        min_class_num = min(counts)
        if num_of_class < 2:
            raise ValueError('number of classes should not be less than 2. The number of classes is: {}'
                             .format(num_of_class))
        elif num_of_class == 2:
            params = {
                'task': 'train',
                'application': 'binary',
                'objective': 'binary',
                'num_leaves': 31,
                'boosting_type': 'gbdt',
                'metric': 'binary_logloss',
                'min_data': 1 if X_train.shape[0] < constants.LIGHTGBM_MIN_NUM_ROW or
                                 min_class_num < constants.LIGHTGBM_MIN_NUM_ROW else 5,
                'min_data_in_bin': 1 if X_train.shape[0] < constants.LIGHTGBM_MIN_NUM_ROW or
                        min_class_num < constants.LIGHTGBM_MIN_NUM_ROW else 3,
            }
        else:
            params = {
                'task': 'train',
                'boosting_type': 'gbdt',
                'objective': 'multiclass',
                'metric': {'multi_logloss'},
                'num_class': num_of_class,
                'num_leaves': 300,
                'verbose': 5,
                'min_data': 1 if X_train.shape[0] < constants.LIGHTGBM_MIN_NUM_ROW or
                        min_class_num < constants.LIGHTGBM_MIN_NUM_ROW else 5,
                'min_data_in_bin': 1 if X_train.shape[0] < constants.LIGHTGBM_MIN_NUM_ROW or
                        min_class_num < constants.LIGHTGBM_MIN_NUM_ROW else 3,
            }
    else:
        raise ValueError('Incorrect task_type: {0}, not able to do '
                         'model feature importance analysis'.format(task_type))

    model = lgbm.train(params,
                       lgb_train,
                       valid_sets=[lgb_train, lgb_valid],
                       num_boost_round=epoch,
                       verbose_eval=0,
                       early_stopping_rounds=50)

    return model


def lightgbm_feature_importance(model, X_column_names):
    """
    Get lightgbm feature importance scores.

    :param model: The trained lightgbm model.
    :type model: lightgbm.Booster
    :param X_column_names: X column names.
    :type X_column_names: numpy.ndarray
    :return: lightgbm feature importance score.
    :rtype: pandas.Series
    """
    importance = list(model.feature_importance())
    feature_name = list(X_column_names[int(x)] for x in model.feature_name())
    if not len(importance):
        raise ValueError("LightGBM's feature_importance is empty.")
    return pd.Series(importance, index=feature_name)
