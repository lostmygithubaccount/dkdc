# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""FeatureType and FeatureTypeThreshold class."""

from enum import Enum


class FeatureType(Enum):
    """Class for storing the feature types that the pre-processor recognizes."""

    Numeric = 1
    DateTime = 2
    Categorical = 3
    CategoricalHash = 4
    Text = 5
    Hashes = 6
    Ignore = 7
    AllNan = 8

    @staticmethod
    def from_str(label: str):
        """
        Construct FeatureType from a string.

        :param label: feature type name in string.
        :type label: str
        :return: FeatureType object.
        :rtype: FeatureType
        """
        for feature_type in FeatureType:
            if label.lower() == feature_type.name.lower():
                return feature_type
        return None
