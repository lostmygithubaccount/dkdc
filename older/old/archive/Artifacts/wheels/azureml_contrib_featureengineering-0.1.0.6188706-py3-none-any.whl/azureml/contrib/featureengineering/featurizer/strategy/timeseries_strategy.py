# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""TimeSeriesStrategy class contains timeseries strategy information."""
from typing import Any, Dict


class TimeSeriesStrategy:
    """Container for TimeSeriesStrategy."""

    def __init__(self, enable_timeseries_transform: bool, ts_param_dict: Dict[str, Any]):
        """
        Construct timeseries strategy object.

        :param enable_timeseries_transform: whether to enable the timeseries transformer.
        :param ts_param_dict: timeseries parameter dictionary.
        """
        self._enable_timeseries_transform = enable_timeseries_transform
        self._ts_param_dict = {}
        self._ts_param_dict.update(ts_param_dict)

    def to_dict(self):
        """
        Create dict from TypeStrategy for serialization usage.

        :return: a dictionary
        """
        dct = dict()
        dct['enable_timeseries_transform'] = self._enable_timeseries_transform
        dct.update(self._ts_param_dict)
        return dct

    def from_dict(self, dct: Dict[str, Any]):
        """
        Create timeseries strategy object from dictionary.

        :param dct: a dictionary.
        :return: a timeseries strategy.
        """
        self._ts_param_dict = {}
        self._ts_param_dict.update(dct)
        if 'enable_timeseries_transform' in self._ts_param_dict:
            self._enable_timeseries_transform = self._ts_param_dict['enable_timeseries_transform']
            self._ts_param_dict.pop('enable_timeseries_transform')
        return self
