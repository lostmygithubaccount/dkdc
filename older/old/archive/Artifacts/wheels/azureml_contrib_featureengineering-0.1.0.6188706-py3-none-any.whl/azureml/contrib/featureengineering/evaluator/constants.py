# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Evaluator constants."""

PANDAS_NUMERIC_TYPES = ['int8', 'int16', 'int32', 'int64', 'uint8', 'uint16', 'uint32', 'uint64', 'float16',
                        'float32', 'float64']
MUTUAL_INFO_WEIGHT = 0.2
PEARSON_WEIGHT = 0.2
LIGHTGBM_WEIGHT = 0.3
LASSO_WEIGHT = 0.3
MISSING_VAL_THRESHOLD = 0.5
VARIANCE_THRESHOLD = 1e-5

NON_NULL_RATIO = 'non_null_ratio'
VARIANCE = 'variance'
MUTUAL_INFO = 'mutual_info'
PEARSON_CORR = 'pearson_corr'
LIGHTGBM = 'lightgbm'
LASSO = 'lasso'
LIGHTGBM_IMPORTANCE = 'lightgbm_importance'
LASSO_IMPORTANCE = 'lasso_importance'
FEATURE = 'feature'
FEATURE_IMPORTANCE = 'feature_importance'
DEFAULT_LABEL_COLUMN_NAME = 'label'
LIGHTGBM_MIN_NUM_ROW = 20
FEATURE_SELECTION_SELECTED_FEATURES_JSON_OUTPUT = 'selected_features.json'


class Tasks:
    """Names for the types of machine learning tasks supported."""

    CLASSIFICATION = 'classification'
    REGRESSION = 'regression'

    ALL = [CLASSIFICATION, REGRESSION]
