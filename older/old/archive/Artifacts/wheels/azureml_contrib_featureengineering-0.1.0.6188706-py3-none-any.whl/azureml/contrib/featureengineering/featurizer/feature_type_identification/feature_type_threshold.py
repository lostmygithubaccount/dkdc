# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""FeatureTypeThreshold class."""


class FeatureTypeThreshold:
    """FeatureTypeThreshold static class."""

    CAT_PCT_THOLD = 0.05
    CAT_HASH_PCT_THOLD = 0.7
    HASH_PCT_THOLD = 0.9
    TEXT_PCT_THOLD = 0.85
    NUMERICAL_PCT_THOLD = 0.05
    CAT_NUM_THOLD = 200
    CAT_HASH_NUM_THOLD = 10000
    CAT_INTEGER_NUM_THOLD = 50
