# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""SelectTopFeatures class used to generate feature scoring and select top features."""
import json
import logging
from typing import Optional

import pandas as pd
from sklearn.base import BaseEstimator
from sklearn.exceptions import NotFittedError
from sklearn.feature_selection.base import SelectorMixin

from azureml.contrib.featureengineering.common.logging import _LoggerFactory, function_log_activity
from azureml.contrib.featureengineering.evaluator import constants
from azureml.contrib.featureengineering.evaluator.feature_importance_evaluator import FeatureImportanceEvaluator
from azureml.contrib.featureengineering.evaluator.numpy_encoder import NumpyEncoder


class SelectTopFeatures(BaseEstimator, SelectorMixin):
    """SelectTopFeatures class that can generate feature scoring and select top features."""

    def __init__(self, task=constants.Tasks.CLASSIFICATION, *, n=-1, percentile=-1,
                 methods=[constants.MUTUAL_INFO, constants.PEARSON_CORR,
                          constants.LIGHTGBM, constants.LASSO],
                 mutual_info_weight=constants.MUTUAL_INFO_WEIGHT,
                 pearson_weight=constants.PEARSON_WEIGHT, lightgbm_weight=constants.LIGHTGBM_WEIGHT,
                 lasso_weight=constants.LASSO_WEIGHT, missing_val_threshold=constants.MISSING_VAL_THRESHOLD,
                 variance_threshold=constants.VARIANCE_THRESHOLD, preprocess=True, client_id="unknown",
                 logger: Optional[logging.Logger] = None):
        """
        Initialize select top features with params defined.

        :param task: 'classification' or 'regression' depending on what kind of ML problem to solve.
        :type task: str or constants.Tasks
        :param n: number of top features to select.
        :type n: int
        :param percentile: percentage of importance to cover when select top features.
        :type percentile: float or -1
        :param methods: which feature selection methods to apply.
        :type methods: list of strs
        :param mutual_info_weight: weight for mutual information in combined feature importance calculation.
        :type mutual_info_weight: float
        :param pearson_weight: weight for pearson correlation in combined feature importance calculation.
        :type pearson_weight: float
        :param lightgbm_weight: weight for lightgbm feature importance in combined feature importance calculation.
        :type lightgbm_weight: float
        :param lasso_weight: weight for lasso feature importance in combined feature importance calculation.
        :type lasso_weight: float
        :param missing_val_threshold: if number of missing value exceeds the threshold, drop the column in feature
        selection. To disable, set to None.
        :type missing_val_threshold: float or None
        :param variance_threshold: if variance falls below the threshold, drop the column. To disable, set to None.
        :type variance_threshold: float or None
        :param preprocess: whether to apply built-in featurization or not. True means apply built-in featurization to
        the input data before feature scoring. False means do not apply built-in featurization. Will report error if
        input data is not numeric when preprocess=False.
        :type preprocess: bool
        :param client_id: client id of the caller.
        :type client_id: str
        :param logger: External logger handler.
        :type logger: logging.Logger
        """
        self._logger = _LoggerFactory.get_logger(__name__, client_id=client_id)
        if logger is not None:
            _LoggerFactory.add_handler(self._logger, logger)

        self._FeatureImportanceEvaluator = FeatureImportanceEvaluator(task, methods=methods,
                                                                      mutual_info_weight=mutual_info_weight,
                                                                      pearson_weight=pearson_weight,
                                                                      lightgbm_weight=lightgbm_weight,
                                                                      lasso_weight=lasso_weight,
                                                                      missing_val_threshold=missing_val_threshold,
                                                                      variance_threshold=variance_threshold,
                                                                      preprocess=preprocess, client_id=client_id,
                                                                      logger=self._logger)

        self._task = task
        self.n = n
        self.percentile = percentile
        self._preprocess = preprocess
        self._isfitted = False

    @function_log_activity
    def fit(self, X, y):
        """
        Run scoring on (X, y) and get the feature importance scoring.

        :param X: The training input.
        :type X: numpy.ndarray, pandas.DataFrame or scipy.sparse.csr_matrix
        :param y: The target values (class labels in classification, real numbers in regression).
        :type y: numpy.ndarray, pandas.Series or pandas.DataFrame
        :return: self
        :rtype: SelectTopFeatures object
        """
        # TODO Also need to test on CSC, COO or BSR sparse matrix
        self.raw_scoring_, self.eng_scoring_ = self._FeatureImportanceEvaluator.get_feature_scoring(X, y)
        self.raw_scoring_ = self.raw_scoring_.sort_values(by=[constants.FEATURE_IMPORTANCE], ascending=False)
        if not self.eng_scoring_.empty:
            self.eng_scoring_ = self.eng_scoring_.sort_values(by=[constants.FEATURE_IMPORTANCE], ascending=False)

        self._isfitted = True
        return self

    @function_log_activity
    def transform(self, X):
        """
        Reduce X to the selected features.

        :param X: The input data.
        :type X: numpy.ndarray, pandas.DataFrame or scipy.sparse.csr_matrix
        :return: The input samples with only selected features.
        :rtype: numpy.ndarray, pandas.DataFrame or scipy.sparse.csr_matrix
        """
        if not self._isfitted:
            raise NotFittedError(
                "This instance is not fitted yet. Call 'fit' with appropriate arguments before using this method.")
        # transformed_X_eng_ is always the selected engineered output based on the data initially used to do fit(),
        # even if later another X_test or X_valid is passed in to do transform()
        returns = self._FeatureImportanceEvaluator.select_top_features(X, n=self.n, percentile=self.percentile)
        self._raw_mask = returns['raw_mask']
        self._eng_mask = returns['eng_mask']
        transformed_X_raw = returns['X_out']
        self.transformed_X_raw_column_names_ = returns['X_out_column_names']
        self.transformed_X_eng_ = returns['X_eng_out']
        self.transformed_X_eng_column_names_ = returns['X_eng_out_column_names']
        self._selected_raw_score = returns['selected_raw_score']
        self._selected_eng_score = returns['selected_eng_score']
        return transformed_X_raw

    @function_log_activity
    def fit_transform(self, X, y):
        """
        Run scoring on (X, y), get the feature importance scoring and reduce X to selected features.

        :param X: The input data.
        :type X: numpy.ndarray, pandas.DataFrame or scipy.sparse.csr_matrix
        :param y: The target values.
        :type y: numpy.ndarray, pandas.Series or pandas.DataFrame
        :return: The input samples with only selected features.
        :rtype: numpy.ndarray, pandas.DataFrame or scipy.sparse.csr_matrix
        """
        return self.fit(X, y).transform(X)

    @function_log_activity
    def set_top_n(self, n):
        """
        Set number of top features to select.

        :param n: number of top features to select.
        :type n: int
        """
        self.percentile = -1
        self.n = n
        self._selected_raw_score = pd.DataFrame()
        self._selected_eng_score = pd.DataFrame()

    @function_log_activity
    def set_top_percentile(self, percentile):
        """
        Set percentage of importance to cover when select top features.

        :param percentile: percent of importance to cover.
        :type percentile: float or -1
        """
        self.n = -1
        self.percentile = percentile
        self._selected_raw_score = pd.DataFrame()
        self._selected_eng_score = pd.DataFrame()

    def _get_support_mask(self):
        pass

    @function_log_activity
    def get_selected_feature_importance(self, verbose=False):
        """
        Get selected features and importance scores.

        :param verbose: whether to print all feature scores or only combined feature importance score.
        :type verbose: bool
        :return: selected features and importance scores.
        :rtype: pandas.DataFrame
        """
        if not self._isfitted:
            raise NotFittedError(
                "This instance is not fitted yet. Call 'fit' with appropriate arguments before using this method.")
        if not hasattr(self, '_selected_raw_score'):
            raise NotFittedError("Call 'transform' with appropriate arguments before using this method.")
        if self._selected_raw_score.empty:
            raise NotFittedError(
                "Number of top features to select has changed. Call 'transform' with appropriate arguments"
                "before using this method.")
        if verbose:
            return self._selected_raw_score
        else:
            return self._selected_raw_score[[constants.FEATURE_IMPORTANCE]]

    @function_log_activity
    def load_selected_features(self, filename=None):
        """
        Load selected features from disk.

        :param filename: filename to load.
        :type filename: str
        :return: selected features mask and column names.
        :rtype: dict
        """
        file = filename if filename is not None else constants.FEATURE_SELECTION_SELECTED_FEATURES_JSON_OUTPUT
        with open(file, 'r') as f:
            data = json.load(f)
        return json.loads(data)

    @function_log_activity
    def save_selected_features(self, filename=None):
        """
        Save selected features as json to disk.

        :param filename: filename to save.
        :type filename: str
        :return: json formatted str with serialized object
        :rtype: str
        """
        if not self._isfitted:
            raise NotFittedError(
                "This instance is not fitted yet. Call 'fit' with appropriate arguments before using this method.")
        if not hasattr(self, '_raw_mask'):
            raise NotFittedError("Call 'transform' with appropriate arguments before using this method.")
        data = json.dumps({'mask': self._raw_mask, 'column_names': self.transformed_X_raw_column_names_},
                          cls=NumpyEncoder)

        file = filename if filename is not None else constants.FEATURE_SELECTION_SELECTED_FEATURES_JSON_OUTPUT
        with open(file, 'w') as f:
            json.dump(data, f)

        return data
