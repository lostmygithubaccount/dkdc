# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""FeatureTypeIdentifier module methods for custom thresholds and feature type identification."""

from collections import OrderedDict

import pandas as pd
from azureml.dataprep.api.engineapi.typedefinitions import FieldType

from azureml.contrib.featureengineering.common import utilities
from .column_info import ColumnInfo
from .feature_type import FeatureType
from .feature_type_threshold import FeatureTypeThreshold


class FeatureTypeIdentifier:
    """FeatureTypeIdentifier used for customize thresholds and feature type identification."""

    def __init__(self,
                 categorical_pct_threshold=FeatureTypeThreshold.CAT_PCT_THOLD,
                 categorical_hash_pct_threshold=FeatureTypeThreshold.CAT_HASH_PCT_THOLD,
                 hash_pct_threshold=FeatureTypeThreshold.HASH_PCT_THOLD,
                 text_pct_threshold=FeatureTypeThreshold.TEXT_PCT_THOLD,
                 numerical_pct_threshold=FeatureTypeThreshold.NUMERICAL_PCT_THOLD,
                 is_inference_type=True):
        """
        Initialize feature type identifier with threshold params and inference type flag.

        :param categorical_pct_threshold: Categorical type percentage threshold.
        :type categorical_pct_threshold: float
        :param categorical_hash_pct_threshold: Categorical hash type percentage threshold.
        :type categorical_hash_pct_threshold: float
        :param hash_pct_threshold: Hash type percentage threshold.
        :type hash_pct_threshold: float
        :param text_pct_threshold: Text type percentage threshold.
        :type text_pct_threshold: float
        :param numerical_pct_threshold: Numerical type percentage threshold.
        :type numerical_pct_threshold: float
        :param is_inference_type: If True, will inference data types.
        :type is_inference_type: bool
        """
        self.categorical_pct_threshold = categorical_pct_threshold
        self.hash_pct_threshold = hash_pct_threshold
        self.text_pct_threshold = text_pct_threshold
        self.numerical_pct_threshold = numerical_pct_threshold
        self.categorical_hash_pct_threshold = categorical_hash_pct_threshold
        self.categorical_num_threshold = FeatureTypeThreshold.CAT_NUM_THOLD
        self.categorical_hash_num_threshold = FeatureTypeThreshold.CAT_HASH_NUM_THOLD
        self.categorical_integer_num_threshold = FeatureTypeThreshold.CAT_INTEGER_NUM_THOLD
        self.is_inference_type = is_inference_type

        self.data_profile = None
        self.columns_info = None
        self._conversion_step = None

    def _get_data_profile(self, data_flow):
        """
        Get data profile from dataflow object.

        :param data_flow: Dataprep Dataflow object.
        :type data_flow: Dataflow
        :return: data profile object.
        :rtype: DataProfile
        :raise : Exception
        """
        try:
            self.data_profile = data_flow.get_profile()
            return self.data_profile
        except ValueError as error:
            # log error
            raise Exception("get profile exception")

    def convert_to_dataflow(self, data):
        """
        Convert input data into Dataflow object.

        :param data: input data that will be converted to Dataflow.
        :type data: numpy.Ndarray or pandas.Dataframe
        :return: Dataprep Dataflow object.
        :rtype: Dataflow
        """
        utilities.check_input(data)
        dataflow = utilities.generate_dataflow(data)

        if self.is_inference_type:
            if self._conversion_step is None:
                dataflow = utilities.proceed_dataflow_type_conversion(dataflow)
                self._conversion_step = dataflow._steps[-1]
            else:
                if dataflow._steps[-1].step_type != "Microsoft.DPrep.SetColumnTypesBlock":
                    new_dataflow = utilities.convert_dataflow_with_conversion_step(dataflow, self._conversion_step)
                    return new_dataflow
        return dataflow

    def get_thresholds(self):
        """
        Get all thresholds into a dictionary.

        :return: All thresholds in a dictionary.
        :rtype: Dict
        """
        class_dict = self.__dict__
        return {k: v for k, v in class_dict.items() if "thresholds" in k}

    def set_thresholds(self,
                       categorical_pct_threshold=FeatureTypeThreshold.CAT_PCT_THOLD,
                       categorical_hash_pct_threshold=FeatureTypeThreshold.CAT_HASH_PCT_THOLD,
                       hash_pct_threshold=FeatureTypeThreshold.HASH_PCT_THOLD,
                       text_pct_threshold=FeatureTypeThreshold.TEXT_PCT_THOLD,
                       numerical_pct_threshold=FeatureTypeThreshold.NUMERICAL_PCT_THOLD):
        """
        Set feature type identifier thresholds with desired value.

        :param categorical_pct_threshold: Categorical type percentage threshold.
        :type categorical_pct_threshold: float
        :param categorical_hash_pct_threshold: Categorical hash type percentage threshold.
        :type categorical_hash_pct_threshold: float
        :param hash_pct_threshold: Hash type percentage threshold.
        :type hash_pct_threshold: float
        :param text_pct_threshold: Text type percentage threshold.
        :type text_pct_threshold: float
        :param numerical_pct_threshold: Numerical type percentage threshold.
        :type numerical_pct_threshold: float
        """
        self.categorical_pct_threshold = categorical_pct_threshold
        self.categorical_hash_pct_threshold = categorical_hash_pct_threshold
        self.hash_pct_threshold = hash_pct_threshold
        self.text_pct_threshold = text_pct_threshold
        self.numerical_pct_threshold = numerical_pct_threshold

        if self.columns_info is not None:
            for column_name, column_info in self.columns_info.items():
                column_info.feature_type = self.detect_column_feature_type(column_info)
                self.columns_info[column_name] = column_info

    def get_columns_info(self):
        """
        Get columns info object.

        Return a dictionary of column info object which contains data types, data statistics.

        :return: list of column info object
        :rtype: List[ColumnInfo]
        """
        return self.columns_info

    def set_columns_info(self, columns_info):
        """
        Set columns info with input columns_info arguments.

        :param columns_info: A dictionary of column name and column
            info object which contains data types, data statistics.
        :type: List[ColumnInfo]
        """
        self.columns_info = columns_info

    def get_column_feature_type(self, column_name: str):
        """
        Get column info for a specific column names.

        :param column_name: column name
        :type column_name: str
        :return: ColumnInfo object which contains data types, data statistics.
        :rtype: ColumnInfo or None
        """
        if column_name in self.columns_info.keys():
            return self.columns_info[column_name].feature_type
        else:
            return None

    @staticmethod
    def _is_feature_type_convertible(field_type: FieldType, current_feature_type: FeatureType,
                                     new_feature_type: FeatureType):
        """
        Check whether feature types are convertible.

        :param field_type: Data type of a given column.
        :type field_type: FieldType
        :param current_feature_type: Current feature type of a given column.
        :type current_feature_type: FeatureType
        :param new_feature_type: Target feature type that current feature type will be converted to.
        :type new_feature_type: FeatureType
        :return: Whether current feature type can convert to new feature type.
        :rtype: bool
        """
        if new_feature_type == FeatureType.Ignore:
            return True

        switcher = {
            FieldType.STRING: [FeatureType.Text, FeatureType.Categorical,
                               FeatureType.CategoricalHash, FeatureType.Ignore, FeatureType.Hashes],
            FieldType.INTEGER: [FeatureType.Numeric, FeatureType.Categorical,
                                FeatureType.CategoricalHash, FeatureType.Hashes,
                                FeatureType.Ignore],
            FieldType.DECIMAL: [FeatureType.Numeric, FeatureType.Categorical,
                                FeatureType.CategoricalHash, FeatureType.Ignore],
            FieldType.DATE: [FeatureType.DateTime, FeatureType.Ignore]
        }
        allowed_feature_type = switcher.get(field_type, [FeatureType.Ignore])
        return current_feature_type in allowed_feature_type and new_feature_type in allowed_feature_type

    def set_column_feature_type(self, column_name: str, feature_type: FeatureType):
        """
        Set feature type of a given column.

        :param column_name: column name
        :type column_name: str
        :param feature_type: Feature type that a given column will be set to.
        :type  feature_type: FeatureType
        :raise: ValueError
        """
        if column_name in self.columns_info.keys():
            column_info = self.columns_info[column_name]
            if self._is_feature_type_convertible(column_info.field_type, column_info.feature_type,
                                                 feature_type):
                column_info.feature_type = feature_type
            else:
                raise ValueError(
                    "Error: column feature type is not compatible, column name: {}, field_type: {"
                    "}, origin_feature_type:{}, new feature_type:{}.".format(
                        column_name, column_info.field_type, column_info.feature_type,
                        feature_type))
        else:
            raise ValueError("Error: column name: {} does not exist.".format(column_name))

    # TODO make sure threshold is scalable to actual dataprofile size
    def detect_column_feature_type(self, column_info: ColumnInfo):
        """
        Detect feature type of a given column using ColumnInfo and heuristic logic.

        :param column_info: ColumnInfo object which contains data types, data statistics.
        :type column_info: ColumnInfo
        :return: Detected feature type.
        :rtype: FeatureType
        """
        if column_info.field_type in [FieldType.UNKNOWN, FieldType.DATAROW, FieldType.ERROR,
                                      FieldType.LIST, FieldType.STREAM, FieldType.NULL]:
            return FeatureType.Ignore

        if column_info.is_all_nan:
            return FeatureType.AllNan
        if column_info.num_unique_vals == 1:
            # If there is only one unique value, then we don't need to include
            # this column for transformations
            return FeatureType.Ignore
        if column_info.field_type == FieldType.DATE:
            return FeatureType.DateTime
        if column_info.num_unique_vals >= min(self.categorical_num_threshold,
                                              self.categorical_pct_threshold *
                                              column_info.total_number_vals):
            if column_info.field_type == FieldType.DECIMAL or column_info.field_type == \
                    FieldType.INTEGER:
                return FeatureType.Numeric
            elif column_info.field_type == FieldType.STRING:
                if column_info.cardinality_ratio > self.text_pct_threshold and \
                        column_info.average_number_spaces > 1.0:
                    return FeatureType.Text
                elif column_info.cardinality_ratio < self.categorical_hash_pct_threshold and \
                        column_info.num_unique_vals < self.categorical_hash_num_threshold:
                    return FeatureType.CategoricalHash
                elif column_info.average_number_spaces > 1.0:
                    return FeatureType.Text
                elif column_info.cardinality_ratio > self.hash_pct_threshold:
                    return FeatureType.Hashes
                else:
                    return FeatureType.Ignore
        if column_info.field_type == FieldType.INTEGER:
            if column_info.num_unique_vals <= min(self.categorical_integer_num_threshold,
                                                  self.categorical_pct_threshold *
                                                  column_info.total_number_vals):
                return FeatureType.Categorical
            else:
                return FeatureType.Numeric
        if column_info.field_type == FieldType.DECIMAL:
            return FeatureType.Numeric
        if column_info.field_type == FieldType.STRING:
            return FeatureType.Categorical
        if column_info.field_type == FieldType.BOOLEAN:
            return FeatureType.CategoricalHash
        return FeatureType.Ignore

    # TODO: remove this methods when DataProfile contains required stats
    @staticmethod
    def _fill_stats(df: pd.DataFrame, column_info: ColumnInfo):
        """
        Fill missing stats for string type.

        :param df: input data
        :type df: pandas.DataFrame
        :param column_info: ColumnInfo object which contains data types, data statistics.
        :type column_info: ColumnInfo
        :return: ColumnInfo object filled with missing stats.
        :rtype: ColumnInfo
        """
        if column_info.field_type == FieldType.STRING:
            column_info.fill_stats_with_text_type(df[column_info.column_name])
        return column_info

    def identify_feature_types(self, data):
        """
        Identify column feature types of a give input data.

        :param data: input data that will be converted to Dataflow.
        :type data: numpy.Ndarray or pandas.Dataframe
        :return: dataflow object with inferred type
        :rtype: Dataflow
        """
        dataflow = self.convert_to_dataflow(data)
        self._get_data_profile(dataflow)
        pandas_df = dataflow.to_pandas_dataframe()
        self.columns_info = OrderedDict()
        for column_name, column_profile in self.data_profile.columns.items():
            column_info = ColumnInfo(column_profile, None)
            column_info = self._fill_stats(pandas_df, column_info)
            column_info.feature_type = self.detect_column_feature_type(column_info)
            self.columns_info[column_name] = column_info
        return dataflow
