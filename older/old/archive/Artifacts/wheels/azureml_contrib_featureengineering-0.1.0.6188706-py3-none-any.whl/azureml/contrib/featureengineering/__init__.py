# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""Package for automatic feature synthesis, public dataset enrichment and feature importance evaluation."""
try:
    from ._version import ver as VERSION

    __version__ = VERSION
except ImportError:
    VERSION = '0.0.0+dev'
    __version__ = VERSION
