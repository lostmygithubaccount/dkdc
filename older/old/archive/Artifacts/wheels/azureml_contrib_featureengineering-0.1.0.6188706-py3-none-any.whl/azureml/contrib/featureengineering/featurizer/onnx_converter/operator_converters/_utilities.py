# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Util of operator converters."""
# -----------------------------------
# Import skl2onnx modules.
import sklearn

import sys
from types import ModuleType


class __DummyClassForSklearn:
    pass


class _SklearnCompatibilityUtil:
    """
    This class is a workaround to unblock the user who is using 0.19.* sklearn versions.

    The reason of this workaround is that the skl2onnx package imports the latest sklearn 0.20.*
    modules and classes directly, and it doesn't provide sklearn 0.19.* backward compatibility.
    Ref: https://github.com/onnx/sklearn-onnx/issues/94
    """

    SKLEARN_INCOMPATIBLE_VER_0_19_1 = '0.19.1'
    SKLEARN_INCOMPATIBLE_VER_0_19_2 = '0.19.2'

    # -------------------
    # Sub module names.
    _M_COMPOSE = 'compose'
    _M_IMPUTE = 'impute'
    _M_PREPROCESSING = 'preprocessing'

    # -------------------
    # Class names.
    # In compose module.
    _C_COLUMN_TRANSFORMER = 'ColumnTransformer'
    # In impute module.
    _C_SIMPLE_IMPUTER = 'SimpleImputer'
    # In preprocess module.
    _C_KBINS_DISCRETIZER = 'KBinsDiscretizer'

    # -------------------
    # Version to array of the sub module names map, for adding modules.
    _sklearn_version_to_new_module_names_map = {
        SKLEARN_INCOMPATIBLE_VER_0_19_1: [_M_COMPOSE, _M_IMPUTE],
        SKLEARN_INCOMPATIBLE_VER_0_19_2: [_M_COMPOSE, _M_IMPUTE]
    }

    # -------------------
    # Version to a map of {sub_module : [class_names]} map, for adding classes.
    _sklearn_ver_to_class_names_in_sub_modules = {
        # The
        SKLEARN_INCOMPATIBLE_VER_0_19_1: [
            # sklearn.compose.ColumnTransformer
            # sklearn.impute.SimpleImputer
            # sklearn.preprocessing.KBinsDiscretizer
            # Compose module.
            {_M_COMPOSE: [_C_COLUMN_TRANSFORMER]},
            # Impute module.
            {_M_IMPUTE: [_C_SIMPLE_IMPUTER]},
            # Preprocess module.
            {_M_PREPROCESSING: [_C_KBINS_DISCRETIZER]}
        ],
        SKLEARN_INCOMPATIBLE_VER_0_19_2: [
            # sklearn.compose.ColumnTransformer
            # sklearn.impute.SimpleImputer
            # sklearn.preprocessing.KBinsDiscretizer
            # Compose module.
            {_M_COMPOSE: [_C_COLUMN_TRANSFORMER]},
            # Impute module.
            {_M_IMPUTE: [_C_SIMPLE_IMPUTER]},
            # Preprocess module.
            {_M_PREPROCESSING: [_C_KBINS_DISCRETIZER]}
        ]
    }


def __add_sub_model_in_sklearn(module_name):
    # Create the module.
    m = ModuleType(module_name, None)
    m.__file__ = module_name + '.py'
    # Register it in sys module, this is needed for import.
    sys.modules['sklearn.' + module_name] = m
    # Add it to sklearn module.
    sklearn.__dict__[module_name] = m
    return m


def __add_class_in_sklearn_sub_module(sub_module_name, class_name):
    sub_module = sklearn.__dict__[sub_module_name]
    if sub_module is None:
        # Ensure the sub module exists, if not, add it.
        sub_module = __add_sub_model_in_sklearn(sub_module_name)
    # Add the class to the sub module.
    sub_module.__dict__[class_name] = __DummyClassForSklearn


def _make_sklearn_compatible_with_skl2onnx():
    """Make the skl2onnx compatible with sklearn specific version.

    It defines sub modules and classes that coming after given specific sklearn package version.
    And those sub modules/classes in sklearn are used in skl2onnx.
    Note. This is safe for the automl package, since we use pinned sklearn version.
    """
    # Get the version of sklearn package that is loaded in runtime.
    import pkg_resources
    sklearn_ver = pkg_resources.get_distribution("scikit_learn").version

    if sklearn_ver == _SklearnCompatibilityUtil.SKLEARN_INCOMPATIBLE_VER_0_19_1 \
            or sklearn_ver == _SklearnCompatibilityUtil.SKLEARN_INCOMPATIBLE_VER_0_19_2:
        # Add sub modules to sklearn, based on this version.
        if sklearn_ver in _SklearnCompatibilityUtil._sklearn_version_to_new_module_names_map:
            sub_modules_to_add = _SklearnCompatibilityUtil._sklearn_version_to_new_module_names_map[sklearn_ver]
            for module_name in sub_modules_to_add:
                __add_sub_model_in_sklearn(module_name)

        # Add classes to sub modules, based on this version.
        if sklearn_ver in _SklearnCompatibilityUtil._sklearn_ver_to_class_names_in_sub_modules:
            mod_to_class_maps = _SklearnCompatibilityUtil._sklearn_ver_to_class_names_in_sub_modules[sklearn_ver]
            for m_to_c_map in mod_to_class_maps:
                for mod_name in m_to_c_map:
                    class_names = m_to_c_map[mod_name]
                    for cls_n in class_names:
                        __add_class_in_sklearn_sub_module(mod_name, cls_n)


# Based on the sklearn version we are pinning, make sklearn be compatible with
# the skl2onnx package.
_make_sklearn_compatible_with_skl2onnx()

from sklearn.feature_extraction.text import CountVectorizer       # noqa: E402


# ------------------------------------
from ..onnx_convert_constants import OnnxConvertConstants       # noqa: E402

# Import the onnx related packages, only if the python version is less than 3.8.
# The onnx package does not support python 3.8 yet.
if sys.version_info < OnnxConvertConstants.OnnxIncompatiblePythonVersion:
    from skl2onnx.common.data_types import Int64TensorType       # noqa: E402
    from skl2onnx.common.data_types import FloatTensorType       # noqa: E402
    from skl2onnx.common.data_types import StringTensorType       # noqa: E402
    from skl2onnx.common.data_types import DictionaryType       # noqa: E402
    from skl2onnx.common.data_types import SequenceType       # noqa: E402

    from skl2onnx.operator_converters.TextVectorizer import convert_sklearn_text_vectorizer       # noqa: E402

    # -----------------------------------
    # Dependencies for convert the lightgbm.
    import onnxmltools.convert.common.data_types       # noqa: E402
    # -----------------------------------
    # Redefine the onnxmltools data type classes, this is needed to fix issue with onnxmltools.
    onnxmltools.convert.common.data_types.Int64TensorType = Int64TensorType
    onnxmltools.convert.common.data_types.StringTensorType = StringTensorType
    onnxmltools.convert.common.data_types.FloatTensorType = FloatTensorType
    onnxmltools.convert.common.data_types.DictionaryType = DictionaryType
    onnxmltools.convert.common.data_types.SequenceType = SequenceType


# -----------------------------------
# AutoML modules.
from azureml.contrib.featureengineering.core.exceptions import OnnxConvertException       # noqa: E402


# -----------------------------------
# Check the Python version, now onnx package only supports < 3.8.
def _raise_exception_if_python_ver_doesnot_support_onnx():
    # Now onnx package only supports < 3.8.
    if sys.version_info >= OnnxConvertConstants.OnnxIncompatiblePythonVersion:
        major = OnnxConvertConstants.OnnxIncompatiblePythonVersion[0]
        minor = OnnxConvertConstants.OnnxIncompatiblePythonVersion[1]
        raise OnnxConvertException("The ONNX conversion does not support Python version {}.{}, "
                                   "please use lower version of Python to get the ONNX models.".format(major, minor))


class OpConverterUtil:
    """Util of operator converters."""

    # The seperator string for cat transformer, used in converting the CountVectorizer,
    # when the number of categories is greater than 2. The purpose is to make the tokenizer
    # return a list containining the original string.
    _COUNT_VECTORIZER_SEPERATOR_FOR_CAT_TRANSFORMER = '_AA51DED7266648A79596883C0B90D67A_'

    @staticmethod
    def _apply_mod(scope, container, var1, var2, result):
        # result = var1 % var2
        # There's no mod op in ONNX[v1.3], mod = v1 - (v2 * (v1/v2)), v1, v2
        # are int vars.
        op_type = OnnxConvertConstants.Div
        div_var = scope.get_unique_variable_name('mod_v1_div_v2')
        attrs = {}    # type: Dict[str, Any]
        container.add_node(op_type, [var1, var2], div_var, op_version=7, **attrs)

        op_type = OnnxConvertConstants.Mul
        v2_mul_v1_div_v2_var = scope.get_unique_variable_name('mod_v2_mul_v1_div_v2_var')
        container.add_node(op_type, [var2, div_var], v2_mul_v1_div_v2_var, op_version=7, **attrs)

        op_type = OnnxConvertConstants.Sub
        container.add_node(op_type, [var1, v2_mul_v1_div_v2_var], result, op_version=7, **attrs)

    @staticmethod
    def _convert_count_vectorizer_wrapper(scope, operator, container):
        raw_op = operator.raw_operator
        tokenizer = raw_op.tokenizer

        # Need to remove the custom tokenizer for the raw op, since skl2onnx doesn't support it.
        if tokenizer is not None:
            # Add an option of seperator string to the container.
            container.options = {CountVectorizer: {
                "sep": [OpConverterUtil._COUNT_VECTORIZER_SEPERATOR_FOR_CAT_TRANSFORMER]}}
            raw_op.tokenizer = None

        # Call the skl2onnx convert method.
        convert_sklearn_text_vectorizer(scope, operator, container)

        if tokenizer is not None:
            # Reset the option in the container and the raw op.
            container.options = None
            raw_op.tokenizer = tokenizer
