# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Automatically select a feature subset from original set meeting a specified performance criteria."""
import logging
import warnings
import pandas as pd
import numpy as np
from typing import Optional
import matplotlib.pyplot as plt
from scipy.sparse import csr_matrix
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, roc_auc_score, precision_score, \
    recall_score, accuracy_score, f1_score

from azureml.automl.core import training_utilities
from azureml.contrib.featureengineering.common import lightgbm
from azureml.contrib.featureengineering.common.logging import _LoggerFactory, function_log_activity, log_msg
from azureml.contrib.featureengineering.evaluator import constants
from azureml.contrib.featureengineering.evaluator.feature_selection import Metrics, DataPreprocessor, \
    feature_selection_utilities
from azureml.contrib.featureengineering.evaluator.select_top_features import SelectTopFeatures


class AutoFeatureSelector:
    """Auto Feature selector to perform feature selection automatically."""

    def __init__(self, task=constants.Tasks.REGRESSION, mode=None, model=None, metric=None, metric_cut_off=0.99,
                 preprocess=True, plot=False, client_id="unknown", logger: Optional[logging.Logger] = None):
        """
        Construct AutoFeatureSelector.

        :param task: 'classification' or 'regression' depending on what kind of ML problem to solve.
        :type task: str or constants.Tasks
        :param mode: 'model_based' or 'model_agnostic'.
        :type mode: str or constants.Tasks
        :param metric: 'rmse', 'r2', 'precision', or 'recall' depending on what metric the cutoff takes place.
        :type metric: str or constants.Tasks
        :param metric_cut_off: percentile of full-data set performance metrics.
        :type metric_cut_off: float
        :param preprocess: True or False
        :type preprocess: bool
        :param plot: True or False
        :type plot: bool
        """
        self._logger = _LoggerFactory.get_logger(__name__, client_id=client_id)
        if logger is not None:
            _LoggerFactory.add_handler(self._logger, logger)

        self._task_type = task
        # TODO add user defined mode, model, metric to run selector
        self.mode = mode
        self.model = model
        if metric is None:
            if self._task_type == constants.Tasks.REGRESSION:
                self.metric = "rmse"
            else:
                self.metric = "accuracy"
        self._cutoff_percentile = metric_cut_off
        self._plot = plot
        self._preprocess = preprocess

        self._percent_list = [1.0]
        self._eval_metrics = dict()
        self._num_of_class = -1
        self.cutoff = -1

        self._raw_feat_name_to_eng_feat_index = None
        self._eng_X_train = None
        self._eng_X_valid = None

        self._top_feature_selector = SelectTopFeatures(task=task, preprocess=preprocess,
                                                       client_id=client_id, logger=logger)
        self._data_preprocessor = DataPreprocessor(task=task, preprocess=preprocess,
                                                   client_id=client_id, logger=logger)

    @function_log_activity
    def fit(self, X, y):
        """
        Entrance to selector, later on more function calls can be added here, e.g. plotting.

        :param X: training feature set
        :type X: pandas.DataFrame, numpy.ndarray, sparse matrix
        :param y: training set label
        :type y: pandas.Series, numpy.ndarray
        :return: selector
        :rtype: AutoFeatureSelector()
        """
        if isinstance(y, pd.DataFrame):
            y_values = y.values.ravel()
        else:
            y_values = y

        if self._task_type == constants.Tasks.CLASSIFICATION:
            self._num_of_class = len(np.unique(y_values))
            if self._num_of_class < 2:
                raise ValueError('number of classes should not be less than 2. The number of classes is: {}'
                                 .format(self._num_of_class))
        self._init_perf_metrics()
        self._performance_versus_percent_of_features(X, y, step=20)
        if self._plot:
            self._plot_perf_vs_perc()
        return self

    @function_log_activity
    def transform(self, X):
        """
        Filter X with selected raw feature columns and return the filtered data.

        :param X: raw feature set
        :type X: pandas.DataFrame, numpy.ndarray, sparse matrix
        :return: selected features
        :rtype: pandas.DataFrame
        """
        selected_percent = -1 if self.cutoff == -1 else self._percent_list[self.cutoff]
        self._top_feature_selector.set_top_percentile(selected_percent)
        return self._top_feature_selector.transform(X)

    @function_log_activity
    def fit_transform(self, X, y):
        """
        Call fit method first then transform method.

        :param X: training feature set
        :type X: pandas.DataFrame, numpy.ndarray, sparse matrix
        :param y: training set label
        :type y: pandas.Series, numpy.ndarray
        :return: selected features
        :rtype: pandas.DataFrame
        """
        return self.fit(X, y).transform(X)

    def _init_perf_metrics(self):
        """Initialize performance metrics to evaluate feature subsets."""
        if self._task_type == constants.Tasks.REGRESSION:
            for metric_name in Metrics.REGRESSION:
                self._eval_metrics[metric_name] = []
        else:
            if self._num_of_class <= 2:
                for metric_name in Metrics.BINARYCLASSIFICATION:
                    self._eval_metrics[metric_name] = []
            else:
                for metric_name in Metrics.MULTICLASSIFICATION:
                    self._eval_metrics[metric_name] = []

    def _performance_versus_percent_of_features(self, X, y, step):
        """
        Calculate performance metrics versus percentage of features Iteratively.

        :param X: training feature set
        :type X: pandas.DataFrame, numpy.ndarray, sparse matrix
        :param y: training set label
        :type y: pandas.Series, numpy.ndarray
        :param step: how many steps to calculate metric.
        :type step: integer
        """
        X_train, X_valid, y_train, y_valid = train_test_split(X, y, random_state=20, test_size=0.2)
        self._top_feature_selector.fit(X_train, y_train)
        self._cal_perf_metrics(X_train, X_valid, y_train, y_valid)

        perf_benchmark = self._cal_cutoff_point()

        for index in range(step):

            percent = (index + 1) * float(1.0) / step
            if percent > float(1.0):
                percent = float(1.0)
            self._percent_list.append(percent)
            self._top_feature_selector.set_top_percentile(percent)
            print("Calculating % of features at " + str(percent) + "...")
            self._cal_perf_metrics(X_train, X_valid, y_train, y_valid)

            if self.metric == "rmse":
                if self.cutoff == -1 and self._eval_metrics[self.metric][-1] <= perf_benchmark:
                    self.cutoff = len(self._eval_metrics[self.metric]) - 1
            else:
                if self.cutoff == -1 and self._eval_metrics[self.metric][-1] >= perf_benchmark:
                    self.cutoff = len(self._eval_metrics[self.metric]) - 1

            if self.cutoff != -1 and self._plot is False:
                log_msg(self._logger, logging.INFO, 'Cutoff point is found at {0}'.format(self.cutoff))
                break

        if self.cutoff == -1:
            warnings.warn("No cutoff point found. Try setting plot = True "
                          "to check model metrics vs. feature number curve to gain more info")

    def _cal_perf_metrics(self, X_train, X_valid, y_train, y_valid):
        """
        Use different selected feature subsets to calculate performance metrics.

        :param X_train: training feature set
        :type X_train: pandas.DataFrame, numpy.ndarray, sparse matrix
        :param X_valid: validation feature set
        :type X_valid: pandas.DataFrame, numpy.ndarray, sparse matrix
        :param y_train: training set label
        :type y_train: pandas.Series, numpy.ndarray
        :param y_valid: validation set label
        :type y_valid: pandas.Series, numpy.ndarray
        """
        X_train_selected = self._top_feature_selector.transform(X_train)
        X_valid_selected = self._top_feature_selector.transform(X_valid)
        selected_feat_names = self._top_feature_selector.transformed_X_raw_column_names_
        X_train_eng, X_valid_eng, y_train_eng, y_valid_eng = \
            self._raw_data_transform(X_train_selected, X_valid_selected, y_train, y_valid, selected_feat_names)

        if self._task_type == constants.Tasks.REGRESSION:
            rmse, r2 = self._eval_lightgbm(X_train_eng, y_train_eng, X_valid_eng, y_valid_eng, 1000)
            self._eval_metrics["rmse"].append(rmse)
            self._eval_metrics["r2"].append(r2)
        elif self._task_type == constants.Tasks.CLASSIFICATION:
            if self._num_of_class <= 2:
                roc_auc, precision, recall, accuracy, f1 = self._eval_lightgbm(
                    X_train_eng, y_train_eng, X_valid_eng, y_valid_eng, 1000)

                self._eval_metrics["roc_auc"].append(roc_auc)
                self._eval_metrics["precision"].append(precision)
                self._eval_metrics["recall"].append(recall)
                self._eval_metrics["accuracy"].append(accuracy)
                self._eval_metrics["f1"].append(f1)
            else:
                accuracy_score_value = self._eval_lightgbm(
                    X_train_eng, y_train_eng, X_valid_eng, y_valid_eng, 1000)
                self._eval_metrics["accuracy"].append(accuracy_score_value)

    def _cal_cutoff_point(self):
        """
        Use curoff percentile to determine the performance bench mark.

        :return: a performance metric cutting point.
        :rtype: float
        """
        perf_benchmark = self._eval_metrics[self.metric][0]
        if self.metric == "rmse":
            perf_benchmark = self._eval_metrics[self.metric][0] * (2.0 - self._cutoff_percentile)
        else:
            perf_benchmark = self._eval_metrics[self.metric][0] * self._cutoff_percentile

        return perf_benchmark

    def _plot_perf_vs_perc(self):
        """Plot performance metrics versus percentile of features."""
        plt.title("Model Performance vs. % of Features")
        plt.xlabel("% of features")
        plt.plot(self._percent_list[1:], self._eval_metrics[self.metric][1:], 'r--', label=self.metric)

        plt.legend()

        plt.show()

    def _eval_lightgbm(self, X_train, y_train, X_valid, y_valid, epoch):
        """
        Use lightGBM to evaluate selected feature set.

        :param X_train: training feature set
        :type X_train: pandas.DataFrame
        :param y_train: training set label
        :type y_train: pandas.DataFrame
        :param X_valid: validation feature set
        :type X_valid: pandas.DataFrame
        :param y_valid: validation set label
        :type y_valid: pandas.DataFrame
        :param epoch: number of epoch for lightGBM
        :type epoch: int
        :return: (rmse, r2) or (roc_auc_score_value, precision_score_value,
                 recall_score_value, accuracy_score_value, f1_score_value)
                 or accuracy
        :rtype: tuple <-- (a number of float types) or float
        """
        gbm = lightgbm.train_lightgbm_model(self._task_type, X=None, y=None, X_train=X_train, y_train=y_train,
                                            X_test=X_valid, y_test=y_valid, epoch=epoch)
        if self._task_type == constants.Tasks.REGRESSION:
            y_pred = gbm.predict(X_valid, num_iteration=gbm.best_iteration)
            rmse = mean_squared_error(y_valid, y_pred) ** 0.5
            r2 = r2_score(y_valid, y_pred)

            return rmse, r2
        else:
            if self._num_of_class <= 2:
                y_prob = gbm.predict(X_valid, num_iteration=gbm.best_iteration)
                y_pred = np.where(y_prob <= 0.5, 0, 1)
                roc_auc_score_value = roc_auc_score(y_valid, y_prob)
                precision_score_value = precision_score(y_valid, y_pred)
                recall_score_value = recall_score(y_valid, y_pred)
                accuracy_score_value = accuracy_score(y_valid, y_pred)
                f1_score_value = f1_score(y_valid, y_pred)

                return roc_auc_score_value, precision_score_value, recall_score_value, accuracy_score_value, \
                    f1_score_value
            else:
                y_prob = gbm.predict(X_valid, num_iteration=gbm.best_iteration)
                y_pred = []

                for x in y_prob:
                    y_pred.append(np.argmax(x))
                accuracy_score_value = accuracy_score(y_valid, y_pred)

                return accuracy_score_value

    def _get_eng_feat_indices_based_on_raw_ranking(self, raw_feat_names):
        """
        Get engineering feature indices from raw feature ranking.

        :param raw_feat_names: raw feature names
        :type raw_feat_names: dict
        :return: a list of engineering indices.
        :rtype: list
        """
        eng_indices = []
        for name in raw_feat_names:
            eng_indices.extend(self._raw_feat_name_to_eng_feat_index[name])
        return eng_indices

    def _raw_data_transform(self, X_train, X_valid, y_train, y_valid, raw_feature_names):
        """
        Transform raw training features and validation features into engineering features.

        :param X_train: training feature set
        :type X_train: pandas.DataFrame
        :param X_valid: validation feature set
        :type X_valid: pandas.DataFrame
        :param raw_feature_names: raw feature names
        :type raw_feature_names: dict
        :return: engineering training features and engineering validation features.
        :rtype: tuple <-- (pandas.DataFrame / scipy.sparse.csr_matrix)
        """
        if self._eng_X_train is None and self._eng_X_valid is None:
            # Extract numpy array out of whatever input data then concat X_train and X_valid sets.
            # Column names is to generate raw feature name to engineered feature index mapping
            X_train, X_valid, y_train, y_valid, X_column_names = \
                self._extract_array(X_train, X_valid, y_train, y_valid)
            if self._data_preprocessor.is_sparse:
                if self._preprocess:
                    X_train_eng = self._data_preprocessor.convert_X_to_numeric_sparse(X_train)
                    X_valid_eng = self._data_preprocessor.convert_X_to_numeric_sparse(X_valid)
                else:
                    _, _ = feature_selection_utilities.validate_no_nan_sparse(X_train, y_train)
                    _, _ = feature_selection_utilities.validate_no_nan_sparse(X_valid, y_valid)
                    X_train_eng, X_valid_eng = X_train, X_valid
            else:
                # Construct DataFrames to include column names so featurizer contains the name to index mapping
                X_train_df = pd.DataFrame(X_train, columns=X_column_names)
                X_valid_df = pd.DataFrame(X_valid, columns=X_column_names)
                if self._preprocess:
                    X_train_eng, featurizer, _ = self._data_preprocessor.convert_X_to_numeric(X_train_df)
                    X_valid_eng = featurizer.transform(X_valid_df)
                    # Store raw feature name to eng feature index mapping.
                    self._raw_feat_name_to_eng_feat_index = \
                        feature_selection_utilities.get_eng_feat_dict(featurizer)[1]
                else:
                    X_train_eng = self._data_preprocessor.validate_no_nan(X_train_df)
                    X_valid_eng = self._data_preprocessor.validate_no_nan(X_valid_df)
            # Store engineering X_train and X_valid
            self._eng_X_train, self._eng_X_valid = X_train_eng, X_valid_eng
        else:
            if self._preprocess and not self._data_preprocessor.is_sparse:
                X_train_eng = self._select_eng_feat_from_raw_names(self._eng_X_train, raw_feature_names)
                X_valid_eng = self._select_eng_feat_from_raw_names(self._eng_X_valid, raw_feature_names)
            else:
                X_train_eng = X_train
                X_valid_eng = X_valid

        # If the X data is in integer format, then the data needs to reformated into float data
        # for LightGBM surrogate model.
        if isinstance(X_train_eng, csr_matrix):
            X_train_eng = training_utilities._upgrade_sparse_matrix_type(X_train_eng)
        if isinstance(X_valid_eng, csr_matrix):
            X_valid_eng = training_utilities._upgrade_sparse_matrix_type(X_valid_eng)

        y_train_eng = self._data_preprocessor.convert_y_to_numeric(y_train)
        y_valid_eng = self._data_preprocessor.convert_y_to_numeric(y_valid)

        return X_train_eng, X_valid_eng, y_train_eng, y_valid_eng

    def _extract_array(self, X_train, X_valid, y_train, y_valid):
        """
        Extract feature and target columns to numpy array.

        :param X_train: training feature set
        :type X_train: pandas.DataFrame / numpy.ndarray / scipy.sparse.csr_matrix
        :param X_valid: validating feature set
        :type X_valid: pandas.DataFrame / numpy.ndarray / scipy.sparse.csr_matrix
        :param y_train: training target column
        :type y_train: pandas.DataFrame / numpy.ndarray
        :param y_valid: validating target column
        :type y_valid: pandas.DataFrame / numpy.ndarray
        :return: extracted training and validating arrays and list of column names
        :rtype: list[numpy.ndarray / scipy.sparse.csr_matrix, list[str]]
        """
        _, X_train_arr, X_column_names, y_train_arr, _ = \
            self._data_preprocessor.check_input_format_extract_data(X_train, y_train)
        _, X_valid_arr, _, y_valid_arr, _ = self._data_preprocessor.check_input_format_extract_data(X_valid, y_valid)
        return X_train_arr, X_valid_arr, y_train_arr, y_valid_arr, X_column_names

    def _select_eng_feat_from_raw_names(self, X, raw_feature_names):
        """
        Map raw feature names to engineering features.

        :param X: engineering feature set
        :type X: numpy.ndarray / scipy.sparse.csr_matrix
        :param raw_feature_names: raw feature names
        :type raw_feature_names: dict
        :return: selected engineering feature subset
        :rtype: numpy.ndarray / scipy.sparse.csr_matrix
        """
        mask = np.full(X.shape[1], False, dtype=bool)
        eng_indices = self._get_eng_feat_indices_based_on_raw_ranking(raw_feature_names)
        mask[eng_indices] = True

        if isinstance(X, csr_matrix) or isinstance(X, np.ndarray):
            return X[:, mask]
        else:
            return X.iloc[:, mask]
