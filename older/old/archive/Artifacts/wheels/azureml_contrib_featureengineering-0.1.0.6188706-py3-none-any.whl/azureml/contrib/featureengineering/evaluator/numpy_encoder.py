# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Special json encoder for numpy.ndarray type."""

import json

import numpy as np


class NumpyEncoder(json.JSONEncoder):
    """Extend json encoder to recognize numpy.ndarray type."""

    def default(self, obj):
        """
        Override default to serialize numpy.ndarray type.

        :param obj: object passed in.
        :type obj: Object
        :return: serializable object.
        :rtype: object
        """
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return json.JSONEncoder.default(self, obj)
