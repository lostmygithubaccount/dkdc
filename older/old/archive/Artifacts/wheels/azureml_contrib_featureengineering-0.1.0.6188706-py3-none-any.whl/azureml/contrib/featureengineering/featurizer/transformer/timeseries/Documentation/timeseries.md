# Time series terminology.

The purpose of this document is to describe the terminology used in the time series forecasting.

**Origin** represents the latest date from which actual values of all features are assumed to be known with certainty.  
**Lag** Assuming that we know the data only for the completed periods lag\_0 and lead\_0 correspond to the most recent observation known with certainty i.e. for the completed period preceding the forecast. lag\_1 is corresponds to one period before lag\_0, while lead\_1 to one period ahead lag\_0. 
**Lead** For a time series x, the value of x_lead1 is the nearest value of x in future that is known to us at the time of constructing the forecast.  Lead operator is the inverse of the lag operator.
For example if we have period of 7 days and we want to estimate lag or lead value on 22th day, then the values for lag\_0 and lead\_0 will be the value on 15th day, for lag\_1 and lead\_1 will be 8th and 29th accordingly.  
**Horizon** the number of steps ahead or behind the date to be forecasted. The size of step is defined by the data frequency. For example if the data is updated weekly, it will be one week.