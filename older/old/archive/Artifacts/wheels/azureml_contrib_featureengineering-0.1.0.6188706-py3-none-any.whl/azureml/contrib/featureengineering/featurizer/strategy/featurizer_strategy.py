# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Featurizer strategy class."""

import json
import logging
from typing import List, Optional, Dict, Any
from sklearn.base import TransformerMixin

from azureml.contrib.featureengineering.common import utilities
from azureml.contrib.featureengineering.featurizer import (FeatureType, ColumnInfo, AutoTransformation,
                                                           TimeSeriesFeatureType)
from azureml.contrib.featureengineering.featurizer.strategy import ColumnStrategy, TimeSeriesStrategy
from azureml.contrib.featureengineering.common.logging import _LoggerFactory, function_log_activity


class FeaturizerStrategy:
    """Container for FeaturizerStrategy."""

    def __init__(self, is_onnx_compatible: bool = False, client_id: str = "unknown",
                 logger: Optional[logging.Logger] = None):
        """
        Construct featurizer strategy object.

        :param is_onnx_compatible: whether to do onnx compatible transformations
        :param client_id: client id of the caller.
        :param logger: External logger if None, then no logs
        """
        # External logger if None, then no logs
        self._logger = _LoggerFactory.get_logger(__name__, client_id=client_id)
        if logger is not None:
            _LoggerFactory.add_handler(self._logger, logger)
        # whether to do onnx compatible transformations.
        self._is_onnx_compatible = is_onnx_compatible
        # key: column names.
        # value: column strategy object.
        # For one column, it would be pretty simple, the key is just the column name, while
        # for multiple columns, it will be like: column1_column2 etc.
        self._column_strategy_dict = {}
        # for auto transformation strategy.
        self._auto_transformation = AutoTransformation()
        # for type name and column names mapping. The key is type name, while the values are
        # list of column name. E.g. {'Numeric', ['col1', 'col2']}
        self._type_columns_dict = {}
        # the set of timeseries column names.
        self._ts_columns = set()
        # the timeseries strategy.
        self._timeseries_strategy = TimeSeriesStrategy(False, dict())

    @function_log_activity
    def load_featurizer_strategy(self, is_onnx_compatible: bool, columns_strategy: [ColumnStrategy],
                                 columns_info: {str, ColumnInfo}, enable_timeseries_transform: bool,
                                 ts_param_dict: Dict[str, Any]):
        """
        Load column and timeseries strategy.

        :param is_onnx_compatible: whether to do onnx compatible transformations.
        :param columns_strategy: list of ColumnStrategy.
        :param columns_info: dictionary, the key the column name while the value is column info of the column.
        :param enable_timeseries_transform: whether to enable the timeseries transformer.
        :param ts_param_dict: timeseries parameter dictionary.
        """
        self._is_onnx_compatible = is_onnx_compatible
        for column_strategy in columns_strategy:
            columns_name = self.generate_column_name(column_strategy.column_names)
            feature_type_name = column_strategy.feature_type_name
            self._column_strategy_dict[columns_name] = column_strategy
            if feature_type_name and len(column_strategy.column_names) == 1:
                if feature_type_name not in self._type_columns_dict:
                    self._type_columns_dict[feature_type_name] = []
                self._type_columns_dict[feature_type_name].append(columns_name)
        self.set_timeseries_params(columns_info, enable_timeseries_transform, ts_param_dict)

    @function_log_activity
    def load_default_featurizer_strategy(self, columns_info: {str, ColumnInfo}, enable_timeseries_transform: bool,
                                         ts_param_dict: Dict[str, Any]):
        """
        Load default column strategy from columns info.

        :param columns_info: dictionary, the key the column name while the value is column info of the column.
        :param enable_timeseries_transform: whether to enable the timeseries transformer.
        :param ts_param_dict: timeseries parameter dictionary.
        """
        for column_name, column_info in columns_info.items():
            transformers = self._get_default_column_strategy(column_info)
            column_strategy = ColumnStrategy([column_name], column_info.feature_type.name, transformers)
            self._column_strategy_dict[column_name] = column_strategy
            feature_type_name = column_info.feature_type.name
            if feature_type_name not in self._type_columns_dict:
                self._type_columns_dict[feature_type_name] = []
            self._type_columns_dict[feature_type_name].append(column_name)
            if column_info.get_timeseries_column_type() is not TimeSeriesFeatureType.NA:
                self._ts_columns.add(column_name)
        self.set_timeseries_params(columns_info, enable_timeseries_transform, ts_param_dict)

    @function_log_activity
    def set_timeseries_params(self, columns_info: {str, ColumnInfo}, enable_timeseries_transform: bool,
                              ts_param_dict: Dict[str, Any]):
        """
        Set timeseries column params.

        :param columns_info: dictionary, the key the column name while the value is column info of the column.
        :param enable_timeseries_transform: whether to enable the timeseries transformer.
        :param ts_param_dict: timeseries parameter dictionary.
        """
        self._ts_columns = set()
        if columns_info is not None:
            for column_name, column_info in columns_info.items():
                if column_info.is_a_timeseries_column():
                    self._ts_columns.add(column_name)
                    if column_name in self._column_strategy_dict:
                        self._column_strategy_dict.pop(column_name)
                elif column_name not in self._column_strategy_dict:
                    # if the column was previous timeseries column, but it is going to be a regular
                    # column, we should call set_feature_type with feature_type_from to empty str.
                    self.set_feature_type(column_name, column_info, '', column_info.feature_type.name)
        self._timeseries_strategy = TimeSeriesStrategy(enable_timeseries_transform, ts_param_dict)

    @function_log_activity
    def add_column_transformer(self, cols: List[str], transformers: List[TransformerMixin]):
        """
        Add transformers with list of columns.

        :param cols:  list of column names.
        :param transformers: list of transformers.
        """
        columns_name = self.generate_column_name(cols)
        if columns_name not in self._ts_columns:
            # To add transformers to the column dictionary.
            if columns_name not in self._column_strategy_dict:
                if len(cols) == 1:
                    raise ValueError("Error: column name doesn't exist in column strategy.")
                else:
                    # try to handle multiple columns case.
                    self._column_strategy_dict[columns_name] = ColumnStrategy(cols, "", [])
            self._column_strategy_dict[columns_name].transformers.append(transformers)
        else:
            logging.warning("Cannot customize transformer on timeseries column: {0}".format(columns_name))

    @function_log_activity
    def add_feature_type_transformer(self, feature_type: FeatureType, transformers: List[TransformerMixin]):
        """
        Add transformers to the feature type.

        :param feature_type: feature type name.
        :param transformers: list of transformers.
        """
        feature_type_name = feature_type.name
        if feature_type_name in self._type_columns_dict:
            # iterate all of the columns that belong to this type for adding transformers.
            for column_name in self._type_columns_dict[feature_type_name]:
                if column_name not in self._ts_columns:
                    self.add_column_transformer([column_name], transformers)

    @function_log_activity
    def set_column_transformer(self, cols: List[str], transformers: List[TransformerMixin]):
        """
        Set transformers to list of columns.

        :param cols: list of column names.
        :param transformers: list of transformers.
        """
        columns_name = self.generate_column_name(cols)
        if columns_name not in self._ts_columns:
            if columns_name not in self._column_strategy_dict:
                raise ValueError("Error: column name doesn't exist in column strategy.")
            self._column_strategy_dict[columns_name].transformers = [transformers]
        else:
            logging.warning("Cannot customize transformer on timeseries column: {0}".format(columns_name))

    @function_log_activity
    def set_feature_type_transformer(self, feature_type: FeatureType, transformers: List[TransformerMixin]):
        """
        Set transformers to the feature type.

        :param feature_type: feature type name.
        :param transformers: list of transformers.
        """
        feature_type_name = feature_type.name
        if feature_type_name in self._type_columns_dict:
            # iterate all of the columns that belong to this type for adding transformers.
            for column_name in self._type_columns_dict[feature_type_name]:
                if column_name not in self._ts_columns:
                    self.set_column_transformer([column_name], transformers)

    @function_log_activity
    def remove_column_transformer(self, cols: List[str]):
        """
        Remove all transformers that associated with the columns.

        :param cols: list of column names.
        """
        columns_name = self.generate_column_name(cols)
        if columns_name not in self._ts_columns:
            # To handle column transformer dictionary
            if columns_name not in self._column_strategy_dict:
                raise ValueError("Error: column name doesn't exist in column strategy.")
            self._column_strategy_dict[columns_name].transformers = []
        else:
            logging.warning("Cannot customize transformer on timeseries column: {0}".format(columns_name))

    @function_log_activity
    def remove_feature_type_transformer(self, feature_type: FeatureType):
        """
        Remove transformers of this feature type.

        :param feature_type: feature type name.
        """
        feature_type_name = feature_type.name
        if feature_type_name in self._type_columns_dict:
            # iterate all of the columns that belong to this type for adding transformers.
            for column_name in self._type_columns_dict[feature_type_name]:
                if column_name not in self._ts_columns:
                    self.remove_column_transformer([column_name])

    @function_log_activity
    def set_feature_type(self, column_name: str, column_info: ColumnInfo, feature_type_name_from: str,
                         feature_type_name_to: str):
        """
        Set feature type for one column.

        :param column_name: column name
        :param column_info: the column info of this column.
        :param feature_type_name_from: the original feature type name.
        :param feature_type_name_to: the new feature type name.
        """
        if feature_type_name_from in self._type_columns_dict:
            if column_name in self._type_columns_dict[feature_type_name_from]:
                self._type_columns_dict[feature_type_name_from].remove(column_name)
        if feature_type_name_to not in self._type_columns_dict:
            self._type_columns_dict[feature_type_name_to] = []
        self._type_columns_dict[feature_type_name_to].append(column_name)
        transformers = self._get_default_column_strategy(column_info)
        column_strategy = ColumnStrategy([column_name], feature_type_name_to, transformers)
        self._column_strategy_dict[column_name] = column_strategy

    @function_log_activity
    def get_featurizer_strategy(self):
        """
        Get feature strategy.

        :return: tuple of column strategy dictionary and timeseries strategy.
        """
        return self._column_strategy_dict, self._timeseries_strategy

    @function_log_activity
    def _get_default_column_strategy(self, column_info):
        """
        Get default feature strategy based on the column info.

        :param column_info: the column info of one column.
        """
        return self._auto_transformation.get_column_transformers(column_info, self._is_onnx_compatible, self._logger)

    @function_log_activity
    def load_json(self, json_string: str = None, file_path: str = None):
        """
        Load json object for initialization.

        :param json_string: json string
        :param file_path: the file path for json string.
        """
        if json_string is None and file_path is not None:
            json_string = utilities.read_files(file_path)
        try:
            dct = json.loads(json_string)
            self._is_onnx_compatible = dct['is_onnx_compatible']
            self._column_strategy_dict = dict(
                map(lambda kv: (kv[0], self._construct_column_strategy_from_dict(kv[1])),
                    dct['column_strategies'].items()))
            self._timeseries_strategy = self._construct_timeseries_strategy_from_dict(dct['timeseries_strategy'])
            return self
        except TypeError:
            raise ValueError("Unable to deserialize the json string to strategy dict object")

    @function_log_activity
    def save_json(self, file_path: str = None):
        """
        Save json to file.

        :param file_path: the file path for saving.
        """
        strategy_dict = dict()
        strategy_dict['is_onnx_compatible'] = self._is_onnx_compatible
        strategy_dict['column_strategies'] = \
            dict(map(lambda kv: (kv[0], kv[1].to_dict()), self._column_strategy_dict.items()))
        strategy_dict['timeseries_strategy'] = self._timeseries_strategy.to_dict()
        try:
            json_string = json.dumps(strategy_dict)
            if file_path is not None:
                utilities.save_files(json_string, file_path)
            return json_string
        except TypeError:
            raise ValueError("Unable to serialize the strategy dict object to json")

    @staticmethod
    def generate_column_name(cols: List[str]):
        """
        Concatenate list of column names.

        :param cols: list of column names.
        """
        cols.sort()
        return '-'.join(cols)

    @staticmethod
    def _construct_column_strategy_from_dict(dct: Dict[str, Any]):
        """
        Construct column strategy from dictionary.

        :param dct: a dictionary.
        :return: a column strategy.
        """
        column_strategy = ColumnStrategy()
        column_strategy = column_strategy.from_dict(dct)
        return column_strategy

    @staticmethod
    def _construct_timeseries_strategy_from_dict(dct: Dict[str, Any]):
        """
        Construct timeseries strategy from dictionary.

        :param dct: a dictionary.
        :return: a timeseries strategy.
        """
        timeseries_strategy = TimeSeriesStrategy(enable_timeseries_transform=False, ts_param_dict=dict())
        timeseries_strategy = timeseries_strategy.from_dict(dct)
        return timeseries_strategy
