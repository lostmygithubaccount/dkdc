# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""TimeSeriesFeatureType class."""

from enum import Enum


class TimeSeriesFeatureType(Enum):
    """Class for storing the feature types that the pre-processor recognizes."""

    NA = 0,
    Time = 1,
    Grain = 2,
    Drop = 3,
    TS_Value = 4,
    Transform = 5
    # TODO: support more feature types

    @staticmethod
    def from_str(label: str):
        """
        Construct TimeSeriesFeatureType from a string.

        :param label: time series feature type name in string.
        :type label: str
        :return: TimeSeriesFeatureType object.
        :rtype: TimeSeriesFeatureType
        """
        for feature_type in TimeSeriesFeatureType:
            if label.lower() == feature_type.name.lower():
                return feature_type
        return None
