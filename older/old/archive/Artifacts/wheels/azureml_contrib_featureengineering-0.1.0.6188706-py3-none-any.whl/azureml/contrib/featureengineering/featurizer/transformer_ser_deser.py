# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Class used for Transformer and serializable dictionary conversion."""
from typing import Dict, Any

from azureml.contrib.featureengineering.featurizer import TransformerConfig, FeaturizerFactory
from sklearn.base import TransformerMixin
from sklearn.cluster import MiniBatchKMeans
from sklearn.preprocessing import Imputer, MaxAbsScaler
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer


def transformer_from_dict(transformer_dict: Dict[str, Any]):
    """
    Create transformer object from a serializable dictionary.

    :param transformer_dict: A serializable dictionary of a transformer.
    :type transformer_dict: Dict[str, Any]
    :return: A transformer object that created from input dictionary.
    :rtype: TransformerMixin
    """
    obj = TransformerConfig.from_dict(transformer_dict)
    transformer = FeaturizerFactory.get(obj)
    return transformer


def transformer_to_dict(transformer: TransformerMixin):
    """
    Create a serializable dictionary from transformer object.

    :param transformer: A transformer object.
    :type transformer: TransformerMixin
    :return: A serializable dictionary of a transformer.
    :rtype: Dict[str, Any]
    """
    return SklearnTransformerHelper.to_dict(transformer)


def imputer_to_dict(imputer: Imputer):
    """
    Create a serializable dictionary from Imputer object.

    :param imputer: A Sklearn Imputer Object.
    :type imputer: TransformerMixin
    :return: A serializable dictionary of an input transformer.
    :rtype: Dict[str, Any]
    """
    dct = {"args": [], "kwargs": {}}  # type: Dict[str, Any]
    dct['id'] = "imputer"
    dct['type'] = "generic"
    dct['kwargs']['missing_values'] = imputer.missing_values
    dct['kwargs']['strategy'] = imputer.strategy
    dct['kwargs']['axis'] = imputer.axis
    dct['kwargs']['verbose'] = imputer.verbose
    dct['kwargs']['copy'] = imputer.copy
    return dct


def minibatchkmeans_to_dict(minibatchkmeans: MiniBatchKMeans):
    """
    Create a serializable dictionary from MiniBatchKMeans object.

    :param minibatchkmeans: A Sklearn MiniBatchKMeans Object.
    :type minibatchkmeans: TransformerMixin
    :return: A serializable dictionary of an input transformer.
    :rtype: Dict[str, Any]
    """
    dct = {"args": [], "kwargs": {}}  # type: Dict[str, Any]
    dct['id'] = "minibatchkmeans_featurizer"
    dct['type'] = "generic"
    dct['kwargs']['n_clusters'] = minibatchkmeans.n_clusters
    dct['kwargs']['init'] = minibatchkmeans.init
    dct['kwargs']['max_iter'] = minibatchkmeans.max_iter
    dct['kwargs']['batch_size'] = minibatchkmeans.batch_size
    dct['kwargs']['verbose'] = minibatchkmeans.verbose
    dct['kwargs']['compute_labels'] = minibatchkmeans.compute_labels
    dct['kwargs']['random_state'] = minibatchkmeans.random_state
    dct['kwargs']['tol'] = minibatchkmeans.tol
    dct['kwargs']['max_no_improvement'] = minibatchkmeans.max_no_improvement
    dct['kwargs']['init_size'] = minibatchkmeans.init_size
    dct['kwargs']['n_init'] = minibatchkmeans.n_init
    dct['kwargs']['reassignment_ratio'] = minibatchkmeans.reassignment_ratio

    return dct


def maxabsscaler_to_dict(maxabsscaler: MaxAbsScaler):
    """
    Create a serializable dictionary from MaxAbsScaler object.

    :param maxabsscaler: A Sklearn MiniBatchKMeans Object.
    :type maxabsscaler: TransformerMixin
    :return: A serializable dictionary of an input transformer.
    :rtype: Dict[str, Any]
    """
    dct = {"args": [], "kwargs": {}}  # type: Dict[str, Any]
    dct['id'] = "maxabsscaler"
    dct['type'] = "generic"
    dct['kwargs']['copy'] = maxabsscaler.copy
    return dct


def count_vectorizer_to_dict(count_vectorizer: CountVectorizer):
    """
    Create a serializable dictionary from CountVectorizer object.

    :param count_vectorizer: A Sklearn MiniBatchKMeans Object.
    :type count_vectorizer: TransformerMixin
    :return: A serializable dictionary of an input transformer.
    :rtype: Dict[str, Any]
    """
    dct = {"args": [], "kwargs": {}}  # type: Dict[str, Any]
    dct['id'] = "count_vectorizer"
    dct['type'] = "text"
    dct['kwargs']['input'] = count_vectorizer.input
    dct['kwargs']['encoding'] = count_vectorizer.encoding
    dct['kwargs']['decode_error'] = count_vectorizer.decode_error
    dct['kwargs']['strip_accents'] = count_vectorizer.strip_accents
    dct['kwargs']['lowercase'] = count_vectorizer.lowercase
    dct['kwargs']['stop_words'] = count_vectorizer.stop_words
    dct['kwargs']['token_pattern'] = count_vectorizer.token_pattern
    dct['kwargs']['max_df'] = count_vectorizer.max_df
    dct['kwargs']['min_df'] = count_vectorizer.min_df
    dct['kwargs']['max_features'] = count_vectorizer.max_features
    dct['kwargs']['binary'] = count_vectorizer.binary
    return dct


def tfidf_vectorizer_to_dict(tfidf_vectorizer: TfidfVectorizer):
    """
    Create a serializable dictionary from TfidfVectorizer object.

    :param tfidf_vectorizer: A Sklearn MiniBatchKMeans Object.
    :type tfidf_vectorizer: TransformerMixin
    :return: A serializable dictionary of an input transformer.
    :rtype: Dict[str, Any]
    """
    dct = {"args": [], "kwargs": {}}  # type: Dict[str, Any]
    dct['id'] = "tfidf_vectorizer"
    dct['type'] = "text"
    dct['kwargs']['input'] = tfidf_vectorizer.input
    dct['kwargs']['encoding'] = tfidf_vectorizer.encoding
    dct['kwargs']['decode_error'] = tfidf_vectorizer.decode_error
    dct['kwargs']['strip_accents'] = tfidf_vectorizer.strip_accents
    dct['kwargs']['lowercase'] = tfidf_vectorizer.lowercase
    dct['kwargs']['stop_words'] = tfidf_vectorizer.stop_words
    dct['kwargs']['token_pattern'] = tfidf_vectorizer.token_pattern
    dct['kwargs']['max_df'] = tfidf_vectorizer.max_df
    dct['kwargs']['min_df'] = tfidf_vectorizer.min_df
    dct['kwargs']['max_features'] = tfidf_vectorizer.max_features
    dct['kwargs']['binary'] = tfidf_vectorizer.binary
    dct['kwargs']['norm'] = tfidf_vectorizer.binary
    dct['kwargs']['use_idf'] = tfidf_vectorizer.use_idf
    dct['kwargs']['smooth_idf'] = tfidf_vectorizer.smooth_idf
    dct['kwargs']['sublinear_tf'] = tfidf_vectorizer.sublinear_tf

    return dct


class SklearnTransformerHelper:
    """Helper class for Sklearn transformers."""

    _transformer_function_dict = {
        Imputer.__name__: imputer_to_dict,
        MiniBatchKMeans.__name__: minibatchkmeans_to_dict,
        MaxAbsScaler.__name__: maxabsscaler_to_dict,
        CountVectorizer.__name__: count_vectorizer_to_dict,
        TfidfVectorizer.__name__: tfidf_vectorizer_to_dict
    }

    @classmethod
    def to_dict(cls, transformer):
        """
        Convert transformer to a serializable dict.

        :param cls:
        :type cls:
        :param transformer: A transformer object.
        :type transformer: TransformerMixin
        :return: a dict of transformer.
        :rtype: Dict[str, Any]
        :raise: Exception
        """
        if transformer.__class__.__name__ in cls._transformer_function_dict:
            return cls._transformer_function_dict[transformer.__class__.__name__](transformer)
        elif hasattr(transformer, '_to_dict'):
            try:
                return transformer._to_dict()
            except Exception as e:
                raise Exception("Error calling to_dict in transformer object. Error: {}".format(e))
