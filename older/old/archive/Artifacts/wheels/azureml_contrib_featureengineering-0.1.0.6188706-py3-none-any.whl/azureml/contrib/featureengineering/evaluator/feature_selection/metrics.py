# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Cutoff Metrics for Auto Feature Selector."""


class Metrics:
    """Names for the types of machine learning tasks supported."""

    BINARYCLASSIFICATION = {"precision", "recall", "roc_auc", "accuracy", "f1"}
    MULTICLASSIFICATION = {"accuracy"}
    REGRESSION = {"rmse", "r2"}

    ALL = [BINARYCLASSIFICATION, MULTICLASSIFICATION, REGRESSION]
