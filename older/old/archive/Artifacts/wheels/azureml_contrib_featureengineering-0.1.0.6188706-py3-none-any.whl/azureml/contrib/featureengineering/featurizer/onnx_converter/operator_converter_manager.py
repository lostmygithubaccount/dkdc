# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Operator manager of onnx conversion module."""
import sys

# -----------------------------------
from . import OnnxConvertConstants
# Import the onnx related packages, only if the python version is less than 3.7.
# The onnx package does not support python 3.7 yet.
if sys.version_info < OnnxConvertConstants.OnnxIncompatiblePythonVersion:
    from sklearn.feature_extraction.text import CountVectorizer

    from skl2onnx.common.data_types import Int64TensorType
    from skl2onnx.common.data_types import FloatTensorType
    from skl2onnx.common.data_types import StringTensorType
    from skl2onnx.common.data_types import DictionaryType
    from skl2onnx.common.data_types import SequenceType

    from skl2onnx import update_registered_converter

    # ----------------
    from skl2onnx.shape_calculators.TextVectorizer import calculate_sklearn_text_vectorizer_output_shapes

    # -----------------------------------
    # onnxmltools modules.
    # Redefine the onnxmltools data type classes, this is needed to fix issue in the
    # onnxmltools.
    import onnxmltools.convert.common.data_types
    onnxmltools.convert.common.data_types.Int64TensorType = Int64TensorType
    onnxmltools.convert.common.data_types.StringTensorType = StringTensorType
    onnxmltools.convert.common.data_types.FloatTensorType = FloatTensorType
    onnxmltools.convert.common.data_types.DictionaryType = DictionaryType
    onnxmltools.convert.common.data_types.SequenceType = SequenceType

# -----------------------------------
# AutoML modules.
from azureml.contrib.featureengineering.core.exceptions import OnnxConvertException       # noqa: E402

# Onnx converter modules.
from . import OnnxConvertConstants       # noqa: E402

from .operator_converters import DataTransformerFeatureConcatenatorConverter       # noqa: E402
from .operator_converters import CatImputerConverter       # noqa: E402
from .operator_converters import HashOneHotVectorizerConverter   # noqa: E402
from .operator_converters import ImputationMarkerConverter    # noqa: E402
from .operator_converters import LaggingTransformerConverter   # noqa: E402
from .operator_converters import StringCastTransformerConverter       # noqa: E402
from .operator_converters import DatetimeTransformerConverter    # noqa: E402
# from .operator_converters import YTransformerLabelEncoderConverter       # noqa: E402
from .operator_converters import OpConverterUtil       # noqa: E402


# ----------------------------------------------------------------
# The operator converter manager class.
# ----------------------------------------------------------------
class OperatorConverterManager:
    """
    The operator converter manager class.

    The central place to hold all the operator converters.
    It will create and register default converters, upper level
    code can also register custom op converters.

    When a converter is registered, it will be setuped, the operator
    classes are responsible of initialize their shape calculator and
    converter methods to the dependent component in skl2onnx package.
    """

    def __init__(self):
        """Construct the operator converter manager."""
        self.inited = False
        # Operator converter registry.
        self.op_converters = {}     # type: Dict[str, _AbstractOperatorConverter]

    def initialize(self):
        """
        Initialize the operator manager.

        This will register the default AutoML operator converters, and the operator
        converters for other packages.
        """
        if not self.inited:
            # Register AutoML shape calculators and converters.
            self._setup_default_operator_converters()
            # Register default shape calculators and converters for other packages.
            self._register_converter_for_count_vectorizer()
            self.inited = True

    def register_op_converter(self, converter, force_overwrite=False):
        """
        Register an operator converter.

        :param converter: operator converter to be registered
        :type converter: _AbstractOperatorConverter
        :param force_overwrite: whether to overwrite the register with same alias
        :type force_overwrite: bool
        """
        alias = converter.get_alias()
        if alias in self.op_converters and not force_overwrite:
            # By default we don't allow register same alias converter.
            raise OnnxConvertException('The operator converter {0} has already been registered.'
                                       .format(alias))
        converter.setup()
        self.op_converters[alias] = converter

    def _setup_default_operator_converters(self):
        # Register AutoML operator converters.
        # -----------------------
        # Transformers.
        self.register_op_converter(CatImputerConverter())
        self.register_op_converter(HashOneHotVectorizerConverter())
        self.register_op_converter(ImputationMarkerConverter())
        self.register_op_converter(LaggingTransformerConverter())
        self.register_op_converter(StringCastTransformerConverter())
        self.register_op_converter(DatetimeTransformerConverter())
        self.register_op_converter(DataTransformerFeatureConcatenatorConverter())

        # -----------------------
        # The Y transformers.
        # self.register_op_converter(YTransformerLabelEncoderConverter())

    def _register_converter_for_count_vectorizer(self):
        update_registered_converter(CountVectorizer,
                                    OnnxConvertConstants.SklearnCountVectorizer,
                                    calculate_sklearn_text_vectorizer_output_shapes,
                                    OpConverterUtil._convert_count_vectorizer_wrapper)
