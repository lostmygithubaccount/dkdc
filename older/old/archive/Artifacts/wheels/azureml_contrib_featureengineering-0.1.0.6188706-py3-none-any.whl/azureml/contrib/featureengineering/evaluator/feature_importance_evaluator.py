# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Internal class to obtain feature importance score."""
import logging
from typing import Optional

import numpy as np
import pandas as pd
import scipy.sparse as sp
from sklearn.exceptions import NotFittedError
from sklearn.feature_selection import VarianceThreshold

from azureml.contrib.featureengineering.common.logging import _LoggerFactory, function_log_activity, log_msg
from azureml.contrib.featureengineering.evaluator import constants
from azureml.contrib.featureengineering.evaluator.feature_selection import feature_selection_utilities, \
    DataPreprocessor


class FeatureImportanceEvaluator:
    """Feature importance evaluator class that can generate feature scoring and select top features."""

    def __init__(self, task=constants.Tasks.CLASSIFICATION, target_name="",
                 methods=[constants.MUTUAL_INFO, constants.PEARSON_CORR, constants.LIGHTGBM, constants.LASSO],
                 mutual_info_weight=constants.MUTUAL_INFO_WEIGHT,
                 pearson_weight=constants.PEARSON_WEIGHT,
                 lightgbm_weight=constants.LIGHTGBM_WEIGHT,
                 lasso_weight=constants.LASSO_WEIGHT,
                 missing_val_threshold=constants.MISSING_VAL_THRESHOLD,
                 variance_threshold=constants.VARIANCE_THRESHOLD, preprocess=True, client_id="unknown",
                 logger: Optional[logging.Logger] = None):
        """
        Initialize feature importance evaluator with params defined.

        :param task: 'classification' or 'regression' depending on what kind of ML problem to solve.
        :type task: str or constants.Tasks
        :param target_name: label column name.
        :type target_name: str
        :param methods: which feature selection methods to apply.
        :type methods: list of strs
        :param mutual_info_weight: weight for mutual information in combined feature importance calculation.
        :type mutual_info_weight: float
        :param pearson_weight: weight for pearson correlation in combined feature importance calculation.
        :type pearson_weight: float
        :param lightgbm_weight: weight for lightgbm feature importance in combined feature importance calculation.
        :type lightgbm_weight: float
        :param lasso_weight: weight for lasso feature importance in combined feature importance calculation.
        :type lasso_weight: float
        :param missing_val_threshold: if number of missing value exceeds the threshold, drop the column in feature
        selection. To disable, set to None.
        :type missing_val_threshold: float or None
        :param variance_threshold: if variance falls below the threshold, drop the column. To disable, set to None.
        :type variance_threshold: float or None
        :param preprocess: whether to apply built-in featurization or not. True means apply built-in featurization to
        the input data before feature scoring. False means do not apply built-in featurization. Will report error if
        input data is not numeric when preprocess=False.
        :type preprocess: bool
        :param client_id: client id of the caller.
        :type client_id: str
        :param logger: External logger handler.
        :type logger: logging.Logger
        """
        self._task_type = task.lower()
        self._logger = _LoggerFactory.get_logger(__name__, client_id=client_id)
        if logger is not None:
            _LoggerFactory.add_handler(self._logger, logger)
        self._client_id = client_id

        if self._task_type not in constants.Tasks.ALL:
            # use log_msg() since self._logger could be None
            raise ValueError('Unrecognized task type {0}. Currently only supporting {1}.'.format(self._task_type,
                                                                                                 constants.Tasks.ALL))
        if target_name is None:
            raise ValueError('Label column must be specified')
        self._target_name = target_name

        if len(methods) == 0:
            methods = [constants.MUTUAL_INFO, constants.PEARSON_CORR, constants.LIGHTGBM, constants.LASSO]
        self._methods = [x.lower() for x in methods]

        self.mutual_info_weight = mutual_info_weight
        self.pearson_weight = pearson_weight
        self.lightgbm_weight = lightgbm_weight
        self.lasso_weight = lasso_weight

        self.missing_val_threshold = missing_val_threshold
        self.variance_threshold = variance_threshold

        self._preprocess = preprocess
        self._data_preprocessor = DataPreprocessor(task=task, preprocess=preprocess,
                                                   client_id=client_id, logger=logger)

    def get_feature_scoring(self, X, y):
        """
        Generate feature scoring.

        :param X: The training input samples.
        :type X: numpy.ndarray, pandas.DataFrame, pandas.SparseDataFrame or scipy.sparse.csr_matrix
        :param y: The target values (class labels in classification, real numbers in regression).
        :type y: numpy.ndarray, pandas.Series or pandas.DataFrame
        :return: raw and eng scoring
        :rtype: tuple
        """
        _, self._X_raw, self._X_raw_column_names, self._y_raw, self._target_name = \
            self._data_preprocessor.check_input_format_extract_data(X, y)
        # below function will fillna if preprocess=True
        # or throw exception if data contains nan and preprocess=False
        self._X_numeric, self._y_numeric, self._X_eng_column_names, self._cols_to_drop_indices = \
            self._convert_X_y_to_numeric(self._X_raw, self._y_raw, self._X_raw_column_names)

        filter_mask = np.full(self._X_raw.shape[1], True, dtype=bool)
        filter_mask[self._cols_to_drop_indices] = False
        return self._calc_scores(self._X_numeric, self._y_numeric,
                                 self._X_eng_column_names if self._preprocess
                                 else self._X_raw_column_names[filter_mask])

    def select_top_features(self, X, n=-1, percentile=-1, missing_val_threshold=constants.MISSING_VAL_THRESHOLD,
                            variance_threshold=constants.VARIANCE_THRESHOLD):
        """
        Select top features given n or percentile.

        :param X: The input data.
        :type X: numpy.ndarray, pandas.DataFrame, pandas.SparseDataFrame or scipy.sparse.csr_matrix
        :param n: number of features to keep.
        :type n: int
        :param percentile: percent of features to keep.
        :type percentile: float
        :param missing_val_threshold:
            if number of missing value exceeds the threshold, drop the column in feature selection.
            To disable, set to None.
        :type missing_val_threshold: float or None
        :param variance_threshold:
            if variance falls below the threshold, drop the column. To disable, set to None.
        :type variance_threshold: float or None
        :return:
            a dictionary.
            raw_mask: mask used to filter input X, type is numpy.ndarray.
            eng_mask: mask used to filter eng X, type is numpy.ndarray, will return empty
            numpy.ndarray if preprccess=False.
            X_out: selected X, type is consistent with input X, i.e. numpy.ndarray,
            pandas.DataFrame, pandas.SparseDataFrame or scipy.sparse.csr_matrix.
            X_out_column_names: column names for selected X, type is numpy.ndarray.
            X_eng_out: selected eng X, type is aligned with input X, i.e. numpy.ndarray,
            pandas.DataFrame, pandas.SparseDataFrame or scipy.sparse.csr_matrix.
            Note if X_eng generated by built-inn featurization is sparse, even if input X
            is pandas.DataFrame or numpy.ndarray, X_eng_out will still be sparse.
            Will return empty numpy.ndarray if preprocess=False.
            X_eng_out_column_names: column names for selected eng X, type is numpy.ndarray,
            will return empty numpy.ndarray if preprocess=False.
            selected_raw_score: feature scoring for selected features, type is pandas.DataFrame.
            selected_eng_score: feature scoring for eng features associated with selected features,
            type is pandas.DataFrame. Will return empty pandas.DataFrame if preprcoess=False.
        :rtype: dict
        """
        self.missing_val_threshold = missing_val_threshold
        self.variance_threshold = variance_threshold

        X_orig, X, X_column_names, _, _ = self._data_preprocessor.check_input_format_extract_data(X)
        n_cols = X.shape[1]
        if not hasattr(self, '_raw_scoring') or self._raw_scoring is None:
            raise NotFittedError(
                "This instance is not fitted yet. Call 'fit' with appropriate arguments before using this method.")

        if n != -1 and n < 0:
            log_msg(self._logger, logging.WARNING,
                    'n should be >=0, <= n_features = {0}; got {1}. Set n to n_features = {0}.'.format(n_cols, n))
            n = n_cols
        if n > n_cols:
            log_msg(self._logger, logging.WARNING,
                    'n should be >=0, <= n_features = {0}; got {1}. Set n to n_features = {0}.'.format(n_cols, n))
            n = n_cols
        if percentile > 1:
            log_msg(self._logger, logging.WARNING,
                    'percentile should be >= 0, <= 1; got {0}. Set percentile to 1.'.format(percentile))
            percentile = 1
        if percentile != -1 and percentile < 0:
            log_msg(self._logger, logging.WARNING,
                    'percentile should be >= 0, >= 1; got {0}. Set percentile to 1.'.format(percentile))
            percentile = 1

        filter_mask = np.full(X.shape[1], True, dtype=bool)
        filter_mask[self._cols_to_drop_indices] = False
        cols_has_feat_importance = self._raw_scoring.loc[self._X_raw_column_names[filter_mask], :]

        if n == -1 and percentile == -1:
            # return all features sorted based on feature importance
            # return the integer indices that would sort the array
            raw_ranking_order = cols_has_feat_importance[constants.FEATURE_IMPORTANCE].values.argsort().tolist()
            raw_ranking_order.reverse()
        elif n == -1:
            # percentile by weight
            raw_ranking_order = feature_selection_utilities.get_top_feature_percentile(cols_has_feat_importance,
                                                                                       percentile)
        else:
            # return n features
            if percentile != -1:
                log_msg(self._logger, logging.WARNING,
                        'Both n and percentile are specified! Use n for feature selection.')
            raw_ranking_order = cols_has_feat_importance[constants.FEATURE_IMPORTANCE].values.argsort().tolist()
            raw_ranking_order.reverse()
            raw_ranking_order = raw_ranking_order[:n]

        if self._preprocess and not self._data_preprocessor.is_sparse:
            featurized_raw_feat_names_to_index = {name: idx for idx, name in
                                                  enumerate(self._featurized_raw_feat_name_to_eng_feat_index)}
            self._raw_feat_index_to_featurized_raw_feat_index = \
                {idx: featurized_raw_feat_names_to_index[name] for idx, name in
                 enumerate(cols_has_feat_importance.index.tolist())}

        raw_mask, eng_mask = self._get_top_features_mask_based_on_ranking(filter_mask, raw_ranking_order, X,
                                                                          self._X_numeric)

        X_out, X_out_column_names = \
            feature_selection_utilities.get_X_based_on_mask_and_input_dtype(X_orig, X, X_column_names, raw_mask,
                                                                            is_eng=False)
        X_eng_out, X_eng_out_column_names = \
            feature_selection_utilities.get_X_based_on_mask_and_input_dtype(X_orig, self._X_numeric,
                                                                            self._X_eng_column_names
                                                                            if self._preprocess else np.empty(0),
                                                                            eng_mask, is_eng=True)

        selected_raw_score, selected_eng_score = \
            self._get_selected_feature_scoring(cols_has_feat_importance, self._eng_scoring, raw_ranking_order)
        return_dict = {'raw_mask': raw_mask, 'eng_mask': eng_mask, 'X_out': X_out,
                       'X_out_column_names': X_out_column_names,
                       'X_eng_out': X_eng_out, 'X_eng_out_column_names': X_eng_out_column_names,
                       'selected_raw_score': selected_raw_score,
                       'selected_eng_score': selected_eng_score}
        return return_dict

    def _get_selected_feature_scoring(self, raw_scoring, eng_scoring, raw_ranking_order):
        """
        Get selected feature scores.

        :param raw_scoring: raw feature scoring.
        :type raw_scoring: pandas.DataFrame
        :param eng_scoring: eng feature scoring.
        :type eng_scoring: pandas.DataFrame
        :param raw_ranking_order: The integer indices that would sort the raw ranking.
        :type raw_ranking_order: list
        :return: selected raw and eng scoring.
        raw_scoring: feature scoring for selected features
        eng_scoring: feature scoring for eng features associated with selected features
        :rtype: tuple(pandas.DataFrame, pandas.DataFrame)
        """
        if self._preprocess:
            if self._data_preprocessor.is_sparse:
                return raw_scoring.iloc[raw_ranking_order], eng_scoring.iloc[raw_ranking_order]
            else:
                eng_indices = self._get_eng_feat_indices_based_on_raw_ranking(raw_ranking_order)
                return raw_scoring.iloc[raw_ranking_order], eng_scoring.iloc[eng_indices]
        else:
            return raw_scoring.iloc[raw_ranking_order], pd.DataFrame()

    def _get_top_features_mask_based_on_ranking(self, filter_mask, raw_ranking_order, X, X_eng):
        """
        Get masks used to filter input X.

        :param filter_mask: mask used to filter columns after missing value ratio and variance check, if
        preprocess=True, also include filtering from built-in featurization.
        :type filter_mask: numpy.ndarray
        :param raw_ranking_order: The integer indices that would sort the raw ranking.
        :type raw_ranking_order: list
        :param X: input X.
        :type X: numpy.ndarray, pandas.DataFrame, pandas.SparseDataFrame or scipy.sparse.csr_matrix
        :param X_eng: eng X.
        :type X_eng: numpy.ndarray, pandas.DataFrame, pandas.SparseDataFrame or scipy.sparse.csr_matrix
        :return: masks used to filter X and eng X. (raw_mask, eng_mask)
        :rtype: tuple(numpy.ndarray, numpy.ndarray)
        """
        raw_mask = np.full(X.shape[1], False, dtype=bool)
        raw_mask[filter_mask] = True

        mask = np.full(X[:, filter_mask].shape[1], False, dtype=bool)
        mask[raw_ranking_order] = True

        raw_mask[raw_mask] &= mask

        if self._preprocess:
            if self._data_preprocessor.is_sparse:
                return raw_mask, mask
            else:
                eng_indices = self._get_eng_feat_indices_based_on_raw_ranking(raw_ranking_order)
                eng_mask = np.full(X_eng.shape[1], False, dtype=bool)
                eng_mask[eng_indices] = True
                return raw_mask, eng_mask
        else:
            return raw_mask, np.empty(0)

    def _get_eng_feat_indices_based_on_raw_ranking(self, raw_ranking_order):
        """
        Get engineered features related to raw features.

        :param raw_ranking_order: The integer indices that would sort the raw ranking order.
        :type raw_ranking_order: list
        :return: The eng indices associated with the raw index.
        :rtype: list
        """
        eng_indices = []
        for idx in raw_ranking_order:
            eng_indices.extend(self._featurized_raw_feat_index_to_eng_feat_indices
                               [self._raw_feat_index_to_featurized_raw_feat_index[idx]])
        return eng_indices

    def _convert_X_y_to_numeric(self, X, y, X_column_names):
        """
        Convert input to numeric.

        Convert X, y to numeric with built-in featurization if preprocess=True,
        else validate there is no nan and the input types are all numeric.

        :param X: The input data.
        :type X: numpy.ndarray
        :param y: The target values.
        :type y: numpy.ndarray
        :param X_column_names: The X column names.
        :type X_column_names: numpy.ndarray
        :return: Tuple of the follow:
        X_numeric: The numeric X.
        y_numeric: The numeric y.
        X_eng_column_names: The column names of output X.
        cols_to_drop_indices: The indices to drop after missing value and variance check. If
        preprocess=True, also include filtered indices from built-in featurization.
        :rtype: tuple(numpy.ndarray, numpy.ndarray, numpy.ndarray, list of ints)
        """
        # there are two cases that we are not dealing with sparse matrix
        # 1. input is not sparse, preprocess=False
        # 2. input is not sparse, preprocess=True, and input only has numeric features
        y_numeric = self._data_preprocessor.convert_y_to_numeric(y)
        X_filtered, X_filtered_column_names, cols_to_drop_indices, self._missing_val_ratio, self._variance = \
            self._filter_cols(X, y_numeric, X_column_names)
        X_eng_column_names = np.empty(0)
        if self._data_preprocessor.is_sparse:
            if self._preprocess:
                X_numeric = self._data_preprocessor.convert_X_to_numeric_sparse(X_filtered)
                X_eng_column_names = X_filtered_column_names
            else:
                X_numeric, y_numeric = feature_selection_utilities.validate_no_nan_sparse(X_filtered, y_numeric)
        else:
            X_filtered_df = pd.DataFrame(X_filtered, columns=X_filtered_column_names)
            if self._preprocess:
                X_numeric, self._featurizer, is_engineered_mat_sparse = \
                    self._data_preprocessor.convert_X_to_numeric(X_filtered_df)
                X_eng_column_names, self._featurized_raw_feat_name_to_eng_feat_index = \
                    feature_selection_utilities.get_eng_feat_dict(self._featurizer)
                # _convert_X_to_numeric() may drop features
                # List of features types that are dropped and not featurized: {Hashes, Ignore, AllNan}
                # TODO check if we can get dropped columns from featurizer directly
                X_featurized_raw_column_names = np.array(list(self._featurized_raw_feat_name_to_eng_feat_index.keys()))
                dropped_cols = np.setdiff1d(X_filtered_column_names, X_featurized_raw_column_names)
                cols_to_drop_indices.extend([np.where(X_column_names == n)[0][0] for n in dropped_cols])

                if not is_engineered_mat_sparse:
                    X_numeric = np.asarray(X_numeric)
            else:
                X_filtered_df[self._target_name] = y_numeric
                df_numeric = self._data_preprocessor.validate_no_nan(X_filtered_df)
                X_numeric = df_numeric.drop(columns=[self._target_name]).values
        return X_numeric, y_numeric, X_eng_column_names, cols_to_drop_indices

    def _filter_cols(self, X, y, X_column_names):
        """
        Filter columns based on missing value and variance thresholds.

        :param X: The input data.
        :type X: numpy.ndarray
        :param y: The target values.
        :type y: numpy.ndarray
        :param X_column_names: The X column names.
        :type X_column_names: numpy.ndarray
        :return: Filtered X, filtered X column names, indices of columns to drop, missing val ratio per column,
        variance per column.
        :rtype: tuple(numpy.ndarray, numpy.ndarray, list, pandas.Series, pandas.Series)
        """
        # 1. non missing/null vals
        # 2. variance
        missing_val_ratio, null_cols_to_drop, var_per_col, no_var_cols_to_drop =  \
            self._calc_missing_val_and_var(X, y, X_column_names, self._target_name, self.missing_val_threshold,
                                           self.variance_threshold)

        # first check if label column is in the cols_to_drop list
        label_index = X.shape[1]
        if label_index in null_cols_to_drop:
            raise ValueError('Missing value in label column exceeds threshold!')

        if label_index in no_var_cols_to_drop:
            unique, counts = np.unique(y, return_counts=True)
            counts_percent = np.asarray((unique, counts / y.shape[0] * 100))
            max_occur = counts_percent[1].max()
            max_occur_label_val = counts_percent[counts_percent[1].argmax()][0]
            log_msg(self._logger, logging.WARNING, 'Labels are very unbalanced! {0}% labels have the '
                                                   'same value = {1}. Please consider adding more under-represented '
                                                   'labels.'.format(max_occur, max_occur_label_val))
            no_var_cols_to_drop.remove(label_index)

        cols_to_drop = list(set(null_cols_to_drop) | set(no_var_cols_to_drop))
        if len(null_cols_to_drop) != 0:
            log_msg(self._logger, logging.info,
                    'Columns {0} are dropped due to exceeding missing value threshold!'.format(null_cols_to_drop))
        if len(no_var_cols_to_drop) != 0:
            log_msg(self._logger, logging.info,
                    'Columns {0} are dropped due to hitting variance threshold!'.format(no_var_cols_to_drop))

        mask = np.full(X.shape[1], True, dtype=bool)
        mask[cols_to_drop] = False
        return X[:, mask], X_column_names[mask], cols_to_drop, missing_val_ratio, var_per_col

    @function_log_activity
    def _calc_scores(self, X, y, X_column_names, keep_original_order=True):
        """
        Calculate feature scores given X, y.

        :param X: The input data.
        :type X: numpy.ndarray or scipy.sparse.csr_matrix
        :param y: The target values.
        :type y: numpy.ndarray
        :param X_column_names: The X column names.
        :type X_column_names: numpy.ndarray
        :param keep_original_order: whether to sort based on combined feature importance score.
        :type keep_original_order: bool
        :return: raw feature scoring matrix, eng feature scoring matrix.
        :rtype: tuple(pandas.DataFrame, pandas.DataFrame)
        """
        # stats after numeric transform
        # model agnostic evaluation
        # 1. non missing/null vals
        # 2. variance
        missing_val_ratio_eng, null_cols_to_drop_eng, var_per_col_eng, no_var_cols_to_drop = \
            self._calc_missing_val_and_var(X, y, X_column_names, self._target_name, self.missing_val_threshold,
                                           self.variance_threshold, calc_missing=False)
        # 3. mutual information
        mutual_info_matrix = pd.DataFrame()
        if constants.MUTUAL_INFO in self._methods:
            mutual_info_matrix = feature_selection_utilities.get_mutual_info_pair(X, y, X_column_names, bins=10)
        # 4. pearson-correlation
        pearson_corr = pd.DataFrame()
        if constants.PEARSON_CORR in self._methods:
            pearson_corr = feature_selection_utilities.get_pearson_corr(X, y, X_column_names, self._target_name)

        # normalize raw data before applying model based feature selection methods
        X_normalized = feature_selection_utilities.normalize_cols(X)
        # model based evaluation
        # 5. lightGBM
        lightGBM_feat_importance = pd.DataFrame()
        if constants.LIGHTGBM in self._methods:
            _, lightGBM_feat_importance = \
                feature_selection_utilities.get_feat_importance_from_lightgbm(X_normalized, y, X_column_names,
                                                                              self._task_type)
        # 6. Linear SVC
        lasso_feat_importance = pd.DataFrame()
        if constants.LASSO in self._methods:
            lasso_feat_importance = \
                feature_selection_utilities.get_feat_importance_from_lasso(X_normalized, y, X_column_names,
                                                                           self._task_type)

        # in our final matrix, do not use missing_val_ratio, but rather 1-missing_val_ratio
        # do this because for every other metric, closer to 0 is bad and closer to 1 is good, so keep it consistent
        self._raw_scoring, self._eng_scoring = self._build_feature_scoring_matrix(self._missing_val_ratio,
                                                                                  self._variance,
                                                                                  missing_val_ratio_eng,
                                                                                  var_per_col_eng, mutual_info_matrix,
                                                                                  pearson_corr,
                                                                                  lightGBM_feat_importance,
                                                                                  lasso_feat_importance,
                                                                                  keep_original_order)
        return self._raw_scoring, self._eng_scoring

    def _get_raw_scores(self, eng_scoring):
        """
        Map engineered feature scores back to raw feature scores.

        :param eng_scoring: eng feature scoring matrix
        :type eng_scoring: pandas.DataFrame
        :return: raw mutual info, raw pearson correlation, raw lightgbm, raw lasso, raw combined feature importance
        scores.
        :rtype: tuple(pandas.DataFrame, pandas.DataFrame, pandas.DataFrame, pandas.DataFrame, pandas.DataFrame)
        """
        featurized_raw_feat_names, self._featurized_raw_feat_index_to_eng_feat_indices = \
            feature_selection_utilities.get_featurized_raw_feat_index_to_eng_feat_indices_list(
                self._featurized_raw_feat_name_to_eng_feat_index)

        # sharing generated features by raw features is not supported
        # TODO revisit after graph based featurization is enabled
        sets = [set(i) for i in self._featurized_raw_feat_index_to_eng_feat_indices]
        # check whether any pair shares any items
        for i in range(len(sets) - 1):
            for j in range(i + 1, len(sets)):
                if len(sets[i].intersection(sets[j])):
                    raise ValueError('raw features cannot share engineered feature indices')

        def f(x, agg_func, **kwargs):
            raw_scores = []
            for feature_indices in self._featurized_raw_feat_index_to_eng_feat_indices:
                raw_scores.append(agg_func(x[feature_indices], **kwargs))

            return raw_scores

        raw_pearson_pd = pd.DataFrame()
        if constants.PEARSON_CORR in self._methods:
            raw_pearson = np.apply_along_axis(f, -1, eng_scoring[constants.PEARSON_CORR].fillna(0).values,
                                              agg_func=max, key=abs)
            raw_pearson_pd = pd.to_numeric(pd.Series(data=raw_pearson, index=featurized_raw_feat_names))

        raw_mutual_info_pd = pd.DataFrame()
        if constants.MUTUAL_INFO in self._methods:
            raw_mutual_info = np.apply_along_axis(f, -1, eng_scoring[constants.MUTUAL_INFO].values, max)
            raw_mutual_info_pd = pd.to_numeric(pd.Series(data=raw_mutual_info, index=featurized_raw_feat_names))

        raw_lightgbm_pd = pd.DataFrame()
        if constants.LIGHTGBM in self._methods:
            raw_lightgbm = np.apply_along_axis(f, -1, eng_scoring[constants.LIGHTGBM_IMPORTANCE].values,
                                               sum)
            raw_lightgbm_pd = pd.to_numeric(pd.Series(data=raw_lightgbm, index=featurized_raw_feat_names))

        raw_lasso_pd = pd.DataFrame()
        if constants.LASSO in self._methods:
            raw_lasso = np.apply_along_axis(f, -1, eng_scoring[constants.LASSO_IMPORTANCE].values, sum)
            raw_lasso_pd = pd.to_numeric(pd.Series(data=raw_lasso, index=featurized_raw_feat_names))

        raw_feat_imp = np.apply_along_axis(f, -1, eng_scoring[constants.FEATURE_IMPORTANCE].values, sum)
        raw_feat_imp_pd = pd.to_numeric(pd.Series(data=raw_feat_imp, index=featurized_raw_feat_names))

        return raw_mutual_info_pd, raw_pearson_pd, raw_lightgbm_pd, raw_lasso_pd, raw_feat_imp_pd

    def _build_feature_scoring_matrix(self, missing_val_ratio, variance, missing_val_ratio_eng, variance_eng,
                                      mutual_info_matrix, pearson,
                                      lightgbm_score, lasso_score, keep_original_order=False):
        """
        Build feature scoring matrix.

        :param missing_val_ratio: missing value ratio per raw feature.
        :type missing_val_ratio: pandas.Series
        :param variance: variance per raw feature.
        :type variance: pandas.Series
        :param missing_val_ratio_eng: missing value ratio per eng feature.
        :type missing_val_ratio_eng: pandas.Series
        :param variance_eng: variance per eng feature.
        :type variance_eng: pandas.Series
        :param mutual_info_matrix: mutual information between each feature and target.
        :type mutual_info_matrix: pandas.Series
        :param pearson: pearson correlation between each feature and target.
        :type pearson: pandas.Series
        :param lightgbm_score: lightgbm feature importance per feature.
        :type lightgbm_score: pandas.Series
        :param lasso_score: lasso feature importance per feature.
        :type lasso_score: pandas.Series
        :param keep_original_order: whether to sort based on combined feature importance score.
        :type keep_original_order: bool
        :return: raw feature scoring matrix, eng feature scoring matrix.
        :rtype: tuple(pandas.DataFrame, pandas.DataFrame)
        """
        if self._preprocess:
            eng_score_matrix = pd.DataFrame()
            # convert missing_val_ratio to 1-, rename to non_null_ratio
            eng_score_matrix[constants.NON_NULL_RATIO] = 1 - missing_val_ratio_eng.loc[
                missing_val_ratio_eng.index != self._target_name]
            eng_score_matrix[constants.VARIANCE] = variance_eng.loc[variance_eng.index != self._target_name]
            if not mutual_info_matrix.empty:
                eng_score_matrix[constants.MUTUAL_INFO] = mutual_info_matrix
            if not pearson.empty:
                eng_score_matrix[constants.PEARSON_CORR] = pearson.loc[pearson.index != self._target_name]
            if not lightgbm_score.empty:
                eng_score_matrix[constants.LIGHTGBM_IMPORTANCE] = lightgbm_score
            if not lasso_score.empty:
                eng_score_matrix[constants.LASSO_IMPORTANCE] = lasso_score
            # return of _calc_final_feature_importance is not sorted otherwise the raw feature to eng feature
            # mapping is wrong
            eng_scoring = self._calc_final_feature_importance(eng_score_matrix)

            raw_score_matrix = pd.DataFrame()
            # convert missing_val_ratio to 1-, rename to non_null_ratio
            raw_score_matrix[constants.NON_NULL_RATIO] = 1 - missing_val_ratio.loc[
                missing_val_ratio.index != self._target_name]
            raw_score_matrix[constants.VARIANCE] = variance.loc[variance.index != self._target_name]

            if not self._data_preprocessor.is_sparse:
                mutual_info_score, pearson, lightgbm_score, lasso_score, feat_importance = \
                    self._get_raw_scores(eng_scoring)
                if not mutual_info_score.empty:
                    raw_score_matrix[constants.MUTUAL_INFO] = mutual_info_score
                if not pearson.empty:
                    raw_score_matrix[constants.PEARSON_CORR] = pearson
                if not lightgbm_score.empty:
                    raw_score_matrix[constants.LIGHTGBM_IMPORTANCE] = lightgbm_score
                if not lasso_score.empty:
                    raw_score_matrix[constants.LASSO_IMPORTANCE] = lasso_score
                raw_score_matrix[constants.FEATURE_IMPORTANCE] = feat_importance
            else:
                raw_score_matrix = eng_scoring

            if not keep_original_order:
                # sort by feature importance
                raw_scoring = raw_score_matrix.sort_values(by=[constants.FEATURE_IMPORTANCE], ascending=False)
                eng_scoring = eng_scoring.sort_values(by=[constants.FEATURE_IMPORTANCE], ascending=False)
            else:
                raw_scoring = raw_score_matrix
            eng_scoring = feature_selection_utilities.zero_max_normalize(eng_scoring, [constants.FEATURE_IMPORTANCE],
                                                                         feature_range=(0, 100))
        else:
            raw_score_matrix = pd.DataFrame()
            # convert missing_val_ratio to 1-, rename to non_null_ratio
            raw_score_matrix[constants.NON_NULL_RATIO] = 1 - missing_val_ratio.loc[
                missing_val_ratio.index != self._target_name]
            raw_score_matrix[constants.VARIANCE] = variance.loc[variance.index != self._target_name]
            if not mutual_info_matrix.empty:
                raw_score_matrix[constants.MUTUAL_INFO] = mutual_info_matrix
            if not pearson.empty:
                raw_score_matrix[constants.PEARSON_CORR] = pearson.loc[pearson.index != self._target_name]
            if not lightgbm_score.empty:
                raw_score_matrix[constants.LIGHTGBM_IMPORTANCE] = lightgbm_score
            if not lasso_score.empty:
                raw_score_matrix[constants.LASSO_IMPORTANCE] = lasso_score
            raw_scoring = self._calc_final_feature_importance(raw_score_matrix)
            if not keep_original_order:
                # sort by feature importance
                raw_scoring = raw_scoring.sort_values(by=[constants.FEATURE_IMPORTANCE], ascending=False)

        raw_scoring = feature_selection_utilities.zero_max_normalize(raw_scoring, [constants.FEATURE_IMPORTANCE],
                                                                     feature_range=(0, 100))

        return raw_scoring, eng_scoring if self._preprocess else pd.DataFrame()

    def _calc_final_feature_importance(self, df):
        """
        Calcuate combined feature importance given various feature scores.

        :param df: The feature importance scoring matrix.
        :type df: pandas.DataFrame
        :return: The feature importance scoring matrix with combined feature importance.
        :rtype: pandas.DataFrame
        """
        df_no_nan_abs = df.fillna(0).abs()
        fs_methods_mapping = {constants.MUTUAL_INFO: constants.MUTUAL_INFO,
                              constants.PEARSON_CORR: constants.PEARSON_CORR,
                              constants.LIGHTGBM: constants.LIGHTGBM_IMPORTANCE,
                              constants.LASSO: constants.LASSO_IMPORTANCE}
        cols_to_normalize = [fs_methods_mapping[x] for x in self._methods]
        df_no_nan_abs = feature_selection_utilities.min_max_normalize(df_no_nan_abs, cols_to_normalize)
        fs_weights = {constants.MUTUAL_INFO: self.mutual_info_weight, constants.PEARSON_CORR: self.pearson_weight,
                      constants.LIGHTGBM: self.lightgbm_weight, constants.LASSO: self.lasso_weight}

        def agg_func(row):
            res = 0
            for x in self._methods:
                res += fs_weights[x] * row[fs_methods_mapping[x]]
            return res

        df[constants.FEATURE_IMPORTANCE] = df_no_nan_abs.apply(agg_func, axis=1)
        return df

    def _calc_missing_val_and_var(self, X, y, X_column_names, target, missing_val_threshold, variance_threshold,
                                  calc_missing=True):
        """
        Calculate missing value ratio and variance per column.

        :param X: The input data.
        :type X: numpy.ndarray or scipy.sparse.csr_matrix
        :param y: The target values.
        :type y: numpy.ndarray
        :param X_column_names: The X column names.
        :type X_column_names: numpy.ndarray
        :param target: label column name.
        :type target: str
        :param missing_val_threshold: if number of missing value exceeds the threshold, drop the column.
        :type missing_val_threshold: float or None
        :param variance_threshold: if variance falls below the threshold, drop the column.
        :type variance_threshold: float or None
        :param calc_missing: whether to calculate missing value ratio.
        :type calc_missing: bool
        :return: missing value ratio per feature, column indices to drop due to missing value threshold, variance per
        feature, column indices to drop due to variance threshold.
        :rtype: tuple(pandas.Series, list of ints, pandas.Series, list of ints)
        """
        # 1. non missing/null vals
        if calc_missing:
            missing_val_ratio, null_cols_to_drop = \
                feature_selection_utilities.calc_and_return_null_cols_to_drop(X, y, X_column_names, target,
                                                                              missing_val_threshold)
        else:
            X_y_column_names = np.append(X_column_names, target)
            missing_val_ratio = pd.Series([float(x) for x in [0] * (X.shape[1] + 1)], index=X_y_column_names)
            null_cols_to_drop = []
        # 2. variance
        var_per_col, no_var_cols_to_drop = \
            self._calc_and_return_no_variance_cols_to_drop(X, y, X_column_names, target, variance_threshold)
        return missing_val_ratio, null_cols_to_drop, var_per_col, no_var_cols_to_drop

    def _calc_and_return_no_variance_cols_to_drop(self, X, y, X_column_names, target, threshold):
        """
        Calculate variance per feature and list of column indices to drop.

        :param X: The input data.
        :type X: numpy.ndarray or scipy.sparse.csr_matrix
        :param y: The target values.
        :type y: numpy.ndarray
        :param X_column_names: The X column names.
        :type X_column_names: numpy.ndarray
        :param target: label column name.
        :type target: str
        :param threshold: if variance falls below the threshold, drop the column.
        :type threshold: float
        :return: variance per feature, column indices to drop.
        :rtype: tuple(pandas.Series, list of ints)
        """
        if isinstance(X, sp.csr_matrix):
            # VarianceThreshold fails when there is nan in sparse matrix
            X_numeric = self._data_preprocessor.convert_X_to_numeric_sparse(X)
            X_y, X_y_column_names = feature_selection_utilities.to_X_y_sparse(X_numeric, y, X_column_names, target)
            selector = VarianceThreshold(threshold)
            selector.fit(X_y)
            variances = selector.variances_
            var_per_col = pd.Series(variances, index=X_y_column_names)
            X_y_column_indices = np.arange(X_y_column_names.shape[0])
            cols_to_drop_indices = X_y_column_indices[~selector.get_support()].tolist()
        else:
            df = feature_selection_utilities.to_X_y_df(X, y, X_column_names, target)
            var_per_col = df.var(ddof=0)
            cols_to_drop = var_per_col.loc[var_per_col < threshold].index.tolist()
            cols_to_drop.extend(var_per_col[var_per_col.isnull()].index.tolist())
            cols_to_drop_indices = [df.columns.get_loc(c) for c in cols_to_drop if c in df]
        return var_per_col, cols_to_drop_indices
