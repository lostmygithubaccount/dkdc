# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Class to hold feature configuration."""
import logging
from typing import Any, Optional, Dict
from operator import itemgetter

from azureml.contrib.featureengineering.core.constants import TimeSeries, TimeSeriesInternal
from azureml.contrib.featureengineering.featurizer import TimeSeriesFeatureType


class FeaturizerConfig:
    """Class to hold featurizer configuration."""

    def __init__(self,
                 enable_general_transform: bool = True,
                 enable_timeseries_transform: bool = False,
                 enable_dataframe_output: bool = True,
                 **kwargs: Any
                 ):
        """
        Initialize all attributes.

        :param enable_general_transform: Flag whether Featurizer should use general transformation strategies
        :type enable_general_transform: bool
        :param enable_timeseries_transform: Flag whether Featurizer should use time series transformation strategies
        :type enable_timeseries_transform: bool
        :param enable_dataframe_output: Flag whether output as DataFrame
        :type enable_dataframe_output: bool
        :param kwargs: dictionary containing metadata for TimeSeries.
        :type kwargs: dict
        """
        self.enable_general_transform = enable_general_transform
        self.enable_timeseries_transform = enable_timeseries_transform
        self.enable_dataframe_output = enable_dataframe_output
        self._ts_keys_members = {}
        self._ts_keys = [
            TimeSeries.TIME_COLUMN_NAME,
            TimeSeries.GRAIN_COLUMN_NAMES,
            TimeSeries.DROP_COLUMN_NAMES,
            TimeSeries.MAX_HORIZON,
            TimeSeriesInternal.DROP_NA,
            TimeSeriesInternal.OVERWRITE_COLUMNS,
            TimeSeriesInternal.TRANSFORM_DICT,
            TimeSeriesInternal.WINDOW_SIZE,
            TimeSeries.COUNTRY_OR_REGION,
            TimeSeries.TARGET_LAGS,
            TimeSeries.SEASONALITY,
            TimeSeries.USE_STL,
            TimeSeriesInternal.LAGS_TO_CONSTRUCT
        ]
        self.set_from_timeseries_dict(kwargs)

    def _verify_settings(self, time_series_dict: Dict[str, str]):
        """
        Verify that input configuration settings are sensible.

        :param time_series_dict: the time series settings.
        :return:
        :rtype: None
        """
        if self.enable_timeseries_transform and \
                (TimeSeries.TIME_COLUMN_NAME not in self._ts_keys_members or
                 self._ts_keys_members[TimeSeries.TIME_COLUMN_NAME] is None):
            raise ValueError('Timeseries need to set time column.')

        # For backward compatible, keep country for a while
        # TODO: remove support for country parameter
        if "country" in time_series_dict:
            logging.warning("Parameter 'country' will be deprecated. Use 'country_or_region'")
            self._ts_keys_members[TimeSeries.COUNTRY_OR_REGION] = time_series_dict["country"]

    def get_ts_params_dict(self) -> Optional[Dict[str, str]]:
        """
        Get time series parameter data.

        Arguments:
            featurizer_config {FeaturizerConfig} -- Featurizer configuration object

        :return: dict -- a dictionary of time series data info

        """
        return self._ts_keys_members

    def set_from_timeseries_dict(self, time_series_dict: Dict[str, str]):
        """Set time series config from dictionary.

        :param time_series_dict: the time series settings.
        """
        if self.enable_timeseries_transform:
            for key, value in time_series_dict.items():
                if key in self._ts_keys:
                    self._ts_keys_members[key] = value
                else:
                    logging.warning("Received unrecognized parameter: {0} {1}".format(key, value))
                    setattr(self, key, value)

        # to handle a special case for timeseries LAGS_TO_CONSTRUCT, since it depends on the value
        # of TimeSeries.TARGET_LAGS, if it is None, the LAGS_TO_CONSTRUCT should also be None.
        if TimeSeries.TARGET_LAGS in self._ts_keys_members and \
                self._ts_keys_members[TimeSeries.TARGET_LAGS] is not None:
            target_lags = int(self._ts_keys_members[TimeSeries.TARGET_LAGS])
            if target_lags < 1 or target_lags > TimeSeriesInternal.MAX_LAG_LENGTH:
                raise ValueError("The {} must be between 1 and {} inclusive."
                                 .format(TimeSeries.TARGET_LAGS, TimeSeriesInternal.MAX_LAG_LENGTH))
            self._ts_keys_members[TimeSeriesInternal.LAGS_TO_CONSTRUCT] =\
                {TimeSeriesInternal.DUMMY_TARGET_COLUMN: target_lags}

        self._verify_settings(time_series_dict)

    def get_ts_columns(self):
        """Get time series column list.

        :return: list of column names that belongs to time series column
        """
        ts_columns = []
        if self._ts_keys_members[TimeSeries.TIME_COLUMN_NAME] is not None:
            ts_columns.append((self._ts_keys_members[TimeSeries.TIME_COLUMN_NAME], TimeSeriesFeatureType.Time))
        if self._ts_keys_members.get(TimeSeries.GRAIN_COLUMN_NAMES) is not None:
            ts_columns.extend(self._get_types_from_list(self._ts_keys_members[TimeSeries.GRAIN_COLUMN_NAMES],
                                                        TimeSeriesFeatureType.Grain,
                                                        ts_columns))
        if self._ts_keys_members.get(TimeSeries.DROP_COLUMN_NAMES) is not None:
            ts_columns.extend(self._get_types_from_list(self._ts_keys_members[TimeSeries.DROP_COLUMN_NAMES],
                                                        TimeSeriesFeatureType.Drop,
                                                        ts_columns))
        if self._ts_keys_members.get(TimeSeriesInternal.TRANSFORM_DICT) is not None:
            ts_columns.extend(self._get_types_from_dict(self._ts_keys_members[TimeSeriesInternal.TRANSFORM_DICT],
                                                        TimeSeriesFeatureType.Transform,
                                                        ts_columns,
                                                        False))
        if self._ts_keys_members.get(TimeSeriesInternal.LAGS_TO_CONSTRUCT) is not None:
            ts_columns.extend(self._get_types_from_dict(self._ts_keys_members[TimeSeriesInternal.LAGS_TO_CONSTRUCT],
                                                        TimeSeriesFeatureType.Transform,
                                                        ts_columns,
                                                        True))

        return ts_columns

    def is_timeseries_transform_enabled(self):
        """
        Get whether time series transformer is enabled or not.

        :return: the enable_timeseries_transform setting.
        """
        return self.enable_timeseries_transform

    def set_timeseries_transform_enabled_flag(self, enable_timeseries_transform: bool):
        """
        Set time series enable transformer flag.

        :param enable_timeseries_transform: whether to enable time series transformer.
        """
        self.enable_timeseries_transform = enable_timeseries_transform

    def _get_types_from_list(self, ts_item, ts_type, ts_columns):
        temp_columns = []
        # could be string or list
        if isinstance(ts_item, str):
            if ts_item not in map(itemgetter(0), ts_columns):
                temp_columns.append((ts_item, ts_type))
        else:
            for col_name in ts_item:
                if col_name not in map(itemgetter(0), ts_columns):
                    temp_columns.append((col_name, ts_type))
        return list(set(temp_columns))

    def _get_types_from_dict(self, ts_dict, ts_type, ts_columns, is_col_in_key):
        temp_columns = []
        # dict containing either string or list of strings
        for key, value in ts_dict.items():
            if is_col_in_key:
                col_name = key
            else:
                col_name = value
            if isinstance(col_name, str):
                col_list = [col_name]
            else:
                col_list = col_name
            for name in col_list:
                if name not in map(itemgetter(0), ts_columns):
                    temp_columns.append((name, ts_type))
        return list(set(temp_columns))
