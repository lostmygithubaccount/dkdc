# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""ImputationMarker operator converter."""
import numbers
import numpy as np
import six

# Import skl2onnx modules.
from sklearn.base import BaseEstimator, ClassifierMixin

from skl2onnx.proto import onnx_proto
from skl2onnx.common.data_types import FloatTensorType
from skl2onnx.common.data_types import StringTensorType

from skl2onnx.common._apply_operation import apply_cast
from skl2onnx.common.utils import check_input_and_output_numbers
from skl2onnx import update_registered_converter

# AutoML modules.
from azureml.contrib.featureengineering.core.exceptions import OnnxConvertException

from ..onnx_convert_constants import OnnxConvertConstants
from ._abstract_operator_converter import _AbstractOperatorConverter


class _YTransformLabelEncoder(BaseEstimator, ClassifierMixin):
    """
    Virtual operator for converting the y transformer LabelEncoder.

    Containing the actual label encoder to do the y transform.
    This class is used by convert the y transformers.
    Since the object of this class needs to be put into last step of
    the reconstructed pipeline, it inherits the BaseEstimator and ClassifierMixin.
    But it's a dummy estimator, and only used for onnx conversion.
    """

    def __init__(self, le):
        """
        Construct the Virtual operator.

        :param le: The raw original operator.
        """
        self.label_encoder = le


class YTransformerLabelEncoderConverter(_AbstractOperatorConverter):
    """Y Transformer LabelEncoder operator converter."""

    def __init__(self):
        """Construct the Y Transformer LabelEncoder operator converter."""
        type(self).OPERATOR_ALIAS = 'AutoMLYTransLabelEncoder'

    def setup(self):
        """Set up the converter."""
        update_registered_converter(_YTransformLabelEncoder,
                                    YTransformerLabelEncoderConverter.OPERATOR_ALIAS,
                                    YTransformerLabelEncoderConverter._calc_y_trans_labelencoder_output_shapes,
                                    YTransformerLabelEncoderConverter._convert_automl_y_trans_labelencoder)

    @staticmethod
    def _calc_y_trans_labelencoder_output_shapes(operator):
        # All inputs and outputs must be float.
        check_input_and_output_numbers(operator, output_count_range=1)

        N = operator.inputs[0].type.shape[0]
        class_labels = operator.raw_operator.classes_
        if all(isinstance(i, np.ndarray) for i in class_labels):
            class_labels = np.concatenate(class_labels)

        if all(isinstance(i, np.ndarray) for i in class_labels):
            class_labels = np.concatenate(class_labels)
        if all(isinstance(i, (six.string_types, six.text_type)) for i in class_labels):
            operator.outputs[0].type = StringTensorType(shape=[N])
        elif all(isinstance(i, (numbers.Real)) for i in class_labels):
            operator.outputs[0].type = FloatTensorType(shape=[N])
        else:
            raise OnnxConvertException('Unsupported or mixed label types')

    @staticmethod
    def _convert_automl_y_trans_labelencoder(scope, operator, container):
        op = operator.raw_operator
        op_type = OnnxConvertConstants.LabelEncoder
        attrs = {'name': scope.get_unique_operator_name(op_type)}
        attrs['classes_strings'] = [str(c) for c in op.classes_]
        attrs['default_string'] = '__unknown__'

        # By default this label encoder output is string type, cast to float if needed.
        need_cast = False
        if isinstance(operator.outputs[0].type, StringTensorType):
            lbl_out = operator.output_full_names
        else:
            lbl_out = scope.get_unique_variable_name('lbl_out')
            need_cast = True
        container.add_node(op_type, operator.input_full_names,
                           lbl_out, op_domain=OnnxConvertConstants.OnnxMLDomain,
                           **attrs)
        if need_cast:
            apply_cast(scope, lbl_out, operator.output_full_names, container, to=onnx_proto.TensorProto.FLOAT)
