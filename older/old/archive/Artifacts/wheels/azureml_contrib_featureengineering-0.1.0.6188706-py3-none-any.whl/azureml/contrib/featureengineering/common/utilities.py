# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Utility methods."""
import os
import pickle
from io import BytesIO
from typing import Dict

import azureml.dataprep as dprep
import numpy as np
import pandas as pd
from azureml.core import Dataset
from azureml.data.dataset_definition import DatasetDefinition
from azureml.dataprep.api.dataflow import Dataflow
from azureml.dataprep.api.step import Step
from azureml.dataprep.api.typeconversions import InferenceInfo


def check_pickleable(obj):
    """Check whether an object is pickleable.

    :param obj: A python object.
    :type obj: Object
    :return: True if object is pickleable, otherwise, False.
    :rtype: bool
    :raise: Exception
    """
    try:
        with BytesIO() as f:
            pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)
        return True
    except Exception:
        return False


def read_files(file_path: str):
    """
    Read str from a given file path.

    :param file_path: A file path, location to a file.
    :type file_path: str
    :return: Content of a file in a string.
    :rtype: str
    :raise: ValueError
    """
    exists = os.path.isfile(file_path)
    if exists:
        file = open(file_path, "rb")
        return file.read().decode()
    else:
        raise ValueError("File path does not exists, path: {}".format(file_path))


def save_files(content, file_path: str):
    """
    Override content in a file.

    :param content: content in string format.
    :type content: str
    :param file_path: A file path, location to a file.
    :type file_path: str
    """
    file = open(file_path, 'w')
    file.write(content)
    file.close()


def load_pickle(file_path):
    """
    Unpickle the file.

    :param path: The file path used by the pickler.
    :return: The unpickled object.
    """
    try:
        with open(file_path, "rb") as f:
            return pickle.load(f)
    except Exception as e:
        raise Exception("UnPickle error {}".format(e))


def save_pickle(obj, file_path):
    """
    Dump the object to a file.

    :param obj: The object to pickle.
    :param path: The path the pickler will use.
    :return: The path.
    """
    try:
        with open(file_path, "wb") as f:
            pickle.dump(obj, f)
    except Exception as e:
        raise Exception("Pickle error {}".format(e))
    return file_path


def check_input(df) -> None:
    """
    Check inputs for transformations.

    :param df: Input dataframe.
    :return:
    """
    # Raise an exception if the input is not a data frame or array
    if not isinstance(df, pd.DataFrame) and not isinstance(df, np.ndarray) \
            and not isinstance(df, Dataflow) and not isinstance(df, Dataset):
        raise ValueError("df should be a pandas DataFrame, numpy array, Dataflow or DataSet.")


def generate_dataflow(data):
    """
    Create a dataflow object from Dataflow, DataSet, DataFrame or ndarray.

    :param data: input data that will be converted to Dataflow.
    :type data: numpy.Ndarray, pandas.Dataframe or Dataflow
    :return: A DataFlow object.
    :rtype: DataFlow or DatasetDefinition
    :raise: ValueError
    """
    if isinstance(data, dprep.Dataflow) or isinstance(data, DatasetDefinition):
        return data
    if isinstance(data, Dataset):
        return data.get_definition()
    if isinstance(data, pd.DataFrame):
        return dprep.read_pandas_dataframe(generate_new_column_names(data), in_memory=True)
    elif isinstance(data, np.ndarray):
        return dprep.read_pandas_dataframe(generate_new_column_names(pd.DataFrame(data)), in_memory=True)
    else:
        raise ValueError("Error: input data must be Dataflow object or pandas DataFrame.")


def proceed_dataflow_type_conversion(dataflow):
    """
    Get learned conversion candidate which will be used for type conversion.

    :param dataflow: A DataFlow object.
    :type dataflow: Dataflow
    :return: A dictionary of inference info.
    :rtype: Dict[str, InferenceInfo]
    :raise: ValueError
    """
    if isinstance(dataflow, dprep.Dataflow) or isinstance(dataflow, DatasetDefinition):
        builder = dataflow.builders.set_column_types()
        builder.learn()
        builder.ambiguous_date_conversions_drop()
        return builder.to_dataflow()
    else:
        raise ValueError("Error: input data must be Dataflow object.")


def convert_dataflow_with_conversion_step(dataflow, conversion_step: Step):
    """
    Convert DataFlow data type using provided conversion candidates.

    :param dataflow: A DataFlow object.
    :type dataflow: Dataflow
    :param conversion_candidates: A DataFlow object.
    :type conversion_candidates: Dict[str, InferenceInfo]
    :return: A new dataflow with inferred type.
    :rtype: Dict[str, InferenceInfo]
    :raise: ValueError
    """
    if isinstance(dataflow, dprep.Dataflow) or isinstance(dataflow, DatasetDefinition):
        dataflow._steps.append(conversion_step)
        return dataflow
    else:
        raise ValueError("Error: input data must be Dataflow object.")


def generate_new_column_names(df):
    """
    Generate new column name if column name is numpy integer.

    :param df: A pandas DataFrame object.
    :type df: Pandas.DataFrame
    :return: A pandas DataFrame object with string column names.
    :rtype: Pandas.DataFrame
    """
    df.rename(columns=lambda x: 'C{0}'.format(x) if isinstance(x, (int, np.integer)) else x,
              inplace=True)
    return df
